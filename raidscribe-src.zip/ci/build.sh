#!/bin/bash
# Builds the APK (run by .github/workflows/build.yml after raidscribe-src.zip is unpacked)
set -e
mkdir -p test
exec > >(tee test/build.log) 2>&1   # saved with the results, so a failed build can be read from the repo
export VERSION_NAME="$(tr -d '[:space:]' < VERSION)"   # the version people see (VERSION file); VERSION_CODE is the build number
echo "== Raidscribe $VERSION_NAME, build ${VERSION_CODE:-?}"
python test/engine_test.py
gradle --no-daemon --stacktrace assembleRelease
mkdir -p out
cp app/build/outputs/apk/release/app-release.apk out/Raidscribe.apk
ls -la out
