#!/bin/bash
# Builds the APK (run by .github/workflows/build.yml after raidscribe-src.zip is unpacked)
set -e
mkdir -p test
exec > >(tee test/build.log) 2>&1   # saved with the results, so a failed build can be read from the repo
export VERSION_NAME="$(tr -d '[:space:]' < VERSION)"   # the version people see (VERSION file); VERSION_CODE is the build number
echo "== Raidscribe $VERSION_NAME, build ${VERSION_CODE:-?}"
python test/engine_test.py
# the signing key comes from the repository's private secrets, never from the repo itself
if [ -z "$KEYSTORE_B64" ] || [ -z "$RAIDSCRIBE_KEYSTORE_PASSWORD" ]; then
  echo "!! The signing key secrets aren't set. In the repo: Settings > Secrets and variables > Actions >"
  echo "!! New repository secret: RAIDSCRIBE_KEYSTORE and RAIDSCRIBE_KEYSTORE_PASSWORD."
  exit 1
fi
export RAIDSCRIBE_KEYSTORE_FILE="${RUNNER_TEMP:-/tmp}/raidscribe-release.jks"
# copying a long line on a phone can add line breaks or spaces: none of them belong in either secret
export RAIDSCRIBE_KEYSTORE_PASSWORD="$(printf '%s' "$RAIDSCRIBE_KEYSTORE_PASSWORD" | tr -d '[:space:]')"
KEY64="$(printf '%s' "$KEYSTORE_B64" | tr -d '[:space:]')"
echo "signing key secret: ${#KEY64} characters (expected 1384), password: ${#RAIDSCRIBE_KEYSTORE_PASSWORD} characters (expected 32)"
if [ "${#KEY64}" -lt 1384 ]; then
  echo "!! The RAIDSCRIBE_KEYSTORE secret is cut short: ${#KEY64} of its 1384 characters. Part of it was lost when it was copied."
  echo "!! Edit the secret and paste the whole long line again (copying on a computer is safest)."
  exit 1
fi
if ! printf '%s' "$KEY64" | base64 -d > "$RAIDSCRIBE_KEYSTORE_FILE" 2>/dev/null; then
  BAD="$(printf '%s' "$KEY64" | tr -d 'A-Za-z0-9+/=' | head -c 20)"
  echo "!! The RAIDSCRIBE_KEYSTORE secret isn't a clean copy of the key: it has characters that don't belong (${#BAD} found)."
  echo "!! Edit the secret and paste only the long line from raidscribe-signing-secrets.txt: nothing before or after it."
  exit 1
fi
if ! keytool -list -keystore "$RAIDSCRIBE_KEYSTORE_FILE" -storepass "$RAIDSCRIBE_KEYSTORE_PASSWORD" -alias raidscribe >/dev/null 2>&1; then
  echo "!! The key and the password don't go together: check RAIDSCRIBE_KEYSTORE_PASSWORD (32 letters and numbers),"
  echo "!! and that RAIDSCRIBE_KEYSTORE is the whole long line."
  exit 1
fi
# it must be exactly the Raidscribe key, or the new APK won't install over the last one
EXPECTED="2C:B2:21:C5:72:20:24:A5:CD:07:D0:46:5F:F7:03:B3:23:99:FC:37:2E:CA:28:16:EC:F6:C7:77:34:44:D9:32"
GOT="$(keytool -list -v -keystore "$RAIDSCRIBE_KEYSTORE_FILE" -storepass "$RAIDSCRIBE_KEYSTORE_PASSWORD" -alias raidscribe 2>/dev/null | grep -m1 'SHA256:' | awk '{print $2}')"
if [ "$GOT" != "$EXPECTED" ]; then
  echo "!! That's a valid key, but not the Raidscribe key (fingerprint $GOT). Use the one from raidscribe-signing-secrets.txt."
  exit 1
fi
echo "signing key OK: $GOT"
gradle --no-daemon --stacktrace assembleRelease
rm -f "$RAIDSCRIBE_KEYSTORE_FILE"
mkdir -p out
cp app/build/outputs/apk/release/app-release.apk out/Raidscribe.apk
ls -la out
# which key signed it (so a wrong or missing secret shows up here, not on someone's phone)
APKSIGNER=$(ls "$ANDROID_HOME"/build-tools/*/apksigner 2>/dev/null | sort -V | tail -1)
[ -n "$APKSIGNER" ] && "$APKSIGNER" verify --print-certs out/Raidscribe.apk | grep -E "SHA-256|DN" || true
