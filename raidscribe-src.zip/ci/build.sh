#!/bin/bash
# Builds the APK (run by .github/workflows/build.yml after raidscribe-src.zip is unpacked)
set -e
mkdir -p test
exec > >(tee test/build.log) 2>&1   # saved with the results, so a failed build can be read from the repo
export VERSION_NAME="$(tr -d '[:space:]' < VERSION)"   # the version people see (VERSION file); VERSION_CODE is the build number
echo "== Raidscribe $VERSION_NAME, build ${VERSION_CODE:-?}"
python test/engine_test.py
# the signing key comes from the repository's private secrets, never from the repo itself
if [ -z "$KEYSTORE_B64" ] || [ -z "$RAIDSCRIBE_KEYSTORE_PASSWORD" ]; then
  echo "!! The signing key secrets aren't set. In the repo: Settings > Secrets and variables > Actions >"
  echo "!! New repository secret: RAIDSCRIBE_KEYSTORE and RAIDSCRIBE_KEYSTORE_PASSWORD."
  exit 1
fi
export RAIDSCRIBE_KEYSTORE_FILE="${RUNNER_TEMP:-/tmp}/raidscribe-release.jks"
printf '%s' "$KEYSTORE_B64" | base64 -d > "$RAIDSCRIBE_KEYSTORE_FILE"
gradle --no-daemon --stacktrace assembleRelease
rm -f "$RAIDSCRIBE_KEYSTORE_FILE"
mkdir -p out
cp app/build/outputs/apk/release/app-release.apk out/Raidscribe.apk
ls -la out
# which key signed it (so a wrong or missing secret shows up here, not on someone's phone)
APKSIGNER=$(ls "$ANDROID_HOME"/build-tools/*/apksigner 2>/dev/null | sort -V | tail -1)
[ -n "$APKSIGNER" ] && "$APKSIGNER" verify --print-certs out/Raidscribe.apk | grep -E "SHA-256|DN" || true
