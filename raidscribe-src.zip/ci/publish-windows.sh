#!/bin/bash
# Puts the Windows installer, portable zip, screenshots and test logs on the "results-windows" branch
mkdir -p results-win
cp out/Raidscribe-Setup-*.exe out/Raidscribe-*-portable.zip results-win/ 2>/dev/null || true
cp -r test-win/. results-win/ 2>/dev/null || true
echo "build $GITHUB_RUN_NUMBER of $GITHUB_SHA" > results-win/RUN.txt
ls out/Raidscribe-Setup-*.exe >/dev/null 2>&1 && echo "installer built" >> results-win/RUN.txt || echo "no installer" >> results-win/RUN.txt
cd results-win
git init -q
git checkout -q -b results-windows
git add -A
git -c user.name="Raidscribe build" -c user.email="build@users.noreply.github.com" commit -qm "Windows results of build $GITHUB_RUN_NUMBER"
git push -qf "https://x-access-token:$TOKEN@github.com/$GITHUB_REPOSITORY" results-windows
