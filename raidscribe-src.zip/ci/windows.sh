#!/bin/bash
# Builds Raidscribe for Windows and tests it (run by .github/workflows/build.yml on a Windows machine, after
# raidscribe-src.zip is unpacked): Raidscribe.exe (PyInstaller), the installer (Inno Setup), a portable zip,
# then windows/win_test.py installs it, uses it like a person would, and uninstalls it.
mkdir -p out test-win
exec > >(tee test-win/build.log) 2>&1   # saved with the results, so a failed build can be read from the repo
set -e -o pipefail
ROOT=$(pwd -W)          # this folder as Windows sees it (D:/a/...)
export VERSION_NAME="$(tr -d '[:space:]' < VERSION)"   # the version people see (VERSION file)
export BUILD_NUMBER=${GITHUB_RUN_NUMBER:-0}
V=$VERSION_NAME
NUM="$(echo "$V" | grep -oE '^[0-9]+(\.[0-9]+){0,2}').$BUILD_NUMBER"   # Windows wants four numbers: 1.0.0.21
echo "== Raidscribe $V (build $BUILD_NUMBER, $NUM) for Windows"
python --version
python -m pip install --disable-pip-version-check -q pyinstaller==6.21.0 pillow==12.2.0 pywinauto==0.6.9

python windows/prepare.py
echo "== Raidscribe.exe"
python -m PyInstaller --noconfirm --clean --windowed --name Raidscribe \
  --icon "$ROOT/windows/raidscribe.ico" --version-file "$ROOT/build/version_info.txt" \
  --add-data "$ROOT/windows/Raidscribe_items.dat;." --add-data "$ROOT/build/THIRD-PARTY-NOTICES.txt;." \
  --distpath "$ROOT/build/dist" --workpath "$ROOT/build/work" --specpath "$ROOT/build" \
  "$ROOT/build/Raidscribe.pyw"
cp build/THIRD-PARTY-NOTICES.txt build/dist/Raidscribe/   # beside the .exe too, where people look for it
ls -la build/dist/Raidscribe

echo "== portable zip"
powershell -NoProfile -Command "Compress-Archive -Force -Path 'build/dist/Raidscribe' -DestinationPath 'out/Raidscribe-$V-portable.zip'"

echo "== installer"
ISCC="/c/Program Files (x86)/Inno Setup 6/ISCC.exe"
if [ ! -f "$ISCC" ]; then choco install innosetup -y --no-progress >/dev/null; fi
MSYS_NO_PATHCONV=1 "$ISCC" /Qp "/DAppVersion=$V" "/DNumVersion=$NUM" windows/raidscribe.iss   # (Git's bash would turn /Qp into a path)
ls -la out

echo "== test"
python windows/win_test.py "$V"
