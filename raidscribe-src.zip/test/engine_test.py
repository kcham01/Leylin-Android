"""Checks the Python side on the test logs before anything is built: every call works and the numbers are right."""
import json, os, shutil, sys, tempfile, time
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'app', 'src', 'main', 'python'))
from api import Api

data = tempfile.mkdtemp()
a = Api(data, os.path.join(HERE, '..', 'app', 'src', 'main', 'assets', 'Raidscribe_items.dat'), logs_dir=os.path.join(HERE, 'logs'))
fails = []
def c(fn, **kw):
    r = json.loads(a.call(fn, json.dumps(kw)))
    if 'error' in r:
        fails.append(f'{fn} {kw}: {r["error"]}')
        return None
    return r['ok']
def check(what, cond):
    print(('ok   ' if cond else 'FAIL ') + what)
    if not cond:
        fails.append(what)
t0 = time.time()
while True:
    s = c('status')
    if s and s['state'] == 'ready' and not s['backfill']:
        break
    if time.time() - t0 > 120:
        fails.append('logs never finished loading'); break
    time.sleep(.3)
nav = c('nav')
names = [r['name'] for r in nav['runs']]
check('runs found: ' + ', '.join(names), {'Karazhan', "Gruul's Lair", 'The Shattered Halls', 'Warsong Gulch', 'Nagrand Arena'} <= set(names))
kara = next(r for r in nav['runs'] if r['name'] == 'Karazhan')
run = c('run', id=kara['id'])
check('Karazhan: 3 kills, 1 wipe', run['stats'][0]['v'] == '3' and run['stats'][1]['v'] == '1')
check('Karazhan has deaths and loot', run['death_total'] > 0 and len(run['loot']) > 0)
who = {r['name']: r['guid'] for r in run['damage']['rows'] + run['healing']['rows']}
det = run['details']
cons = lambda n: {c['name']: c['n'] for c in det[who[n]]['cons']}
cds = lambda n: {c[0]: c[1] for c in det[who[n]]['cds']}
check('exact potion names: Frostina Super Mana Potion x4', cons('Frostina').get('Super Mana Potion') == 4 and 'Mana potion' not in cons('Frostina'))
check('Holyra Major Mana Potion x4, Master Healthstone x4', cons('Holyra').get('Major Mana Potion') == 4 and cons('Holyra').get('Master Healthstone') == 4)
check('cooldowns: Frostina Ice Block x4, Rainmaker Bloodlust x4', cds('Frostina').get('Ice Block') == 4 and cds('Rainmaker').get('Bloodlust') == 4)
check('interrupts: Thokk 4 with Pummel, stopped Fear', det[who['Thokk']]['ints'] == 4 and det[who['Thokk']]['int_by'] == [['Pummel', 4]] and det[who['Thokk']]['kicked'][0][0] == 'Fear')
check('deaths are in the drop-downs with what killed them', sum(len(x['deaths']) for x in det.values()) == run['death_total'] and all(d['spell'] for x in det.values() for d in x['deaths']))
n = 0
for r in nav['runs']:
    d = c('run', id=r['id'])
    for p in d['pulls']:
        c('fight', id=p['id']); n += 1
    for row in d['damage']['rows']:
        c('player', run=r['id'], guid=row['guid'])
    c('share_text', kind='run', ident=r['id']); c('card', kind='run', ident=r['id'])
check(f'{n} fights open', n > 20)
for t in ('weeks', 'bosses', 'players', 'attendance', 'loot'):
    check('history ' + t, c('history', tab=t) is not None)
wk = c('history', tab='weeks')['weeks'][0]['start']
check('week summary', (c('share_text', kind='week', ident=str(wk)) or '').startswith('**Week of'))
check('chat loot', len(c('chat_loot', q=0)['groups']) > 0)
check('rolls', len(c('chat_rolls')['rolls']) > 5)
check('activity', len(c('chat_activity')['groups']) > 0)
check('messages', len(c('chat_messages')['rows']) == 300)
check('watch', len(c('chat_watch', words='healer')['rows']) > 0)
check('item tooltip', len(c('item', name="Maulgar's Warhelm")['tooltip']) > 3)
check('report saved', bool(c('save_report', kind='run', ident=kara['id'])))
check('browse', len(c('browse', dir=os.path.join(HERE, 'logs'))['logs']) == 3)
a.w.running = False
shutil.rmtree(data, ignore_errors=True)

# logs copied in while the app is open (on a phone they arrive in batches): every one is read
tmp = tempfile.mkdtemp()
logs = os.path.join(tmp, 'Logs'); os.makedirs(logs)
src = os.path.join(HERE, 'logs')
shutil.copy(os.path.join(src, 'WoWCombatLog-102226_193000.txt'), logs)
b = Api(os.path.join(tmp, 'data'), None, logs_dir=logs)
def ready(api_, secs=120):
    t0 = time.time()
    while time.time() - t0 < secs:
        st = json.loads(api_.call('status'))['ok']
        if st['state'] == 'ready' and not st['backfill']:
            return True
        time.sleep(.3)
    return False
ready(b)
before = {r['name'] for r in json.loads(b.call('nav'))['ok']['runs']}
shutil.copy(os.path.join(src, 'WoWCombatLog-101926_190000.txt'), logs)   # an older log, copied in later
time.sleep(14); ready(b)
after = {r['name'] for r in json.loads(b.call('nav'))['ok']['runs']}
check('a log copied in while open is read: ' + ', '.join(sorted(after - before)), before == {"Gruul's Lair"} and {'Karazhan', 'The Shattered Halls'} <= after)
b.w.running = False
shutil.rmtree(tmp, ignore_errors=True)
print('ERRORS:' if fails else 'all good')
for f in fails:
    print('  ', f)
sys.exit(1 if fails else 0)
