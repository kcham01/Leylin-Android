plugins {
    id("com.android.application") version "8.11.1" apply false
    id("com.chaquo.python") version "17.1.0" apply false
}
