# ======================================================================
#  Watcher: reads the Logs folder in the background, keeps parsers fed.
# ======================================================================

import hashlib
import os
import pickle
import queue
import re
import threading
import time
import traceback
from datetime import datetime

from savedvars import find_saved_files, load_events  # dev

CHUNK = 8 << 20
CACHE_VERSION = 10   # bump whenever parsing changes, so saved results from older versions are read again
NAME_TIME = re.compile(r'WoWCombatLog-(\d{2})(\d{2})(\d{2})_(\d{2})(\d{2})(\d{2})', re.I)


def is_combat(name):
    n = name.lower()
    return n.startswith('wowcombatlog') and n.endswith('.txt')


def is_chat(name):
    n = name.lower()
    return n.startswith('wowchatlog') and n.endswith('.txt')


def real_size(path):
    """File size from an open handle. Windows can report a stale size for files another program is still writing."""
    with open(path, 'rb') as fh:
        return fh.seek(0, 2)


def file_order(path):
    m = NAME_TIME.search(os.path.basename(path))
    if m:
        mo, d, y, h, mi, s = (int(x) for x in m.groups())
        try:
            return datetime(2000 + y, mo, d, h, mi, s).timestamp()
        except ValueError:
            pass
    return os.path.getmtime(path)


class Tail:
    """Reads a growing text file line by line from a byte offset."""

    def __init__(self, path, parser, offset=0):
        self.path, self.parser, self.offset, self.rem = path, parser, offset, b''
        self.gone = False
        self.bad_lines = 0
        self.first_error = None

    def read(self, lock, progress=None, limit=None):
        """Feeds every complete new line to the parser. Returns True if anything was read."""
        size = real_size(self.path)
        if size < self.offset:
            return None  # file was replaced or truncated
        if size == self.offset:
            return False
        with open(self.path, 'rb') as fh:
            fh.seek(self.offset)
            while self.offset < size:
                data = fh.read(min(CHUNK, size - self.offset))
                if not data:
                    break
                self.offset += len(data)
                buf = self.rem + data
                cut = buf.rfind(b'\n')
                if cut < 0:
                    self.rem = buf
                    continue
                self.rem = buf[cut + 1:]
                text = buf[:cut + 1].decode('utf-8', 'replace')
                with lock:
                    feed = self.parser.feed
                    for line in text.splitlines():
                        if line:
                            try:
                                feed(line)
                            except Exception:
                                # one odd line must never cost the lines after it
                                self.bad_lines += 1
                                if self.first_error is None:
                                    self.first_error = f'{self.path}: {line[:300]!r}\n{traceback.format_exc()}'
                if progress:
                    progress(self.offset / max(1, size))
        return True


class Watcher(threading.Thread):
    def __init__(self, folder, cache_dir, combat_cls, chat_cls):
        super().__init__(daemon=True)
        self.folder = folder
        self.cache_dir = cache_dir
        self.Combat, self.Chat = combat_cls, chat_cls
        self.q = queue.Queue()
        self.lock = threading.RLock()
        self.sources = []     # finished logs: snapshots
        self.active = None    # Tail on the newest combat log
        self.chat = None      # Tail on the chat log
        self.version = 0
        self.backfill = None    # (done, total) while older logs are read in the background
        self.versions = {'combat': 0, 'fights': 0, 'chat': 0, 'addon': 0}  # what changed, so the window redraws only what it must
        self.last_chat = 0
        self.last_read = 0
        self.loaded = False
        self.running = True
        self.done = set()     # combat logs already read in full (in sources)
        self.queued = set()   # combat logs found later and being read in the background
        self.sizes = {}       # their size at the last look
        self.addon_events = []   # what the Raidscribe AutoLog addon recorded (rosters, lockouts, loot)
        self.addon_files = []
        self.addon_stamp = None

    def post(self, *msg):
        self.q.put(msg)

    # ---- cache ----
    def cache_path(self, key):
        return os.path.join(self.cache_dir, hashlib.md5(f'v{CACHE_VERSION}|{key}'.encode()).hexdigest() + '.pkl')

    def cache_get(self, key):
        try:
            with open(self.cache_path(key), 'rb') as fh:
                return pickle.load(fh)
        except Exception:
            return None

    def cache_put(self, key, snap):
        try:
            os.makedirs(self.cache_dir, exist_ok=True)
            tmp = self.cache_path(key) + '.tmp'
            with open(tmp, 'wb') as fh:
                pickle.dump(snap, fh, protocol=pickle.HIGHEST_PROTOCOL)
            os.replace(tmp, self.cache_path(key))
        except Exception:
            pass

    def cache_prune(self, keep_keys):
        keep = {os.path.basename(self.cache_path(k)) for k in keep_keys}
        try:
            for n in os.listdir(self.cache_dir):
                if n.endswith('.pkl') and n not in keep:
                    os.remove(os.path.join(self.cache_dir, n))
        except Exception:
            pass

    # ---- folder ----
    def list_logs(self):
        combat, chat = [], []
        for n in os.listdir(self.folder):
            p = os.path.join(self.folder, n)
            if is_combat(n):
                combat.append(p)
            elif is_chat(n):
                chat.append(p)
        combat.sort(key=file_order)
        chat.sort(key=os.path.getmtime)
        return combat, chat

    def me(self):
        with self.lock:
            sets = [s['players'] for s in self.sources] + ([self.active.parser.players] if self.active else [])
            for players in reversed(sets):
                for p in players.values():
                    if p.get('mine'):
                        return p['name']
        return None

    def open_active(self, path, label):
        year = datetime.fromtimestamp(os.path.getmtime(path)).year
        t = Tail(path, self.Combat(year, os.path.basename(path)))
        t.read(self.lock, lambda pct: self.post('progress', label, pct))
        with self.lock:
            self.active = t

    def open_chat(self, path):
        year = datetime.fromtimestamp(os.path.getmtime(path)).year
        t = Tail(path, self.Chat(year, self.me()))
        t.read(self.lock, lambda pct: self.post('progress', 'Reading chat log', pct))
        with self.lock:
            self.chat = t

    def load(self):
        """Gets the window going fast: saved results for old logs, then the newest log and the chat log, then
        'loaded'. Old logs that were never read before (or need reading again after an update) are read
        afterwards in the background, newest first, while the live log is already being followed."""
        combat, chat = self.list_logs()
        newest = combat.pop() if combat else None
        keep, todo = [], []
        for path in combat:
            try:
                st = os.stat(path)
            except OSError:
                continue
            key = f'{os.path.basename(path)}|{st.st_size}|{int(st.st_mtime)}'
            keep.append(key)
            snap = self.cache_get(key)
            with self.lock:
                self.done.add(path)
                if snap is not None:
                    self.sources.append(snap)
            if snap is None:
                todo.append((path, key, st))
        self.cache_prune(keep)
        if newest:
            self.open_active(newest, f'Reading {os.path.basename(newest)}')
        if chat:
            self.open_chat(chat[-1])
        self.load_addon()
        self.last_read = time.time()
        self.loaded = True
        self.version += 1
        self.post('loaded')
        if todo:
            self.backfill = (0, len(todo))
            threading.Thread(target=self.read_older, args=(todo[::-1],), daemon=True).start()

    def read_older(self, todo):
        for i, (path, key, st) in enumerate(todo):
            if not self.running:
                return
            self.backfill = (i, len(todo))
            try:
                year = datetime.fromtimestamp(st.st_mtime).year
                t = Tail(path, self.Combat(year, os.path.basename(path)))
                t.read(threading.RLock())
                t.parser.finish()
                snap = t.parser.snapshot()
                self.cache_put(key, snap)
            except FileNotFoundError:
                continue
            except Exception:
                self.post('warn', f'Couldn\u2019t read {os.path.basename(path)}:\n' + traceback.format_exc())
                continue
            with self.lock:
                self.sources.append(snap)
                self.versions['combat'] += 1
                self.versions['fights'] += 1
                self.version += 1
            self.post('changed', dict(self.versions))
        self.backfill = None
        self.post('changed', dict(self.versions))

    def drop_active(self, cache=True):
        """Moves the current combat log into history (when WoW starts a new one, or the file is deleted)."""
        old = self.active
        with self.lock:
            old.parser.finish()
            snap = old.parser.snapshot()
            self.sources.append(snap)
            self.done.add(old.path)
            self.active = None
        if cache:
            try:
                st = os.stat(old.path)
                self.cache_put(f'{os.path.basename(old.path)}|{st.st_size}|{int(st.st_mtime)}', snap)
            except OSError:
                pass

    def load_addon(self):
        """Re-reads the addon's saved data when WoW has written it (on logout or /reload). Returns True if it changed."""
        try:
            files = find_saved_files(self.folder)
            stamp = tuple((f, os.path.getmtime(f), os.path.getsize(f)) for f in files)
        except Exception:
            return False
        if stamp == self.addon_stamp:
            return False
        warnings = []
        events = load_events(self.folder, warnings)
        with self.lock:
            self.addon_events, self.addon_files, self.addon_stamp = events, files, stamp
        for w in warnings:
            self.post('warn', 'Addon data: ' + str(w))
        return True

    def report_bad_lines(self):
        for t in (self.active, self.chat):
            if t and t.first_error and not getattr(t, 'reported', False):
                t.reported = True
                self.post('warn', f'Skipped {t.bad_lines} line(s) that could not be read. First one:\n{t.first_error}')

    def tail(self):
        changed = False
        if self.active:
            p = self.active.parser
            before = (p.handled, len(p.fights), p.cur is not None)
            try:
                r = self.active.read(self.lock)
            except FileNotFoundError:
                # the log was deleted: keep everything already read, stop watching it
                self.drop_active(cache=False)
                r, changed = False, True
                self.versions['combat'] += 1
                self.versions['fights'] += 1
            if r is None:  # log cleared or replaced: read it again from the start
                self.open_active(self.active.path, 'Re-reading combat log')
                changed = True
                self.versions['combat'] += 1
                self.versions['fights'] += 1
            elif r:
                self.last_read = time.time()
            if self.active:
                with self.lock:
                    p = self.active.parser
                    p.tick(time.time() * 1000)
                    if (p.handled, len(p.fights), p.cur is not None) != before:
                        changed = True
                        self.versions['combat'] += 1
                        if len(p.fights) != before[1]:
                            self.versions['fights'] += 1  # a fight finished: the summaries change
        if self.chat and not self.chat.gone:
            try:
                r = self.chat.read(self.lock)
            except FileNotFoundError:
                self.chat.gone = True  # keep the messages already read; pick the file up again if WoW recreates it
                r = False
            if r is None:
                with self.lock:
                    self.chat.offset, self.chat.rem = 0, b''
                r = self.chat.read(self.lock)
            if r:
                if not self.chat.parser.me:
                    self.chat.parser.me = self.me()
                changed = True
                self.last_chat = time.time()
                self.versions['chat'] += 1
                self.post('chat')
        return changed

    def rescan(self):
        if not os.path.isdir(self.folder):
            return False
        combat, chat = self.list_logs()
        changed = False
        if chat:
            newest = chat[-1]
            if not self.chat:
                self.open_chat(newest)
                changed = True
            elif self.chat.gone or self.chat.path != newest:
                # carry on in the new or recreated file, keeping what was read so far
                with self.lock:
                    self.chat.path, self.chat.offset, self.chat.rem, self.chat.gone = newest, 0, b'', False
                changed = True
        fresh = [p for p in combat if p not in self.done]
        if fresh and (not self.active or self.active.path != fresh[-1]):
            if self.active:
                self.drop_active()
            self.open_active(fresh[-1], 'Reading new combat log')
            changed = True
        # logs copied in alongside it (several at once, or older ones): read them in the background too.
        # On a PC WoW writes one log at a time, but on a phone logs arrive in batches.
        extra = [p for p in fresh if (not self.active or p != self.active.path) and p not in self.queued]
        if extra:
            todo = []
            for path in extra:
                try:
                    st = os.stat(path)
                except OSError:
                    continue
                size = (st.st_size, int(st.st_mtime))
                if self.sizes.get(path) != size:   # still being copied: wait until it stops growing
                    self.sizes[path] = size
                    continue
                self.queued.add(path)
                with self.lock:
                    self.done.add(path)
                todo.append((path, f'{os.path.basename(path)}|{st.st_size}|{int(st.st_mtime)}', st))
            if todo:
                threading.Thread(target=self.read_older, args=(todo[::-1],), daemon=True).start()
        return changed

    def run(self):
        while self.running and not os.path.isdir(self.folder):
            self.post('missing')
            time.sleep(3)
        if not self.running:  # stopped while waiting (another folder was picked)
            return
        self.post('found')
        try:
            self.load()
        except Exception:
            self.post('error', traceback.format_exc())
        n = 0
        while self.running:
            try:
                changed = self.tail()
                self.report_bad_lines()
                n += 1
                if n % 5 == 0 and self.rescan():
                    changed = True
                    self.versions['combat'] += 1
                    self.versions['fights'] += 1
                    self.versions['chat'] += 1
                if n % 15 == 0 and self.load_addon():
                    changed = True
                    self.versions['addon'] += 1
                if changed:
                    self.version += 1
                    self.post('changed', dict(self.versions))
            except Exception:
                # WoW may be mid-write or the folder briefly unavailable: try again next second
                self.post('warn', traceback.format_exc())
            time.sleep(1)
