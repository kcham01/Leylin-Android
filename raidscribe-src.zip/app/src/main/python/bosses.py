# Boss NPC ids for TBC and classic dungeons and raids. The Anniversary client writes no ENCOUNTER_START/END lines,
# so bosses are recognised by which NPCs you fight. instance id -> [(encounter id, boss name, (npc ids, ...)), ...]
# Several ids = a council, a mounted/merged boss or an event with variants (the Opera). Ids are game data (npc and
# encounter ids, as listed by boss-mod addons); negative ids are made up for classic bosses with no encounter id.
BOSS_TABLE = {
    33: [(-3872, 'Deathsworn Captain', (3872,)), (-3886, 'Razorclaw the Butcher', (3886,)), (-3887, 'Baron Silverlaine', (3887,)), (-3914, 'Rethilgore', (3914,)), (-3927, 'Wolf Master Nandos', (3927,)), (-4274, 'Fenrus the Devourer', (4274,)), (-4275, 'Archmage Arugal', (4275,)), (-4278, 'Commander Springvale', (4278,)), (-4279, 'Odo the Blindwatcher', (4279,))],
    34: [(-1663, 'Dextren Ward', (1663,)), (-1666, 'Kam Deepfury', (1666,)), (-1696, 'Targorr the Dread', (1696,)), (-1716, 'Bazil Thredd', (1716,)), (-1717, 'Hamhock', (1717,)), (-1720, 'Bruegal Ironknuckle', (1720,))],
    36: [(2967, "Rhahk'Zor", (644,)), (2968, "Sneed's Shredder", (642, 643)), (2969, 'Gilnid', (1763,)), (2970, 'Mr. Smite', (646,)), (2971, 'Captain Greenskin', (647,)), (2972, 'Edwin Van Cleef', (639,)), (2986, 'Cookie', (645,)), (3676, 'Miner Johnson', (3586,))],
    43: [(585, 'Lady Anacondra', (3671,)), (586, 'Lord Cobrahn', (3669,)), (587, 'Kresh', (3653,)), (588, 'Lord Pythas', (3670,)), (589, 'Skum', (3674,)), (590, 'Lord Serpentis', (3673,)), (591, 'Verdan the Everliving', (5775,)), (592, 'Mutanus the Devourer', (3654,)), (-5912, 'Deviate Faerie Dragon', (5912,))],
    47: [(1659, 'Overload Ramtusk', (4420,)), (1661, 'Charlga Razorflank', (4421,)), (-4422, 'Agathelos the Raging', (4422,)), (-4424, 'Aggem Thorncurse', (4424,)), (-4425, 'Blind Hunter', (4425,)), (-4428, 'Death Speaker Jargba', (4428,)), (-4842, 'Earthcaller Halmgar', (4842,)), (-6168, 'Roogug', (6168,))],
    48: [(2761, 'Ghamoo-Ra', (4887,)), (2762, 'Lady Sarevess', (4831,)), (2763, 'Gelihast', (6243,)), (2765, "Old Serra'kis", (4830,)), (2766, 'Twilight Lord Kelris', (4832,)), (2767, "Aku'mai", (4829,))],
    70: [(547, 'Revelosh', (6910,)), (548, 'The Lost Dwarves', (6906, 6907, 6908)), (549, 'Ironaya', (7228,)), (551, 'Ancient Stone Keeper', (7206,)), (552, 'Galgann Firehammer', (7291,)), (553, 'Grimlok', (4854,)), (554, 'Archaedas', (2748,)), (1887, 'Obsidian Sentinel', (7023,))],
    90: [(-6229, 'Crowd Pummeler 9-60', (6229,)), (-6235, 'Electrocutioner 6000', (6235,)), (-7079, 'Viscous Fallout', (7079,)), (-7361, 'Grubbis', (7361,)), (-7800, 'Mekgineer Thermaplugg', (7800,))],
    109: [(486, 'Dreamscythe', (5721,)), (487, 'Weaver', (5720,)), (488, "Jammal'an the Prophet", (5710,)), (490, 'Morphaz', (5719,)), (491, 'Hazzas', (5722,)), (492, 'Avatar of Hakkar', (8443,)), (493, 'Shade of Eranikus', (5709,)), (3582, "Atal'alarion", (8580,))],
    129: [(-7354, 'Ragglesnout', (7354,)), (-7355, "Tuten'kash", (7355,)), (-7356, 'Plaguemaw the Rotting', (7356,)), (-7357, 'Mordress Fire Eye', (7357,)), (-7358, 'Amnenar the Coldbringer', (7358,)), (-8567, 'Glutton', (8567,))],
    189: [(444, 'Interrogator Vishas', (3983,)), (446, 'Houndmaster Loksey', (3974,)), (447, 'Arcanist Doan', (6487,)), (448, 'Herod', (3975,)), (449, 'High Inquisitor Fairbanks', (4542,)), (450, 'Mograine & Whitemane', (3976, 3977)), (-4543, 'Bloodmage Thalnos', (4543,))],
    209: [(593, 'Hydromancer Velrath', (7795,)), (594, "Gahz'rilla", (7273,)), (595, "Antu'sul", (8127,)), (596, 'Theka the Martyr', (7272,)), (597, "Witch Doctor Zum'rah", (7271,)), (598, "Nekrum & Sezz'ziz", (7275, 7796)), (600, 'Chief Ukorz Sandscalp', (7267,))],
    229: [(267, 'Highlord Omokk', (9196,)), (268, "Shadow Hunter Vosh'gajin", (9236,)), (269, 'War Master Voone', (9237,)), (270, 'Mother Smolderweb', (10596,)), (271, 'Urok Doomhowl', (10584,)), (272, 'Quartermaster Zigris', (9736,)), (273, 'Gizrul', (10268,)), (274, 'Halycon', (10220,)), (275, 'Overlord Wyrmthalak', (9568,)), (-9816, 'Pyroguard Emberseer', (9816,)), (-10264, 'Solakar Flamewreath', (10264,)), (-10339, 'Warchief Rend Blackhand', (10339, 10429)), (-10363, 'General Drakkisath', (10363,)), (-10430, 'The Beast', (10430,)), (-10509, 'Jed Runewatcher', (10509,)), (-10899, 'Goraluk Anvilcrack', (10899,)), (-16042, 'Lord Valthalak', (16042,))],
    230: [(227, 'High Interrogator Gerstahn', (9018,)), (228, 'Lord Roccor', (9025,)), (229, 'Houndmaster Grebmar', (9319,)), (230, 'Ring of Law', (9027, 9028, 9029, 9030, 9031, 9032)), (231, 'Pyromancer Loregrain', (9024,)), (232, 'Lord Incendius', (9017,)), (233, 'Warden Stilgiss', (9041,)), (234, 'Fineous Darkvire', (9056,)), (235, "Bael'Gar", (9016,)), (236, 'General Angerforge', (9033,)), (237, 'Golem Lord Argelmach', (8983,)), (238, 'Hurley Blackbreath', (9537,)), (239, 'Phalanx', (9502,)), (241, 'Plugger Spazzring', (9499,)), (242, 'Ambassador Flamelash', (9156,)), (243, 'The Seven', (9034, 9035, 9036, 9037, 9038, 9039, 9040)), (244, 'Magmus', (9938,)), (245, 'Emperor Dagran Thaurissan', (9019,))],
    249: [(1084, 'Onyxia', (10184,))],
    269: [(1919, 'Aeonus', (17881,)), (1920, 'Chrono Lord Deja', (17879,)), (1921, 'Temporus', (17880,))],
    289: [(-1853, 'Darkmaster Gandling', (1853,)), (-10432, 'Vectus', (10432,)), (-10433, 'Marduk Blackpool', (10433,)), (-10502, 'Lady Illucia Barov', (10502,)), (-10503, 'Jandice Barov', (10503,)), (-10504, 'Lord Alexei Barov', (10504,)), (-10505, 'Instructor Malicia', (10505,)), (-10506, 'Kirtonos the Herald', (10506,)), (-10507, 'The Ravenian', (10507,)), (-10508, 'Ras Frostwhisper', (10508,)), (-10901, 'Lorekeeper Polkelt', (10901,)), (-11261, 'Doctor Theolen Krastinov', (11261,)), (-11622, 'Rattlegore', (11622,))],
    309: [(784, 'High Priest Venoxis', (14507,)), (785, 'High Priestess Jeklik', (14517,)), (786, "High Priestess Mar'li", (14510,)), (787, 'Bloodlord Mandokir', (11382, 14988)), (788, 'Edge of Madness', (15083,)), (789, 'High Priest Thekal', (11347, 11348, 14509)), (790, "Gahz'ranka", (15114,)), (791, 'High Priestess Arlokk', (14515,)), (792, "Jin'do the Hexxer", (11380,)), (793, 'Hakkar the Soulflayer', (14834,))],
    329: [(472, 'The Unforgiven', (10516,)), (473, 'Hearthsinger Forresten', (10558,)), (474, 'Timmy the Cruel', (10808,)), (475, 'Cannon Master Willey', (10997,)), (476, 'Malor the Zealous', (11032,)), (477, 'Archivist Galford', (10811,)), (478, 'Balnazzar', (10813,)), (479, 'Baroness Anastari', (10436,)), (480, "Nerub'enkan", (10437,)), (481, 'Maleki the Pallid', (10438,)), (482, 'Magistrate Barthilas', (10435,)), (483, 'Ramstein the Gorger', (10439,)), (1885, 'Postmaster Malown', (11143,))],
    349: [(422, 'Noxxion', (13282,)), (423, 'Razorlash', (12258,)), (424, 'Lord Vyletongue', (12236,)), (425, 'Celebras the Cursed', (12225,)), (426, 'Landslide', (12203,)), (427, 'Tinkerer Gizlock', (13601,)), (428, 'Rotgrip', (13596,)), (429, 'Princess Theradras', (12201,))],
    389: [(1443, 'Oggleflint', (11517,)), (1444, 'Jergosh the Invoker', (11518,)), (1445, 'Bazzalan', (11519,)), (1446, 'Taragaman the Hungerer', (11520,))],
    429: [(346, 'Alzzin the Wildshaper', (11492,)), (347, 'Illyanna Ravensoak', (11488,)), (348, 'Magister Kalendris', (11487,)), (349, "Immol'thar", (11496,)), (350, 'Tendris Warpwood', (11489,)), (361, 'Prince Tortheldrin', (11486,)), (362, "Guard Mol'dar", (14326,)), (363, 'Stomper Kreeg', (14322,)), (364, 'Guard Fengus', (14321,)), (365, "Guard Slip'kik", (14323,)), (366, 'Captain Kromcrush', (14325,)), (367, "Cho'Rush the Observer", (14324,)), (368, 'King Gordok', (11501,)), (-11490, 'Zevrim Thornhoof', (11490,)), (-13280, 'Hydrospawn', (13280,)), (-14327, 'Lethtendris', (14327,))],
    469: [(610, 'Razorgore the Untamed', (12435,)), (611, 'Vaelastrasz the Corrupt', (13020,)), (612, 'Broodlord Lashlayer', (12017,)), (613, 'Firemaw', (11983,)), (615, 'Flamegor', (11981,)), (616, 'Chromaggus', (14020,)), (617, 'Nefarian', (11583,)), (-11981, 'Ebonroc and Flamegor', (11981, 14601)), (-14601, 'Ebonroc', (14601,))],
    509: [(718, 'Kurinnaxx', (15348,)), (719, 'General Rajaxx', (15341,)), (720, 'Moam', (15340,)), (721, 'Buru the Gorger', (15370,)), (722, 'Ayamiss the Hunter', (15369,)), (723, 'Ossirian the Unscarred', (15339,))],
    531: [(710, 'Silithid Royalty', (15511, 15543, 15544)), (711, 'Battleguard Sartura', (15516,)), (712, 'Fankriss the Unyielding', (15510,)), (713, 'Viscidus', (15299,)), (714, 'Princess Huhuran', (15509,)), (715, 'Twin Emperors', (15275, 15276)), (716, 'Ouro', (15517,)), (717, "C'Thun", (15589, 15727))],
    532: [(652, 'Attumen the Huntsman', (16151, 16152)), (653, 'Moroes', (15687,)), (654, 'Maiden of Virtue', (16457,)), (655, 'Romulo and Julianne', (17533, 17534)), (655, 'The Big Bad Wolf', (17521,)), (655, 'Wizard of Oz', (18168,)), (656, 'The Curator', (15691,)), (657, 'Terestian Illhoof', (15688,)), (658, 'Shade of Aran', (16524,)), (659, 'Netherspite', (15689,)), (660, 'Chess Event', (21752,)), (661, 'Prince Malchezaar', (15690,)), (662, 'Nightbane', (17225,))],
    533: [(1107, "Anub'Rekhan", (15956,)), (1108, 'Gluth', (15932,)), (1109, 'Gothik the Harvester', (16060,)), (1110, 'Grand Widow Faerlina', (15953,)), (1111, 'Grobbulus', (15931,)), (1112, 'Heigan the Unclean', (15936,)), (1113, 'Instructor Razuvious', (16061,)), (1114, "Kel'Thuzad", (15990,)), (1115, 'Loatheb', (16011,)), (1116, 'Maexxna', (15952,)), (1117, 'Noth the Plaguebringer', (15954,)), (1118, 'Patchwerk', (16028,)), (1119, 'Sapphiron', (15989,)), (1120, 'Thaddius', (15928,)), (1121, 'The Four Horsemen', (16062, 16063, 16064, 16065))],
    534: [(618, 'Rage Winterchill', (17767,)), (619, 'Anetheron', (17808,)), (620, "Kaz'rogal", (17888,)), (621, 'Azgalor', (17842,)), (622, 'Archimonde', (17968,))],
    540: [(1935, 'Blood Guard Porung', (20923,)), (1936, 'Grand Warlock Nethekurse', (16807,)), (1937, "Warbringer O'mrogg", (16809,)), (1938, 'Warchief Kargath Bladefist', (16808,))],
    542: [(1922, 'The Maker', (17381,)), (1923, "Keli'dan the Breaker", (17377,)), (1924, 'Broggok', (17380,))],
    543: [(1891, 'Omor the Unscarred', (17308,)), (1892, 'Nazan & Vazruden', (17307, 17537)), (1893, 'Watchkeeper Gargolmar', (17306,))],
    544: [(651, 'Magtheridon', (17257,))],
    545: [(1942, 'Hydromancer Thespia', (17797,)), (1943, 'Mekgineer Steamrigger', (17796,)), (1944, 'Warlord Kalithresh', (17798,))],
    546: [(1945, "Ghaz'an", (18105,)), (1946, 'Hungarfen', (17770,)), (1947, "Swamplord Musel'ek", (17826,)), (1948, 'The Black Stalker', (17882,))],
    547: [(1939, 'Mennu the Betrayer', (17941,)), (1940, 'Quagmirran', (17942,)), (1941, 'Rokmar the Crackler', (17991,))],
    548: [(623, 'Hydross the Unstable', (21216,)), (624, 'The Lurker Below', (21217,)), (625, 'Leotheras the Blind', (21215,)), (626, 'Fathom-Lord Karathress', (21214,)), (627, 'Morogrim Tidewalker', (21213,)), (628, 'Lady Vashj', (21212,))],
    550: [(730, "Al'ar", (19514,)), (731, 'Void Reaver', (19516,)), (732, 'High Astromancer Solarian', (18805,)), (733, "Kael'thas Sunstrider", (19622,))],
    552: [(1913, 'Dalliah the Doomsayer', (20885,)), (1914, 'Harbinger Skyriss', (20912,)), (1915, 'Wrath-Scryer Soccothrates', (20886,)), (1916, 'Zereketh the Unbound', (20870,))],
    553: [(1925, 'Commander Sarannis', (17976,)), (1926, 'High Botanist Freywinn', (17975,)), (1927, 'Laj', (17980,)), (1928, 'Thorngrin the Tender', (17978,)), (1929, 'Warp Splinter', (17977,))],
    554: [(1930, 'Nethermancer Sepethrea', (19221,)), (1931, 'Pathaleon the Calculator', (19220,)), (1932, 'Mechano-Lord Capacitus', (19219,)), (1933, 'Gatewatcher Gyro-Kill', (19218,)), (1934, 'Gatewatcher Iron-Hand', (19710,))],
    555: [(1908, 'Ambassador Hellmaw', (18731,)), (1909, 'Blackheart the Inciter', (18667,)), (1910, 'Murmur', (18708,)), (1911, 'Grandmaster Vorpil', (18732,))],
    556: [(1902, 'Talon King Ikiss', (18473,)), (1903, 'Darkweaver Syth', (18472,)), (1904, 'Anzu', (23035,))],
    557: [(250, 'Yor', (22930,)), (1899, 'Nexus-Prince Shaffar', (18344,)), (1900, 'Pandemonius', (18341,)), (1901, 'Tavarok', (18343,))],
    558: [(1889, 'Exarch Maladaar', (18373,)), (1890, 'Shirrak the Dead Watcher', (18371,))],
    560: [(1905, 'Lieutenant Drake', (17848,)), (1906, 'Epoch Hunter', (18096,)), (1907, 'Captain Skarloc', (17862,))],
    564: [(601, "High Warlord Naj'entus", (22887,)), (602, 'Supremus', (22898,)), (603, 'Shade of Akama', (22841,)), (604, 'Teron Gorefiend', (22871,)), (605, 'Gurtogg Bloodboil', (22948,)), (606, 'Essence of Souls', (23420,)), (607, 'Mother Shahraz', (22947,)), (608, 'Illidari Council', (22949, 22950, 22951, 22952)), (609, 'Illidan Stormrage', (22917,))],
    565: [(649, 'High King Maulgar', (18831, 18832, 18834, 18835, 18836)), (650, 'Gruul the Dragonkiller', (19044,))],
    568: [(1189, "Akil'zon", (23574,)), (1190, 'Nalorakk', (23576,)), (1191, "Jan'alai", (23578,)), (1192, 'Halazzi', (23577,)), (1193, 'Hex Lord Malacrass', (24239,)), (1194, "Zul'jin", (23863,))],
    580: [(724, 'Kalecgos', (24850,)), (725, 'Brutallus', (24882,)), (726, 'Felmyst', (25038,)), (727, 'Eredar Twins', (25165, 25166)), (728, "M'uru", (25741,)), (729, "Kil'jaeden", (25315,))],
    585: [(1894, "Kael'thas Sunstrider (Party)", (24664,)), (1895, 'Priestess Delrissa', (24560,)), (1897, 'Selin Fireheart', (24723,)), (1898, 'Vexallus', (24744,))],
}
BOSS_NPC = {npc: (enc, name, inst) for inst, lst in BOSS_TABLE.items() for enc, name, npcs in lst for npc in npcs}
# holiday bosses: kills are counted, but they don't count toward an instance's boss total
HOLIDAY_BOSSES = [(189, -23682, 'Headless Horseman', (23682, 23775)), (547, -25740, 'Ahune', (25740,)),
                  (230, -23872, 'Coren Direbrew', (23872,))]
for _inst, _enc, _name, _npcs in HOLIDAY_BOSSES:
    for _n in _npcs:
        BOSS_NPC[_n] = (_enc, _name, _inst)
for _n in (15550,):  # Attumen on foot (before he mounts Midnight)
    BOSS_NPC[_n] = (652, 'Attumen the Huntsman', 532)

# classic dungeons and raids (TBC ones are named in activities.CATALOG)
CLASSIC_INSTANCES = {
    389: ('Ragefire Chasm', 'dungeon', 5), 36: ('The Deadmines', 'dungeon', 5), 43: ('Wailing Caverns', 'dungeon', 5),
    33: ('Shadowfang Keep', 'dungeon', 5), 34: ('The Stockade', 'dungeon', 5), 48: ('Blackfathom Deeps', 'dungeon', 5),
    90: ('Gnomeregan', 'dungeon', 5), 47: ('Razorfen Kraul', 'dungeon', 5), 129: ('Razorfen Downs', 'dungeon', 5),
    189: ('Scarlet Monastery', 'dungeon', 5), 70: ('Uldaman', 'dungeon', 5), 209: ("Zul'Farrak", 'dungeon', 5),
    349: ('Maraudon', 'dungeon', 5), 109: ('Sunken Temple', 'dungeon', 5), 230: ('Blackrock Depths', 'dungeon', 5),
    229: ('Blackrock Spire', 'dungeon', 10), 429: ('Dire Maul', 'dungeon', 5), 289: ('Scholomance', 'dungeon', 5),
    329: ('Stratholme', 'dungeon', 5),
}

ENC_NPCS = {}  # encounter id -> every NPC that is part of it
for _n, (_e, _, _) in BOSS_NPC.items():
    ENC_NPCS.setdefault(_e, set()).add(_n)
HOLIDAY_ENCS = {e for _, e, _, _ in HOLIDAY_BOSSES}  # a holiday boss can be summoned again and again in one visit
