# ======================================================================
#  Activities: what you were doing (raid, dungeon, PvP, farming), sessions,
#  summaries, history and the text/report data used for sharing.
#  Pure data, no UI.
# ======================================================================

from datetime import datetime, timedelta

from parsers import INSTANCE_BOSSES  # dev
from bosses import CLASSIC_INSTANCES, HOLIDAY_ENCS  # dev

SESSION_GAP = 2 * 3600_000   # this long with nothing happening starts a new session
DISCORD_LIMIT = 1900         # Discord's message limit is 2000 characters; leave room

# instance ID -> (name, kind, size). TBC content plus the older raids people still run.
CATALOG = {
    # TBC raids
    532: ('Karazhan', 'raid', 10), 565: ("Gruul's Lair", 'raid', 25), 544: ("Magtheridon's Lair", 'raid', 25),
    548: ('Serpentshrine Cavern', 'raid', 25), 550: ('Tempest Keep', 'raid', 25), 534: ('Hyjal Summit', 'raid', 25),
    564: ('Black Temple', 'raid', 25), 568: ("Zul'Aman", 'raid', 10), 580: ('Sunwell Plateau', 'raid', 25),
    # older raids
    409: ('Molten Core', 'raid', 40), 469: ('Blackwing Lair', 'raid', 40), 509: ("Ruins of Ahn'Qiraj", 'raid', 20),
    531: ("Temple of Ahn'Qiraj", 'raid', 40), 309: ("Zul'Gurub", 'raid', 20), 249: ("Onyxia's Lair", 'raid', 40), 533: ('Naxxramas', 'raid', 40),
    # TBC dungeons
    543: ('Hellfire Ramparts', 'dungeon', 5), 542: ('The Blood Furnace', 'dungeon', 5), 540: ('The Shattered Halls', 'dungeon', 5),
    547: ('The Slave Pens', 'dungeon', 5), 546: ('The Underbog', 'dungeon', 5), 545: ('The Steamvault', 'dungeon', 5),
    557: ('Mana-Tombs', 'dungeon', 5), 558: ('Auchenai Crypts', 'dungeon', 5), 556: ('Sethekk Halls', 'dungeon', 5),
    555: ('Shadow Labyrinth', 'dungeon', 5), 560: ('Old Hillsbrad Foothills', 'dungeon', 5), 269: ('The Black Morass', 'dungeon', 5),
    554: ('The Mechanar', 'dungeon', 5), 553: ('The Botanica', 'dungeon', 5), 552: ('The Arcatraz', 'dungeon', 5),
    585: ("Magisters' Terrace", 'dungeon', 5),
    # battlegrounds and arenas
    489: ('Warsong Gulch', 'battleground', 10), 529: ('Arathi Basin', 'battleground', 15), 30: ('Alterac Valley', 'battleground', 40),
    566: ('Eye of the Storm', 'battleground', 15), 559: ('Nagrand Arena', 'arena', 5), 562: ("Blade's Edge Arena", 'arena', 5),
    572: ('Ruins of Lordaeron', 'arena', 5),
}
for _k, _v in CLASSIC_INSTANCES.items():
    CATALOG.setdefault(_k, _v)
KIND_LABEL = {'raid': 'Raid', 'dungeon': 'Dungeon', 'battleground': 'Battleground', 'arena': 'Arena', 'instance': 'Instance'}
KIND_ORDER = ['raid', 'dungeon', 'battleground', 'arena', 'instance']


# ---------------------------------------------------------------- helpers

def fight_dur(f):
    return max(1000, f['end'] - f['start'])


def dur(ms):
    s = max(0, round(ms / 1000))
    if s >= 3600:
        return f'{s // 3600}h {s % 3600 // 60:02d}m'
    return f'{s // 60}:{s % 60:02d}'


def span(ms):
    """A length of time people read at a glance: 45s, 13m, 1h 23m (not 13:21, which looks like a clock time)."""
    s = max(0, round(ms / 1000))
    if s < 60:
        return f'{s}s'
    m = round(s / 60)
    if m < 60:
        return f'{m}m'
    return f'{m // 60}h {m % 60:02d}m'


def plural(n, word):
    return f"{n} {word}{'' if n == 1 else 's'}"


def fmt(n):
    if n >= 1e6:
        return f'{n / 1e6:.2f}M'
    if n >= 1e4:
        return f'{n / 1e3:.1f}k'
    return f'{round(n):,}'


def gold(copper):
    copper = int(round(copper))
    sign = '-' if copper < 0 else ''
    copper = abs(copper)
    g, s = copper // 10000, copper % 10000 // 100
    return f'{sign}{g:,}g {s}s' if g else f'{sign}{s}s {copper % 100}c'


def day_label(ts):
    d = datetime.fromtimestamp(ts / 1000)
    return d.strftime('%a, %b ') + str(d.day)


def clock(ts):
    return datetime.fromtimestamp(ts / 1000).strftime('%I:%M %p').lstrip('0')


def week_start(ts):
    """Weekly reset week, starting Tuesday (US realms)."""
    d = datetime.fromtimestamp(ts / 1000)
    start = (d - timedelta(days=(d.weekday() - 1) % 7)).replace(hour=0, minute=0, second=0, microsecond=0)
    return int(start.timestamp() * 1000)


def kind_of(run, fights):
    info = CATALOG.get(run.get('instance_id'))
    if info:
        return info[1]
    name = (run.get('name') or '').lower()
    if 'arena' in name:
        return 'arena'
    sizes = [f.get('size') or 0 for f in fights if f['kind'] == 'boss']
    if sizes:
        return 'raid' if max(sizes) > 5 else 'dungeon'
    players = len({g for f in fights for g in f['players']})
    return 'raid' if players > 5 else 'dungeon' if fights else 'instance'


# ---------------------------------------------------------------- model

class Model:
    """Everything the summary screens and exports need, built from the parsed logs."""

    def __init__(self, fights, runs, players, by_id, cp=None, addon_events=None, me=None, items=None):
        self.fights, self.runs, self.players, self.by_id = fights, runs, players, by_id
        self.items = items  # ItemDB: quality and id by item name (the chat log only has names)
        self.cp = cp
        self.events = addon_events or []
        self.me = me
        self.annotate_runs()
        self.assign_loot()
        self._run_cache = {}

    # ---- runs ----
    def run_fights(self, run):
        return [self.by_id[i] for i in run['fights'] if i in self.by_id]

    def annotate_runs(self):
        enter = [e for e in self.events if e.get('e') == 'enter']
        pvp = [e for e in self.events if e.get('e') == 'pvp']
        for r in self.runs:
            fights = self.run_fights(r)
            r['kind'] = kind_of(r, fights)
            info = CATALOG.get(r.get('instance_id'))
            if info and r.get('name') in (None, '', 'Instance'):
                r['name'] = info[0]
            # the addon knows the difficulty and lockout (exact), when it's installed
            near = [e for e in enter if e.get('id') == r.get('instance_id') and r['start'] - 3600_000 <= e['ts'] <= r['end']]
            if near:
                e = near[-1]
                r['difficulty_name'] = e.get('diffName')
                r['lockout'] = e.get('lockout')
                if e.get('type') in ('arena', 'pvp'):
                    r['kind'] = 'arena' if e.get('type') == 'arena' else 'battleground'
            if r['kind'] in ('battleground', 'arena'):
                # the first result recorded after this match started (a later one belongs to the next match)
                res = [e for e in pvp if e.get('id') == r.get('instance_id') and r['start'] <= e['ts'] <= r['end'] + 600_000]
                r['result'] = None if not res else ('win' if res[0].get('win') else 'loss' if res[0].get('win') is False else None)

    LOOT_AFTER = 300_000  # loot up to 5 minutes after a run's last fight still belongs to it

    _loot_cache = (None, None)

    def all_loot(self):
        """Every looted item, with names resolved. Reused between redraws until the chat log or addon data grows."""
        cp = self.cp
        key = (id(cp), len(cp.loot) if cp else 0, len(self.events), bool(self.items and self.items.ready), self.me)
        if Model._loot_cache[0] == key:
            return Model._loot_cache[1]
        out = self._all_loot()
        Model._loot_cache = (key, out)
        return out

    def _all_loot(self):
        q = self.items.quality if self.items else (lambda name, q=None: q)
        if self.cp and self.cp.loot:
            return [{'ts': l['ts'], 'who': self.name_of(l['who'], l['ts']), 'mine': l['who'] == 'You', 'name': l['item']['name'],
                     'q': q(l['item']['name'], l['item']['q']), 'count': l['count'], 'won': bool(l.get('won')), 'roll': l.get('roll')} for l in self.cp.loot]
        return [{'ts': e['ts'], 'who': (e.get('who') or '').split('-')[0], 'name': e.get('name') or f"item {e.get('item')}",
                 'q': q(e.get('name'), e.get('q')), 'count': e.get('n') or 1, 'won': False, 'roll': None} for e in self.events if e.get('e') == 'loot']

    def assign_loot(self):
        """Every item belongs to exactly one place: the run it dropped in, or nowhere (farming/world)."""
        import bisect
        self.loot_run = {}
        self.run_loot = {}
        spans = sorted(((r['start'] - 60_000, r['end'] + self.LOOT_AFTER, r['id']) for r in self.runs))
        starts = [a for a, _, _ in spans]
        self.loot = self.all_loot()
        for i, l in enumerate(self.loot):
            owner = None
            k = bisect.bisect_right(starts, l['ts'])
            while k > 0:  # the latest run that started before the item and still covers it wins
                k -= 1
                a, b, rid = spans[k]
                if l['ts'] <= b:
                    owner = rid
                    break
                if l['ts'] - a > 48 * 3600_000:
                    break
            self.loot_run[i] = owner
            if owner:
                self.run_loot.setdefault(owner, []).append(l)

    def loot_of_run(self, run):
        # raids: blue and better; dungeons: green and better (what the group rolls on); anything rolled for counts too
        low = 2 if run.get('kind') == 'dungeon' else 3
        return [l for l in self.run_loot.get(run['id'], ()) if l['q'] is None or l['q'] >= low or l.get('won')]

    # ---- sessions (days played) ----
    @property
    def sessions(self):
        if not hasattr(self, '_sessions'):
            self._sessions = self.build_sessions()
        return self._sessions

    def build_sessions(self):
        """Groups everything into sittings: anything closer together than SESSION_GAP is one session."""
        points = [(f['start'], f['end']) for f in self.fights]
        cp = self.cp
        if cp:
            points += [(l['ts'], l['ts']) for l in cp.loot if self.is_mine(l['who'])]
            points += [(m['ts'], m['ts']) for m in cp.money]
        points += [(e['ts'], e['ts']) for e in self.events if e.get('e') in ('login', 'logout', 'enter', 'leave', 'money', 'loot')]
        if not points:
            return []
        points.sort()
        sessions = []
        cur = None
        for a, b in points:
            if cur is None or a - cur['end'] > SESSION_GAP:
                cur = {'start': a, 'end': b}
                sessions.append(cur)
            else:
                cur['end'] = max(cur['end'], b)
        for i, s in enumerate(sessions):
            s['id'] = f"s{s['start']}"
            s['runs'] = [r for r in self.runs if s['start'] <= r['start'] <= s['end']]
            s['world_fights'] = [f for f in self.fights if not f.get('run_id') and s['start'] <= f['start'] <= s['end']]
        return sessions

    def session_of(self, run):
        return next((s for s in self.sessions if run in s['runs']), None)

    def is_mine(self, who):
        return who in ('You', self.me) if self.me else who == 'You'

    def you_at(self, ts):
        """Which of your characters was playing at that moment: the addon knows exactly, the chat log sometimes."""
        import bisect
        if not hasattr(self, '_chars'):
            chars = sorted((e['ts'], e['c'].split('-')[0]) for e in self.events if e.get('c') and e.get('ts'))
            self._chars = chars
            self._char_ts = [t for t, _ in chars]
        k = bisect.bisect_right(self._char_ts, ts)
        if k and ts - self._chars[k - 1][0] < 12 * 3600_000:
            return self._chars[k - 1][1]
        got = self.cp.you_at(ts) if self.cp and hasattr(self.cp, 'you_at') else None
        return got or self.me

    def name_of(self, who, ts):
        return (self.you_at(ts) or 'You') if who == 'You' else who

    def in_any_run(self, ts):
        return any(r['start'] - 60_000 <= ts <= r['end'] + 120_000 for r in self.runs)

    # ---- run summary ----
    def run_summary(self, run, scope='boss'):
        """All the numbers for one instance run: bosses, players, deaths, loot.
        scope 'boss' totals boss fights (or everything when there were none), 'all' totals every fight."""
        fights = self.run_fights(run)
        bosses_by_id, order = {}, []
        for f in fights:
            if f['kind'] != 'boss':
                continue
            key = f.get('encounter_id') or f['name']
            if key not in bosses_by_id:
                bosses_by_id[key] = {'id': key, 'name': f['name'], 'attempts': []}
                order.append(bosses_by_id[key])
            bosses_by_id[key]['attempts'].append(f)
        for b in order:
            kill = next((a for a in b['attempts'] if a['success']), None)
            b['kill'] = kill
            b['wipes'] = [a for a in b['attempts'] if not a['success']]
        end = max([run['end']] + [f['end'] for f in fights]) if fights else run['end']
        boss_fights = [f for f in fights if f['kind'] == 'boss']
        counted = boss_fights if scope == 'boss' and boss_fights else fights   # dungeons/PvP without boss lines use everything

        agg = {}
        for f in counted:
            d = fight_dur(f)
            for g, st in f['players'].items():
                a = agg.setdefault(g, {'guid': g, 'name': st['name'], 'dmg': 0, 'heal': 0, 'time': 0, 'deaths': 0, 'interrupts': 0,
                                       'dispels': 0, 'cons': 0, 'cons_by': {}, 'avoid': 0, 'taken': 0,
                                       'cds_by': {}, 'int_by': {}, 'kicked': {}, 'taken_by': {}})
                a['dmg'] += st['dmg']; a['heal'] += st['heal']; a['time'] += d; a['deaths'] += st['deaths']
                a['interrupts'] += st['interrupts']; a['dispels'] += st['dispels']; a['avoid'] += st['avoid']; a['taken'] += st['taken']
                for k, v in st['cons'].items():
                    a['cons'] += v
                    a['cons_by'][k] = a['cons_by'].get(k, 0) + v
                for src_key, dst_key in (('cds', 'cds_by'), ('int_by', 'int_by'), ('kicked', 'kicked'), ('taken_by', 'taken_by')):
                    for k, v in (st.get(src_key) or {}).items():
                        a[dst_key][k] = a[dst_key].get(k, 0) + v
        for a in agg.values():
            a['dps'] = a['dmg'] / max(1, a['time'] / 1000)
            a['hps'] = a['heal'] / max(1, a['time'] / 1000)
            p = self.players.get(a['guid']) or {}
            a['cls'] = p.get('cls')
        players = sorted(agg.values(), key=lambda a: -a['dmg'])
        deaths = [dict(d, fight=f['name'], fight_id=f['id'], at=d['ts'] - f['start']) for f in fights for d in f['deaths']]
        loot = self.loot_of_run(run)
        kills = [b for b in order if b['kill'] and b['id'] not in HOLIDAY_ENCS]
        holiday = [(b['name'], sum(1 for a in b['attempts'] if a['success'])) for b in order if b['kill'] and b['id'] in HOLIDAY_ENCS]
        first_pull = min((f['start'] for f in fights), default=run['start'])
        last_kill = max((b['kill']['end'] for b in kills), default=None)
        wipes = [a for b in order for a in b['wipes']]
        roster = self.roster_for(run, end)
        return {
            'run': run, 'kind': run.get('kind', 'instance'), 'name': run['name'], 'start': run['start'], 'end': end,
            'bosses': order, 'kills': len(kills), 'known_bosses': self.known_bosses(run), 'wipes': len(wipes),
            'wipe_time': sum(fight_dur(f) for f in wipes), 'clear_time': (last_kill - first_pull) if last_kill else None,
            'players': players, 'deaths': deaths, 'loot': loot, 'fights': fights, 'roster': roster,
            'difficulty': run.get('difficulty_name'), 'result': run.get('result'),
            'trash_time': sum(fight_dur(f) for f in fights if f['kind'] == 'trash'),
            'scope': 'boss' if counted is boss_fights and boss_fights else 'all', 'counted': counted,
            'records': self.records_set_in(run, order), 'holiday': holiday,
        }

    def known_bosses(self, run):
        info = INSTANCE_BOSSES.get(run.get('instance_id'))
        return len(info[1]) if info else 0

    def roster_for(self, run, end):
        """Who was there: the addon's roster if it recorded one, otherwise everyone seen in the fights."""
        rosters = [e for e in self.events if e.get('e') == 'roster']
        before = [e for e in rosters if run['start'] - 7200_000 <= e['ts'] <= run['start'] + 60_000]
        during = [e for e in rosters if run['start'] + 60_000 < e['ts'] <= end]
        snaps = before[-1:] + during  # the group as it was when the run started, plus anyone who joined
        names = []
        if snaps:
            for e in snaps:
                for m in e.get('members') or []:
                    n = (m.get('n') or '').split('-')[0]
                    if n and n not in names:
                        names.append(n)
        else:
            seen = {}
            for f in self.run_fights(run):
                for g, st in f['players'].items():
                    seen.setdefault(st['name'], 0)
                    seen[st['name']] += 1
            names = sorted(seen)
        return names

    # ---- records ----
    def records(self):
        """Fastest kill per boss, and each player's best DPS per boss, over all logs."""
        if hasattr(self, '_records'):
            return self._records
        kills, dps = {}, {}
        for f in self.fights:
            if f['kind'] != 'boss' or not f['success']:
                continue
            key = f.get('encounter_id') or f['name']
            d = fight_dur(f)
            if key not in kills or d < kills[key]['time']:
                kills[key] = {'time': d, 'fight_id': f['id'], 'ts': f['start'], 'name': f['name']}
            sec = d / 1000
            for g, st in f['players'].items():
                v = st['dmg'] / sec
                k = (st['name'], key)
                if v > 0 and (k not in dps or v > dps[k]['dps']):
                    dps[k] = {'dps': v, 'fight_id': f['id'], 'ts': f['start'], 'boss': f['name'], 'name': st['name']}
        self._records = {'kills': kills, 'dps': dps}
        return self._records

    def records_set_in(self, run, bosses):
        """Records broken in this run, compared with earlier kills only: faster kills, and personal-best DPS."""
        kills_by_boss = {}
        for f in self.fights:
            if f['kind'] == 'boss' and f['success']:
                kills_by_boss.setdefault(f.get('encounter_id') or f['name'], []).append(f)
        out, personal = [], []
        for b in bosses:
            k = b.get('kill')
            if not k:
                continue
            earlier = [f for f in kills_by_boss.get(k.get('encounter_id') or k['name'], []) if f['start'] < k['start']]
            if not earlier:
                continue  # a first kill isn't a record yet
            if fight_dur(k) < min(fight_dur(f) for f in earlier):
                out.append(f"Fastest {k['name']} kill: {dur(fight_dur(k))} (was {dur(min(fight_dur(f) for f in earlier))})")
            sec = fight_dur(k) / 1000
            for st in k['players'].values():
                prev = [ps['dmg'] / (fight_dur(f) / 1000) for f in earlier for ps in f['players'].values() if ps['name'] == st['name'] and ps['dmg'] > 0]
                now = st['dmg'] / sec
                if prev and now > max(prev):
                    personal.append((now / max(prev) - 1, f"{st['name']}: best DPS on {k['name']}, {round(now):,} (up {round(100 * (now / max(prev) - 1))}%)"))
        personal.sort(key=lambda x: -x[0])
        return out + [t for _, t in personal[:5]]

    # ---- session summary ----
    def session_summary(self, s):
        runs = [self.run_summary(r) for r in s['runs']]
        cp = self.cp
        money_in = money_out = 0
        farm_loot = []
        if cp:
            for m in cp.money:
                if s['start'] - 60_000 <= m['ts'] <= s['end'] + 60_000:
                    money_in += m['copper']
            farm_loot = [l for i, l in enumerate(self.loot) if s['start'] - 60_000 <= l['ts'] <= s['end'] + 60_000
                         and l.get('mine') and self.loot_run.get(i) is None]
        addon_money = [e for e in self.events if e.get('e') == 'money' and s['start'] - 60_000 <= e['ts'] <= s['end'] + 60_000]
        money_net = None
        if addon_money:  # the addon sees every change (quests, vendors, mail, repairs), not just looted coins
            money_net = sum(e.get('d', 0) for e in addon_money)
            money_out = -sum(e.get('d', 0) for e in addon_money if e.get('d', 0) < 0)
            if not cp:
                money_in = sum(e.get('d', 0) for e in addon_money if e.get('d', 0) > 0)
        within = lambda lst: [e for e in (getattr(cp, lst, None) or []) if s['start'] - 60_000 <= e['ts'] <= s['end'] + 60_000] if cp else []
        honor = sum(e['amount'] for e in within('honor'))
        rep = {}
        for e in within('reputation'):
            rep[e['faction']] = rep.get(e['faction'], 0) + (e['amount'] if e.get('up', True) else -e['amount'])
        quests = sum(1 for e in within('quests') if e.get('done'))
        badges = {}
        for e in within('currency'):
            badges[e['item']['name']] = badges.get(e['item']['name'], 0) + e['count']
        in_runs = sum(r['end'] - r['start'] for r in runs)
        total = max(1, s['end'] - s['start'])
        outside = max(0, total - in_runs)
        by_kind = {}
        for r in runs:
            by_kind.setdefault(r['kind'], []).append(r)
        pvp = [r for r in runs if r['kind'] in ('battleground', 'arena')]
        return {
            'session': s, 'start': s['start'], 'end': s['end'], 'duration': total, 'runs': runs, 'by_kind': by_kind,
            'kills': sum(r['kills'] for r in runs if r['kind'] in ('raid', 'dungeon')),
            'wipes': sum(r['wipes'] for r in runs if r['kind'] in ('raid', 'dungeon')),
            'deaths': sum(len(r['deaths']) for r in runs) + sum(len(f['deaths']) for f in s['world_fights']),
            'money_in': money_in, 'money_out': money_out, 'money_net': money_net,
            'honor': honor, 'reputation': sorted(rep.items(), key=lambda kv: -kv[1]), 'quests_done': quests, 'currency': badges, 'gold_per_hour': money_in / (total / 3600_000) if total > 600_000 else None,
            'farm_loot': farm_loot, 'outside_time': outside, 'world_fights': len(s['world_fights']),
            'pvp': {'matches': len(pvp), 'wins': sum(1 for r in pvp if r['result'] == 'win'), 'losses': sum(1 for r in pvp if r['result'] == 'loss')},
        }

    # ---- history ----
    def weeks(self):
        """Per reset week: raids, kills, wipes, who came, what dropped."""
        weeks = {}
        for r in self.runs:
            w = weeks.setdefault(week_start(r['start']), {'start': week_start(r['start']), 'runs': [], 'kills': 0, 'wipes': 0, 'attendance': {}, 'loot': []})
            sm = self.run_summary_cached(r)
            w['runs'].append(sm)
            if sm['kind'] in ('raid', 'dungeon'):
                w['kills'] += sm['kills']
                w['wipes'] += sm['wipes']
            if sm['kind'] == 'raid':
                for n in sm['roster']:
                    w['attendance'][n] = w['attendance'].get(n, 0) + 1
                w['loot'] += sm['loot']
        return [weeks[k] for k in sorted(weeks, reverse=True)]

    def run_summary_cached(self, r, scope='boss'):
        key = (r['id'], len(r['fights']), r['end'], scope)
        if key not in self._run_cache:
            self._run_cache[key] = self.run_summary(r, scope)
        return self._run_cache[key]

    # ---- one player in one run ----
    def player_summary(self, run, guid, scope='boss'):
        """One person's night: their totals and ranks, every fight, top abilities, deaths, consumables and loot."""
        sm = self.run_summary_cached(run, scope)
        me = next((p for p in sm['players'] if p['guid'] == guid), None)
        if me is None:
            return None
        dealers = [p for p in sm['players'] if p['dmg'] > 0]
        healers = sorted([p for p in sm['players'] if p['heal'] > 0], key=lambda p: -p['hps'])
        dealers.sort(key=lambda p: -p['dps'])
        rank_d = next((i + 1 for i, p in enumerate(dealers) if p['guid'] == guid), None)
        rank_h = next((i + 1 for i, p in enumerate(healers) if p['guid'] == guid), None)
        seen, rows = {}, []
        dmg_by, heal_by = {}, {}
        for f in sm['counted']:
            st = f['players'].get(guid)
            key = f.get('encounter_id') or f['name']
            if f['kind'] == 'boss':
                seen[key] = seen.get(key, 0) + 1
            if not st:
                continue
            sec = fight_dur(f) / 1000
            rows.append({'fight': f, 'name': f['name'] or 'Trash', 'kind': f['kind'], 'success': f.get('success'), 'attempt': seen.get(key) if f['kind'] == 'boss' else None,
                         'time': fight_dur(f), 'dmg': st['dmg'], 'dps': st['dmg'] / sec, 'heal': st['heal'], 'hps': st['heal'] / sec,
                         'deaths': st['deaths'], 'taken': st['taken'], 'boss_hp': f.get('boss_hp')})
            for k, v in (st.get('dmg_by') or {}).items():
                dmg_by[k] = dmg_by.get(k, 0) + v
            for k, v in (st.get('heal_by') or {}).items():
                heal_by[k] = heal_by.get(k, 0) + v
        deaths = [d for d in sm['deaths'] if d.get('guid') == guid]
        loot = [l for l in sm['loot'] if l['who'] == me['name']]
        return {'run': run, 'run_summary': sm, 'guid': guid, 'player': me, 'name': me['name'], 'cls': me.get('cls'),
                'start': sm['start'], 'end': sm['end'], 'kind': sm['kind'], 'scope': sm['scope'],
                'rank_dps': rank_d, 'of_dps': len(dealers), 'rank_hps': rank_h, 'of_hps': len(healers),
                'fights': rows, 'dmg_by': sorted(dmg_by.items(), key=lambda kv: -kv[1]), 'heal_by': sorted(heal_by.items(), key=lambda kv: -kv[1]),
                'deaths': deaths, 'loot': loot, 'cons_by': sorted(me['cons_by'].items(), key=lambda kv: -kv[1])}

    def raid_nights(self):
        """One entry per raid night (a raid instance on a date) with who was there, oldest first."""
        nights = {}
        for r in self.runs:
            if r.get('kind') != 'raid':
                continue
            sm = self.run_summary_cached(r)
            key = (datetime.fromtimestamp(sm['start'] / 1000).date(), sm['name'])
            n = nights.setdefault(key, {'start': sm['start'], 'name': sm['name'], 'roster': set()})
            n['roster'].update(sm['roster'])
            n['start'] = min(n['start'], sm['start'])
        return sorted(nights.values(), key=lambda n: n['start'])

    def attendance(self):
        """Raid attendance across all raid nights."""
        raids = [self.run_summary_cached(r) for r in self.runs if r.get('kind') == 'raid']
        nights = {}
        for sm in raids:
            key = (datetime.fromtimestamp(sm['start'] / 1000).date(), sm['name'])
            nights.setdefault(key, set()).update(sm['roster'])
        total = len(nights)
        counts = {}
        for names in nights.values():
            for n in names:
                counts[n] = counts.get(n, 0) + 1
        return total, sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))

    def loot_by_player(self):
        out = {}
        for r in self.runs:
            if r.get('kind') != 'raid':
                continue
            for l in self.run_summary_cached(r)['loot']:
                out.setdefault(l['who'], []).append(dict(l, raid=r['name']))
        return sorted(out.items(), key=lambda kv: (-len(kv[1]), kv[0]))

    def player_history(self):
        """Every player's raid boss kills over time: per kill DPS/HPS, per week, per boss."""
        if hasattr(self, '_phist'):
            return self._phist
        out = {}
        for r in self.runs:
            if r.get('kind') != 'raid':  # raid bosses only: a level 70 soloing an old dungeon boss would swamp the numbers
                continue
            for f in self.run_fights(r):
                if f['kind'] != 'boss' or not f['success'] or f.get('encounter_id') in HOLIDAY_ENCS:
                    continue
                sec = fight_dur(f) / 1000
                wk = week_start(f['start'])
                for g, st in f['players'].items():
                    p = self.players.get(g) or {}
                    name = st['name']
                    h = out.setdefault(name, {'name': name, 'cls': p.get('cls'), 'kills': [], 'weeks': {}, 'bosses': {}, 'runs': set()})
                    if p.get('cls'):
                        h['cls'] = p['cls']
                    k = {'ts': f['start'], 'boss': f['name'], 'run': r['name'], 'run_id': r['id'], 'fight_id': f['id'], 'kind': r.get('kind'),
                         'dmg': st['dmg'], 'heal': st['heal'], 'dps': st['dmg'] / sec, 'hps': st['heal'] / sec, 'time': sec, 'deaths': st['deaths']}
                    h['kills'].append(k)
                    h['runs'].add(r['id'])
                    w = h['weeks'].setdefault(wk, {'dmg': 0, 'heal': 0, 'time': 0, 'kills': 0})
                    w['dmg'] += st['dmg']; w['heal'] += st['heal']; w['time'] += sec; w['kills'] += 1
                    h['bosses'].setdefault(f['name'], []).append(k)
        for h in out.values():
            t = sum(k['time'] for k in h['kills']) or 1
            h['dmg'] = sum(k['dmg'] for k in h['kills'])
            h['heal'] = sum(k['heal'] for k in h['kills'])
            h['dps'], h['hps'] = h['dmg'] / t, h['heal'] / t
            h['healer'] = h['heal'] > h['dmg']
            key = 'hps' if h['healer'] else 'dps'
            h['best'] = max(h['kills'], key=lambda k: k[key]) if h['kills'] else None
            h['trend'] = [(wk, (w['heal'] if h['healer'] else w['dmg']) / max(1, w['time'])) for wk, w in sorted(h['weeks'].items())]
            h['runs'] = len(h['runs'])
        self._phist = out
        return out

    def week_top(self, wk_start, n=3):
        """The best average DPS and HPS on boss kills in one reset week."""
        dps, hps = [], []
        for h in self.player_history().values():
            w = h['weeks'].get(wk_start)
            if not w or not w['time']:
                continue
            if w['dmg'] > w['heal']:
                dps.append((w['dmg'] / w['time'], h))
            elif w['heal']:
                hps.append((w['heal'] / w['time'], h))
        return sorted(dps, key=lambda x: -x[0])[:n], sorted(hps, key=lambda x: -x[0])[:n]

    def boss_history(self):
        """Every boss you've fought: kills, wipes, best and latest kill time."""
        out = {}
        for f in self.fights:
            if f['kind'] != 'boss':
                continue
            if f.get('encounter_id') in HOLIDAY_ENCS:
                continue
            key = f.get('encounter_id') or f['name']
            b = out.setdefault(key, {'name': f['name'], 'kills': [], 'wipes': 0, 'pulls': [], 'weeks': {}})
            b['pulls'].append(f)
            w = b['weeks'].setdefault(week_start(f['start']), {'kills': 0, 'wipes': 0, 'best': None})
            if f['success']:
                b['kills'].append(f)
                w['kills'] += 1
                w['best'] = min(fight_dur(f), w['best'] or fight_dur(f))
            else:
                b['wipes'] += 1
                w['wipes'] += 1
        for b in out.values():
            b['best'] = min((fight_dur(k) for k in b['kills']), default=None)
            b['latest'] = fight_dur(b['kills'][-1]) if b['kills'] else None
        return sorted(out.values(), key=lambda b: (-(b['pulls'][-1]['start'] if b['pulls'] else 0)))


# ---------------------------------------------------------------- sharing: Discord text

def _cut(lines, limit=DISCORD_LIMIT):
    out, n = [], 0
    for l in lines:
        if n + len(l) + 1 > limit:
            out.append('…')
            break
        out.append(l)
        n += len(l) + 1
    return '\n'.join(out)


def run_header(sm):
    bits = [day_label(sm['start']), span(sm['end'] - sm['start'])]
    if sm['kind'] in ('raid', 'dungeon') and sm['bosses']:
        bits.append(f"{sm['kills']}/{sm['known_bosses']} bosses" if sm['known_bosses'] else plural(sm['kills'], 'boss').replace('bosss', 'bosses'))
        if sm['wipes']:
            bits.append(plural(sm['wipes'], 'wipe'))
    for name, n in sm.get('holiday') or ():
        bits.append(f"{name} ×{n}" if n > 1 else name)
    if sm.get('result'):
        bits.append('Win' if sm['result'] == 'win' else 'Loss')
    title = (sm.get('difficulty') + ' ' if sm.get('difficulty') and sm['kind'] == 'dungeon' and 'Heroic' in (sm.get('difficulty') or '') else '') + sm['name']
    return title, bits


def _fits(lines, block, limit=DISCORD_LIMIT):
    return len('\n'.join(lines + block)) <= limit


def group_table(players, kind='raid'):
    """The whole group as a fixed-width table (Discord shows code blocks in a monospace font)."""
    if not players:
        return []
    nw = min(16, max(6, max(len(p['name']) for p in players)))
    heals = any(p['heal'] for p in players)
    head = f"{'Player':<{nw}} {'DPS':>6} {'Damage':>7}" + (f" {'HPS':>5} {'Healing':>7}" if heals else '') + f" {'Died':>4}"
    out = ['```', head]
    for p in players:
        dps = f"{round(p['dps']):,}" if p['dmg'] else '–'
        dmg = fmt(p['dmg']) if p['dmg'] else '–'
        line = f"{p['name'][:nw]:<{nw}} {dps:>6} {dmg:>7}"
        if heals:
            hps = f"{round(p['hps']):,}" if p['heal'] else '–'
            heal = fmt(p['heal']) if p['heal'] else '–'
            line += f" {hps:>5} {heal:>7}"
        line += f" {p['deaths'] or '–':>4}"
        out.append(line)
    out.append('```')
    return out


def discord_run(sm, top=None):
    """The whole group's night: bosses, every player's numbers, deaths and loot."""
    title, bits = run_header(sm)
    lines = [f"**{title}** · " + ' · '.join(bits)]
    if sm['bosses']:
        lines.append('')
        for b in sm['bosses']:
            pips = ''.join('✅' if a['success'] else '❌' for a in b['attempts'])
            extra = []
            if b['kill']:
                extra.append(f"{dur(fight_dur(b['kill']))}")
            wipes = [f"{round(a['boss_hp'] * 100)}%" for a in b['wipes'] if a.get('boss_hp') is not None]
            if wipes:
                extra.append('wipes at ' + ', '.join(wipes))
            lines.append(f"{pips} {b['name']}" + (f" — {' · '.join(extra)}" if extra else ''))
    players = sorted(sm['players'], key=lambda p: -p['dps'])
    if top:
        players = players[:top]
    table = group_table(players, sm['kind'])
    while table and not _fits(lines + [''], table) and len(players) > 5:
        players = players[:-1]  # very big raids: drop the bottom rows rather than break the table
        table = group_table(players, sm['kind'])
    if table:
        scope = 'boss fights' if sm.get('scope') == 'boss' else 'all fights'
        lines += ['', f'**Group** ({scope})'] + table
    if sm['records'] and _fits(lines, ['🏆 ' + ' · '.join(sm['records'][:4])]):
        lines.append('🏆 ' + ' · '.join(sm['records'][:4]))
    if sm['loot']:
        block = ['**Loot**']
        for l in sm['loot']:
            line = f"• {l['name']} → {l['who']}"
            if not _fits(lines, block + [line, '• …and more']):
                block.append(f"• …and {len(sm['loot']) - len(block) + 1} more")
                break
            block.append(line)
        if len(block) > 1 and _fits(lines, [''] + block):
            lines += [''] + block
    return _cut(lines)


def player_header(ps):
    sm = ps['run_summary']
    title, bits = run_header(sm)
    cls = (ps.get('cls') or '').title()
    return f"{ps['name']}" + (f" ({cls})" if cls else ''), f"{title} · {day_label(sm['start'])}"


def discord_player(ps):
    """One person's numbers for one run, ready to paste."""
    me = ps['player']
    who, where = player_header(ps)
    lines = [f"**{who}** · {where}"]
    bits = []
    if me['dmg']:
        bits.append(f"DPS **{round(me['dps']):,}**" + (f" (#{ps['rank_dps']} of {ps['of_dps']})" if ps['rank_dps'] else '') + f" · {fmt(me['dmg'])} damage")
    if me['heal']:
        bits.append(f"HPS **{round(me['hps']):,}**" + (f" (#{ps['rank_hps']} of {ps['of_hps']})" if ps['rank_hps'] else '') + f" · {fmt(me['heal'])} healing")
    bits.append(f"Deaths {me['deaths']}" + (f" · Interrupts {me['interrupts']}" if me['interrupts'] else '') + (f" · Dispels {me['dispels']}" if me['dispels'] else ''))
    lines += bits
    boss_rows = [r for r in ps['fights'] if r['kind'] == 'boss']
    if boss_rows:
        lines.append('')
        for r in boss_rows:
            mark = '✅' if r['success'] else '❌'
            val = f"{round(r['dps']):,} dps" if r['dmg'] >= r['heal'] else f"{round(r['hps']):,} hps"
            lines.append(f"{mark} {r['name']}" + (f" #{r['attempt']}" if (r['attempt'] or 1) > 1 else '') + f" — {val}" + (' 💀' if r['deaths'] else ''))
    total_d = sum(v for _, v in ps['dmg_by']) or 1
    if ps['dmg_by']:
        lines += ['', '**Damage by ability** ' + ' · '.join(f"{k} {round(100 * v / total_d)}%" for k, v in ps['dmg_by'][:5])]
    total_h = sum(v for _, v in ps['heal_by']) or 1
    if ps['heal_by']:
        lines.append('**Healing by ability** ' + ' · '.join(f"{k} {round(100 * v / total_h)}%" for k, v in ps['heal_by'][:5]))
    if ps['cons_by']:
        lines.append('**Consumables** ' + ', '.join(f"{k} ×{v}" for k, v in ps['cons_by'][:6]))
    if ps['deaths']:
        lines.append('**Deaths** ' + ', '.join(f"{d['fight']} ({d.get('spell') or '?'})" for d in ps['deaths'][:6]))
    if ps['loot']:
        lines.append('**Loot** ' + ', '.join(l['name'] for l in ps['loot'][:8]))
    return _cut(lines)


def discord_session(ss):
    s = ss['session']
    lines = [f"**Session · {day_label(ss['start'])}** · {clock(ss['start'])}–{clock(ss['end'])} · {span(ss['duration'])}"]
    for kind in KIND_ORDER:
        for sm in ss['by_kind'].get(kind, []):
            title, bits = run_header(sm)
            lines.append(f"• **{title}** · " + ' · '.join(bits[1:]))
    if ss['money_in']:
        g = f"💰 {gold(ss['money_in'])} looted"
        if ss['gold_per_hour']:
            g += f" ({gold(ss['gold_per_hour'])}/hour)"
        lines.append(g)
    if ss['pvp']['matches']:
        p = ss['pvp']
        lines.append(f"⚔️ {p['matches']} PvP match{'es' if p['matches'] != 1 else ''}" + (f" · {p['wins']}W {p['losses']}L" if p['wins'] or p['losses'] else ''))
    progress = []
    if ss.get('honor'):
        progress.append(f"{ss['honor']:,} honor")
    for faction, n in (ss.get('reputation') or [])[:3]:
        progress.append(f"{'+' if n >= 0 else ''}{n:,} {faction}")
    for name, n in (ss.get('currency') or {}).items():
        progress.append(f"+{n} {name}")
    if ss.get('quests_done'):
        progress.append(plural(ss['quests_done'], 'quest'))
    if progress:
        lines.append('📈 ' + ' · '.join(progress))
    epics = [l for sm in ss['runs'] for l in sm['loot'] if (l['q'] or 0) >= 4] + [l for l in ss['farm_loot'] if (l['q'] or 0) >= 4]
    if epics:
        lines.append('🟣 ' + ', '.join(f"{l['name']} → {l['who']}" for l in epics[:8]))
    return _cut(lines)


# ---------------------------------------------------------------- sharing: reports and spreadsheets

def cell_spec(text, color=None, bold=False):
    return {'text': str(text), 'color': color, 'bold': bold}


def report_run(sm, class_color=lambda c: None, quality_color=lambda q: None):
    title, bits = run_header(sm)
    doc = {'title': title, 'subtitle': ' · '.join(bits), 'generated': datetime.now().strftime('%Y-%m-%d %H:%M'), 'stats': [], 'sections': []}
    st = doc['stats']
    if sm['bosses']:
        st.append({'value': f"{sm['kills']}" + (f"/{sm['known_bosses']}" if sm['known_bosses'] else ''), 'label': 'Bosses killed', 'tone': None})
        st.append({'value': str(sm['wipes']), 'label': 'Wipes', 'tone': 'wipe' if sm['wipes'] else None})
        st.append({'value': dur(sm['wipe_time']), 'label': 'Time spent on wipes', 'tone': None})
    if sm.get('result'):
        st.append({'value': 'Win' if sm['result'] == 'win' else 'Loss', 'label': 'Result', 'tone': 'kill' if sm['result'] == 'win' else 'wipe'})
    st.append({'value': str(len(sm['deaths'])), 'label': 'Deaths', 'tone': None})
    st.append({'value': span(sm['end'] - sm['start']), 'label': 'Total time', 'tone': None})
    if sm['bosses']:
        doc['sections'].append({'title': 'Bosses', 'kind': 'bosses', 'bosses': [
            {'name': b['name'], 'attempts': [{'kill': a['success'], 'hp': a.get('boss_hp'), 'duration': dur(fight_dur(a))} for a in b['attempts']],
             'note': f"{dur(fight_dur(b['kill']))} kill" if b['kill'] else ('not killed' if b['attempts'] else '')} for b in sm['bosses']]})
    rows = []
    for p in sm['players']:
        c = class_color(p['cls'])
        z = lambda v, txt=None: (txt if txt is not None else f'{v:,}') if v else '–'
        rows.append([cell_spec(p['name'], c, True), z(p['dmg'], f"{round(p['dps']):,}"), z(p['dmg'], fmt(p['dmg'])), z(p['heal'], f"{round(p['hps']):,}"),
                     z(p['heal'], fmt(p['heal'])), z(p['deaths']), z(p['interrupts']), z(p['dispels']), z(p['cons']), z(p['avoid'], fmt(p['avoid']))])
    doc['sections'].append({'title': 'Raid members' if sm['kind'] == 'raid' else 'Group', 'kind': 'table',
                            'columns': [{'label': 'Player', 'align': 'left'}] + [{'label': l, 'align': 'right'} for l in
                                        ['DPS', 'Damage', 'HPS', 'Healing', 'Deaths', 'Interrupts', 'Dispels', 'Consumables', 'Avoidable dmg']],
                            'rows': rows, 'note': 'DPS and HPS cover boss fights' if sm.get('scope') == 'boss' else 'DPS and HPS cover every fight'})
    if sm['deaths']:
        doc['sections'].append({'title': 'Deaths', 'kind': 'table', 'columns': [{'label': 'Fight', 'align': 'left'}, {'label': 'Time', 'align': 'right'},
                                {'label': 'Player', 'align': 'left'}, {'label': 'Killed by', 'align': 'left'}],
                                'rows': [[d['fight'], dur(d['at']), cell_spec(d['name'], None, True), f"{d.get('spell') or '?'} ({d.get('killer') or '?'})"] for d in sm['deaths']]})
    if sm['loot']:
        doc['sections'].append({'title': 'Loot', 'kind': 'table', 'columns': [{'label': 'Time', 'align': 'left'}, {'label': 'Item', 'align': 'left'}, {'label': 'Looted by', 'align': 'left'}],
                                'rows': [[clock(l['ts']), cell_spec(f"[{l['name']}]", quality_color(l['q']), True), l['who']] for l in sm['loot']]})
    if sm['records']:
        doc['sections'].append({'title': 'Records set', 'kind': 'list', 'items': sm['records']})
    if sm['roster']:
        doc['sections'].append({'title': 'Who was there', 'kind': 'text', 'text': ', '.join(sm['roster'])})
    return doc


def sheets_run(sm):
    players = [[p['name'], p['cls'] or '', round(p['dps']), p['dmg'], round(p['hps']), p['heal'], p['deaths'], p['interrupts'], p['dispels'], p['cons'], p['avoid'], p['taken']]
               for p in sm['players']]
    fights = [[f['name'], 'Boss' if f['kind'] == 'boss' else 'Trash', ('Kill' if f['success'] else 'Wipe') if f['kind'] == 'boss' else '',
               datetime.fromtimestamp(f['start'] / 1000).strftime('%H:%M:%S'), round(fight_dur(f) / 1000),
               round(f['boss_hp'] * 100) if f.get('boss_hp') is not None and not f['success'] else '', len(f['deaths']),
               sum(s['dmg'] for s in f['players'].values())] for f in sm['fights']]
    per_fight = []
    for f in sm['fights']:
        sec = fight_dur(f) / 1000
        for s in f['players'].values():
            per_fight.append([f['name'], datetime.fromtimestamp(f['start'] / 1000).strftime('%H:%M:%S'), s['name'], s['dmg'], round(s['dmg'] / sec),
                              s['heal'], round(s['heal'] / sec), s['taken'], s['deaths'], s['interrupts'], s['dispels']])
    deaths = [[d['fight'], round(d['at'] / 1000), d['name'], d.get('spell') or '', d.get('killer') or '', d.get('amount') or 0] for d in sm['deaths']]
    loot = [[datetime.fromtimestamp(l['ts'] / 1000).strftime('%H:%M:%S'), l['name'], l['who'], l['count']] for l in sm['loot']]
    return [
        ('Players', ['Player', 'Class', 'DPS', 'Damage', 'HPS', 'Healing', 'Deaths', 'Interrupts', 'Dispels', 'Consumables', 'Avoidable damage', 'Damage taken'], players),
        ('Fights', ['Fight', 'Type', 'Result', 'Start', 'Seconds', 'Boss health left %', 'Deaths', 'Damage'], fights),
        ('Per fight', ['Fight', 'Start', 'Player', 'Damage', 'DPS', 'Healing', 'HPS', 'Damage taken', 'Deaths', 'Interrupts', 'Dispels'], per_fight),
        ('Deaths', ['Fight', 'Seconds in', 'Player', 'Killed by spell', 'Killed by', 'Last hit'], deaths),
        ('Loot', ['Time', 'Item', 'Looted by', 'Count'], loot),
    ]


def report_session(ss, quality_color=lambda q: None):
    doc = {'title': f"Session · {day_label(ss['start'])}", 'subtitle': f"{clock(ss['start'])} – {clock(ss['end'])} · {span(ss['duration'])}",
           'generated': datetime.now().strftime('%Y-%m-%d %H:%M'), 'stats': [], 'sections': []}
    raids = len(ss['by_kind'].get('raid', []))
    dungeons = len(ss['by_kind'].get('dungeon', []))
    doc['stats'] = [{'value': str(raids), 'label': 'Raids', 'tone': None}, {'value': str(dungeons), 'label': 'Dungeons', 'tone': None},
                    {'value': str(ss['kills']), 'label': 'Bosses killed', 'tone': None},
                    {'value': str(ss['wipes']), 'label': 'Wipes', 'tone': 'wipe' if ss['wipes'] else None},
                    {'value': gold(ss['money_in']), 'label': 'Gold looted', 'tone': None}]
    rows = []
    for kind in KIND_ORDER:
        for sm in ss['by_kind'].get(kind, []):
            title, bits = run_header(sm)
            rows.append([KIND_LABEL.get(kind, kind), cell_spec(title, None, True), clock(sm['start']), ' · '.join(bits[1:])])
    if rows:
        doc['sections'].append({'title': 'What you did', 'kind': 'table', 'columns': [{'label': 'Type', 'align': 'left'}, {'label': 'Where', 'align': 'left'},
                                {'label': 'Started', 'align': 'left'}, {'label': 'Result', 'align': 'left'}], 'rows': rows})
    if ss['money_in'] or ss['farm_loot']:
        items = []
        if ss['money_in']:
            items.append(f"Gold looted: {gold(ss['money_in'])}" + (f" ({gold(ss['gold_per_hour'])} per hour)" if ss['gold_per_hour'] else ''))
        if ss['money_out']:
            items.append(f"Gold spent: {gold(ss['money_out'])}")
        if ss.get('money_net') is not None:
            items.append(f"Net change in your gold: {gold(ss['money_net'])}")
        items += [cell_spec(f"[{l['name']}]" + (f" ×{l['count']}" if l['count'] > 1 else ''), quality_color(l['q']), True) for l in ss['farm_loot'][:40]]
        doc['sections'].append({'title': 'Farming', 'kind': 'list', 'items': items})
    return doc


def sheets_session(ss):
    runs = []
    for sm in ss['runs']:
        runs.append([KIND_LABEL.get(sm['kind'], sm['kind']), sm['name'], datetime.fromtimestamp(sm['start'] / 1000).strftime('%Y-%m-%d %H:%M'),
                     round((sm['end'] - sm['start']) / 60000), sm['kills'], sm['wipes'], len(sm['deaths']), len(sm['loot']), sm.get('result') or ''])
    loot = [[datetime.fromtimestamp(l['ts'] / 1000).strftime('%H:%M:%S'), l['name'], l['who'], l['count']] for sm in ss['runs'] for l in sm['loot']]
    loot += [[datetime.fromtimestamp(l['ts'] / 1000).strftime('%H:%M:%S'), l['name'], l['who'], l['count']] for l in ss['farm_loot']]
    return [('Runs', ['Type', 'Where', 'Started', 'Minutes', 'Bosses killed', 'Wipes', 'Deaths', 'Loot', 'Result'], runs),
            ('Loot', ['Time', 'Item', 'Looted by', 'Count'], loot)]


def report_player(ps, class_color=lambda c: None, quality_color=lambda q: None):
    me = ps['player']
    who, where = player_header(ps)
    doc = {'title': who, 'subtitle': where, 'generated': datetime.now().strftime('%Y-%m-%d %H:%M'), 'stats': [], 'sections': [],
           'title_color': class_color(ps.get('cls'))}
    st = doc['stats']
    if me['dmg']:
        st.append({'value': f"{round(me['dps']):,}", 'label': 'DPS' + (f" · #{ps['rank_dps']} of {ps['of_dps']}" if ps['rank_dps'] else ''), 'tone': None})
        st.append({'value': fmt(me['dmg']), 'label': 'Damage', 'tone': None})
    if me['heal']:
        st.append({'value': f"{round(me['hps']):,}", 'label': 'HPS' + (f" · #{ps['rank_hps']} of {ps['of_hps']}" if ps['rank_hps'] else ''), 'tone': None})
        st.append({'value': fmt(me['heal']), 'label': 'Healing', 'tone': None})
    st.append({'value': str(me['deaths']), 'label': 'Deaths', 'tone': 'wipe' if me['deaths'] else None})
    z = lambda v, txt=None: (txt if txt is not None else f'{v:,}') if v else '–'
    rows = []
    for r in ps['fights']:
        res = ('Kill' if r['success'] else 'Wipe') if r['kind'] == 'boss' else 'Trash'
        rows.append([cell_spec(r['name'] + (f" #{r['attempt']}" if (r['attempt'] or 1) > 1 else ''), None, True), res, dur(r['time']),
                     z(r['dmg'], f"{round(r['dps']):,}"), z(r['dmg'], fmt(r['dmg'])), z(r['heal'], f"{round(r['hps']):,}"), z(r['heal'], fmt(r['heal'])), z(r['deaths'])])
    if rows:
        doc['sections'].append({'title': 'Fights', 'kind': 'table', 'columns': [{'label': 'Fight', 'align': 'left'}, {'label': 'Result', 'align': 'left'}] +
                                [{'label': l, 'align': 'right'} for l in ('Time', 'DPS', 'Damage', 'HPS', 'Healing', 'Deaths')], 'rows': rows})
    for title, items in (('Damage by ability', ps['dmg_by']), ('Healing by ability', ps['heal_by'])):
        total = sum(v for _, v in items) or 1
        if items:
            doc['sections'].append({'title': title, 'kind': 'table', 'columns': [{'label': 'Ability', 'align': 'left'}, {'label': 'Amount', 'align': 'right'}, {'label': 'Share', 'align': 'right'}],
                                    'rows': [[k, fmt(v), f'{100 * v / total:.0f}%'] for k, v in items[:15]]})
    if ps['deaths']:
        doc['sections'].append({'title': 'Deaths', 'kind': 'table', 'columns': [{'label': 'Fight', 'align': 'left'}, {'label': 'Time', 'align': 'right'}, {'label': 'Killed by', 'align': 'left'}],
                                'rows': [[d['fight'], dur(d['at']), f"{d.get('spell') or '?'} ({d.get('killer') or '?'})"] for d in ps['deaths']]})
    if ps['cons_by']:
        doc['sections'].append({'title': 'Consumables', 'kind': 'list', 'items': [f'{k} ×{v}' for k, v in ps['cons_by']]})
    if ps['loot']:
        doc['sections'].append({'title': 'Loot', 'kind': 'list', 'items': [cell_spec(f"[{l['name']}]", quality_color(l['q']), True) for l in ps['loot']]})
    return doc


def sheets_player(ps):
    fights = [[r['name'], r['attempt'] or '', ('Kill' if r['success'] else 'Wipe') if r['kind'] == 'boss' else 'Trash',
               datetime.fromtimestamp(r['fight']['start'] / 1000).strftime('%H:%M:%S'), round(r['time'] / 1000), r['dmg'], round(r['dps']),
               r['heal'], round(r['hps']), r['taken'], r['deaths']] for r in ps['fights']]
    abil = [['Damage', k, v] for k, v in ps['dmg_by']] + [['Healing', k, v] for k, v in ps['heal_by']]
    deaths = [[d['fight'], round(d['at'] / 1000), d.get('spell') or '', d.get('killer') or '', d.get('amount') or 0] for d in ps['deaths']]
    return [('Fights', ['Fight', 'Attempt', 'Result', 'Start', 'Seconds', 'Damage', 'DPS', 'Healing', 'HPS', 'Damage taken', 'Deaths'], fights),
            ('Abilities', ['Type', 'Ability', 'Amount'], abil),
            ('Deaths', ['Fight', 'Seconds in', 'Killed by spell', 'Killed by', 'Last hit'], deaths),
            ('Consumables', ['Item', 'Count'], [[k, v] for k, v in ps['cons_by']]),
            ('Loot', ['Item', 'Count'], [[l['name'], l['count']] for l in ps['loot']])]


def discord_week(wk, top):
    """One reset week, ready to paste: what you ran, kills and wipes, the best performers, who came."""
    dps, hps = top
    end = datetime.fromtimestamp(wk['start'] / 1000) + timedelta(days=6)
    lines = [f"**Week of {day_label(wk['start'])} – {end.strftime('%a, %b ')}{end.day}** · {plural(wk['kills'], 'kill')} · {plural(wk['wipes'], 'wipe')}"]
    for sm in sorted(wk['runs'], key=lambda r: r['start']):
        if sm['kind'] not in ('raid', 'dungeon'):
            continue
        title, bits = run_header(sm)
        lines.append(f"• **{title}** · " + ' · '.join(bits))
    if dps:
        lines += ['', '**Top damage on bosses** ' + ' · '.join(f"{i + 1}. {h['name']} {round(v):,}" for i, (v, h) in enumerate(dps))]
    if hps:
        lines.append('**Top healing on bosses** ' + ' · '.join(f"{i + 1}. {h['name']} {round(v):,}" for i, (v, h) in enumerate(hps)))
    if wk['attendance']:
        lines += ['', '**Raiders** ' + ', '.join(sorted(wk['attendance']))]
    if wk['loot']:
        lines.append(f"**Raid drops** {len(wk['loot'])}")
    return _cut(lines)
