"""Entry point the Android app calls: one Api for the whole app (see api.py)."""
from api import Api


def make_api(data_dir, items_path):
    return Api(data_dir, items_path)
