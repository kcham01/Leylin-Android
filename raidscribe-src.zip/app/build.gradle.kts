plugins {
    id("com.android.application")
    id("com.chaquo.python")
}

android {
    namespace = "app.raidscribe"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.raidscribe"
        minSdk = 26
        targetSdk = 35
        versionCode = (System.getenv("VERSION_CODE") ?: "1").toInt()
        versionName = System.getenv("VERSION_NAME") ?: "1.0"
        ndk {
            // phones (arm64) and the test emulator (x86_64)
            abiFilters += listOf("arm64-v8a", "x86_64")
        }
    }

    signingConfigs {
        create("release") {
            // The same key every build, so new versions install over old ones.
            storeFile = file("../raidscribe-release.jks")
            storePassword = "raidscribe-android"
            keyAlias = "raidscribe"
            keyPassword = "raidscribe-android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    androidResources {
        noCompress += listOf("dat")
    }
}

chaquopy {
    defaultConfig {
        version = "3.12"
    }
}

dependencies {
    implementation("androidx.core:core:1.13.1")
}
