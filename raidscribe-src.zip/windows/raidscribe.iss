; Raidscribe for Windows: the installer (Inno Setup 6). Built by ci/windows.sh:
;   ISCC.exe /DAppVersion=1.0.0-beta /DNumVersion=1.0.0.21 windows\raidscribe.iss
; Installs for the current user only (no admin prompt) into %LOCALAPPDATA%\Programs\Raidscribe,
; adds a Start menu entry (and a desktop one if ticked) and an uninstaller in Settings > Apps.
; Settings and history (%LOCALAPPDATA%\Raidscribe) are kept on uninstall, like most apps.

#ifndef AppVersion
  #define AppVersion "0.0.0"
#endif
#ifndef NumVersion
  #define NumVersion "0.0.0.0"
#endif

[Setup]
; The AppId never changes: it's how Windows knows a new version is an update of the same app.
AppId={{620482ED-1406-4D08-969E-B7BBD7D12839}
AppName=Raidscribe
AppVersion={#AppVersion}
AppVerName=Raidscribe {#AppVersion}
AppPublisher=Raidscribe
AppPublisherURL=https://github.com/kcham01/Raidscribe
AppSupportURL=https://github.com/kcham01/Raidscribe
AppComments=Combat and chat log reader for World of Warcraft: Burning Crusade Classic Anniversary
VersionInfoVersion={#NumVersion}
VersionInfoDescription=Raidscribe installer
VersionInfoProductName=Raidscribe
DefaultDirName={autopf}\Raidscribe
DisableProgramGroupPage=yes
DisableDirPage=auto
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0
OutputDir=..\out
OutputBaseFilename=Raidscribe-Setup-{#AppVersion}
SetupIconFile=raidscribe.ico
UninstallDisplayIcon={app}\Raidscribe.exe
UninstallDisplayName=Raidscribe
WizardStyle=modern
WizardImageFile=wizard-1x.bmp,wizard-2x.bmp
WizardSmallImageFile=wizard-small-1x.bmp,wizard-small-2x.bmp
Compression=lzma2/max
SolidCompression=yes
CloseApplications=yes
RestartApplications=no
SetupLogging=yes

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; Flags: unchecked

[Files]
Source: "..\build\dist\Raidscribe\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\Raidscribe"; Filename: "{app}\Raidscribe.exe"; AppUserModelID: "Raidscribe.LogReader"; Comment: "WoW combat and chat log reader"
Name: "{autodesktop}\Raidscribe"; Filename: "{app}\Raidscribe.exe"; AppUserModelID: "Raidscribe.LogReader"; Tasks: desktopicon

[Run]
Filename: "{app}\Raidscribe.exe"; Description: "Open Raidscribe"; Flags: nowait postinstall skipifsilent
