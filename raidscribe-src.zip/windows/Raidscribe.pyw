"""
Raidscribe: reads your World of Warcraft combat and chat logs and shows fights, wipes,
instance runs, loot and rolls, updating live while you play.

Most people should use the Windows installer (Raidscribe-Setup.exe) instead. To run this file directly,
double-click it (needs Python 3.9 or newer from python.org). It only uses what comes with Python.
It finds World of Warcraft by itself; if it can't, it asks you to choose the folder.
"""

APP_VERSION = "dev"
APP_BUILD = ""

import csv
import glob
import hashlib
import html
import json
import logging
import math
import os
import pickle
import queue
import re
import struct
import subprocess
import sys
import tempfile
import threading
import time
import tkinter as tk
import tkinter.font as tkfont
import traceback
import urllib.parse
import webbrowser
import zipfile
import zlib
from datetime import datetime
from datetime import datetime, timedelta
from xml.sax.saxutils import escape as xml_escape

# Boss NPC ids for TBC and classic dungeons and raids. The Anniversary client writes no ENCOUNTER_START/END lines,
# so bosses are recognised by which NPCs you fight. instance id -> [(encounter id, boss name, (npc ids, ...)), ...]
# Several ids = a council, a mounted/merged boss or an event with variants (the Opera). Ids are game data (npc and
# encounter ids, as listed by boss-mod addons); negative ids are made up for classic bosses with no encounter id.
BOSS_TABLE = {
    33: [(-3872, 'Deathsworn Captain', (3872,)), (-3886, 'Razorclaw the Butcher', (3886,)), (-3887, 'Baron Silverlaine', (3887,)), (-3914, 'Rethilgore', (3914,)), (-3927, 'Wolf Master Nandos', (3927,)), (-4274, 'Fenrus the Devourer', (4274,)), (-4275, 'Archmage Arugal', (4275,)), (-4278, 'Commander Springvale', (4278,)), (-4279, 'Odo the Blindwatcher', (4279,))],
    34: [(-1663, 'Dextren Ward', (1663,)), (-1666, 'Kam Deepfury', (1666,)), (-1696, 'Targorr the Dread', (1696,)), (-1716, 'Bazil Thredd', (1716,)), (-1717, 'Hamhock', (1717,)), (-1720, 'Bruegal Ironknuckle', (1720,))],
    36: [(2967, "Rhahk'Zor", (644,)), (2968, "Sneed's Shredder", (642, 643)), (2969, 'Gilnid', (1763,)), (2970, 'Mr. Smite', (646,)), (2971, 'Captain Greenskin', (647,)), (2972, 'Edwin Van Cleef', (639,)), (2986, 'Cookie', (645,)), (3676, 'Miner Johnson', (3586,))],
    43: [(585, 'Lady Anacondra', (3671,)), (586, 'Lord Cobrahn', (3669,)), (587, 'Kresh', (3653,)), (588, 'Lord Pythas', (3670,)), (589, 'Skum', (3674,)), (590, 'Lord Serpentis', (3673,)), (591, 'Verdan the Everliving', (5775,)), (592, 'Mutanus the Devourer', (3654,)), (-5912, 'Deviate Faerie Dragon', (5912,))],
    47: [(1659, 'Overload Ramtusk', (4420,)), (1661, 'Charlga Razorflank', (4421,)), (-4422, 'Agathelos the Raging', (4422,)), (-4424, 'Aggem Thorncurse', (4424,)), (-4425, 'Blind Hunter', (4425,)), (-4428, 'Death Speaker Jargba', (4428,)), (-4842, 'Earthcaller Halmgar', (4842,)), (-6168, 'Roogug', (6168,))],
    48: [(2761, 'Ghamoo-Ra', (4887,)), (2762, 'Lady Sarevess', (4831,)), (2763, 'Gelihast', (6243,)), (2765, "Old Serra'kis", (4830,)), (2766, 'Twilight Lord Kelris', (4832,)), (2767, "Aku'mai", (4829,))],
    70: [(547, 'Revelosh', (6910,)), (548, 'The Lost Dwarves', (6906, 6907, 6908)), (549, 'Ironaya', (7228,)), (551, 'Ancient Stone Keeper', (7206,)), (552, 'Galgann Firehammer', (7291,)), (553, 'Grimlok', (4854,)), (554, 'Archaedas', (2748,)), (1887, 'Obsidian Sentinel', (7023,))],
    90: [(-6229, 'Crowd Pummeler 9-60', (6229,)), (-6235, 'Electrocutioner 6000', (6235,)), (-7079, 'Viscous Fallout', (7079,)), (-7361, 'Grubbis', (7361,)), (-7800, 'Mekgineer Thermaplugg', (7800,))],
    109: [(486, 'Dreamscythe', (5721,)), (487, 'Weaver', (5720,)), (488, "Jammal'an the Prophet", (5710,)), (490, 'Morphaz', (5719,)), (491, 'Hazzas', (5722,)), (492, 'Avatar of Hakkar', (8443,)), (493, 'Shade of Eranikus', (5709,)), (3582, "Atal'alarion", (8580,))],
    129: [(-7354, 'Ragglesnout', (7354,)), (-7355, "Tuten'kash", (7355,)), (-7356, 'Plaguemaw the Rotting', (7356,)), (-7357, 'Mordress Fire Eye', (7357,)), (-7358, 'Amnenar the Coldbringer', (7358,)), (-8567, 'Glutton', (8567,))],
    189: [(444, 'Interrogator Vishas', (3983,)), (446, 'Houndmaster Loksey', (3974,)), (447, 'Arcanist Doan', (6487,)), (448, 'Herod', (3975,)), (449, 'High Inquisitor Fairbanks', (4542,)), (450, 'Mograine & Whitemane', (3976, 3977)), (-4543, 'Bloodmage Thalnos', (4543,))],
    209: [(593, 'Hydromancer Velrath', (7795,)), (594, "Gahz'rilla", (7273,)), (595, "Antu'sul", (8127,)), (596, 'Theka the Martyr', (7272,)), (597, "Witch Doctor Zum'rah", (7271,)), (598, "Nekrum & Sezz'ziz", (7275, 7796)), (600, 'Chief Ukorz Sandscalp', (7267,))],
    229: [(267, 'Highlord Omokk', (9196,)), (268, "Shadow Hunter Vosh'gajin", (9236,)), (269, 'War Master Voone', (9237,)), (270, 'Mother Smolderweb', (10596,)), (271, 'Urok Doomhowl', (10584,)), (272, 'Quartermaster Zigris', (9736,)), (273, 'Gizrul', (10268,)), (274, 'Halycon', (10220,)), (275, 'Overlord Wyrmthalak', (9568,)), (-9816, 'Pyroguard Emberseer', (9816,)), (-10264, 'Solakar Flamewreath', (10264,)), (-10339, 'Warchief Rend Blackhand', (10339, 10429)), (-10363, 'General Drakkisath', (10363,)), (-10430, 'The Beast', (10430,)), (-10509, 'Jed Runewatcher', (10509,)), (-10899, 'Goraluk Anvilcrack', (10899,)), (-16042, 'Lord Valthalak', (16042,))],
    230: [(227, 'High Interrogator Gerstahn', (9018,)), (228, 'Lord Roccor', (9025,)), (229, 'Houndmaster Grebmar', (9319,)), (230, 'Ring of Law', (9027, 9028, 9029, 9030, 9031, 9032)), (231, 'Pyromancer Loregrain', (9024,)), (232, 'Lord Incendius', (9017,)), (233, 'Warden Stilgiss', (9041,)), (234, 'Fineous Darkvire', (9056,)), (235, "Bael'Gar", (9016,)), (236, 'General Angerforge', (9033,)), (237, 'Golem Lord Argelmach', (8983,)), (238, 'Hurley Blackbreath', (9537,)), (239, 'Phalanx', (9502,)), (241, 'Plugger Spazzring', (9499,)), (242, 'Ambassador Flamelash', (9156,)), (243, 'The Seven', (9034, 9035, 9036, 9037, 9038, 9039, 9040)), (244, 'Magmus', (9938,)), (245, 'Emperor Dagran Thaurissan', (9019,))],
    249: [(1084, 'Onyxia', (10184,))],
    269: [(1919, 'Aeonus', (17881,)), (1920, 'Chrono Lord Deja', (17879,)), (1921, 'Temporus', (17880,))],
    289: [(-1853, 'Darkmaster Gandling', (1853,)), (-10432, 'Vectus', (10432,)), (-10433, 'Marduk Blackpool', (10433,)), (-10502, 'Lady Illucia Barov', (10502,)), (-10503, 'Jandice Barov', (10503,)), (-10504, 'Lord Alexei Barov', (10504,)), (-10505, 'Instructor Malicia', (10505,)), (-10506, 'Kirtonos the Herald', (10506,)), (-10507, 'The Ravenian', (10507,)), (-10508, 'Ras Frostwhisper', (10508,)), (-10901, 'Lorekeeper Polkelt', (10901,)), (-11261, 'Doctor Theolen Krastinov', (11261,)), (-11622, 'Rattlegore', (11622,))],
    309: [(784, 'High Priest Venoxis', (14507,)), (785, 'High Priestess Jeklik', (14517,)), (786, "High Priestess Mar'li", (14510,)), (787, 'Bloodlord Mandokir', (11382, 14988)), (788, 'Edge of Madness', (15083,)), (789, 'High Priest Thekal', (11347, 11348, 14509)), (790, "Gahz'ranka", (15114,)), (791, 'High Priestess Arlokk', (14515,)), (792, "Jin'do the Hexxer", (11380,)), (793, 'Hakkar the Soulflayer', (14834,))],
    329: [(472, 'The Unforgiven', (10516,)), (473, 'Hearthsinger Forresten', (10558,)), (474, 'Timmy the Cruel', (10808,)), (475, 'Cannon Master Willey', (10997,)), (476, 'Malor the Zealous', (11032,)), (477, 'Archivist Galford', (10811,)), (478, 'Balnazzar', (10813,)), (479, 'Baroness Anastari', (10436,)), (480, "Nerub'enkan", (10437,)), (481, 'Maleki the Pallid', (10438,)), (482, 'Magistrate Barthilas', (10435,)), (483, 'Ramstein the Gorger', (10439,)), (1885, 'Postmaster Malown', (11143,))],
    349: [(422, 'Noxxion', (13282,)), (423, 'Razorlash', (12258,)), (424, 'Lord Vyletongue', (12236,)), (425, 'Celebras the Cursed', (12225,)), (426, 'Landslide', (12203,)), (427, 'Tinkerer Gizlock', (13601,)), (428, 'Rotgrip', (13596,)), (429, 'Princess Theradras', (12201,))],
    389: [(1443, 'Oggleflint', (11517,)), (1444, 'Jergosh the Invoker', (11518,)), (1445, 'Bazzalan', (11519,)), (1446, 'Taragaman the Hungerer', (11520,))],
    429: [(346, 'Alzzin the Wildshaper', (11492,)), (347, 'Illyanna Ravensoak', (11488,)), (348, 'Magister Kalendris', (11487,)), (349, "Immol'thar", (11496,)), (350, 'Tendris Warpwood', (11489,)), (361, 'Prince Tortheldrin', (11486,)), (362, "Guard Mol'dar", (14326,)), (363, 'Stomper Kreeg', (14322,)), (364, 'Guard Fengus', (14321,)), (365, "Guard Slip'kik", (14323,)), (366, 'Captain Kromcrush', (14325,)), (367, "Cho'Rush the Observer", (14324,)), (368, 'King Gordok', (11501,)), (-11490, 'Zevrim Thornhoof', (11490,)), (-13280, 'Hydrospawn', (13280,)), (-14327, 'Lethtendris', (14327,))],
    469: [(610, 'Razorgore the Untamed', (12435,)), (611, 'Vaelastrasz the Corrupt', (13020,)), (612, 'Broodlord Lashlayer', (12017,)), (613, 'Firemaw', (11983,)), (615, 'Flamegor', (11981,)), (616, 'Chromaggus', (14020,)), (617, 'Nefarian', (11583,)), (-11981, 'Ebonroc and Flamegor', (11981, 14601)), (-14601, 'Ebonroc', (14601,))],
    509: [(718, 'Kurinnaxx', (15348,)), (719, 'General Rajaxx', (15341,)), (720, 'Moam', (15340,)), (721, 'Buru the Gorger', (15370,)), (722, 'Ayamiss the Hunter', (15369,)), (723, 'Ossirian the Unscarred', (15339,))],
    531: [(710, 'Silithid Royalty', (15511, 15543, 15544)), (711, 'Battleguard Sartura', (15516,)), (712, 'Fankriss the Unyielding', (15510,)), (713, 'Viscidus', (15299,)), (714, 'Princess Huhuran', (15509,)), (715, 'Twin Emperors', (15275, 15276)), (716, 'Ouro', (15517,)), (717, "C'Thun", (15589, 15727))],
    532: [(652, 'Attumen the Huntsman', (16151, 16152)), (653, 'Moroes', (15687,)), (654, 'Maiden of Virtue', (16457,)), (655, 'Romulo and Julianne', (17533, 17534)), (655, 'The Big Bad Wolf', (17521,)), (655, 'Wizard of Oz', (18168,)), (656, 'The Curator', (15691,)), (657, 'Terestian Illhoof', (15688,)), (658, 'Shade of Aran', (16524,)), (659, 'Netherspite', (15689,)), (660, 'Chess Event', (21752,)), (661, 'Prince Malchezaar', (15690,)), (662, 'Nightbane', (17225,))],
    533: [(1107, "Anub'Rekhan", (15956,)), (1108, 'Gluth', (15932,)), (1109, 'Gothik the Harvester', (16060,)), (1110, 'Grand Widow Faerlina', (15953,)), (1111, 'Grobbulus', (15931,)), (1112, 'Heigan the Unclean', (15936,)), (1113, 'Instructor Razuvious', (16061,)), (1114, "Kel'Thuzad", (15990,)), (1115, 'Loatheb', (16011,)), (1116, 'Maexxna', (15952,)), (1117, 'Noth the Plaguebringer', (15954,)), (1118, 'Patchwerk', (16028,)), (1119, 'Sapphiron', (15989,)), (1120, 'Thaddius', (15928,)), (1121, 'The Four Horsemen', (16062, 16063, 16064, 16065))],
    534: [(618, 'Rage Winterchill', (17767,)), (619, 'Anetheron', (17808,)), (620, "Kaz'rogal", (17888,)), (621, 'Azgalor', (17842,)), (622, 'Archimonde', (17968,))],
    540: [(1935, 'Blood Guard Porung', (20923,)), (1936, 'Grand Warlock Nethekurse', (16807,)), (1937, "Warbringer O'mrogg", (16809,)), (1938, 'Warchief Kargath Bladefist', (16808,))],
    542: [(1922, 'The Maker', (17381,)), (1923, "Keli'dan the Breaker", (17377,)), (1924, 'Broggok', (17380,))],
    543: [(1891, 'Omor the Unscarred', (17308,)), (1892, 'Nazan & Vazruden', (17307, 17537)), (1893, 'Watchkeeper Gargolmar', (17306,))],
    544: [(651, 'Magtheridon', (17257,))],
    545: [(1942, 'Hydromancer Thespia', (17797,)), (1943, 'Mekgineer Steamrigger', (17796,)), (1944, 'Warlord Kalithresh', (17798,))],
    546: [(1945, "Ghaz'an", (18105,)), (1946, 'Hungarfen', (17770,)), (1947, "Swamplord Musel'ek", (17826,)), (1948, 'The Black Stalker', (17882,))],
    547: [(1939, 'Mennu the Betrayer', (17941,)), (1940, 'Quagmirran', (17942,)), (1941, 'Rokmar the Crackler', (17991,))],
    548: [(623, 'Hydross the Unstable', (21216,)), (624, 'The Lurker Below', (21217,)), (625, 'Leotheras the Blind', (21215,)), (626, 'Fathom-Lord Karathress', (21214,)), (627, 'Morogrim Tidewalker', (21213,)), (628, 'Lady Vashj', (21212,))],
    550: [(730, "Al'ar", (19514,)), (731, 'Void Reaver', (19516,)), (732, 'High Astromancer Solarian', (18805,)), (733, "Kael'thas Sunstrider", (19622,))],
    552: [(1913, 'Dalliah the Doomsayer', (20885,)), (1914, 'Harbinger Skyriss', (20912,)), (1915, 'Wrath-Scryer Soccothrates', (20886,)), (1916, 'Zereketh the Unbound', (20870,))],
    553: [(1925, 'Commander Sarannis', (17976,)), (1926, 'High Botanist Freywinn', (17975,)), (1927, 'Laj', (17980,)), (1928, 'Thorngrin the Tender', (17978,)), (1929, 'Warp Splinter', (17977,))],
    554: [(1930, 'Nethermancer Sepethrea', (19221,)), (1931, 'Pathaleon the Calculator', (19220,)), (1932, 'Mechano-Lord Capacitus', (19219,)), (1933, 'Gatewatcher Gyro-Kill', (19218,)), (1934, 'Gatewatcher Iron-Hand', (19710,))],
    555: [(1908, 'Ambassador Hellmaw', (18731,)), (1909, 'Blackheart the Inciter', (18667,)), (1910, 'Murmur', (18708,)), (1911, 'Grandmaster Vorpil', (18732,))],
    556: [(1902, 'Talon King Ikiss', (18473,)), (1903, 'Darkweaver Syth', (18472,)), (1904, 'Anzu', (23035,))],
    557: [(250, 'Yor', (22930,)), (1899, 'Nexus-Prince Shaffar', (18344,)), (1900, 'Pandemonius', (18341,)), (1901, 'Tavarok', (18343,))],
    558: [(1889, 'Exarch Maladaar', (18373,)), (1890, 'Shirrak the Dead Watcher', (18371,))],
    560: [(1905, 'Lieutenant Drake', (17848,)), (1906, 'Epoch Hunter', (18096,)), (1907, 'Captain Skarloc', (17862,))],
    564: [(601, "High Warlord Naj'entus", (22887,)), (602, 'Supremus', (22898,)), (603, 'Shade of Akama', (22841,)), (604, 'Teron Gorefiend', (22871,)), (605, 'Gurtogg Bloodboil', (22948,)), (606, 'Essence of Souls', (23420,)), (607, 'Mother Shahraz', (22947,)), (608, 'Illidari Council', (22949, 22950, 22951, 22952)), (609, 'Illidan Stormrage', (22917,))],
    565: [(649, 'High King Maulgar', (18831, 18832, 18834, 18835, 18836)), (650, 'Gruul the Dragonkiller', (19044,))],
    568: [(1189, "Akil'zon", (23574,)), (1190, 'Nalorakk', (23576,)), (1191, "Jan'alai", (23578,)), (1192, 'Halazzi', (23577,)), (1193, 'Hex Lord Malacrass', (24239,)), (1194, "Zul'jin", (23863,))],
    580: [(724, 'Kalecgos', (24850,)), (725, 'Brutallus', (24882,)), (726, 'Felmyst', (25038,)), (727, 'Eredar Twins', (25165, 25166)), (728, "M'uru", (25741,)), (729, "Kil'jaeden", (25315,))],
    585: [(1894, "Kael'thas Sunstrider (Party)", (24664,)), (1895, 'Priestess Delrissa', (24560,)), (1897, 'Selin Fireheart', (24723,)), (1898, 'Vexallus', (24744,))],
}
BOSS_NPC = {npc: (enc, name, inst) for inst, lst in BOSS_TABLE.items() for enc, name, npcs in lst for npc in npcs}
# holiday bosses: kills are counted, but they don't count toward an instance's boss total
HOLIDAY_BOSSES = [(189, -23682, 'Headless Horseman', (23682, 23775)), (547, -25740, 'Ahune', (25740,)),
                  (230, -23872, 'Coren Direbrew', (23872,))]
for _inst, _enc, _name, _npcs in HOLIDAY_BOSSES:
    for _n in _npcs:
        BOSS_NPC[_n] = (_enc, _name, _inst)
for _n in (15550,):  # Attumen on foot (before he mounts Midnight)
    BOSS_NPC[_n] = (652, 'Attumen the Huntsman', 532)

# classic dungeons and raids (TBC ones are named in activities.CATALOG)
CLASSIC_INSTANCES = {
    389: ('Ragefire Chasm', 'dungeon', 5), 36: ('The Deadmines', 'dungeon', 5), 43: ('Wailing Caverns', 'dungeon', 5),
    33: ('Shadowfang Keep', 'dungeon', 5), 34: ('The Stockade', 'dungeon', 5), 48: ('Blackfathom Deeps', 'dungeon', 5),
    90: ('Gnomeregan', 'dungeon', 5), 47: ('Razorfen Kraul', 'dungeon', 5), 129: ('Razorfen Downs', 'dungeon', 5),
    189: ('Scarlet Monastery', 'dungeon', 5), 70: ('Uldaman', 'dungeon', 5), 209: ("Zul'Farrak", 'dungeon', 5),
    349: ('Maraudon', 'dungeon', 5), 109: ('Sunken Temple', 'dungeon', 5), 230: ('Blackrock Depths', 'dungeon', 5),
    229: ('Blackrock Spire', 'dungeon', 10), 429: ('Dire Maul', 'dungeon', 5), 289: ('Scholomance', 'dungeon', 5),
    329: ('Stratholme', 'dungeon', 5),
}

ENC_NPCS = {}  # encounter id -> every NPC that is part of it
for _n, (_e, _, _) in BOSS_NPC.items():
    ENC_NPCS.setdefault(_e, set()).add(_n)
HOLIDAY_ENCS = {e for _, e, _, _ in HOLIDAY_BOSSES}  # a holiday boss can be summoned again and again in one visit
# ======================================================================
#  Consumables: the spell an item casts when used -> (item id, item name, kind)
#  Generated by tools/make_consumables.py from the cMaNGOS TBC database (item facts only).
# ======================================================================

CONSUMABLE_SPELLS = {
    65: (1400, 'Swiftfeather Token', 'other'),
    89: (3441, 'Deprecated Crippling Agent', 'other'),
    126: (13508, 'Eye of Arachnida', 'other'),
    143: (1402, 'Brimstone', 'other'),
    370: (1995, "Deprecated Cat's Paw", 'other'),
    430: (159, 'Refreshing Spring Water', 'food'),
    431: (1179, 'Ice Cold Milk', 'food'),
    432: (1205, 'Melon Juice', 'food'),
    433: (117, 'Tough Jerky', 'food'),
    434: (414, 'Dalaran Sharp', 'food'),
    435: (422, 'Dwarven Mild', 'food'),
    437: (2455, 'Minor Mana Potion', 'potion'),
    438: (1072, 'Full Moonshine', 'food'),
    439: (118, 'Minor Healing Potion', 'potion'),
    440: (858, 'Lesser Healing Potion', 'potion'),
    441: (929, 'Healing Potion', 'potion'),
    673: (1177, 'Oil of Olaf', 'other'),
    700: (3434, 'Slumber Sand', 'other'),
    706: (1612, 'Deprecated Skullsplitter Idol', 'other'),
    806: (1450, 'Potion of Fervor', 'potion'),
    833: (1401, 'Green Tea Leaf', 'food'),
    1008: (4420, 'Unk Item #16 - Consumable (Amplify Magic)', 'other'),
    1090: (2091, 'Magic Dust', 'other'),
    1127: (1487, 'Conjured Pumpernickel', 'food'),
    1129: (3927, 'Fine Aged Cheddar', 'food'),
    1131: (8076, 'Conjured Sweet Roll', 'food'),
    1133: (1708, 'Sweet Nectar', 'food'),
    1135: (1645, 'Moonberry Juice', 'food'),
    1137: (8078, 'Conjured Sparkling Water', 'food'),
    1138: (1703, 'Crystal Basilisk Spine', 'other'),
    1139: (1704, 'Deprecated Cold Basilisk Eye', 'other'),
    1152: (1851, 'Cleansing Water', 'other'),
    1940: (1178, 'Explosive Rocket', 'other'),
    2006: (1176, 'Smelling Salts', 'other'),
    2023: (3827, 'Mana Potion', 'potion'),
    2024: (1710, 'Greater Healing Potion', 'potion'),
    2052: (5205, 'Sprouted Frond', 'other'),
    2120: (1127, 'Flash Bundle', 'other'),
    2367: (2454, "Elixir of Lion's Strength", 'elixir'),
    2370: (2456, 'Minor Rejuvenation Potion', 'potion'),
    2374: (2457, 'Elixir of Minor Agility', 'elixir'),
    2378: (2458, 'Elixir of Minor Fortitude', 'elixir'),
    2379: (2459, 'Swiftness Potion', 'potion'),
    2380: (3384, 'Minor Magic Resistance Potion', 'potion'),
    2381: (2461, 'Deprecated Elemental Resistance Potion', 'potion'),
    2639: (2682, 'Cooked Crab Claw', 'food'),
    2791: (4423, 'Unk Item #17 - Consumable (Power Word: Fortitude)', 'other'),
    2823: (2892, 'Deadly Poison', 'other'),
    2824: (2893, 'Deadly Poison II', 'other'),
    2828: (2862, 'Rough Sharpening Stone', 'other'),
    2829: (2863, 'Coarse Sharpening Stone', 'other'),
    2830: (2871, 'Heavy Sharpening Stone', 'other'),
    2831: (2304, 'Light Armor Kit', 'enhancement'),
    2832: (2313, 'Medium Armor Kit', 'enhancement'),
    2833: (4265, 'Heavy Armor Kit', 'enhancement'),
    3112: (3239, 'Rough Weightstone', 'other'),
    3113: (3240, 'Coarse Weightstone', 'other'),
    3114: (3241, 'Heavy Weightstone', 'other'),
    3160: (3390, 'Elixir of Lesser Agility', 'elixir'),
    3164: (3391, "Elixir of Ogre's Strength", 'elixir'),
    3166: (3383, 'Elixir of Wisdom', 'elixir'),
    3169: (3387, 'Limited Invulnerability Potion', 'potion'),
    3219: (3382, "Weak Troll's Blood Potion", 'potion'),
    3220: (3389, 'Elixir of Defense', 'elixir'),
    3222: (3388, "Strong Troll's Blood Potion", 'potion'),
    3223: (3826, "Mighty Troll's Blood Potion", 'potion'),
    3231: (22584, 'QAEnchant Cloak +3 Agility', 'other'),
    3408: (3775, 'Crippling Poison', 'other'),
    3592: (2633, 'Jungle Remedy', 'potion'),
    3593: (3825, 'Elixir of Fortitude', 'elixir'),
    3594: (3824, 'Shadow Oil', 'other'),
    3595: (3829, 'Frost Oil', 'other'),
    3680: (3823, 'Lesser Invisibility Potion', 'potion'),
    3974: (4405, 'Crude Scope', 'device'),
    3975: (4406, 'Standard Scope', 'device'),
    3976: (4407, 'Accurate Scope', 'device'),
    4042: (3928, 'Superior Healing Potion', 'potion'),
    4054: (4358, 'Rough Dynamite', 'explosive'),
    4056: (4367, 'Small Seaforium Charge', 'explosive'),
    4057: (4376, 'Flame Deflector', 'device'),
    4060: (4388, 'Discombobulator Ray', 'device'),
    4061: (4365, 'Coarse Dynamite', 'explosive'),
    4062: (4378, 'Heavy Dynamite', 'explosive'),
    4064: (4360, 'Rough Copper Bomb', 'explosive'),
    4065: (4370, 'Large Copper Bomb', 'explosive'),
    4066: (4374, 'Small Bronze Bomb', 'explosive'),
    4067: (4380, 'Big Bronze Bomb', 'explosive'),
    4068: (4390, 'Iron Grenade', 'explosive'),
    4069: (4394, 'Big Iron Bomb', 'explosive'),
    4071: (4366, 'Target Dummy', 'device'),
    4072: (4392, 'Advanced Target Dummy', 'device'),
    4074: (4384, 'Explosive Sheep', 'explosive'),
    4075: (4398, 'Large Seaforium Charge', 'explosive'),
    4077: (4386, 'Ice Deflector', 'device'),
    4078: (4391, 'Compact Harvest Reaper Kit', 'device'),
    4100: (4395, 'Goblin Land Mine', 'explosive'),
    4130: (4481, 'Cresting Charm', 'other'),
    4131: (4480, 'Thundering Charm', 'other'),
    4132: (4479, 'Burning Charm', 'other'),
    4318: (4546, 'Call of the Raptor', 'other'),
    4941: (4623, 'Lesser Stoneshield Potion', 'potion'),
    5004: (2680, 'Spiced Wolf Meat', 'food'),
    5005: (724, 'Goretusk Liver Pie', 'food'),
    5006: (1017, 'Seasoned Wolf Kabob', 'food'),
    5007: (3728, 'Tasty Lion Steak', 'food'),
    5020: (4952, 'Stormstout', 'other'),
    5021: (4953, 'Trogg Ale', 'other'),
    5100: (5013, 'Fertile Bulb', 'other'),
    5134: (4852, 'Flash Bomb', 'explosive'),
    5257: (1262, 'Keg of Thunderbrew Lager', 'other'),
    5665: (5206, 'Bogling Root', 'other'),
    5720: (5509, 'Healthstone', 'other'),
    5723: (5510, 'Greater Healthstone', 'other'),
    5761: (5237, 'Mind-numbing Poison', 'other'),
    5909: (5265, 'Watered-down Beer', 'food'),
    5917: (1191, 'Bag of Marbles', 'other'),
    6114: (5342, 'Raptor Punch', 'food'),
    6262: (5512, 'Minor Healthstone', 'other'),
    6263: (5511, 'Lesser Healthstone', 'other'),
    6296: (5421, 'Fiery Blaze Enchantment', 'other'),
    6410: (5473, 'Scorpid Surprise', 'food'),
    6476: (22588, 'QAEnchant Cloak +10 Shadow Resistance', 'other'),
    6512: (3828, 'Elixir of Detect Lesser Invisibility', 'elixir'),
    6612: (5631, 'Rage Potion', 'potion'),
    6613: (5633, 'Great Rage Potion', 'potion'),
    6614: (5632, 'Cowardly Flight Potion', 'potion'),
    6615: (5634, 'Free Action Potion', 'potion'),
    6668: (9318, 'Red Firework', 'other'),
    6724: (5816, 'Light of Elune', 'other'),
    6727: (5823, 'Poisonous Mushroom', 'other'),
    6758: (5859, 'Party Grenade', 'other'),
    6902: (5878, 'Super Snuff', 'other'),
    6918: (5880, 'Crate With Holes', 'other'),
    7108: (5951, 'Moist Towelette', 'other'),
    7178: (5996, 'Elixir of Water Breathing', 'elixir'),
    7216: (6042, 'Iron Shield Spike', 'enhancement'),
    7218: (6043, 'Iron Counterweight', 'enhancement'),
    7220: (6041, 'Steel Weapon Chain', 'enhancement'),
    7233: (6049, 'Fire Protection Potion', 'potion'),
    7239: (6050, 'Frost Protection Potion', 'potion'),
    7242: (6048, 'Shadow Protection Potion', 'potion'),
    7245: (6051, 'Holy Protection Potion', 'potion'),
    7254: (6052, 'Nature Protection Potion', 'potion'),
    7285: (6074, 'War Horn Mouthpiece', 'other'),
    7291: (1165, 'Test Food', 'food'),
    7364: (6183, 'Unlit Poor Torch', 'other'),
    7396: (1322, 'Fishliver Oil', 'other'),
    7407: (6213, 'Test Sharpening Stone', 'other'),
    7737: (6299, 'Sickly Looking Fish', 'food'),
    7840: (6372, 'Swim Speed Potion', 'potion'),
    7844: (6373, 'Elixir of Firepower', 'elixir'),
    7932: (6452, 'Anti-Venom', 'other'),
    7933: (6453, 'Strong Anti-Venom', 'other'),
    8063: (6522, 'Deviate Fish', 'food'),
    8070: (1970, 'Restoring Balm', 'other'),
    8087: (6529, 'Shiny Bauble', 'other'),
    8088: (6530, 'Nightcrawlers', 'other'),
    8089: (6533, 'Aquadynamic Fish Attractor', 'device'),
    8090: (6532, 'Bright Baubles', 'other'),
    8091: (3013, 'Scroll of Protection', 'scroll'),
    8094: (1478, 'Scroll of Protection II', 'scroll'),
    8095: (4421, 'Scroll of Protection III', 'scroll'),
    8096: (955, 'Scroll of Intellect', 'scroll'),
    8097: (2290, 'Scroll of Intellect II', 'scroll'),
    8098: (4419, 'Scroll of Intellect III', 'scroll'),
    8099: (1180, 'Scroll of Stamina', 'scroll'),
    8100: (1711, 'Scroll of Stamina II', 'scroll'),
    8101: (4422, 'Scroll of Stamina III', 'scroll'),
    8112: (1181, 'Scroll of Spirit', 'scroll'),
    8113: (1712, 'Scroll of Spirit II', 'scroll'),
    8114: (4424, 'Scroll of Spirit III', 'scroll'),
    8115: (3012, 'Scroll of Agility', 'scroll'),
    8116: (1477, 'Scroll of Agility II', 'scroll'),
    8117: (4425, 'Scroll of Agility III', 'scroll'),
    8118: (954, 'Scroll of Strength', 'scroll'),
    8119: (2289, 'Scroll of Strength II', 'scroll'),
    8120: (4426, 'Scroll of Strength III', 'scroll'),
    8176: (1187, 'Spiked Collar', 'other'),
    8202: (6635, 'Earth Sapta', 'other'),
    8212: (6662, 'Elixir of Giant Growth', 'elixir'),
    8213: (6657, 'Savory Deviate Delight', 'food'),
    8277: (5457, 'Severed Voodoo Claw', 'other'),
    8312: (835, 'Large Rope Net', 'other'),
    8331: (6714, 'Ez-Thro Dynamite', 'explosive'),
    8375: (22585, 'QAEnchant Gloves +5 Mining', 'other'),
    8532: (6811, 'Aquadynamic Fish Lens', 'other'),
    8679: (6947, 'Instant Poison', 'other'),
    8686: (6949, 'Instant Poison II', 'other'),
    8688: (6950, 'Instant Poison III', 'other'),
    8693: (6951, 'Mind-numbing Poison II', 'other'),
    8898: (6636, 'Fire Sapta', 'other'),
    8899: (6637, 'Water Sapta', 'other'),
    8900: (6638, 'Air Sapta', 'other'),
    9092: (7307, 'Flesh Eating Worm', 'other'),
    9172: (7388, 'Skull Key', 'other'),
    9512: (7676, 'Thistle Tea', 'food'),
    9515: (3456, 'Dog Whistle', 'other'),
    9781: (7967, 'Mithril Shield Spike', 'enhancement'),
    9783: (7969, 'Mithril Spurs', 'enhancement'),
    9900: (7964, 'Solid Sharpening Stone', 'other'),
    9903: (7965, 'Solid Weightstone', 'other'),
    9976: (7970, 'E.C.A.C.', 'other'),
    10052: (5513, 'Mana Jade', 'other'),
    10057: (8007, 'Mana Citrine', 'other'),
    10058: (8008, 'Mana Ruby', 'other'),
    10256: (12215, 'Heavy Kodo Stew', 'food'),
    10257: (24540, 'Edible Fern', 'other'),
    10344: (8173, 'Thick Armor Kit', 'enhancement'),
    10369: (8243, 'Scooby Snack', 'food'),
    10667: (8410, 'R.O.I.D.S.', 'other'),
    10668: (8411, 'Lung Juice Cocktail', 'other'),
    10669: (8412, 'Ground Scorpok Assay', 'other'),
    10692: (8423, 'Cerebral Cortex Compound', 'other'),
    10693: (8424, 'Gizzard Gum', 'other'),
    10723: (8095, "Hinott's Oil", 'other'),
    10738: (8444, "Executioner's Key", 'other'),
    10772: (8493, "Weegli's Barrel", 'other'),
    10850: (8546, 'Powerful Smelling Salts', 'other'),
    11007: (2686, 'Thunder Ale', 'food'),
    11008: (2593, 'Flask of Port', 'food'),
    11009: (2594, 'Flagon of Mead', 'food'),
    11202: (3776, 'Crippling Poison II', 'other'),
    11319: (8827, 'Elixir of Water Walking', 'elixir'),
    11328: (8949, 'Elixir of Agility', 'elixir'),
    11334: (9187, 'Elixir of Greater Agility', 'elixir'),
    11338: (8926, 'Instant Poison IV', 'other'),
    11339: (8927, 'Instant Poison V', 'other'),
    11340: (8928, 'Instant Poison VI', 'other'),
    11348: (13445, 'Elixir of Superior Defense', 'elixir'),
    11349: (8951, 'Elixir of Greater Defense', 'elixir'),
    11350: (8956, 'Oil of Immolation', 'other'),
    11355: (8984, 'Deadly Poison III', 'other'),
    11356: (8985, 'Deadly Poison IV', 'other'),
    11359: (9030, 'Restorative Potion', 'potion'),
    11364: (9036, 'Magic Resistance Potion', 'potion'),
    11371: (9088, 'Gift of Arthas', 'elixir'),
    11387: (9144, 'Wildvine Potion', 'potion'),
    11389: (9154, 'Elixir of Detect Undead', 'elixir'),
    11390: (9155, 'Arcane Elixir', 'elixir'),
    11392: (9172, 'Invisibility Potion', 'potion'),
    11396: (9179, 'Elixir of Greater Intellect', 'elixir'),
    11399: (9186, 'Mind-numbing Poison III', 'other'),
    11403: (9197, 'Elixir of Dream Vision', 'elixir'),
    11405: (9206, 'Elixir of Giants', 'elixir'),
    11406: (9224, 'Elixir of Demonslaying', 'elixir'),
    11407: (9233, 'Elixir of Detect Demon', 'elixir'),
    11474: (9264, 'Elixir of Shadow Power', 'elixir'),
    11540: (9312, 'Blue Firework', 'other'),
    11541: (9313, 'Green Firework', 'other'),
    11542: (9314, 'Red Streaks Firework', 'other'),
    11543: (9317, 'Red, White and Blue Firework', 'other'),
    11544: (9315, 'Yellow Rose Firework', 'other'),
    11547: (9319, "Nimboya's Laden Pike", 'other'),
    11629: (9361, "Cuergo's Gold with Worm", 'food'),
    11732: (9421, 'Major Healthstone', 'other'),
    11903: (6149, 'Greater Mana Potion', 'potion'),
    11923: (9719, 'Broken Blade of Heroes', 'other'),
    12174: (10309, 'Scroll of Agility IV', 'scroll'),
    12175: (10305, 'Scroll of Protection IV', 'scroll'),
    12176: (10308, 'Scroll of Intellect IV', 'scroll'),
    12177: (10306, 'Scroll of Spirit IV', 'scroll'),
    12178: (10307, 'Scroll of Stamina IV', 'scroll'),
    12179: (10310, 'Scroll of Strength IV', 'scroll'),
    12253: (10419, 'Unk Item #61 - Consumable (Dowse Eternal Flame)', 'other'),
    12419: (10507, 'Solid Dynamite', 'explosive'),
    12421: (10514, 'Mithril Frag Bomb', 'explosive'),
    12438: (10684, 'Colossal Parachute', 'other'),
    12459: (10546, 'Deadly Scope', 'device'),
    12460: (10548, 'Sniper Scope', 'device'),
    12543: (10562, 'Hi-Explosive Bomb', 'explosive'),
    12562: (10586, 'The Big One', 'explosive'),
    12608: (10592, 'Catseye Elixir', 'elixir'),
    12735: (10663, 'Essence of Hakkar', 'other'),
    12802: (10687, 'Empty Vial Labeled #1', 'other'),
    12805: (10688, 'Empty Vial Labeled #2', 'other'),
    12806: (10689, 'Empty Vial Labeled #3', 'other'),
    12808: (10690, 'Empty Vial Labeled #4', 'other'),
    12883: (5507, 'Ornate Spyglass', 'device'),
    13219: (10918, 'Wound Poison', 'other'),
    13225: (10920, 'Wound Poison II', 'other'),
    13226: (10921, 'Wound Poison III', 'other'),
    13227: (10922, 'Wound Poison IV', 'other'),
    13241: (10646, 'Goblin Sapper Charge', 'explosive'),
    13424: (1434, 'Glowing Wax Stick', 'other'),
    13808: (10830, 'M73 Frag Grenade', 'other'),
    14199: (11148, 'Samophlange Manual Page', 'other'),
    14814: (11325, 'Dark Iron Ale Mug', 'other'),
    15048: (11825, 'Pet Bombling', 'device'),
    15049: (11826, "Lil' Smoky", 'device'),
    15057: (11590, 'Mechanical Repair Kit', 'device'),
    15698: (11914, 'Empty Cursed Ooze Jar', 'other'),
    15699: (11948, 'Empty Tainted Ooze Jar', 'other'),
    15700: (11951, 'Whipper Root Tuber', 'food'),
    15701: (11952, "Night Dragon's Breath", 'other'),
    15702: (11953, 'Empty Pure Sample Jar', 'other'),
    15822: (12190, 'Dreamless Sleep Potion', 'potion'),
    15852: (12217, 'Dragonbreath Chili', 'food'),
    16138: (12404, 'Dense Sharpening Stone', 'other'),
    16195: (12440, 'Magic Knucklebone (DND)', 'other'),
    16375: (4945, 'Faintly Glowing Skull', 'other'),
    16447: (12526, 'TEST Challenge to Urok', 'other'),
    16537: (12586, 'Immature Venom Sac', 'other'),
    16589: (8529, 'Noggenfogger Elixir', 'elixir'),
    16622: (12643, 'Dense Weightstone', 'other'),
    16623: (12645, 'Thorium Shield Spike', 'enhancement'),
    16629: (12650, 'Attuned Dampener', 'other'),
    16666: (12662, 'Demonic Rune', 'other'),
    17038: (12820, 'Winterfall Firewater', 'elixir'),
    17133: (12886, "Pamela's Doll's Head", 'other'),
    17161: (12922, 'Empty Canteen', 'other'),
    17271: (13156, 'Mystic Crystal', 'other'),
    17528: (13442, 'Mighty Rage Potion', 'potion'),
    17530: (13443, 'Superior Mana Potion', 'potion'),
    17531: (13444, 'Major Mana Potion', 'potion'),
    17534: (13446, 'Major Healing Potion', 'potion'),
    17535: (13447, 'Elixir of the Sages', 'elixir'),
    17537: (13453, 'Elixir of Brute Force', 'elixir'),
    17538: (13452, 'Elixir of the Mongoose', 'elixir'),
    17539: (13454, 'Greater Arcane Elixir', 'elixir'),
    17540: (13455, 'Greater Stoneshield Potion', 'potion'),
    17543: (13457, 'Greater Fire Protection Potion', 'potion'),
    17544: (13456, 'Greater Frost Protection Potion', 'potion'),
    17545: (13460, 'Greater Holy Protection Potion', 'potion'),
    17546: (13458, 'Greater Nature Protection Potion', 'potion'),
    17548: (13459, 'Greater Shadow Protection Potion', 'potion'),
    17549: (13461, 'Greater Arcane Protection Potion', 'potion'),
    17550: (13462, 'Purification Potion', 'potion'),
    17624: (13506, 'Flask of Petrification', 'flask'),
    17626: (13510, 'Flask of the Titans', 'flask'),
    17627: (13511, 'Flask of Distilled Wisdom', 'flask'),
    17628: (13512, 'Flask of Supreme Power', 'flask'),
    17629: (13513, 'Flask of Chromatic Resistance', 'flask'),
    17639: (13514, 'Wail of the Banshee', 'other'),
    18071: (13724, 'Enriched Manna Biscuit', 'food'),
    18124: (13810, 'Blessed Sunfruit', 'food'),
    18140: (13813, 'Blessed Sunfruit Juice', 'other'),
    18229: (13927, 'Cooked Glossy Mightfish', 'food'),
    18230: (13928, 'Grilled Squid', 'food'),
    18231: (13929, 'Hot Smoked Bass', 'food'),
    18232: (13932, 'Poached Sunscale Salmon', 'food'),
    18233: (13931, 'Nightfin Soup', 'food'),
    18234: (13934, 'Mightfish Steak', 'food'),
    18832: (14894, 'Lily Root', 'other'),
    19057: (15564, 'Rugged Armor Kit', 'enhancement'),
    19199: (15723, 'Tea with Sugar', 'other'),
    19363: (15778, 'Mechanical Yeti', 'other'),
    19566: (15846, 'Salt Shaker', 'device'),
    19646: (15869, 'Silver Skeleton Key', 'other'),
    19649: (15870, 'Golden Skeleton Key', 'other'),
    19651: (15871, 'Truesilver Skeleton Key', 'other'),
    19769: (15993, 'Thorium Grenade', 'explosive'),
    19784: (16005, 'Dark Iron Bomb', 'explosive'),
    19805: (16023, 'Masterwork Target Dummy', 'device'),
    19821: (16040, 'Arcane Bomb', 'explosive'),
    19931: (16103, 'Test Enchant Boots Stamina', 'other'),
    19932: (16104, 'QAEnchhelp Cloak +7 Fire Resistance', 'other'),
    20707: (5232, 'Minor Soulstone', 'other'),
    20709: (15872, 'Arcanite Skeleton Key', 'other'),
    20762: (16892, 'Lesser Soulstone', 'other'),
    20763: (16893, 'Soulstone', 'other'),
    20764: (16895, 'Greater Soulstone', 'other'),
    20765: (16896, 'Major Soulstone', 'other'),
    20875: (17048, 'Rumsey Rum', 'other'),
    21149: (17198, 'Egg Nog', 'food'),
    21160: (17204, 'Eye of Sulfuras', 'other'),
    21393: (17348, 'Major Healing Draught', 'potion'),
    21394: (17349, 'Superior Healing Draught', 'potion'),
    21395: (17351, 'Major Mana Draught', 'potion'),
    21396: (17352, 'Superior Mana Draught', 'potion'),
    21920: (17708, 'Elixir of Frost Power', 'elixir'),
    21935: (17716, 'Snowmaster 9000', 'device'),
    21955: (17747, 'Razorlash Root', 'other'),
    22051: (17827, 'QAEnchant Bracer +9 Strength', 'other'),
    22052: (17828, 'QAEnchant Bracer +9 Stamina', 'other'),
    22053: (17829, 'QAEnchant Bracer +9 Spirit', 'other'),
    22054: (17830, 'QAEnchant Bracer +7 Intellect', 'other'),
    22089: (17882, 'QAEnchant Chest +100 Health', 'other'),
    22090: (17883, 'QAEnchant Chest +100 Mana', 'other'),
    22091: (17884, 'QAEnchant Cloak +5 Resistances', 'other'),
    22092: (17885, 'QAEnchant Cloak +70 Armor', 'other'),
    22094: (17887, 'QAEnchant 2H Weapon +9 Damage', 'other'),
    22095: (17888, 'QAEnchant Weapon +5 Damage', 'other'),
    22098: (17891, 'QAEnchant Shield +7 Stamina', 'other'),
    22099: (17892, 'QAEnchant Shield +8 Frost Resistance', 'other'),
    22100: (17893, 'QAEnchant Shield +9 Spirit', 'other'),
    22101: (17894, 'QAEnchant Boots +7 Agility', 'other'),
    22102: (17895, 'QAEnchant Boots +5 Spirit', 'other'),
    22103: (17896, 'QAEnchant Boots +7 Stamina', 'other'),
    22104: (17897, 'QAEnchant Gloves +7 Strength', 'other'),
    22105: (17898, 'QAEnchant Gloves +7 Agility', 'other'),
    22106: (17899, 'QAEnchant Gloves +1% Haste', 'other'),
    22700: (18232, 'Field Repair Bot 74A', 'device'),
    22725: (18251, 'Core Armor Kit', 'enhancement'),
    22729: (18253, 'Major Rejuvenation Potion', 'potion'),
    22731: (18254, 'Runn Tum Tuber Surprise', 'food'),
    22734: (8079, 'Conjured Crystal Water', 'food'),
    22756: (18262, 'Elemental Sharpening Stone', 'other'),
    22779: (18283, 'Biznicks 247x128 Accurascope', 'device'),
    22789: (18269, 'Gordok Green Grog', 'other'),
    22790: (18284, "Kreeg's Stout Beatdown", 'other'),
    22792: (18297, 'Thornling Seed', 'other'),
    22807: (18294, 'Elixir of Greater Water Breathing', 'elixir'),
    22999: (18587, 'Goblin Jumper Cables XL', 'device'),
    23000: (18588, 'Ez-Thro Dynamite II', 'explosive'),
    23004: (18645, 'Gnomish Alarm-O-Bot', 'device'),
    23008: (18594, 'Powerful Seaforium Charge', 'explosive'),
    23034: (18606, 'Alliance Battle Standard', 'other'),
    23035: (18607, 'Horde Battle Standard', 'other'),
    23063: (18641, 'Dense Dynamite', 'explosive'),
    23065: (18640, 'Happy Fun Rock', 'other'),
    23126: (18660, 'World Enlarger', 'device'),
    23135: (18662, 'Heavy Leather Ball', 'other'),
    23141: (18666, 'QAEnchant Weapon Crusader', 'other'),
    23142: (18667, 'QAEnchant Weapon Icy Chill', 'other'),
    23143: (18668, 'QAEnchant Weapon Spell Power', 'other'),
    23144: (18669, 'QAEnchant Weapon Healing Power', 'other'),
    23468: (19004, 'Minor Healthstone', 'other'),
    23469: (19005, 'Minor Healthstone', 'other'),
    23470: (19006, 'Lesser Healthstone', 'other'),
    23471: (19007, 'Lesser Healthstone', 'other'),
    23472: (19008, 'Healthstone', 'other'),
    23473: (19009, 'Healthstone', 'other'),
    23474: (19010, 'Greater Healthstone', 'other'),
    23475: (19011, 'Greater Healthstone', 'other'),
    23476: (19012, 'Major Healthstone', 'other'),
    23477: (19013, 'Major Healthstone', 'other'),
    23538: (19046, 'Frostwolf Battle Standard', 'other'),
    23539: (19045, 'Stormpike Battle Standard', 'other'),
    23540: (19060, 'Warsong Gulch Enriched Ration', 'other'),
    23541: (19061, 'Warsong Gulch Iron Ration', 'other'),
    23542: (19062, 'Warsong Gulch Field Ration', 'other'),
    23645: (19183, 'Hourglass Sand', 'other'),
    23692: (19301, 'Alterac Manna Biscuit', 'food'),
    23698: (19318, 'Bottled Alterac Spring Water', 'other'),
    23786: (19440, 'Powerful Anti-Venom', 'other'),
    23853: (17162, 'Eric Test Item A', 'other'),
    24005: (19696, 'Harvest Bread', 'food'),
    24302: (19971, 'High Test Eternium Fishing Line', 'enhancement'),
    24355: (19997, 'Harvest Nectar', 'other'),
    24360: (20002, 'Greater Dreamless Sleep Potion', 'potion'),
    24361: (20004, "Major Troll's Blood Potion", 'potion'),
    24363: (20007, 'Mageblood Potion', 'potion'),
    24364: (20008, 'Living Action Potion', 'potion'),
    24382: (20079, 'Spirit of Zanza', 'other'),
    24383: (20081, 'Swiftness of Zanza', 'other'),
    24384: (20031, 'Essence Mango', 'food'),
    24409: (20063, 'Arathi Basin Field Ration', 'other'),
    24410: (20064, 'Arathi Basin Iron Ration', 'other'),
    24411: (20062, 'Arathi Basin Enriched Ration', 'other'),
    24417: (20080, 'Sheen of Zanza', 'other'),
    24707: (20388, 'Lollipop', 'other'),
    24717: (20397, 'Hallowed Wand - Pirate', 'other'),
    24718: (20398, 'Hallowed Wand - Ninja', 'other'),
    24719: (20399, 'Hallowed Wand - Leper Gnome', 'other'),
    24720: (20413, 'Hallowed Wand - Random', 'other'),
    24724: (20411, 'Hallowed Wand - Skeleton', 'other'),
    24733: (20410, 'Hallowed Wand - Bat', 'other'),
    24737: (20409, 'Hallowed Wand - Ghost', 'other'),
    24741: (20414, 'Hallowed Wand - Wisp', 'other'),
    24800: (20452, 'Smoked Desert Dumplings', 'food'),
    24869: (20516, 'Bobbing Apple', 'food'),
    24930: (20557, "Hallow's End Pumpkin Treat", 'other'),
    25037: (20709, 'Rumsey Rum Light', 'food'),
    25117: (20744, 'Minor Wizard Oil', 'other'),
    25118: (20745, 'Minor Mana Oil', 'other'),
    25121: (20750, 'Wizard Oil', 'other'),
    25122: (20749, 'Brilliant Wizard Oil', 'other'),
    25123: (20748, 'Brilliant Mana Oil', 'other'),
    25247: (20834, 'Ornate Spyglass XT', 'device'),
    25351: (20844, 'Deadly Poison V', 'other'),
    25465: (20905, 'Festival of Nian Firework', 'other'),
    25660: (21023, "Dirge's Kickin' Chimaerok Chops", 'food'),
    25677: (21038, 'Hardpacked Snowball', 'other'),
    25690: (21072, 'Smoked Sagefish', 'food'),
    25691: (21217, 'Sagefish Delight', 'food'),
    25722: (21114, 'Rumsey Rum Dark', 'food'),
    25804: (21151, 'Rumsey Rum Black Label', 'food'),
    25823: (21745, "Elder's Moonstone", 'other'),
    25860: (21212, 'Fresh Holly', 'other'),
    25990: (21215, "Graccu's Mince Meat Fruitcake", 'food'),
    26019: (22587, 'QAEnchant Boots +8% Speed', 'other'),
    26020: (22586, 'QAEnchant Gloves +5 Herbalism', 'other'),
    26030: (11950, 'Windblossom Berries', 'other'),
    26067: (21325, 'Mechanical Greench', 'other'),
    26263: (21537, 'Festival Dumplings', 'other'),
    26276: (21546, 'Elixir of Greater Firepower', 'elixir'),
    26286: (23496, 'Unk Item #160 - Consumable (Small Red Rocket)', 'other'),
    26373: (21711, 'Lunar Festival Invitation', 'other'),
    26389: (21721, 'Moonglow', 'food'),
    26521: (21744, 'Lucky Rocket Cluster', 'other'),
    26677: (3386, 'Potion of Curing', 'elixir'),
    26682: (21834, 'Unk Item #119 - Consumable (Perfume)', 'other'),
    26743: (22023, 'QAEnchant Weapon +20 Spirit', 'other'),
    26785: (21835, 'Anesthetic Poison', 'other'),
    26792: (22020, 'QAEnchant Weapon +15 Agility', 'other'),
    26793: (22021, 'QAEnchant Weapon +22 Intellect', 'other'),
    26846: (21922, 'Unk Item #120 - Consumable (Picnic Blanket)', 'other'),
    26891: (21927, 'Instant Poison VII', 'other'),
    26899: (22259, 'Unbestowed Friendship Bracelet', 'other'),
    26967: (22053, 'Deadly Poison VI', 'other'),
    27089: (22018, 'Conjured Glacier Water', 'food'),
    27093: (22022, 'QAEnchant Weapon +15 Strength', 'other'),
    27094: (24408, 'Edible Stalks', 'other'),
    27102: (22024, 'QAEnchant Weapon Unholy', 'other'),
    27103: (22044, 'Mana Emerald', 'other'),
    27104: (22025, 'QAEnchant Weapon Lifestealing', 'other'),
    27107: (22028, 'QAEnchant Chest +4 Stats', 'other'),
    27108: (22029, 'QAEnchant Gloves +20 Frost Damage', 'other'),
    27109: (22030, 'QAEnchant Gloves +20 Fire Damage', 'other'),
    27110: (22031, 'QAEnchant Gloves +20 Shadow Damage', 'other'),
    27111: (22032, 'QAEnchant Gloves +30 Healing', 'other'),
    27112: (22033, 'QAEnchant Gloves +15 Agility', 'other'),
    27113: (22034, 'QAEnchant Gloves +2% Threat', 'other'),
    27114: (22035, 'QAEnchant Gloves +5 Skinning', 'other'),
    27115: (22036, 'QAEnchant Bracer +4 Mana5', 'other'),
    27116: (22037, 'QAEnchant Bracer +24 Healing', 'other'),
    27117: (22038, 'QAEnchant Shield +2% Block Chance', 'other'),
    27118: (22039, 'QAEnchant Cloak +15 Fire Resistance', 'other'),
    27119: (22040, 'QAEnchant Cloak +15 Nature Resistance', 'other'),
    27120: (22041, 'QAEnchant Cloak +8 Stealth', 'other'),
    27121: (22042, 'QAEnchant Cloak -2% Threat', 'other'),
    27122: (22043, 'QAEnchant Cloak +1% Dodge', 'other'),
    27186: (22054, 'Deadly Poison VII', 'other'),
    27188: (22055, 'Wound Poison V', 'other'),
    27235: (22103, 'Master Healthstone', 'other'),
    27236: (22104, 'Master Healthstone', 'other'),
    27237: (22105, 'Master Healthstone', 'other'),
    27239: (22116, 'Master Soulstone', 'other'),
    27652: (22193, 'Bloodkelp Elixir of Resistance', 'other'),
    27653: (22192, 'Bloodkelp Elixir of Dodging', 'other'),
    27720: (22236, 'Buttermilk Delight', 'other'),
    27721: (22238, 'Very Berry Cream', 'other'),
    27722: (22239, 'Sweet Surprise', 'other'),
    27723: (22237, 'Dark Desire', 'other'),
    27869: (20520, 'Dark Rune', 'other'),
    28013: (22521, 'Superior Mana Oil', 'other'),
    28017: (22522, 'Superior Wizard Oil', 'other'),
    28273: (22710, 'Bloodthistle', 'herb'),
    28486: (22779, 'Scourgebane Draught', 'other'),
    28488: (22778, 'Scourgebane Infusion', 'other'),
    28489: (22823, 'Elixir of Camouflage', 'elixir'),
    28490: (22824, 'Elixir of Major Strength', 'elixir'),
    28491: (22825, 'Elixir of Healing Power', 'elixir'),
    28492: (22826, 'Sneaking Potion', 'potion'),
    28493: (22827, 'Elixir of Major Frost Power', 'elixir'),
    28494: (22828, 'Insane Strength Potion', 'potion'),
    28495: (22829, 'Super Healing Potion', 'potion'),
    28496: (22830, 'Elixir of the Searching Eye', 'elixir'),
    28497: (22831, 'Elixir of Major Agility', 'elixir'),
    28499: (22832, 'Super Mana Potion', 'potion'),
    28501: (22833, 'Elixir of Major Firepower', 'elixir'),
    28502: (22834, 'Elixir of Major Defense', 'elixir'),
    28503: (22835, 'Elixir of Major Shadow Power', 'elixir'),
    28504: (22836, 'Major Dreamless Sleep Potion', 'potion'),
    28506: (22837, 'Heroic Potion', 'potion'),
    28507: (22838, 'Haste Potion', 'potion'),
    28508: (22839, 'Destruction Potion', 'potion'),
    28509: (22840, 'Elixir of Major Mageblood', 'elixir'),
    28511: (22841, 'Major Fire Protection Potion', 'potion'),
    28512: (22842, 'Major Frost Protection Potion', 'potion'),
    28513: (22844, 'Major Nature Protection Potion', 'potion'),
    28514: (22848, 'Elixir of Empowerment', 'elixir'),
    28515: (22849, 'Ironshield Potion', 'potion'),
    28517: (22850, 'Super Rejuvenation Potion', 'potion'),
    28518: (22851, 'Flask of Fortification', 'flask'),
    28519: (22853, 'Flask of Mighty Restoration', 'flask'),
    28520: (22854, 'Flask of Relentless Assault', 'flask'),
    28521: (22861, 'Flask of Blinding Light', 'flask'),
    28527: (22795, 'Fel Blossom', 'other'),
    28536: (22845, 'Major Arcane Protection Potion', 'potion'),
    28537: (22846, 'Major Shadow Protection Potion', 'potion'),
    28538: (22847, 'Major Holy Protection Potion', 'potion'),
    28540: (22866, 'Flask of Pure Death', 'flask'),
    28548: (22871, 'Shrouding Potion', 'potion'),
    28714: (22788, 'Flame Cap', 'herb'),
    28726: (22797, 'Nightmare Seed', 'herb'),
    28800: (23055, 'Word of Thawing', 'other'),
    28891: (23122, 'Consecrated Sharpening Stone', 'other'),
    28898: (23123, 'Blessed Wizard Oil', 'other'),
    29004: (23163, "Performer's Wand", 'other'),
    29006: (23164, 'Bubbly Beverage', 'other'),
    29007: (23161, 'Freshly-Squeezed Lemonade', 'other'),
    29008: (23160, 'Friendship Bread', 'food'),
    29029: (23176, 'Fizzy Energy Drink', 'other'),
    29041: (23175, 'Tasty Summer Treat', 'other'),
    29055: (23172, 'Refreshing Red Apple', 'food'),
    29073: (22895, 'Conjured Cinnamon Roll', 'food'),
    29116: (23215, 'Bag of Smorc Ingredients', 'other'),
    29236: (3087, 'Mug of Shimmer Stout', 'potion'),
    29251: (23329, 'Enriched Lasher Root', 'other'),
    29271: (23334, 'Cracked Power Core', 'other'),
    29276: (23354, 'Crystalized Mana Residue', 'other'),
    29297: (23361, 'Cleansing Vial', 'other'),
    29305: (23379, 'Cinder Bracers', 'other'),
    29308: (23381, 'Chipped Power Core', 'other'),
    29312: (23386, 'Condensed Mana Powder', 'other'),
    29324: (23418, 'Test Sapper Charge', 'explosive'),
    29332: (23327, 'Fire-toasted Bun', 'other'),
    29333: (23326, 'Midsummer Sausage', 'other'),
    29334: (23211, 'Toasted Smorc', 'other'),
    29335: (23435, 'Elderberry Pie', 'other'),
    29348: (23444, 'Goldenmist Special Brew', 'elixir'),
    29364: (23417, 'Sanctified Crystal', 'other'),
    29432: (22682, 'Frozen Rune', 'other'),
    29443: (13509, 'Clutch of Foresight', 'other'),
    29452: (23528, 'Fel Sharpening Stone', 'other'),
    29453: (23529, 'Adamantite Sharpening Stone', 'other'),
    29454: (23530, 'Felsteel Shield Spike', 'enhancement'),
    29507: (23575, 'Lesser Ward of Shielding', 'other'),
    29720: (23576, 'Greater Ward of Shielding', 'other'),
    30088: (23194, 'Lesser Mark of the Dawn', 'other'),
    30089: (23195, 'Mark of the Dawn', 'other'),
    30090: (23196, 'Greater Mark of the Dawn', 'other'),
    30164: (23715, 'Permanent Lung Juice Cocktail', 'other'),
    30173: (23718, 'Permanent Ground Scorpok Assay', 'other'),
    30175: (23719, 'Permanent Cerebral Cortex Compound', 'other'),
    30177: (23721, 'Permanent Gizzard Gum', 'other'),
    30178: (23722, 'Permanent R.O.I.D.S.', 'other'),
    30183: (23725, 'QAEnchant Fiery Weapon', 'other'),
    30187: (23727, 'QAEnchant Gloves +5 Fishing', 'other'),
    30190: (23728, 'QAEnchant Gloves Riding Skill', 'other'),
    30216: (23736, 'Fel Iron Bomb', 'explosive'),
    30217: (23737, 'Adamantite Grenade', 'explosive'),
    30229: (18599, 'QAEnchant 2H Weapon +25 Agility', 'other'),
    30250: (23764, 'Adamantite Scope', 'device'),
    30252: (23765, 'Khorium Scope', 'device'),
    30260: (23766, 'Stabilized Eternium Scope', 'device'),
    30261: (23767, "Crashin' Thrashin' Robot", 'device'),
    30262: (23768, 'White Smoke Flare', 'other'),
    30263: (23769, 'Red Smoke Flare', 'other'),
    30264: (23771, 'Green Smoke Flare', 'other'),
    30265: (23770, 'Blue Smoke Flare', 'other'),
    30297: (23696, '[PH] Potion of Heightened Senses [DEP]', 'potion'),
    30331: (23794, 'Permanent Sheen of Zanza', 'other'),
    30336: (23795, 'Permanent Spirit of Zanza', 'other'),
    30338: (23796, 'Permanent Swiftness of Zanza', 'other'),
    30427: (23821, 'Zapthrottle Mote Extractor', 'device'),
    30434: (23819, 'Elemental Seaforium Charge', 'explosive'),
    30435: (23820, 'Critter Enlarger', 'device'),
    30461: (23826, 'The Bigger One', 'explosive'),
    30486: (23827, 'Super Sapper Charge', 'explosive'),
    30489: (23645, "Seer's Relic", 'other'),
    30524: (23840, 'Remote Mail Terminal', 'device'),
    30526: (23841, 'Gnomish Flame Turret', 'explosive'),
    30550: (23862, 'Redemption of the Fallen', 'other'),
    30557: (23865, 'Wrath of the Titans', 'other'),
    30562: (23857, 'Legacy of the Mountain King', 'other'),
    30567: (23864, 'Torment of the Worgen', 'other'),
    30840: (23982, "Kessel's Whistle", 'other'),
    30845: (23985, 'Crystal of Vitality', 'other'),
    30847: (23986, 'Crystal of Insight', 'other'),
    30848: (23989, 'Crystal of Ferocity', 'other'),
    31116: (24140, 'Blackened Urn', 'other'),
    31367: (24268, 'Netherweave Net', 'other'),
    31368: (24269, 'Heavy Netherweave Net', 'other'),
    31369: (24275, 'Silver Spellthread', 'enhancement'),
    31370: (24276, 'Golden Spellthread', 'enhancement'),
    31371: (24273, 'Mystic Spellthread', 'enhancement'),
    31372: (24274, 'Runic Spellthread', 'enhancement'),
    31479: (24289, 'Chrono-beacon', 'other'),
    31606: (25465, 'Stormcrow Amulet', 'other'),
    31736: (24355, 'Ironvine Seeds', 'other'),
    31920: (24421, 'Nagrand Cherry', 'other'),
    31958: (24491, 'Cannonball', 'other'),
    32027: (24429, 'Expedition Flare', 'other'),
    32028: (24494, 'Tears of the Goddess', 'other'),
    32042: (24474, 'Violet Scrying Crystal', 'other'),
    32096: (24522, 'Thrallmar Favor', 'other'),
    32098: (24520, 'Honor Hold Favor', 'other'),
    32112: (24539, 'Marsh Lichen', 'food'),
    32125: (24541, 'Medicinal Swamp Moss', 'other'),
    32254: (25498, 'Rough Stone Statue', 'other'),
    32274: (23559, 'Lesser Rune of Warding', 'other'),
    32282: (25521, 'Greater Rune of Warding', 'other'),
    32304: (25548, 'Tallstalk Mushroom', 'potion'),
    32305: (25550, 'Redcap Toadstool', 'other'),
    32397: (25650, 'Knothide Armor Kit', 'enhancement'),
    32398: (25651, "Vindicator's Armor Kit", 'enhancement'),
    32399: (25652, "Magister's Armor Kit", 'enhancement'),
    32426: (25679, 'Comfortable Insoles', 'other'),
    32802: (25880, 'Coarse Stone Statue', 'other'),
    32803: (25881, 'Heavy Stone Statue', 'other'),
    32804: (25882, 'Solid Stone Statue', 'other'),
    32805: (25883, 'Dense Stone Statue', 'other'),
    32806: (25884, 'Primal Stone Statue', 'other'),
    32812: (25886, 'Purple Smoke Flare', 'other'),
    33019: (27317, 'Elemental Sapta', 'other'),
    33060: (27388, 'Mr. Pinchy', 'other'),
    33077: (27498, 'Scroll of Agility V', 'scroll'),
    33078: (27499, 'Scroll of Intellect V', 'scroll'),
    33079: (27500, 'Scroll of Protection V', 'scroll'),
    33080: (27501, 'Scroll of Spirit V', 'scroll'),
    33081: (27502, 'Scroll of Stamina V', 'scroll'),
    33082: (27503, 'Scroll of Strength V', 'scroll'),
    33253: (27651, 'Buzzard Bites', 'food'),
    33255: (27658, 'Roasted Clefthoof', 'food'),
    33258: (27667, 'Spicy Crawdad', 'food'),
    33260: (27655, 'Ravager Dog', 'food'),
    33262: (27659, 'Warp Burger', 'food'),
    33264: (27657, 'Blackened Basilisk', 'food'),
    33266: (27663, 'Blackened Sporefish', 'food'),
    33269: (27666, 'Golden Fish Sticks', 'food'),
    33272: (27656, 'Sporeling Snack', 'food'),
    33655: (28038, 'Seaforium PU-36 Explosive Nether Modulator', 'other'),
    33720: (28102, 'Onslaught Elixir', 'elixir'),
    33721: (28103, "Adept's Elixir", 'elixir'),
    33725: (22019, 'Conjured Croissant', 'food'),
    33726: (28104, 'Elixir of Mastery', 'elixir'),
    33744: (28110, 'Fat Gnome and Little Elf', 'other'),
    33772: (28112, 'Underspore Pod', 'food'),
    33824: (28131, 'Reaver Buster Launcher', 'other'),
    33836: (28132, 'Area 52 Special', 'other'),
    34291: (28399, 'Filtered Draenic Water', 'food'),
    34339: (28420, 'Fel Weightstone', 'other'),
    34340: (28421, 'Adamantite Weightstone', 'other'),
    34603: (28607, 'Sunfury Disguise', 'other'),
    35113: (29324, 'Warp-Attuned Orb', 'other'),
    35129: (29443, 'Bloodmaul Brutebane Brew', 'other'),
    35270: (29394, 'Lyribread', 'food'),
    35271: (27660, 'Talbuk Steak', 'food'),
    35409: (29482, 'Ethereum Essence', 'other'),
    35415: (29483, 'Shadow Armor Kit', 'enhancement'),
    35416: (29485, 'Flame Armor Kit', 'enhancement'),
    35418: (29486, 'Frost Armor Kit', 'enhancement'),
    35419: (29487, 'Nature Armor Kit', 'enhancement'),
    35420: (29488, 'Arcane Armor Kit', 'enhancement'),
    35474: (29532, 'Drums of Panic', 'other'),
    35475: (29528, 'Drums of War', 'other'),
    35476: (29529, 'Drums of Battle', 'other'),
    35477: (29530, 'Drums of Speed', 'other'),
    35478: (29531, 'Drums of Restoration', 'other'),
    35488: (29533, 'Cobrahide Leg Armor', 'enhancement'),
    35489: (29534, 'Clefthide Leg Armor', 'enhancement'),
    35490: (29535, 'Nethercobra Leg Armor', 'enhancement'),
    35495: (29536, 'Nethercleft Leg Armor', 'enhancement'),
    35673: (29585, 'Legion Whip', 'other'),
    35734: (29778, 'Phase Disruptor', 'other'),
    35745: (29796, "Socrethar's Teleportation Stone", 'other'),
    35791: (29837, 'QAEnchant Weapon +81 Healing', 'other'),
    35792: (29838, 'QAEnchant Weapon Battlemaster', 'other'),
    35793: (29839, 'QAEnchant Weapon Mongoose', 'other'),
    35794: (29840, 'QAEnchant Weapon Soulfrost', 'other'),
    35795: (29841, 'QAEnchant Weapon Sunfire', 'other'),
    35796: (29842, 'QAEnchant Weapon +40 Spell Damage', 'other'),
    35797: (29843, 'QAEnchant Weapon +30 Intellect', 'other'),
    35798: (29844, 'QAEnchant Weapon +7 Damage', 'other'),
    35799: (29845, 'QAEnchant Weapon +20 Strength', 'other'),
    35800: (29846, 'QAEnchant 2H Weapon +35 Agility', 'other'),
    35801: (29847, 'QAEnchant 2H Weapon +70 Attack Power', 'other'),
    35802: (29848, 'QAEnchant Shield +5 Resistances', 'other'),
    35803: (29849, 'QAEnchant Shield +18 Stamina', 'other'),
    35804: (29850, 'QAEnchant Shield +12 Intellect', 'other'),
    35805: (29851, 'QAEnchant Shield +15 Block Value', 'other'),
    35806: (29852, 'QAEnchant Boots +9 Stamina & +8% Speed', 'other'),
    35807: (29853, 'QAEnchant Boots +6 Agility & +8% Speed', 'other'),
    35808: (29854, 'QAEnchant Boots +5 Snare Resist & +10 Hit Rating', 'other'),
    35809: (29856, 'QAEnchant Boots +12 Agility', 'other'),
    35810: (29857, 'QAEnchant Boots +12 Stamina', 'other'),
    35811: (29858, 'QAEnchant Cloak +15 Shadow Resistance', 'other'),
    35812: (29859, 'QAEnchant Cloak +15 Arcane Resistance', 'other'),
    35813: (29860, 'QAEnchant Cloak +12 Agility', 'other'),
    35814: (29861, 'QAEnchant Cloak +20 Spell Penetration', 'other'),
    35815: (29862, 'QAEnchant Gloves +35 Healing', 'other'),
    35816: (29863, 'QAEnchant Gloves +20 Spell Damage', 'other'),
    35817: (29864, 'QAEnchant Gloves +15 Spell Hit Rating', 'other'),
    35818: (29866, 'QAEnchant Gloves +10 Spell Crit Rating', 'other'),
    35819: (29867, 'QAEnchant Gloves +15 Strength', 'other'),
    35820: (29868, 'QAEnchant Gloves +26 Attack Power', 'other'),
    35821: (29869, 'QAEnchant Chest +15 Resilience', 'other'),
    35822: (29870, 'QAEnchant Chest +6 Mana5', 'other'),
    35823: (29871, 'QAEnchant Chest +15 Spirit', 'other'),
    35824: (29872, 'QAEnchant Chest +6 Stats', 'other'),
    35825: (29873, 'QAEnchant Chest +150 Mana', 'other'),
    35826: (29874, 'QAEnchant Chest +150 Health', 'other'),
    36281: (30191, 'QAEnchant Ring +2 Weapon Damage', 'other'),
    36282: (30193, 'QAEnchant Ring +12 Spell Damage', 'other'),
    36283: (30195, 'QAEnchant Ring +20 Healing', 'other'),
    36284: (30197, 'QAEnchant Ring +4 Stats', 'other'),
    36285: (30198, 'QAEnchant Cloak +7 Resistances', 'other'),
    36286: (30199, 'QAEnchant Boots +4 Health & Mana5', 'other'),
    36444: (30347, "Alexander's Test Healthstone", 'other'),
    36923: (30540, "Tally's Waiver (Unsigned)", 'other'),
    37058: (30615, 'Halaani Whiskey', 'other'),
    37346: (30690, 'Power Converter', 'other'),
    37678: (30793, 'Skettis See Invis Potion', 'potion'),
    37834: (30811, 'Scroll of Demonic Unbanishing', 'other'),
    38156: (31121, 'Costume Scraps', 'other'),
    38157: (31122, 'Overseer Disguise', 'other'),
    38318: (31337, 'Orb of the Blackwhelp', 'other'),
    38543: (31437, 'Medicinal Drake Essence', 'other'),
    38551: (31449, 'Distilled Stalker Sight', 'other'),
    38552: (31450, 'Stealth of the Stalker', 'other'),
    38553: (31451, 'Pure Energy', 'other'),
    38606: (31518, 'Exorcism Feather', 'other'),
    38612: (31517, 'Dire Pinfeather', 'other'),
    38613: (31495, 'Grishnath Orb', 'other'),
    38615: (31535, 'Bloodboil Poison', 'other'),
    38908: (31676, 'Fel Regeneration Potion', 'potion'),
    38929: (31677, 'Fel Mana Potion', 'potion'),
    38954: (31679, 'Fel Strength Elixir', 'elixir'),
    39010: (31702, 'Challenge from the Horde', 'other'),
    39403: (31842, 'QAEnchant Bracer +12 Intellect', 'other'),
    39404: (31843, 'QAEnchant Bracer +24 Attack Power', 'other'),
    39405: (31844, 'QAEnchant Bracer +30 Healing', 'other'),
    39406: (31845, 'QAEnchant Bracer +15 Spell Damage', 'other'),
    39407: (31846, 'QAEnchant Bracer +12 Defense', 'other'),
    39408: (31847, 'QAEnchant Bracer +12 Stamina', 'other'),
    39409: (30877, 'QAEnchant Bracer +6 Mana5 Sec', 'other'),
    39410: (31848, 'QAEnchant Bracer +4 All Stats', 'other'),
    39411: (31849, 'QAEnchant Bracer +12 Strength', 'other'),
    39625: (32062, 'Elixir of Major Fortitude', 'elixir'),
    39626: (32063, 'Earthen Elixir', 'elixir'),
    39627: (32067, 'Elixir of Draenic Wisdom', 'elixir'),
    39628: (32068, 'Elixir of Ironskin', 'elixir'),
    39681: (23831, 'Goblin Tonk Controller', 'device'),
    39684: (23832, 'Gnomish Tonk Controller', 'device'),
    39844: (32406, 'Skyguard Blasting Charges', 'other'),
    39948: (32408, "Naj'entus Spine", 'other'),
    39965: (32413, 'Frost Grenade', 'explosive'),
    39980: (32424, "Blade's Edge Ogre Brew", 'other'),
    40309: (32426, 'Testing Darkrune', 'other'),
    40527: (32542, 'Imp in a Ball', 'other'),
    40543: (32563, 'Grilled Picnic Treat', 'other'),
    40548: (32576, 'Depleted Crystal Focus', 'other'),
    40567: (32599, 'Unstable Flask of the Bandit', 'flask'),
    40568: (32596, 'Unstable Flask of the Elder', 'flask'),
    40572: (32598, 'Unstable Flask of the Beast', 'flask'),
    40573: (32600, 'Unstable Flask of the Physician', 'flask'),
    40575: (32597, 'Unstable Flask of the Soldier', 'flask'),
    40576: (32601, 'Unstable Flask of the Sorcerer', 'flask'),
    40768: (32686, "Mingo's Fortune Giblets", 'food'),
    41030: (32721, 'Skyguard Rations', 'food'),
    41031: (32722, 'Enriched Terocone Juice', 'food'),
    41273: (32775, 'Deepdiving Pearl', 'other'),
    41304: (32783, 'Blue Ogre Brew', 'other'),
    41306: (32784, 'Red Ogre Brew', 'other'),
    41443: (32839, 'Cauldron of Major Arcane Protection', 'other'),
    41494: (32849, 'Cauldron of Major Fire Protection', 'other'),
    41495: (32850, 'Cauldron of Major Frost Protection', 'other'),
    41497: (32851, 'Cauldron of Major Nature Protection', 'other'),
    41498: (32852, 'Cauldron of Major Shadow Protection', 'other'),
    41608: (32901, 'Shattrath Flask of Relentless Assault', 'flask'),
    41609: (32898, 'Shattrath Flask of Fortification', 'flask'),
    41610: (32899, 'Shattrath Flask of Mighty Restoration', 'flask'),
    41611: (32900, 'Shattrath Flask of Supreme Power', 'flask'),
    41617: (32903, 'Cenarion Mana Salve', 'other'),
    41618: (32902, 'Bottled Nethergon Energy', 'potion'),
    41619: (32904, 'Cenarion Healing Salve', 'other'),
    41620: (32905, 'Bottled Nethergon Vapor', 'potion'),
    42012: (32952, 'QAEnchant Weapon Spellsurge', 'other'),
    42077: (35772, "Unk Item #253 - Trade Goods - Other - Trinket (Alchemist's Stone)", 'other'),
    42114: (32967, 'DEBUG - Headless Horseman - Extinguish Fire', 'other'),
    42118: (32965, 'DEBUG - Headless Horseman - Create Fire Node', 'other'),
    42132: (32966, 'DEBUG - Headless Horseman - Start Fire', 'other'),
    42254: (37490, 'Aromatic Honey Brew', 'other'),
    42255: (37489, "Izzard's Ever Flavor", 'other'),
    42256: (37488, 'Wild Winter Pilsner', 'other'),
    42257: (37493, 'Blackrock Lager', 'other'),
    42258: (37498, "Bartlett's Bitter Brew", 'other'),
    42259: (37496, 'Binary Brew', 'other'),
    42260: (37497, 'Autumnal Acorn Ale', 'other'),
    42261: (37499, "Lord of Frost's Private Label", 'other'),
    42263: (37492, 'Springtime Stout', 'other'),
    42264: (37495, 'Draenic Pale Ale', 'other'),
    42309: (33053, 'Hot Buttered Trout', 'food'),
    42313: (33063, 'Really Tough Brewfest Bread', 'other'),
    42340: (32971, 'Water Bucket', 'other'),
    42365: (33079, 'Murloc Costume', 'other'),
    42383: (33081, 'Voodoo Skull', 'other'),
    42391: (33083, 'Orcish Grog', 'other'),
    42687: (33185, 'Adamantite Weapon Chain', 'enhancement'),
    42735: (33208, 'Flask of Chromatic Wonder', 'flask'),
    42753: (33219, 'Goblin Gumbo Kettle', 'other'),
    42760: (33218, 'Goblin Gumbeaux', 'other'),
    42775: (33217, 'Unstacked Tricky Treat', 'other'),
    42924: (33800, 'Unk Item #228 - Consumable (Giddyup!)', 'other'),
    43005: (33315, 'QAEnchant Weapon Executioner', 'other'),
    43154: (33234, 'Iced Berry Slush', 'other'),
    43674: (20475, 'Adamantite Arrow Maker', 'other'),
    43706: (33825, 'Skullfish Soup', 'food'),
    43730: (33866, 'Stormchops', 'food'),
    43732: (33865, 'Amani Hex Stick', 'other'),
    43763: (33872, 'Spicy Hot Talbuk', 'food'),
    43771: (33874, "Kibler's Bits", 'food'),
    43777: (33924, 'Delicious Chocolate Cake', 'food'),
    43808: (33927, 'Brewfest Pony Keg', 'other'),
    43816: (33930, 'Amani Charm of the Bloodletter', 'other'),
    43818: (33931, 'Amani Charm of Mighty Mojo', 'other'),
    43820: (33932, 'Amani Charm of the Witch Doctor', 'other'),
    43822: (33933, 'Amani Charm of the Raging Defender', 'other'),
    43864: (33956, "Harkor's Home Brew", 'other'),
    43959: (37494, 'Stranglethorn Brew', 'other'),
    43961: (37491, "Metok's Bubble Bock", 'other'),
    44010: (34046, 'Skill: Catch', 'other'),
    44012: (34251, 'Skill: Throw', 'other'),
    44029: (34047, 'Skill: Sprint', 'other'),
    44083: (34048, 'Skill: Tackle', 'other'),
    44107: (33030, 'Barleybrew Clear', 'other'),
    44109: (33028, 'Barleybrew Light', 'other'),
    44110: (33029, 'Barleybrew Dark', 'other'),
    44111: (33031, 'Thunder 45', 'other'),
    44112: (33032, 'Thunderbrew Ale', 'other'),
    44113: (33033, 'Thunderbrew Stout', 'other'),
    44114: (33034, 'Gordok Grog', 'other'),
    44115: (33035, 'Ogre Mead', 'other'),
    44116: (33036, "Mudder's Milk", 'other'),
    44151: (34061, 'Turbo-Charged Flying Machine Control', 'device'),
    44153: (34060, 'Flying Machine Control', 'device'),
    44166: (34062, 'Conjured Manna Biscuit', 'food'),
    44168: (34153, 'Player, Gnome/Blood Elf', 'other'),
    44169: (34154, 'Player, Human/Undead', 'other'),
    44170: (34152, 'Player, Dwarf/Orc', 'other'),
    44171: (34151, 'Player, Draenei/Tauren', 'other'),
    44173: (34155, 'Player, Troll/Night Elf', 'other'),
    44212: (34068, "Weighted Jack-o'-Lantern", 'other'),
    44389: (34113, 'Field Repair Bot 110G', 'device'),
    44436: (33226, 'Tricky Treat', 'other'),
    44467: (34130, "Recovery Diver's Potion", 'elixir'),
    44752: (34252, 'Skill: Juke', 'other'),
    44769: (34207, 'Glove Reinforcements', 'enhancement'),
    44817: (34250, 'Skill: Throw Bullet', 'other'),
    44968: (34330, 'Heavy Knothide Armor Kit', 'enhancement'),
    45019: (34412, 'Sparkling Apple Cider', 'other'),
    45020: (34411, 'Hot Apple Cider', 'food'),
    45051: (34440, "Mad Alchemist's Potion", 'potion'),
    45072: (34475, 'Arcane Charges', 'other'),
    45153: (34258, 'Love Rocket', 'other'),
    45171: (34504, 'Adamantite Shell Machine', 'other'),
    45257: (31666, 'Battered Steam Tonk Controller', 'device'),
    45373: (34537, 'Bloodberry Elixir', 'elixir'),
    45385: (34646, '[PH] Everburning Elixir', 'potion'),
    45395: (34538, 'Blessed Weapon Coating', 'other'),
    45397: (34539, 'Righteous Weapon Coating', 'other'),
    45426: (34686, 'Brazier of Dancing Flames', 'other'),
    45440: (22728, 'Steam Tonk Controller', 'device'),
    45618: (33867, 'Broiled Bloodfin', 'food'),
    45694: (34832, "Captain Rumsey's Lager", 'food'),
    45697: (34836, 'Spun Truesilver Fishing Line', 'enhancement'),
    45729: (34850, 'Midsummer Ground Flower', 'other'),
    45731: (34861, 'Sharpened Fish Hook', 'other'),
    45819: (34599, 'Juggling Torch', 'other'),
    46168: (35223, "Papa Hummel's Old-Fashioned Pet Biscuit", 'other'),
    46461: (35396, 'Enchant 2H Weapon - Major Agility', 'other'),
    46462: (35397, 'Enchant 2H Weapon - Savagery', 'other'),
    46470: (35398, "Enchant Boots - Boar's Speed", 'other'),
    46471: (35399, "Enchant Boots - Cat's Swiftness", 'other'),
    46472: (35400, 'Enchant Boots - Dexterity', 'other'),
    46490: (35417, 'Enchant Boots - Fortitude', 'other'),
    46491: (35418, 'Enchant Boots - Surefooted', 'other'),
    46492: (35419, 'Enchant Boots - Vitality', 'other'),
    46493: (35420, 'Enchant Bracer - Brawn', 'other'),
    46494: (35421, 'Enchant Bracer - Fortitude', 'other'),
    46495: (35422, 'Enchant Bracer - Major Defense', 'other'),
    46496: (35423, 'Enchant Bracer - Major Intellect', 'other'),
    46497: (35424, 'Enchant Bracer - Restore Mana Prime', 'other'),
    46498: (35425, 'Enchant Bracer - Spellpower', 'other'),
    46499: (35426, 'Enchant Bracer - Stats', 'other'),
    46500: (35427, 'Enchant Bracer - Superior Healing', 'other'),
    46501: (35428, 'Enchant Chest - Exceptional Health', 'other'),
    46502: (35429, 'Enchant Chest - Exceptional Stats', 'other'),
    46503: (35430, 'Enchant Chest - Major Resilience', 'other'),
    46504: (35431, 'Enchant Chest - Major Spirit', 'other'),
    46505: (35432, 'Enchant Cloak - Greater Agility', 'other'),
    46506: (35433, 'Enchant Cloak - Greater Arcane Resistance', 'other'),
    46507: (35434, 'Enchant Cloak - Greater Shadow Resistance', 'other'),
    46508: (35435, 'Enchant Cloak - Major Resistance', 'other'),
    46509: (35436, 'Enchant Cloak - Spell Penetration', 'other'),
    46510: (35437, 'Enchant Cloak - Major Armor', 'other'),
    46511: (35438, 'Enchant Gloves - Assault', 'other'),
    46512: (35439, 'Enchant Gloves - Blasting', 'other'),
    46513: (35440, 'Enchant Gloves - Major Healing', 'other'),
    46514: (35441, 'Enchant Gloves - Major Spellpower', 'other'),
    46515: (35442, 'Enchant Gloves - Major Strength', 'other'),
    46516: (35443, 'Enchant Gloves - Spell Strike', 'other'),
    46517: (35444, 'Enchant Ring - Healing Power', 'other'),
    46518: (35445, 'Enchant Ring - Spellpower', 'other'),
    46519: (35446, 'Enchant Ring - Stats', 'other'),
    46520: (35447, 'Enchant Ring - Striking', 'other'),
    46522: (35448, 'Enchant Shield - Intellect', 'other'),
    46524: (35449, 'Enchant Shield - Major Stamina', 'other'),
    46525: (35450, 'Enchant Shield - Resistance', 'other'),
    46526: (35451, 'Enchant Shield - Shield Block', 'other'),
    46527: (35452, 'Enchant Weapon - Battlemaster', 'other'),
    46529: (35453, 'Enchant Weapon - Greater Agility', 'other'),
    46531: (35454, 'Enchant Weapon - Major Healing', 'other'),
    46532: (35455, 'Enchant Weapon - Major Intellect', 'other'),
    46533: (35456, 'Enchant Weapon - Major Spellpower', 'other'),
    46535: (35457, 'Enchant Weapon - Major Striking', 'other'),
    46536: (35458, 'Enchant Weapon - Mongoose', 'other'),
    46537: (35459, 'Enchant Weapon - Potency', 'other'),
    46538: (35460, 'Enchant Weapon - Soulfrost', 'other'),
    46539: (35461, 'Enchant Weapon - Spellsurge', 'other'),
    46540: (35462, 'Enchant Weapon - Sunfire', 'other'),
    46590: (35499, 'Ninja Grenade [PH]', 'explosive'),
    46683: (35565, 'Juicy Bear Burger', 'food'),
    46812: (35710, 'Delicious Baked Ham', 'food'),
    46837: (35716, 'Shattrath Flask of Pure Death', 'flask'),
    46839: (35717, 'Shattrath Flask of Blinding Light', 'flask'),
    46898: (35563, 'Charred Bear Kabobs', 'food'),
    46927: (35720, "Lord of Frost's Private Label", 'food'),
    47004: (5740, 'Red Fireworks Rocket', 'other'),
    47175: (23246, 'Fiery Festival Brew', 'other'),
    47371: (36748, "Dark Brewmaiden's Brew", 'other'),
    48807: (37567, 'Injector Kit: Super Healing Potions', 'device'),
    48889: (37582, 'Pyroblast Cinnamon Ball', 'other'),
    48890: (37583, 'G.N.E.R.D.S.', 'other'),
    48891: (37584, 'Soothing Spearmint Candy', 'other'),
    48892: (37585, 'Chewy Fel Taffy', 'other'),
    49007: (37604, 'Tooth Pick', 'other'),
    49352: (37710, "Crashin' Thrashin' Racer Controller", 'device'),
    49357: (37750, 'Fresh Brewfest Hops', 'other'),
    49512: (1399, 'Magic Candle', 'other'),
    49844: (37863, "Direbrew's Remote", 'other'),
    50049: (38165, 'Unk Item #255 - Consumable (Summon Ethereal Pet)', 'other'),
    50247: (38233, 'Path of Illidan', 'other'),
    50369: (38294, 'Ethereal Liqueur', 'other'),
    50425: (38300, 'Diluted Ethereum Essence', 'other'),
    50477: (38308, 'Ethereal Essence Sphere', 'other'),
    50749: (38518, "Cro's Apple", 'other'),
    50986: (38466, 'Sulfuron Slammer', 'food'),
    51010: (38320, 'Dire Brew', 'other'),
    51510: (38577, 'Party G.R.E.N.A.D.E.', 'other'),
    51661: (38626, 'Empty Brew Bottle', 'other'),
    52009: (38291, 'Ethereal Mutagen', 'other'),
    52845: (39476, 'Fresh Goblin Brewfest Hops', 'other'),
}
# ======================================================================
#  Log parsers (combat + chat). Pure Python, no UI.
# ======================================================================



F_MINE, F_PARTY, F_RAID, F_GROUP = 0x1, 0x2, 0x4, 0x7
F_FRIENDLY = 0x10
F_PLAYER, F_PET, F_GUARDIAN, F_OBJECT = 0x400, 0x1000, 0x2000, 0x4000
NO_GUID = '0000000000000000'
LIVE_IDLE = 30000       # live: a fight with nothing new in the log for this long has ended
OPEN_WORLD_GAP = 20000  # out in the world, a fight with a mob still alive survives this long a pause
NPC_BOSS_GAP = 20000    # ms of quiet that ends a boss fight found by its NPC (no ENCOUNTER_END to say so)
TRASH_GAP = 5000        # ms without combat that ends a trash fight
ACTIVE_GAP = 3500       # gaps longer than this don't count as active time
RUN_GAP = 3 * 3600_000  # re-entering the same instance after this long is a new run
WORLD_INSTANCES = {0, 1, 530, 571}
PVP_INSTANCES = {489, 529, 30, 566, 559, 562, 572, 617, 618}  # battlegrounds and arenas
SELF_REZ = {'Soulstone Resurrection', 'Reincarnation', 'Ankh', 'Resurrection'}

CLASS_SPELLS = {
    'WARRIOR': ['Heroic Strike', 'Sunder Armor', 'Bloodthirst', 'Mortal Strike', 'Whirlwind', 'Shield Slam', 'Revenge', 'Battle Shout', 'Commanding Shout', 'Execute', 'Slam', 'Cleave', 'Devastate', 'Thunder Clap', 'Demoralizing Shout', 'Rampage', 'Overpower', 'Hamstring', 'Intercept', 'Shield Block', 'Bloodrage', 'Berserker Rage', 'Deep Wound', 'Deep Wounds', 'Taunt'],
    'ROGUE': ['Sinister Strike', 'Eviscerate', 'Slice and Dice', 'Mutilate', 'Backstab', 'Rupture', 'Hemorrhage', 'Instant Poison', 'Deadly Poison', 'Wound Poison', 'Kick', 'Expose Armor', 'Envenom', 'Ambush', 'Garrote', 'Blade Flurry', 'Adrenaline Rush', 'Kidney Shot', 'Cheap Shot', 'Gouge', 'Feint', 'Vanish', 'Shiv'],
    'HUNTER': ['Steady Shot', 'Auto Shot', 'Arcane Shot', 'Multi-Shot', 'Serpent Sting', "Hunter's Mark", 'Aimed Shot', 'Kill Command', 'Bestial Wrath', 'Rapid Fire', 'Raptor Strike', 'Mongoose Bite', 'Wing Clip', 'Feign Death', 'Misdirection', 'Explosive Trap', 'Immolation Trap', 'Freezing Trap', 'Scatter Shot', 'Silencing Shot', 'Concussive Shot', 'Viper Sting', 'Volley', 'Mend Pet', 'Tranquilizing Shot'],
    'MAGE': ['Frostbolt', 'Fireball', 'Arcane Missiles', 'Arcane Blast', 'Scorch', 'Fire Blast', 'Ice Lance', 'Arcane Explosion', 'Pyroblast', 'Frost Nova', 'Counterspell', 'Polymorph', 'Evocation', 'Arcane Power', 'Icy Veins', 'Combustion', 'Ice Block', 'Mana Shield', 'Ice Barrier', 'Blink', 'Cone of Cold', 'Flamestrike', "Dragon's Breath", 'Blast Wave', 'Molten Armor', 'Mage Armor', 'Arcane Intellect', 'Arcane Brilliance', 'Ignite', 'Presence of Mind', 'Cold Snap', 'Remove Lesser Curse', 'Summon Water Elemental', 'Invisibility'],
    'WARLOCK': ['Shadow Bolt', 'Corruption', 'Curse of Agony', 'Curse of the Elements', 'Curse of Recklessness', 'Curse of Doom', 'Curse of Tongues', 'Immolate', 'Incinerate', 'Life Tap', 'Unstable Affliction', 'Siphon Life', 'Seed of Corruption', 'Drain Life', 'Drain Soul', 'Searing Pain', 'Soul Fire', 'Shadowburn', 'Conflagrate', 'Fear', 'Howl of Terror', 'Death Coil', 'Banish', 'Hellfire', 'Rain of Fire', 'Dark Pact', 'Fel Armor', 'Demon Armor', 'Soulshatter', 'Shadowfury', 'Summon Imp', 'Summon Felhunter', 'Summon Voidwalker', 'Summon Succubus', 'Summon Felguard', 'Create Healthstone', 'Ritual of Souls'],
    'PRIEST': ['Flash Heal', 'Greater Heal', 'Renew', 'Prayer of Healing', 'Prayer of Mending', 'Power Word: Shield', 'Circle of Healing', 'Binding Heal', 'Mind Blast', 'Shadow Word: Pain', 'Shadow Word: Death', 'Mind Flay', 'Vampiric Touch', 'Vampiric Embrace', 'Devouring Plague', 'Shadowfiend', 'Smite', 'Holy Fire', 'Power Word: Fortitude', 'Prayer of Fortitude', 'Inner Fire', 'Psychic Scream', 'Fade', 'Dispel Magic', 'Mass Dispel', 'Abolish Disease', 'Pain Suppression', 'Power Infusion', 'Shadowform', 'Lightwell', 'Desperate Prayer', 'Mana Burn', 'Divine Spirit', 'Prayer of Spirit', 'Shadow Protection', 'Prayer of Shadow Protection', 'Inner Focus', 'Fear Ward', 'Silence'],
    'DRUID': ['Rejuvenation', 'Lifebloom', 'Regrowth', 'Healing Touch', 'Swiftmend', 'Tranquility', 'Wrath', 'Starfire', 'Moonfire', 'Insect Swarm', 'Hurricane', 'Mangle (Cat)', 'Mangle (Bear)', 'Shred', 'Rip', 'Ferocious Bite', 'Rake', 'Maul', 'Swipe', 'Lacerate', 'Faerie Fire', 'Faerie Fire (Feral)', 'Innervate', 'Rebirth', 'Barkskin', 'Cat Form', 'Bear Form', 'Dire Bear Form', 'Moonkin Form', 'Tree of Life', 'Mark of the Wild', 'Gift of the Wild', 'Thorns', 'Entangling Roots', 'Cyclone', 'Abolish Poison', 'Remove Curse', "Nature's Swiftness", 'Growl', 'Demoralizing Roar', "Tiger's Fury", 'Prowl', 'Dash'],
    'SHAMAN': ['Lightning Bolt', 'Chain Lightning', 'Chain Heal', 'Lesser Healing Wave', 'Healing Wave', 'Earth Shock', 'Flame Shock', 'Frost Shock', 'Stormstrike', 'Windfury Attack', 'Windfury Totem', 'Grace of Air Totem', 'Strength of Earth Totem', 'Mana Spring Totem', 'Mana Tide Totem', 'Searing Totem', 'Fire Nova Totem', 'Magma Totem', 'Totem of Wrath', 'Wrath of Air Totem', 'Tremor Totem', 'Grounding Totem', 'Earth Shield', 'Water Shield', 'Lightning Shield', 'Bloodlust', 'Heroism', 'Purge', 'Cure Poison', 'Cure Disease', 'Shamanistic Rage', 'Elemental Mastery', 'Flametongue Attack', 'Rockbiter Weapon', 'Earthbind Totem', 'Tranquil Air Totem', 'Healing Stream Totem', 'Ancestral Spirit'],
    'PALADIN': ['Holy Light', 'Flash of Light', 'Holy Shock', 'Judgement', 'Judgement of Light', 'Judgement of Wisdom', 'Judgement of the Crusader', 'Judgement of Righteousness', 'Judgement of Command', 'Judgement of Blood', 'Judgement of Vengeance', 'Seal of Light', 'Seal of Wisdom', 'Seal of Righteousness', 'Seal of Command', 'Seal of the Crusader', 'Seal of Blood', 'Seal of Vengeance', 'Crusader Strike', 'Consecration', 'Holy Shield', "Avenger's Shield", 'Exorcism', 'Hammer of Wrath', 'Hammer of Justice', 'Divine Shield', 'Divine Protection', 'Blessing of Protection', 'Blessing of Freedom', 'Blessing of Sacrifice', 'Blessing of Might', 'Blessing of Wisdom', 'Blessing of Kings', 'Blessing of Salvation', 'Greater Blessing of Might', 'Greater Blessing of Wisdom', 'Greater Blessing of Kings', 'Greater Blessing of Salvation', 'Cleanse', 'Purify', 'Lay on Hands', 'Divine Favor', 'Divine Illumination', 'Righteous Defense', 'Righteous Fury', 'Avenging Wrath', 'Devotion Aura', 'Retribution Aura', 'Concentration Aura', 'Sanctity Aura', 'Vengeance', 'Redemption', 'Seal of Justice'],
}
for _c, _names in {'WARRIOR': ['Battle Stance', 'Defensive Stance', 'Berserker Stance', 'Charge', 'Victory Rush', 'Recklessness', 'Shield Wall', 'Last Stand', 'Intimidating Shout', 'Pummel', 'Shield Bash', 'Disarm', 'Sweeping Strikes', 'Death Wish', 'Spell Reflection', 'Intervene'], 'ROGUE': ['Stealth', 'Sprint', 'Evasion', 'Cloak of Shadows', 'Blind', 'Sap', 'Distract', 'Cold Blood', 'Preparation', 'Shadowstep', 'Pick Pocket', 'Mind-numbing Poison', 'Crippling Poison', 'Deadly Throw', 'Riposte'], 'HUNTER': ['Aspect of the Hawk', 'Aspect of the Monkey', 'Aspect of the Cheetah', 'Aspect of the Pack', 'Aspect of the Viper', 'Aspect of the Wild', 'Aspect of the Beast', 'Trueshot Aura', 'Call Pet', 'Revive Pet', 'Feed Pet', 'Track Humanoids', 'Track Beasts', 'Flare', 'Deterrence', 'Disengage', 'Intimidation', 'Readiness', 'Wyvern Sting', 'Scorpid Sting', 'Arcane Shot'], 'MAGE': ['Frost Armor', 'Ice Armor', 'Dampen Magic', 'Amplify Magic', 'Conjure Water', 'Conjure Food', 'Conjure Mana Emerald', 'Slow Fall', 'Fire Ward', 'Frost Ward', 'Spellsteal', 'Slow', 'Ritual of Refreshment', 'Teleport: Shattrath', 'Portal: Shattrath'], 'WARLOCK': ['Demon Skin', 'Shadow Ward', 'Unending Breath', 'Detect Invisibility', 'Create Soulstone', 'Create Firestone', 'Create Spellstone', 'Ritual of Summoning', 'Health Funnel', 'Enslave Demon', 'Eye of Kilrogg', 'Soul Link', 'Amplify Curse', 'Curse of Weakness', 'Curse of Exhaustion', 'Fel Domination', 'Demonic Sacrifice'], 'PRIEST': ['Touch of Weakness', 'Shadowguard', 'Feedback', "Elune's Grace", 'Starshards', 'Chastise', 'Holy Nova', 'Levitate', 'Mind Control', 'Mind Soothe', 'Mind Vision', 'Resurrection', 'Shackle Undead', 'Spirit of Redemption'], 'DRUID': ['Travel Form', 'Aquatic Form', 'Flight Form', 'Swift Flight Form', 'Omen of Clarity', 'Leader of the Pack', 'Moonkin Aura', 'Hibernate', 'Soothe Animal', 'Track Humanoids (Cat)', 'Frenzied Regeneration', 'Enrage', 'Feral Charge', 'Bash', 'Pounce', 'Ravage', 'Claw', 'Revive'], 'SHAMAN': ['Ghost Wolf', 'Flametongue Weapon', 'Windfury Weapon', 'Frostbrand Weapon', 'Rockbiter Weapon', 'Water Walking', 'Water Breathing', 'Far Sight', 'Astral Recall', 'Reincarnation', 'Stoneskin Totem', 'Stoneclaw Totem', 'Windwall Totem', 'Nature Resistance Totem', 'Fire Resistance Totem', 'Frost Resistance Totem', 'Poison Cleansing Totem', 'Disease Cleansing Totem', 'Sentry Totem', 'Fire Elemental Totem', 'Earth Elemental Totem', 'Unleashed Rage', 'Totemic Call'], 'PALADIN': ['Crusader Aura', 'Shadow Resistance Aura', 'Frost Resistance Aura', 'Fire Resistance Aura', 'Sense Undead', 'Summon Warhorse', 'Summon Charger', 'Turn Undead', 'Repentance', 'Blessing of Light', 'Greater Blessing of Light', 'Blessing of Sanctuary', 'Greater Blessing of Sanctuary', 'Divine Intervention', 'Spiritual Attunement']}.items():
    CLASS_SPELLS[_c] = CLASS_SPELLS[_c] + [n for n in _names if n not in CLASS_SPELLS[_c]]
# names that more than one class (or pets and procs) can show up with tell nothing
# and effects the log credits to whoever carries them (a Lifebloom bloom, Earth Shield and Prayer of Mending heals,
# Thorns damage, Windfury procs, party auras and totem buffs)
_AMBIGUOUS = {"Nature's Swiftness", 'Enrage', 'Track Humanoids', 'Revive', 'Claw', 'Bash', 'Shoot', 'Resurrection',
              'Lifebloom', 'Earth Shield', 'Prayer of Mending', 'Thorns', 'Windfury Attack', 'Heroism', 'Bloodlust',
              'Leader of the Pack', 'Moonkin Aura', 'Trueshot Aura', 'Unleashed Rage', 'Tree of Life', 'Totem of Wrath',
              'Wrath of Air Totem', 'Grace of Air Totem', 'Strength of Earth Totem', 'Mana Spring Totem', 'Windfury Totem',
              'Tranquil Air Totem', 'Stoneskin Totem', 'Nature Resistance Totem', 'Fire Resistance Totem', 'Frost Resistance Totem',
              'Devotion Aura', 'Retribution Aura', 'Concentration Aura', 'Sanctity Aura', 'Crusader Aura',
              'Shadow Resistance Aura', 'Frost Resistance Aura', 'Fire Resistance Aura', 'Vampiric Embrace', 'Mana Tide Totem',
              'Healing Stream Totem', 'Fire Nova Totem', 'Magma Totem', 'Searing Totem'}
_seen_in = {}
for _c, _names in CLASS_SPELLS.items():
    for _n in _names:
        _seen_in.setdefault(_n, set()).add(_c)
SPELL_CLASS = {n: c for c, names in CLASS_SPELLS.items() for n in names if len(_seen_in[n]) == 1 and n not in _AMBIGUOUS}

# Consumables are named from the item's own use-spell (consumables.py), so a 17531 is a "Major Mana Potion" and a
# 28499 a "Super Mana Potion". Names below are only a fallback for logs from other game versions.
COMBAT_CONSUMABLES = {'potion', 'other', 'explosive', 'device', 'herb'}   # not food, elixirs, flasks or scrolls: those go on before the pull
COMBAT_FOOD = {9512}   # Thistle Tea: the one "food" used mid-fight
CONSUMABLE_NAMES = {'Healing Potion', 'Restore Mana', 'Master Healthstone', 'Major Healthstone', 'Greater Healthstone', 'Healthstone', 'Dark Rune', 'Demonic Rune'}
CONSUMABLE_IDS = set()
CONSUMABLE_LABEL = {'Healing Potion': 'Healing potion', 'Restore Mana': 'Mana potion'}
# Cooldowns and utility spells worth showing per player (TBC), by name so every rank counts
NOTABLE = {
    # staying alive
    'Ice Block': 'defensive', 'Divine Shield': 'defensive', 'Divine Protection': 'defensive', 'Blessing of Protection': 'defensive',
    'Lay on Hands': 'defensive', 'Shield Wall': 'defensive', 'Last Stand': 'defensive', 'Evasion': 'defensive', 'Cloak of Shadows': 'defensive',
    'Vanish': 'defensive', 'Feign Death': 'defensive', 'Barkskin': 'defensive', 'Frenzied Regeneration': 'defensive', 'Pain Suppression': 'defensive',
    'Blessing of Sacrifice': 'defensive', 'Shamanistic Rage': 'defensive', 'Soulshatter': 'defensive', 'Fade': 'defensive', 'Invisibility': 'defensive',
    'Spell Reflection': 'defensive', 'Intervene': 'defensive', 'Sprint': 'defensive', 'Dash': 'defensive', 'Blink': 'defensive',
    'Divine Intervention': 'defensive', 'Ice Barrier': 'defensive', 'Mana Shield': 'defensive', 'Gift of the Naaru': 'defensive', 'Stoneform': 'defensive',
    'Will of the Forsaken': 'defensive', 'Escape Artist': 'defensive', 'Every Man for Himself': 'defensive',
    # big cooldowns
    'Bloodlust': 'cooldown', 'Heroism': 'cooldown', 'Arcane Power': 'cooldown', 'Icy Veins': 'cooldown', 'Combustion': 'cooldown',
    'Presence of Mind': 'cooldown', 'Cold Snap': 'cooldown', 'Evocation': 'cooldown', 'Summon Water Elemental': 'cooldown', 'Death Wish': 'cooldown',
    'Recklessness': 'cooldown', 'Sweeping Strikes': 'cooldown', 'Bloodrage': 'cooldown', 'Blade Flurry': 'cooldown', 'Adrenaline Rush': 'cooldown',
    'Cold Blood': 'cooldown', 'Preparation': 'cooldown', 'Bestial Wrath': 'cooldown', 'Rapid Fire': 'cooldown', 'Readiness': 'cooldown',
    'Avenging Wrath': 'cooldown', 'Divine Favor': 'cooldown', 'Divine Illumination': 'cooldown', 'Elemental Mastery': 'cooldown',
    "Nature's Swiftness": 'cooldown', 'Inner Focus': 'cooldown', 'Power Infusion': 'cooldown', 'Shadowfiend': 'cooldown',
    'Fire Elemental Totem': 'cooldown', 'Earth Elemental Totem': 'cooldown', 'Mana Tide Totem': 'cooldown', 'Innervate': 'cooldown',
    'Tranquility': 'cooldown', 'Force of Nature': 'cooldown', 'Amplify Curse': 'cooldown', 'Berserking': 'cooldown', 'Blood Fury': 'cooldown',
    'Arcane Torrent': 'cooldown', 'Mana Torrent': 'cooldown', 'Lifeblood': 'cooldown',
    # helping the raid
    'Rebirth': 'utility', 'Misdirection': 'utility', 'Taunt': 'utility', 'Growl': 'utility', 'Challenging Shout': 'utility',
    'Challenging Roar': 'utility', 'Righteous Defense': 'utility', 'Mocking Blow': 'utility', 'Intimidating Shout': 'utility', 'Psychic Scream': 'utility',
    'Fear Ward': 'utility', 'Tremor Totem': 'utility', 'Grounding Totem': 'utility', 'Polymorph': 'utility', 'Banish': 'utility', 'Fear': 'utility',
    'Shackle Undead': 'utility', 'Hibernate': 'utility', 'Freezing Trap': 'utility', 'Frost Trap': 'utility', 'Frost Nova': 'utility',
    'Hammer of Justice': 'utility', 'Blind': 'utility', 'Tranquilizing Shot': 'utility', 'Soothing Kiss': 'utility', 'Curse of Tongues': 'utility',
    'Soulstone Resurrection': 'utility', 'Mass Dispel': 'utility', 'Feral Charge': 'utility', 'Intimidation': 'utility', 'Scatter Shot': 'utility',
    'Wyvern Sting': 'utility', 'Repentance': 'utility', 'Cyclone': 'utility', 'Entangling Roots': 'utility', 'Seduction': 'utility', 'Death Coil': 'utility',
    'Howl of Terror': 'utility', 'Shadowfury': 'utility', 'Concussion Blow': 'utility', 'Disarm': 'utility', 'Piercing Howl': 'utility',
}

# Damage players could have avoided. A source name limits it to one caster when the spell name is shared.
AVOIDABLE = {
    'Flame Wreath': None,
    'Arcane Explosion': {'Shade of Aran'},
    'Blizzard': {'Shade of Aran'},
    'Hellfire': {'Netherspite Infernal'},
    'Consumption': None,
    'Charred Earth': None,
    'Shadow Nova': {'Prince Malchezaar'},
    'Distracting Ash': None,
}

# Known raid boss lists (encounter IDs from the game data), used to show progress like 8/11.
INSTANCE_BOSSES = {
    532: ('Karazhan', [(652, 'Attumen the Huntsman'), (653, 'Moroes'), (654, 'Maiden of Virtue'), (655, 'Opera Hall'), (656, 'The Curator'), (657, 'Terestian Illhoof'), (658, 'Shade of Aran'), (659, 'Netherspite'), (660, 'Chess Event'), (661, 'Prince Malchezaar'), (662, 'Nightbane')]),
    565: ("Gruul's Lair", [(649, 'High King Maulgar'), (650, 'Gruul the Dragonkiller')]),
    544: ("Magtheridon's Lair", [(651, 'Magtheridon')]),
    568: ("Zul'Aman", [(1189, "Akil'zon"), (1190, 'Nalorakk'), (1191, "Jan'alai"), (1192, 'Halazzi'), (1193, 'Hex Lord Malacrass'), (1194, "Zul'jin")]),
}

# every other dungeon and raid: boss lists from the NPC table (bosses.py), in encounter order
for _inst, _lst in BOSS_TABLE.items():
    if _inst not in INSTANCE_BOSSES:
        _seen = []
        for _e, _n, _ in _lst:
            if _e not in [x[0] for x in _seen]:
                _seen.append((_e, 'Opera Event' if _e == 655 else _n))
        INSTANCE_BOSSES[_inst] = (CLASSIC_INSTANCES.get(_inst, ('',))[0], _seen)

HANDLED = {
    'COMBAT_LOG_VERSION', 'ZONE_CHANGE', 'ENCOUNTER_START', 'ENCOUNTER_END', 'SPELL_SUMMON', 'UNIT_DIED', 'PARTY_KILL', 'SPELL_RESURRECT',
    'SWING_DAMAGE', 'RANGE_DAMAGE', 'SPELL_DAMAGE', 'SPELL_PERIODIC_DAMAGE', 'SPELL_BUILDING_DAMAGE', 'DAMAGE_SHIELD', 'DAMAGE_SPLIT', 'ENVIRONMENTAL_DAMAGE',
    'SPELL_HEAL', 'SPELL_PERIODIC_HEAL', 'SPELL_ABSORBED', 'SPELL_INTERRUPT', 'SPELL_DISPEL', 'SPELL_STOLEN', 'SPELL_CAST_SUCCESS',
}
DAMAGE_EVENTS = {'SWING_DAMAGE', 'RANGE_DAMAGE', 'SPELL_DAMAGE', 'SPELL_PERIODIC_DAMAGE', 'SPELL_BUILDING_DAMAGE', 'DAMAGE_SHIELD', 'DAMAGE_SPLIT', 'ENVIRONMENTAL_DAMAGE'}
HEAL_EVENTS = {'SPELL_HEAL', 'SPELL_PERIODIC_HEAL'}
GUID_PREFIXES = ('Player-', 'Creature-', 'Pet-', 'Vehicle-', 'GameObject-', 'Vignette-', 'Item-')


def npc_of(guid):
    """Creature-0-6263-530-15-18476-000056BBC3 -> 18476"""
    p = guid.split('-')
    return int(p[5]) if len(p) > 6 and p[5].isdigit() else None


def is_guid(s):
    return s == NO_GUID or s.startswith(GUID_PREFIXES)


def is_float(s):
    if '.' not in s:
        return False
    s = s[1:] if s[:1] == '-' else s
    a, _, b = s.partition('.')
    return a.isdigit() and b.isdigit()


def is_int(s):
    s = s[1:] if s[:1] == '-' else s
    return s.isdigit()


def to_int(s):
    try:
        return int(s)
    except (TypeError, ValueError):
        return 0


def flags_of(s):
    try:
        return int(s, 16)
    except (TypeError, ValueError):
        return 0


def short_name(n):
    """'Name-Realm' or 'Name-Realm-US' -> 'Name'. Player names can't contain a dash, realm names can."""
    if not n:
        return n
    i = n.find('-')
    return n[:i] if i > 0 else n


class Stamper:
    """Turns 'M/D[/Y] HH:MM:SS.mmm' into epoch milliseconds, caching each second."""

    def __init__(self, year):
        self.year = year
        self.cache = {}
        self.last_month = None

    def __call__(self, stamp):
        sp = stamp.find(' ')
        if sp < 0:
            return None
        date, clock = stamp[:sp], stamp[sp + 1:]
        hms, _, frac = clock.partition('.')
        key = date + ' ' + hms
        base = self.cache.get(key)
        if base is None:
            try:
                d = date.split('/')
                month = int(d[0])
                if len(d) > 2:
                    y = int(d[2])
                else:
                    # no year in the stamp: a log running past New Year's Eve goes from month 12 to month 1
                    if self.last_month and self.last_month - month >= 6:
                        self.year += 1
                    y = self.year
                    self.last_month = month
                if y < 100:
                    y += 2000
                h, m, s = hms.split(':')
                base = int(datetime(y, int(d[0]), int(d[1]), int(h), int(m), int(s)).timestamp() * 1000)
            except (ValueError, IndexError):
                return None
            if len(self.cache) > 200_000:
                self.cache.clear()
            self.cache[key] = base
        return base + int((frac + '000')[:3]) if frac[:3].isdigit() else base


def split_line(line):
    """Returns (stamp, rest) where rest is everything after the two spaces, or (None, None)."""
    i = line.find('  ')
    if i < 0:
        return None, None
    return line[:i], line[i + 2:].rstrip('\r\n')


def new_stats(name):
    return {'name': name, 'dmg': 0, 'heal': 0, 'overheal': 0, 'absorb': 0, 'taken': 0, 'interrupts': 0, 'dispels': 0, 'deaths': 0,
            'cons': {}, 'avoid': 0, 'avoid_hits': 0, 'active': 0, 'last': 0, 'dmg_by': {}, 'heal_by': {}, 'taken_by': {}, 'kicked': {},
            'int_by': {}, 'cds': {}}


class CombatParser:
    def __init__(self, year=None, source=''):
        self.stamp = Stamper(year or datetime.now().year)
        self.source = source
        self.advanced = None
        self.adv_len = 0
        self.players = {}       # guid -> {name, cls, mine}
        self.classes = {}       # any player's name -> class, from class spells they cast (colours names in chat)
        self.class_votes = {}   # name -> {class: spells seen}; the class with the most wins, so one odd spell can't flip it
        self.owners = {}        # pet guid -> owner guid
        self.recent = {}        # player guid -> last events (death recap)
        self.fights = []
        self.runs = []
        self.cur = None
        self.run = None
        self.zone = None
        self.saw_zone = False
        self.last_ts = 0
        self.seq = 0
        self.handled = 0  # lines that could change what's shown
        self.clock_shift = 0
        self.after_enc = None   # the boss fight that just ended, while its leftover adds/council may still be fought
        self.recent_dead = {}   # creature guid -> (ts, fight it died in): hits landing just after a death belong there
        self.raw_layout = None  # damage lines carry the unmitigated amount (amount, raw, overkill...) - learnt from the log
        self.enc_mode = False   # the log writes ENCOUNTER_START/END (retail-style clients); otherwise bosses are found by NPC id

    # ---- groups ----
    def group_of(self, guid, flags, name):
        if not (flags & F_GROUP) or guid == NO_GUID:
            return None
        if flags & F_PLAYER:
            if guid not in self.players:
                self.players[guid] = {'name': short_name(name), 'cls': None, 'mine': bool(flags & F_MINE)}
            return guid
        if flags & (F_PET | F_GUARDIAN | F_OBJECT):
            owner = self.owners.get(guid)
            if owner and owner in self.players:
                return owner
        return None

    def stats(self, fight, guid):
        s = fight['players'].get(guid)
        if s is None:
            s = fight['players'][guid] = new_stats(self.players[guid]['name'])
        return s

    @staticmethod
    def mark_active(s, ts):
        if s.get('last') and ts - s['last'] <= ACTIVE_GAP:
            s['active'] += ts - s['last']
        s['last'] = ts

    # ---- runs ----
    def run_for(self, f):
        in_instance = self.zone['is_instance'] if self.zone else False
        inst_id = self.zone['id'] if self.zone else None
        if not self.saw_zone and f.get('instance_id'):
            in_instance, inst_id = True, f['instance_id']
        if not in_instance:
            if f['kind'] == 'trash' and self.run and not self.saw_zone and f['start'] - self.run['end'] < 1_800_000:
                return self.run
            return None
        r = self.run
        boss_again = f['kind'] == 'boss' and r is not None and f.get('encounter_id') in r['killed'] and f.get('encounter_id') not in HOLIDAY_ENCS
        entry = self.zone.get('entry') if self.zone else None
        new_match = inst_id in PVP_INSTANCES and r is not None and r.get('entry') != entry  # every battleground/arena entry is its own match
        if r is None or r['instance_id'] != inst_id or f['start'] - r['end'] > RUN_GAP or boss_again or new_match:
            info = INSTANCE_BOSSES.get(inst_id)
            name = (self.zone and self.zone['is_instance'] and self.zone['name']) or (info and info[0]) or f.get('zone_name') or 'Instance'
            self.run = {'id': f"r{self.source}-{f['start']}", 'instance_id': inst_id, 'name': name, 'start': f['start'], 'end': f['start'],
                        'fights': [], 'killed': [], 'wipes': 0, 'source': self.source, 'entry': entry,
                        'difficulty': self.zone.get('diff') if self.zone else f.get('difficulty')}
            self.runs.append(self.run)
            if boss_again and r is not None and r['instance_id'] == inst_id and entry is not None:
                # a reset and a fresh run: what happened since you last zoned in belongs to the new run
                moved = [x for x in self.fights if x.get('run_id') == r['id'] and x.get('entry') == entry]
                if moved:
                    ids = {x['id'] for x in moved}
                    r['fights'] = [i for i in r['fights'] if i not in ids]
                    r['wipes'] -= sum(1 for x in moved if x['kind'] == 'boss' and not x['success'])
                    r['killed'] = [k for k in r['killed'] if not any(x['kind'] == 'boss' and x['success'] and x.get('encounter_id') == k for x in moved)] + \
                                  [k for k in r['killed'] if False]
                    rest = [x for x in self.fights if x['id'] in set(r['fights'])]
                    r['end'] = max((x['end'] for x in rest), default=r['start'])
                    for x in moved:
                        x['run_id'] = self.run['id']
                    self.run['fights'] = [x['id'] for x in moved]
                    self.run['start'] = min(x['start'] for x in moved)
                    self.run['wipes'] = sum(1 for x in moved if x['kind'] == 'boss' and not x['success'])
        return self.run

    # ---- fights ----
    def open_fight(self, kind, ts, **extra):
        self.seq += 1
        f = {'id': f'{self.source}#{self.seq}', 'kind': kind, 'name': '', 'start': ts, 'end': ts, 'players': {}, 'hostiles': {}, 'deaths': [],
             'boss': None, 'success': None, 'live': True, 'zone_name': self.zone['name'] if self.zone else '', 'attempt': None,
             'run_id': None, 'boss_hp': None, 'targets': 0, 'entry': self.zone.get('entry') if self.zone else None}
        f.update(extra)
        self.cur = f
        return f

    def close_fight(self, ts=None):
        f = self.cur
        if not f:
            return
        self.cur = None
        f['live'] = False
        f['kills'] = len(f.get('dead') or ())
        for k in ('boss_npcs', 'npc_last', 'npcs_dead', 'last_kill', 'forced', 'gap', 'alive', 'dead', 'cleared'):
            f.pop(k, None)
        if f['kind'] == 'boss' and ts:
            f['end'] = ts
        for s in f['players'].values():
            s.pop('last', None)
        f['deaths'] = [d for d in f['deaths'] if not d.get('fake')]
        if f['kind'] == 'trash':
            dmg = sum(s['dmg'] for s in f['players'].values())
            killed = bool(f.get('dead'))
            if dmg == 0 and not f['deaths']:
                return
            if f['end'] - f['start'] < 1500 and dmg < 2000 and not killed:
                return
            if f['hostiles']:
                name, h = max(f['hostiles'].items(), key=lambda kv: kv[1]['dmg'])
                n = len(h['units'])
                f['name'] = name + (f' ×{n}' if n > 1 else '')
                f['targets'] = len(f['hostiles'])
            else:
                f['name'] = 'Trash'
        for h in f['hostiles'].values():
            h['units'] = len(h['units'])
        b = f.pop('boss', None)
        if b and b['max']:
            f['boss_hp'] = max(0.0, min(1.0, b['hp'] / b['max']))
        run = self.run_for(f)
        if run:
            f['run_id'] = run['id']
            run['fights'].append(f['id'])
            run['end'] = max(run['end'], f['end'])
            if f['kind'] == 'boss':
                f['attempt'] = 1 + sum(1 for x in self.fights if x.get('run_id') == run['id'] and x['kind'] == 'boss' and x.get('encounter_id') == f.get('encounter_id'))
                if f['success']:
                    run['killed'].append(f.get('encounter_id'))
                else:
                    run['wipes'] += 1
        self.fights.append(f)

    def boss_hit(self, fight, guid, ts):
        """A boss NPC is in the fight. Without ENCOUNTER lines (old dungeons on the Anniversary client) the pull
        becomes a boss attempt; with them, it notes which parts of a council are still fighting."""
        npc = npc_of(guid)
        info = BOSS_NPC.get(npc)
        if not info:
            return fight
        enc, name, inst = info
        if fight['kind'] == 'trash' and not self.enc_mode:
            fight.update({'kind': 'boss', 'encounter_id': enc, 'name': name, 'instance_id': inst, 'boss': {'max': 0, 'hp': 0}, 'by_npc': True})
        if fight['kind'] == 'boss' and fight.get('encounter_id') == enc:
            if 'boss_npcs' not in fight:
                fight['boss_npcs'] = ENC_NPCS.get(enc, set())
                fight['npc_last'], fight['npcs_dead'], fight['last_kill'] = {}, set(), None
            fight['npc_last'][npc] = ts
        return fight

    def end_npc_boss(self):
        """Kill if the boss died (a council: all of it that fought); otherwise it was a wipe or a reset."""
        f = self.cur
        if not f or not f.get('by_npc'):
            return
        b = f.get('boss')
        hp_left = b['hp'] / b['max'] if b and b.get('max') else None
        # the game doesn't log every death (units far from you can be missing), so a boss last seen
        # nearly dead also counts as killed
        killed = bool(f.get('forced') or f.get('npcs_dead') or (hp_left is not None and hp_left <= 0.03))
        f['success'] = killed
        end = f['end'] if f.get('forced') or not f.get('last_kill') else f['last_kill']
        if killed and f.get('boss'):
            f['boss']['hp'] = 0
        self.close_fight(end)

    def tail_fight(self, guid, ts, name=None):
        """Fighting what's left of a boss encounter just after it ended goes into that boss fight."""
        t = self.after_enc
        if not t or not guid.startswith('Creature-'):
            return None
        f = t['f']
        if ts - f['end'] > 15000:
            self.after_enc = None
            return None
        if npc_of(guid) not in t['npcs'] and name not in f['hostiles'] and ts - t['end0'] > 2000:
            return None  # the council itself, or anything that was already part of the fight (its summons)
        cur = self.cur
        if cur and (cur['kind'] == 'boss' or cur['players']):
            return None  # something else has started
        if cur:
            self.cur = None  # an empty trash fight opened a moment ago: drop it
        f['end'] = ts
        run = next((r for r in reversed(self.runs) if r['id'] == f.get('run_id')), None)
        if run:
            run['end'] = max(run['end'], ts)
        return f

    def trash_over(self, f, ts, guid=None):
        """Is this trash fight finished? Everything it was fighting died (and this is a new target or a moment
        later), or nothing happened for a while. Out in the world a mob that's still alive keeps the fight
        going through pauses (a Gouge, a kite, a sheep), because deaths there are always logged."""
        cl = f.get('cleared')
        if cl is not None and (ts - cl > 1500 or (guid is not None and guid not in f['alive'] and guid not in f['dead'])):
            return True
        quiet = ts - f['end']
        if quiet <= TRASH_GAP:
            return False
        open_world = not (self.zone and self.zone['is_instance'])
        return not (open_world and f.get('alive') and quiet <= OPEN_WORLD_GAP)

    def touch_trash(self, ts, guid=None):
        cur = self.cur
        if cur and cur['kind'] == 'boss':
            if cur.get('by_npc'):
                cur['end'] = ts
            return cur
        if cur and self.trash_over(cur, ts, guid):
            self.close_fight()
        if not self.cur:
            self.open_fight('trash', ts, alive=set(), dead=set(), cleared=None)
        cur = self.cur
        cur['end'] = ts
        if guid is not None and guid not in cur['dead']:
            cur['alive'].add(guid)
            cur['cleared'] = None
        return cur

    def active_fight(self, ts):
        f = self.cur
        if not f:
            return None
        if f['kind'] == 'boss':
            return f
        return None if self.trash_over(f, ts) else f

    def remember(self, guid, ev):
        q = self.recent.get(guid)
        if q is None:
            q = self.recent[guid] = []
        q.append(ev)
        if len(q) > 14:
            del q[0]

    def note_class(self, f):
        if len(f) > 10:
            c = SPELL_CLASS.get(f[10].strip('"'))
            if c:
                self.vote_class(short_name(f[2].strip('"')), c)

    def vote_class(self, name, c):
        if not name:
            return None
        v = self.class_votes.get(name)
        if v is None:
            v = self.class_votes[name] = {}
        v[c] = v.get(c, 0) + 1
        best = max(v, key=v.get)
        self.classes[name] = best
        return best

    def infer_class(self, guid, src_guid, spell):
        p = self.players.get(guid)
        if not p or guid != src_guid:
            return
        c = SPELL_CLASS.get(spell)
        if c:
            p['cls'] = self.vote_class(p['name'], c)

    # ---- one line ----
    def feed(self, line):
        stamp, rest = split_line(line)
        if rest is None:
            return
        c = rest.find(',')
        ev = rest[:c] if c > 0 else rest
        if ev not in HANDLED or len(rest) > 20000:
            if ev == 'SPELL_AURA_APPLIED' and rest.startswith('Player-', c + 1):
                self.note_class(rest.split(',', 11))
            return
        ts = self.stamp(stamp)
        if ts is None:
            return
        ts += self.clock_shift
        if self.last_ts and ts < self.last_ts - 300_000:
            back = self.last_ts - ts
            if 3_300_000 <= back <= 3_900_000:
                # clocks went back an hour (end of daylight saving): keep time moving forward
                self.clock_shift += 3_600_000
                ts += 3_600_000
            else:
                return  # out-of-order line: WoW writes in time order, so this isn't a real event
        self.last_ts = max(ts, self.last_ts)
        self.handled += 1
        cur = self.cur
        if cur:
            if cur['kind'] == 'boss':
                if not cur.get('by_npc'):
                    cur['end'] = ts
                elif ts - cur['end'] > cur.get('gap', NPC_BOSS_GAP):
                    self.end_npc_boss()
            elif self.trash_over(cur, ts):
                self.close_fight()
        f = next(csv.reader((rest,)))

        if ev == 'COMBAT_LOG_VERSION':
            if 'ADVANCED_LOG_ENABLED' in f:
                i = f.index('ADVANCED_LOG_ENABLED')
                self.advanced = len(f) > i + 1 and f[i + 1] == '1'
            return
        if ev == 'ZONE_CHANGE':
            if len(f) < 3 or not is_int(f[1]):
                return
            if self.cur and self.cur.get('by_npc'):
                self.end_npc_boss()
            if self.cur and self.cur['kind'] == 'trash':
                self.close_fight()
            zid = to_int(f[1]) if len(f) > 1 else 0
            diff = to_int(f[3]) if len(f) > 3 else None
            self.saw_zone = True
            # every map that isn't one of the open-world continents is an instance; battlegrounds and arenas
            # report difficulty 0, so difficulty can't be used to tell
            is_inst = zid not in WORLD_INSTANCES
            prev = self.zone
            entry = (prev or {}).get('entry', 0) + (1 if is_inst and (not prev or prev['id'] != zid) else 0)
            self.zone = {'id': zid, 'name': f[2] if len(f) > 2 else '', 'is_instance': is_inst, 'diff': diff, 'entry': entry}
            return
        if ev == 'ENCOUNTER_START':
            if len(f) < 3 or not is_int(f[1]):
                return
            self.enc_mode = True
            self.after_enc = None
            c = self.cur
            if c and c.get('by_npc'):
                if c.get('encounter_id') == to_int(f[1]) and ts - c['start'] < 15000 and not c.get('forced'):
                    c['by_npc'] = False  # the pull was spotted by its NPC a moment before the game announced it
                    return
                self.end_npc_boss()
            if self.cur:
                self.close_fight()
            self.open_fight('boss', ts, encounter_id=to_int(f[1]), name=f[2], difficulty=to_int(f[3]) if len(f) > 3 else 0,
                            size=to_int(f[4]) if len(f) > 4 else 0, instance_id=to_int(f[5]) if len(f) > 5 else None, boss={'max': 0, 'hp': 0})
            return
        if ev == 'ENCOUNTER_END':
            if len(f) < 6 or to_int(f[1]) != (self.cur or {}).get('encounter_id'):
                return  # incomplete, or the end of a different encounter
            c = self.cur
            if c and c['kind'] == 'boss':
                ok = len(f) > 5 and f[5] == '1'
                dead = c.get('npcs_dead') or set()
                c['success'] = ok
                self.close_fight(ts)
                if ok:
                    # the game can call it while part of a council still fights (High King Maulgar dies first):
                    # fighting those NPCs straight afterwards still belongs to this boss fight
                    self.after_enc = {'f': c, 'npcs': ENC_NPCS.get(c.get('encounter_id'), set()) - dead, 'end0': ts}
            return
        if len(f) < 9:
            return
        s_guid, s_name, s_flags = f[1], f[2], flags_of(f[3])
        d_guid, d_name, d_flags = f[5], f[6], flags_of(f[7])
        if ev == 'SPELL_CAST_SUCCESS' and s_guid.startswith('Player-'):
            self.note_class(f)

        if ev == 'SPELL_SUMMON':
            owner = self.group_of(s_guid, s_flags, s_name)
            if owner and d_guid != NO_GUID:
                self.owners[d_guid] = owner
            return
        if ev in ('UNIT_DIED', 'PARTY_KILL'):
            cur = self.cur
            if d_guid.startswith(('Creature-', 'Vehicle-')) and d_guid not in self.recent_dead:
                if len(self.recent_dead) > 300:
                    self.recent_dead = {g: v for g, v in self.recent_dead.items() if ts - v[0] < 10000}
                self.recent_dead[d_guid] = (ts, cur or (self.fights[-1] if self.fights else None))
            if cur and cur['kind'] == 'trash' and d_guid in cur.get('alive', ()):
                cur['alive'].discard(d_guid)
                cur['dead'].add(d_guid)
                if not cur['alive']:
                    cur['cleared'] = ts
            if d_guid.startswith('Creature-'):
                if cur and cur['kind'] == 'boss' and 'boss_npcs' in cur:
                    npc = npc_of(d_guid)
                    if npc in cur['boss_npcs']:
                        cur['npcs_dead'].add(npc)
                        cur['last_kill'] = ts
                        if cur.get('by_npc') and set(cur['npc_last']) <= cur['npcs_dead']:
                            cur['end'] = ts
                            self.end_npc_boss()
                return
            if (d_flags & F_PLAYER) and (d_flags & F_GROUP) and d_guid in self.players:
                t = self.after_enc
                fight = (t['f'] if t and ts - t['f']['end'] < 3000 else None) or self.active_fight(ts) or self.cur
                if not fight:
                    return
                q = [e for e in self.recent.get(d_guid, []) if ts - e['ts'] <= 10000]
                last = next((e for e in reversed(q) if e['t'] == 'd'), None)
                fight['deaths'].append({'guid': d_guid, 'name': self.players[d_guid]['name'], 'ts': ts, 'killer': last['src'] if last else None,
                                        'spell': last['spell'] if last else None, 'amount': last['amount'] if last else 0, 'recap': q})
                self.stats(fight, d_guid)['deaths'] += 1
                self.recent.pop(d_guid, None)
            return
        if ev == 'SPELL_RESURRECT':
            if self.cur:
                for d in self.cur['deaths']:
                    if d['guid'] == d_guid:
                        d['rezzed'] = True
            return

        # prefix
        p, spell, spell_id = 9, None, 0
        if ev == 'SWING_DAMAGE':
            spell = 'Melee'
        elif ev == 'ENVIRONMENTAL_DAMAGE':
            spell, p = (f[9] if len(f) > 9 else 'Environment'), 10
        elif len(f) > 11:
            spell_id, spell, p = to_int(f[9]), f[10], 12
        else:
            return

        is_damage = ev in DAMAGE_EVENTS
        is_heal = ev in HEAL_EVENTS

        # advanced block: infoGUID, ownerGUID, curHP, maxHP, ... posX, posY, mapID, facing, level
        d = p
        if (is_damage or is_heal or ev == 'SPELL_CAST_SUCCESS') and self.advanced is not False and len(f) > p and is_guid(f[p]):
            end = -1
            if self.adv_len:
                e = p + self.adv_len
                if e <= len(f) and is_float(f[e - 5]) and is_float(f[e - 4]) and is_int(f[e - 3]):
                    end = e
            if end < 0:
                i = p + 6
                while i + 4 < len(f) and i < p + 26:
                    if is_float(f[i]) and is_float(f[i + 1]) and is_int(f[i + 2]) and is_float(f[i + 3]) and is_int(f[i + 4]):
                        end = i + 5
                        break
                    i += 1
                if end > 0:
                    self.adv_len = end - p
            if end > 0:
                d = end
                info, owner = f[p], f[p + 1]
                if owner != NO_GUID and info != NO_GUID and owner in self.players:
                    self.owners[info] = owner
                fight = self.cur
                if fight and fight.get('boss') is not None and info != NO_GUID and not info.startswith('Player-'):
                    info_flags = d_flags if info == d_guid else s_flags if info == s_guid else 0
                    if not (info_flags & F_FRIENDLY):
                        mx, hp = to_int(f[p + 3]), to_int(f[p + 2])
                        if mx >= fight['boss']['max']:
                            fight['boss']['max'], fight['boss']['hp'] = mx, hp

        if is_damage:
            n = len(f) - d
            amount = to_int(f[d]) if n > 0 else 0
            if not amount:
                return
            src = self.group_of(s_guid, s_flags, s_name)
            dst = self.group_of(d_guid, d_flags, d_name) if d_flags & F_PLAYER else None
            # most clients put the unmitigated amount right after the amount (amount, raw, overkill, ...), older ones
            # don't (amount, overkill, school, ...). Overkill is -1 on every hit that doesn't kill, so the first such
            # hit shows which layout this log uses (a crit's raw amount is below the amount, so values can't tell)
            raw = self.raw_layout
            if raw is None:
                if n > 2 and f[d + 2] == '-1':
                    raw = self.raw_layout = True
                elif n > 1 and f[d + 1] == '-1':
                    raw = self.raw_layout = False
                else:
                    raw = n >= 11 or (n >= 10 and is_int(f[d + 1]) and to_int(f[d + 1]) >= amount)
            ok_i = d + (2 if raw else 1)
            overkill = max(0, to_int(f[ok_i])) if ok_i < len(f) and is_int(f[ok_i]) else 0
            if src and not (d_flags & F_FRIENDLY):
                # damage done counts what the target actually lost, like the game's combat text (no overkill)
                amount = max(0, amount - overkill) if overkill < amount else amount
                rd = self.recent_dead.get(d_guid)
                if rd and rd[1] is not None and ts - rd[0] < 3000:
                    fight = rd[1]  # the killing blow's overkill, a last DoT tick: part of the fight that killed it
                else:
                    fight = self.tail_fight(d_guid, ts, d_name) or self.touch_trash(ts, d_guid)
                    if d_guid.startswith('Creature-'):
                        fight = self.boss_hit(fight, d_guid, ts)
                s = self.stats(fight, src)
                label = spell if s_guid == src else f'{short_name(s_name)}: {spell}'
                s['dmg'] += amount
                s['dmg_by'][label] = s['dmg_by'].get(label, 0) + amount
                self.mark_active(s, ts)
                h = fight['hostiles'].get(d_name)
                if h is None:
                    h = fight['hostiles'][d_name] = {'dmg': 0, 'units': set()}
                h['dmg'] += amount
                if isinstance(h['units'], set):  # a closed fight (a boss fight's tail) keeps only the count
                    h['units'].add(d_guid)
                self.infer_class(src, s_guid, spell)
            elif dst and not (s_flags & F_GROUP):
                fight = self.active_fight(ts) if s_flags & F_FRIENDLY else (self.tail_fight(s_guid, ts, s_name) or self.touch_trash(ts, s_guid))
                if fight and s_guid.startswith('Creature-'):
                    fight = self.boss_hit(fight, s_guid, ts)
                crit_i = d + (7 if raw else 6)
                self.remember(dst, {'t': 'd', 'ts': ts, 'amount': amount, 'src': s_name or 'Environment', 'spell': spell,
                                    'crit': crit_i < len(f) and f[crit_i] == '1', 'overkill': max(0, overkill)})
                if not fight:
                    return
                s = self.stats(fight, dst)
                s['taken'] += amount
                s['taken_by'][spell] = s['taken_by'].get(spell, 0) + amount
                if spell in AVOIDABLE:
                    srcs = AVOIDABLE[spell]
                    if srcs is None or s_name in srcs:
                        s['avoid'] += amount
                        s['avoid_hits'] += 1
            return

        if is_heal:
            src = self.group_of(s_guid, s_flags, s_name)
            n = len(f) - d
            amount = to_int(f[d]) if n > 0 else 0
            oi = d + (2 if n >= 5 else 1)
            over = to_int(f[oi]) if oi < len(f) else 0
            eff = max(0, amount - over)
            dst = self.group_of(d_guid, d_flags, d_name) if d_flags & F_PLAYER else None
            if dst and eff > 0:
                self.remember(dst, {'t': 'h', 'ts': ts, 'amount': eff, 'src': s_name, 'spell': spell})
            if not src:
                return
            self.infer_class(src, s_guid, spell)
            fight = self.active_fight(ts)
            if not fight:
                return
            s = self.stats(fight, src)
            s['heal'] += eff
            s['overheal'] += min(over, amount)
            label = spell if s_guid == src else f'{short_name(s_name)}: {spell}'
            if eff:
                s['heal_by'][label] = s['heal_by'].get(label, 0) + eff
            self.mark_active(s, ts)
            return

        if ev == 'SPELL_ABSORBED':
            c = 9 if (is_guid(f[9]) and len(f) - 9 <= 9) else 12
            if len(f) <= c + 7:
                return
            caster = self.group_of(f[c], flags_of(f[c + 2]), f[c + 1])
            amount = to_int(f[c + 7])
            if not caster or not amount:
                return
            fight = self.active_fight(ts)
            if not fight:
                return
            s = self.stats(fight, caster)
            label = f[c + 5]
            s['heal'] += amount
            s['absorb'] += amount
            s['heal_by'][label] = s['heal_by'].get(label, 0) + amount
            return

        src = self.group_of(s_guid, s_flags, s_name)
        if not src:
            return
        if ev == 'SPELL_INTERRUPT':
            fight = self.active_fight(ts)
            if fight:
                s = self.stats(fight, src)
                s['interrupts'] += 1
                what = f[13] if len(f) > 13 else '?'
                s['kicked'][what] = s['kicked'].get(what, 0) + 1   # what they stopped
                s['int_by'][spell] = s['int_by'].get(spell, 0) + 1  # what they stopped it with
            return
        if ev in ('SPELL_DISPEL', 'SPELL_STOLEN'):
            fight = self.active_fight(ts)
            if fight:
                self.stats(fight, src)['dispels'] += 1
            return
        if ev == 'SPELL_CAST_SUCCESS':
            if src == s_guid:
                self.infer_class(src, s_guid, spell)
            fight = self.active_fight(ts)
            if fight:
                if spell in SELF_REZ:
                    for dd in fight['deaths']:
                        if dd['guid'] == src:
                            dd['rezzed'] = True
                else:
                    # a "dead" player acting again without a resurrect was feigning
                    shaman = (self.players.get(src) or {}).get('cls') == 'SHAMAN' or self.classes.get(short_name(s_name)) == 'SHAMAN'
                    for dd in fight['deaths']:
                        if dd['guid'] == src and not dd.get('rezzed') and dd['ts'] + 500 < ts < dd['ts'] + 60000:
                            if shaman:
                                dd['rezzed'] = True  # Reincarnation isn't logged as a cast: a shaman back on their feet still died
                            else:
                                dd['fake'] = True
            info = CONSUMABLE_SPELLS.get(spell_id)
            label = None
            if info is not None:
                if info[2] in COMBAT_CONSUMABLES or spell_id in COMBAT_FOOD:
                    label = info[1]   # the item's own name
            elif spell in CONSUMABLE_NAMES:
                label = CONSUMABLE_LABEL.get(spell, spell)
            fc = fight or self.cur
            if fc and (label or (spell in NOTABLE and src == s_guid)):
                s = self.stats(fc, src)
                if label:
                    s['cons'][label] = s['cons'].get(label, 0) + 1
                if spell in NOTABLE and src == s_guid:   # the player's own casts, not their pet's
                    s.setdefault('cds', {})
                    s['cds'][spell] = s['cds'].get(spell, 0) + 1

    def tick(self, now_ms):
        """Ends a trash fight that's gone quiet (live mode)."""
        # WoW writes the log in bursts, so the rest of a fight can turn up seconds later: don't end a fight on the
        # clock too eagerly (a fight whose mobs all died ends soon; anything else waits LIVE_IDLE)
        cur = self.cur
        if cur and cur['kind'] == 'trash':
            cl = cur.get('cleared')
            if (cl is not None and now_ms - cl > 3000) or now_ms - cur['end'] > LIVE_IDLE:
                self.close_fight()
        elif self.cur and self.cur.get('by_npc') and now_ms - self.cur['end'] > self.cur.get('gap', NPC_BOSS_GAP) + 2000:
            self.end_npc_boss()

    def finish(self):
        if self.cur and self.cur.get('by_npc'):
            self.end_npc_boss()
        if self.cur:
            if self.cur['kind'] == 'boss':
                self.cur['success'] = False
                self.cur['unfinished'] = True
            self.close_fight(self.cur['end'])

    def snapshot(self):
        return {'source': self.source, 'players': self.players, 'fights': self.fights, 'runs': [r for r in self.runs if r['fights']], 'classes': self.classes}


# ======================================================================
#  Chat log
# ======================================================================
#
# WoWChatLog.txt line format (no year in the stamp on Classic clients, two spaces before the text):
#   10/13 10:01:51.269  |Hchannel:RAID|h[Raid]|h Name: text
#   10/13 10:01:51.269  Name receives loot: |cffa335ee|Hitem:16805::::|h[Felheart Gloves]|h|r.
# Channel tags, player names and items can be |H...|h hyperlinks; colour codes (|cffRRGGBB ... |r) are kept.
# Everything is matched on the text with those codes removed, except items, which are read from the raw line
# so their quality colour and item id survive.

QUALITY_BY_COLOR = {'9d9d9d': 0, 'ffffff': 1, '1eff00': 2, '0070dd': 3, 'a335ee': 4, 'ff8000': 5, 'e6cc80': 6, '00ccff': 7}
ITEM_RE = re.compile(r'(?:\|c[fF]{2}([0-9a-fA-F]{6}))?(?:\|H(item:[^|]*)\|h)?\[([^\]]+)\](?:\|h)?(?:\|r)?')
CODES_RE = re.compile(r'\|c[0-9a-fA-F]{8}|\|r|\|H[^|]*\|h|\|h|\|T[^|]*\|t|\|A[^|]*\|a')

# ---- language: every English phrase the chat parser recognises lives here ----
# To support another client language, copy this dict, translate the patterns, and pass it as ChatParser(lang=...).
# Groups must keep the same names. 'who' never includes the realm (that is cut off afterwards).
EN = {
    # [Channel] Name: text  (also "[2. Trade - City] Name: text")
    'channel_line': r'^\[(?:(?P<num>\d+)\. )?(?P<ch>[^\]]+)\] (?P<who>\[?[^:\[\]]+?\]?): (?P<text>.*)$',
    'channel_names': {
        'Raid Warning': 'raidwarning', 'Raid Leader': 'raid', 'Raid': 'raid',
        'Party Leader': 'party', 'Party': 'party', 'Party Guide': 'party',
        'Guild': 'guild', 'Officer': 'officer',
        'Battleground Leader': 'instance', 'Battleground': 'instance', 'Instance Leader': 'instance', 'Instance': 'instance',
    },
    'whisper_in': r'^(?P<who>.+?) whispers: (?P<text>.*)$',
    'whisper_out': r'^To (?P<who>.+?): (?P<text>.*)$',
    'say': r'^(?P<who>.+?) (?P<verb>says|yells): (?P<text>.*)$',
    'say_verbs': {'says': 'say', 'yells': 'yell'},
    'npc_emote': r'^(?P<who>.+?) (?:whispers|emotes): (?P<text>.*)$',

    'loot': r'^(?P<who>You|.+?) receives? (?:bonus )?loot: (?P<item>.*?)(?:x(?P<count>\d+))?\.?$',
    'item_received': r'^(?P<who>You|.+?) receives? item: (?P<item>.*?)(?:x(?P<count>\d+))?\.?$',
    'created': r'^(?P<who>You|.+?) creates?:? (?P<item>.*?)(?:x(?P<count>\d+))?\.?$',
    'won': r'^(?P<who>You|.+?) won: (?P<item>.*?)(?: \((?P<type>Need|Greed|Disenchant) - (?P<val>\d+)\))?\.?$',
    'roll': r'^(?P<who>.+?) rolls (?P<val>\d+) \((?P<lo>\d+)-(?P<hi>\d+)\)\.?$',
    'group_roll': r'^(?P<type>Need|Greed|Disenchant|Transmog) Roll - (?P<val>\d+) for (?P<item>.*) by (?P<who>.+?)\.?$',
    'roll_choice': r'^(?P<who>You|.+?) (?:have|has) selected (?P<type>Need|Greed|Disenchant|Transmog|Pass) for: (?P<item>.*?)\.?$',
    'passed': r'^(?P<who>You|.+?)(?: automatically)? passed on: (?P<item>.*?)(?: because .*)?\.?$',
    'all_passed': r'^Everyone passed on: (?P<item>.*?)\.?$',
    'money': r'^(?:You loot|Your share of the loot is|You receive) (?P<coins>(?:\d+ (?:Gold|Silver|Copper)(?:, )?)+)\.?$',
    'coin': r'(\d+) (Gold|Silver|Copper)',
    'coin_units': {'Gold': 10000, 'Silver': 100, 'Copper': 1},

    'reset': r'^(?P<instance>.+?) has been reset\.?$',
    'reset_failed': r'^Cannot reset (?P<instance>.+?)\.\s*(?P<why>.*)$',
    'honor': r'^You have been awarded (?P<amount>\d+) honor(?: points)?\.?$',
    'honor_kill': r'^(?P<target>.+?) dies(?:, honorable kill Rank: (?P<rank>[^(]+?) \((?:Estimated Honor Points: )?(?P<amount>\d+)(?: Honor Points)?\)| \(Honorable Kill(?:: (?P<rank2>[^)]+))?\)\. You gain (?P<amount2>\d+) Honor.*)\.?$',
    'rep_up': r'^(?:Your )?[Rr]eputation with (?P<faction>.+?) (?:has )?(?P<dir>increased|decreased)(?: by (?P<amount>\d+))?\.?',
    'rep_up_old': r'^Your reputation with (?P<faction>.+?) has (?:very slightly |slightly |greatly )?(?P<dir>increased|decreased)\.?$',
    'xp_kill': r'^(?P<target>.+?) dies, you gain (?P<amount>\d+) experience\.(?: \((?P<bonus>.*)\))?$',
    'xp': r'^You gain (?P<amount>\d+) experience\.(?: \((?P<bonus>.*)\))?$',
    'quest_done': r'^(?P<quest>.+?) completed\.$',
    'quest_accepted': r'^Quest accepted: (?P<quest>.+)$',
    'level_up': r'^Congratulations, you have reached level (?P<level>\d+)!?$',
    'achievement': r'^(?P<who>.+?) has earned the achievement (?P<what>.+?)!$',
    'others_money': r'^(?P<who>.+?) loots (?P<coins>(?:\d+ (?:Gold|Silver|Copper)(?:, )?)+)\.$',
    'currency': r'^You receive currency: (?P<item>.*?)(?:x(?P<count>\d+))?\.$',
    'skill_up': r'^Your skill in (?P<skill>.+?) has increased to (?P<level>\d+)\.$',
    'discovered': r'^Discovered: (?P<zone>.+)$',
    'disenchanted': r'^(?P<item>.+?) was disenchanted for loot by (?P<who>.+?)\.$',
    # group-loot messages are prefixed with a clickable "[Loot]: " in this client
    'loot_prefix': '[Loot]: ',
    'afk_on': r'^You are now (?P<kind>Away|AFK|Busy|DND)(?:\.|: ?(?P<text>.*?)\.?)$',
    'afk_off': r'^You are no longer (?:marked )?(?P<kind>Away|AFK|Busy|DND)\.?$',
    'online': r'^(?P<who>.+?) has come online\.?$',
    'offline': r'^(?P<who>.+?) has gone offline\.?$',
    'joins': r'^(?P<who>.+?) (?:joins the (?:party|raid)|has joined the (?:raid group|instance group|party|battle))\.?$',
    'leaves': r'^(?P<who>.+?) (?:leaves the (?:party|raid)|has left the (?:raid group|instance group|party|battle))\.?$',
    'you_leave': r'^(?:You leave the group|You have been removed from the group|Your group has been disbanded|You have left the raid group)\.?$',
    'you_join': r'^You have joined a raid group\.?$',
    'loot_master': r'^(?P<who>.+?) is now the loot master\.?$',
    'loot_method': r'^Looting (?:changed|set) to (?P<method>.+?)\.?$',
    'loot_threshold': r'^Loot threshold set to (?P<quality>.+?)\.?$',
    'difficulty': r'^(?P<what>Dungeon|Raid|Legacy Raid) Difficulty set to (?P<level>.+?)\.(?: \((?P<note>.*)\))?$',
    'died': r'^(?P<who>.+?) has died\.?$',
    'you_died': r'^You (?:have )?died\.?$',
}

# first word of the message -> which patterns are worth trying (keeps every line to one or two regex tries)
_SYSTEM_ORDER = ['money', 'group_roll', 'all_passed', 'roll', 'roll_choice', 'passed', 'loot', 'item_received', 'won', 'created',
                 'reset', 'reset_failed', 'honor', 'honor_kill', 'rep_up_old', 'rep_up', 'xp_kill', 'xp', 'quest_accepted', 'quest_done',
                 'level_up', 'achievement', 'afk_on', 'afk_off', 'online', 'offline', 'joins', 'leaves', 'you_leave', 'loot_master',
                 'loot_method', 'loot_threshold', 'difficulty', 'you_died', 'died', 'you_join', 'others_money', 'currency', 'skill_up',
                 'discovered', 'disenchanted']
_KEYWORDS = {  # a message must contain this text for the pattern to be tried at all
    'money': ('Copper', 'Silver', 'Gold'), 'group_roll': (' Roll - ',), 'all_passed': ('passed on',), 'roll': (' rolls ',),
    'roll_choice': ('selected',), 'passed': ('passed on',), 'loot': ('loot:',), 'item_received': ('item:',), 'won': ('won',),
    'created': ('create',), 'reset': ('been reset',), 'reset_failed': ('Cannot reset',), 'honor': ('honor',), 'honor_kill': ('onorable',),
    'rep_up_old': ('eputation',), 'rep_up': ('eputation',), 'xp_kill': ('experience',), 'xp': ('experience',), 'quest_accepted': ('Quest accepted',),
    'quest_done': ('completed.',), 'level_up': ('reached level',), 'achievement': ('achievement',), 'afk_on': ('You are now',),
    'afk_off': ('no longer',), 'online': ('online',), 'offline': ('offline',), 'joins': ('join',), 'leaves': ('left', 'leaves'),
    'you_leave': ('group',), 'loot_master': ('loot master',), 'loot_method': ('Looting',), 'loot_threshold': ('threshold',),
    'difficulty': ('Difficulty set',), 'you_died': ('died',), 'died': ('died',), 'you_join': ('joined a raid',),
    'others_money': (' loots ',), 'currency': ('currency:',), 'skill_up': ('Your skill in',), 'discovered': ('Discovered:',),
    'disenchanted': ('disenchanted for loot',),
}


def _compile(lang):
    out = {k: re.compile(v) for k, v in lang.items() if isinstance(v, str) and k != 'loot_prefix'}
    out['_lang'] = lang
    return out


# one search finds every keyword in a line; only the patterns those keywords point to are tried
_KW_TO_KEYS = {}
for _k in _SYSTEM_ORDER:
    for _kw in _KEYWORDS[_k]:
        _KW_TO_KEYS.setdefault(_kw, set()).add(_k)
# a lookahead so keywords that overlap ("honor" inside "honorable") are all found
_KW_RE = re.compile('(?=(' + '|'.join(re.escape(k) for k in sorted(_KW_TO_KEYS, key=len, reverse=True)) + '))')
# the commonest system lines, checked before the general scan (order matters: the first word that fits wins)
_FAST = (('loot:', ('loot',)), (' Roll - ', ('group_roll',)), (' rolls ', ('roll',)), (' won: ', ('won',)),
         ('Copper', ('money', 'others_money')), ('Silver', ('money', 'others_money')), ('Gold', ('money', 'others_money')),
         ('experience', ('xp_kill', 'xp')), ('eputation', ('rep_up_old', 'rep_up')))
_KW_OVERLAP = {kw: {o for o in _KW_TO_KEYS if o != kw and (o in kw or kw in o)} for kw in _KW_TO_KEYS}


_LANGS = {'en': _compile(EN)}


def strip_codes(s):
    return CODES_RE.sub('', s) if '|' in s else s


class _ChatStamper(Stamper):
    """Chat lines are spread out (rarely two in one second), so cache per hour and add minutes and seconds."""

    def __call__(self, stamp):
        sp = stamp.find(' ')
        if sp < 0:
            return None
        date, clock = stamp[:sp], stamp[sp + 1:]
        try:
            hh, mm, rest = clock.split(':')
            ss, _, frac = rest.partition('.')
            offset = (int(mm) * 60 + int(ss)) * 1000 + (int((frac + '000')[:3]) if frac[:3].isdigit() else 0)
        except ValueError:
            return None
        key = date + ' ' + hh
        base = self.cache.get(key)
        if base is None:
            base = Stamper.__call__(self, f'{date} {hh}:00:00.000')
            if base is None:
                return None
            self.cache[key] = base
        if int(mm) > 59 or int(ss) > 59:
            return None
        return base + offset


def _link_at(s, i):
    """Reads the item link whose '|Hitem:' starts at index i: colour (if any), id and name."""
    color = s[i - 6:i].lower() if i >= 10 and s[i - 10:i - 6].lower() == '|cff' else None
    j = s.find(':', i + 7)
    k = s.find('|h[', i)
    e = s.find(']|h', k + 3) if k >= 0 else -1
    if k < 0 or e < 0:
        return None, -1
    return {'name': s[k + 3:e], 'q': QUALITY_BY_COLOR.get(color), 'id': to_int(s[i + 7:j]) if 0 < j < k else to_int(s[i + 7:k])}, e + 3


def item_of(s):
    """The first item in a message: a real item link if there is one, else the first [bracketed] name."""
    i = s.find('|Hitem:')
    if i >= 0:
        it, _ = _link_at(s, i)
        if it:
            return it
    m = ITEM_RE.search(s)
    if not m:
        return None
    color = m.group(1).lower() if m.group(1) else None
    return {'name': m.group(3), 'q': QUALITY_BY_COLOR.get(color), 'id': to_int(m.group(2).split(':')[1]) if m.group(2) else None}


def items_of(s):
    """Every item linked in a message (a roll call can link several)."""
    out = []
    i = s.find('|Hitem:')
    while i >= 0:
        it, end = _link_at(s, i)
        if not it:
            break
        out.append(it)
        i = s.find('|Hitem:', end)
    return out


def clean_name(n):
    """'[Name-Realm]' / 'Name-Realm' / 'Name' -> 'Name'. Battle.net names (with spaces) are kept whole."""
    n = n.strip()
    if n[:1] == '[' and n[-1:] == ']':
        n = n[1:-1]
    i = n.find('-')
    return (n[:i] if i > 0 and ' ' not in n else n).strip()


def _item_from(raw, text_item):
    it = item_of(raw)
    if it:
        return it
    name = text_item.strip()
    if name[:1] == '[' and name.rfind(']') > 0:
        name = name[1:name.rfind(']')]
    return {'name': name, 'q': None, 'id': None}


class ChatParser:
    def _add_loot(self, entry):
        """Group loot writes 'X won: [item]' and then 'X receives loot: [item]' for the same drop: count it once."""
        name = entry['item'].get('name')
        for prev in reversed(self.loot[-12:]):
            if entry['ts'] - prev['ts'] > 120_000:
                break
            if prev['who'] == entry['who'] and prev['item'].get('name') == name and bool(prev.get('won')) != bool(entry.get('won')) and not prev.get('paired'):
                prev['paired'] = True
                if entry.get('won'):
                    prev['won'] = True
                    if entry.get('roll'):
                        prev['roll'] = entry['roll']
                if prev['item'].get('q') is None:
                    prev['item'] = entry['item']
                return
        self.loot.append(entry)

    def __init__(self, year=None, me=None, lang='en'):
        self.stamp = _ChatStamper(year or datetime.now().year)
        self.R = _LANGS.get(lang) or _LANGS['en']
        L = self.R['_lang']
        self.channel_names = L['channel_names']
        self.say_verbs = L['say_verbs']
        self.coin_units = L['coin_units']
        self.loot_prefix = L['loot_prefix']
        self.messages = []      # every chat line, including system lines (kind tells what a system line was)
        self.loot = []          # items looted / won
        self.roll_sessions = []
        self.money = []
        self.me = me
        # extra things worth knowing, each a list of dicts with 'ts'
        self.resets = []        # {instance, ok}
        self.honor = []         # {amount, target?}
        self.reputation = []    # {faction, amount, up}
        self.xp = []            # {amount, target?}
        self.quests = []        # {quest, done}
        self.levels = []        # {level}
        self.achievements = []  # {who, what}
        self.status = []        # {state: 'away'|'busy'|'back', text}
        self.presence = []      # {who, online}
        self.group = []         # {who, joined}  who='You' for your own leaving
        self.loot_settings = [] # {what: 'master'|'method'|'threshold'|'difficulty', value}
        self.crafted = []       # {who, item, count}
        self.deaths = []        # {who}
        self.roll_choices = []  # {who, type, item}
        self.others_money = []  # {who, copper}  gold other group members looted
        self.currency = []      # {item, count}
        self.skills = []        # {skill, level}
        self.discovered = []    # {zone}
        self.disenchants = []   # {who, item}
        self.last_item_call = None
        self.you_seen = []      # (ts, character name) whenever the log shows who "You" is
        self.session = None
        self._group_sessions = {}
        self.bad = 0

    def _who(self, s):
        # "You" stays "You": the chat log can span several characters, so who "You" is depends on when (see you_at)
        return 'You' if s == 'You' else clean_name(s)

    def _infer_you(self, ts, item):
        """Group rolls name everyone, you included: a roller who never chose Need/Greed under their own name is you."""
        s = self._group_sessions.get('ng:' + item)
        if not s or ts - s['end'] > 180_000:
            return
        mine = others = None
        for c in self.roll_choices[-60:]:
            if c['item'].get('name') == item and ts - c['ts'] < 300_000:
                if c['who'] == 'You':
                    mine = True
                else:
                    others = (others or set()) | {c['who']}
        if not mine:
            return
        cand = {r['who'] for r in s['rolls']} - (others or set())
        if len(cand) == 1:
            name = cand.pop()
            if not self.you_seen or self.you_seen[-1][1] != name:
                self.you_seen.append((ts, name))

    def you_at(self, ts):
        """The character "You" meant at that moment, when the log gave it away (None if it never did)."""
        best = None
        for t, name in self.you_seen:
            if t <= ts + 3600_000:
                best = name
            else:
                break
        if best is None and self.you_seen and self.you_seen[0][0] - ts < 12 * 3600_000:
            best = self.you_seen[0][1]
        return best

    def feed(self, line):
        i = line.find('  ')
        if i < 0:
            return
        raw = line[i + 2:].rstrip('\r\n')
        ts = self.stamp(line[:i])
        if ts is None:
            return
        R = self.R
        # fast path for the commonest line: |Hchannel:GUILD|h[Guild]|h Name: text
        if raw.startswith('|Hchannel:'):
            a = raw.find('|h[', 10)
            b = raw.find(']|h ', a) if a > 0 else -1
            c = raw.find(': ', b + 4) if b > 0 else -1
            if c > 0:
                name, who, body = raw[a + 3:b], raw[b + 4:c], raw[c + 2:]
                dot = name.find('. ')
                if dot > 0 and name[:dot].isdigit():
                    ch, name = 'channel', name[dot + 2:]
                else:
                    ch = self.channel_names.get(name)
                if ch:
                    if '|' in who or who[:1] == '[':
                        who = clean_name(strip_codes(who))
                    else:
                        d = who.find('-')
                        if d > 0 and ' ' not in who:
                            who = who[:d]
                    msg = {'ts': ts, 'ch': ch, 'ch_name': name, 'who': who, 'text': strip_codes(body) if '|' in body else body}
                    self.messages.append(msg)
                    if ch in ('raid', 'raidwarning', 'party', 'instance') and '|Hitem:' in body:
                        its = items_of(body)
                        if its:
                            self.last_item_call = {'ts': ts, 'item': its[0], 'items': its, 'by': msg['who']}
                    return
        text = strip_codes(raw)
        if not text:
            return
        lp = self.loot_prefix
        if text.startswith(lp):
            text = text[len(lp):]
            cut = raw.find(']|h: ')
            raw = raw[cut + 5:] if cut >= 0 else raw[len(lp):]
            if not text:
                return
        elif text.startswith('Loot: '):
            # the Anniversary client writes the prefix as plain text (links are stripped from the log file)
            text = text[6:]
            raw = raw[raw.find('Loot: ') + 6:] if 'Loot: ' in raw else text
            if not text:
                return

        # [Channel] Name: text
        if text[0] == '[':
            m = R['channel_line'].match(text)
            if m:
                name = m.group('ch')
                if m.group('num'):
                    ch, ch_name = 'channel', name
                else:
                    ch, ch_name = self.channel_names.get(name), name
                if ch:
                    msg = {'ts': ts, 'ch': ch, 'ch_name': ch_name, 'who': clean_name(m.group('who')), 'text': m.group('text')}
                    self.messages.append(msg)
                    if ch in ('raid', 'raidwarning', 'party', 'instance'):
                        body = raw[raw.find(': ') + 2:] if ': ' in raw else raw
                        its = items_of(body)
                        if its:
                            self.last_item_call = {'ts': ts, 'item': its[0], 'items': its, 'by': msg['who']}
                    return
            # a Battle.net friend: "[Real Name] whispers: hi"
            m = R['whisper_in'].match(text)
            if m and m.group('who').endswith(']'):
                self.messages.append({'ts': ts, 'ch': 'whisper', 'ch_name': 'From', 'who': clean_name(m.group('who')), 'text': m.group('text'), 'bn': True})
                return

        if text.startswith('To '):
            m = R['whisper_out'].match(text)
            if m:
                who = m.group('who')
                self.messages.append({'ts': ts, 'ch': 'whisper', 'ch_name': 'To', 'who': clean_name(who), 'text': m.group('text'), 'out': True,
                                      'bn': who.startswith('[') or ' ' in who})
                return
        if ' whispers: ' in text:
            m = R['whisper_in'].match(text)
            if m:
                who = m.group('who')
                self.messages.append({'ts': ts, 'ch': 'whisper', 'ch_name': 'From', 'who': clean_name(who), 'text': m.group('text'),
                                      'bn': who.startswith('[')})
                return
        if ' says: ' in text or ' yells: ' in text:
            m = R['say'].match(text)
            if m:
                ch = self.say_verbs[m.group('verb')]
                self.messages.append({'ts': ts, 'ch': ch, 'ch_name': 'Say' if ch == 'say' else 'Yell', 'who': clean_name(m.group('who')), 'text': m.group('text')})
                return

        for kw, keys in _FAST:
            if kw in text:
                for key in keys:
                    m = R[key].match(text)
                    if m and self._system(key, m, ts, raw, text) is not False:
                        return
                break
        found = _KW_RE.findall(text)
        if found:
            keys = set()
            for kw in found:
                keys |= _KW_TO_KEYS[kw]
                for o in _KW_OVERLAP[kw]:  # a longer keyword can hide a shorter one at the same spot
                    if o in text:
                        keys |= _KW_TO_KEYS[o]
            for key in _SYSTEM_ORDER:
                if key in keys:
                    m = R[key].match(text)
                    if m and self._system(key, m, ts, raw, text) is not False:
                        return
        self.messages.append({'ts': ts, 'ch': 'system', 'ch_name': 'System', 'who': '', 'text': text, 'kind': 'other'})

    def _sys(self, ts, text, kind):
        self.messages.append({'ts': ts, 'ch': 'system', 'ch_name': 'System', 'who': '', 'text': text, 'kind': kind})

    def _system(self, key, m, ts, raw, text):
        """Handles one recognised system line. Returns False to let the next pattern try."""
        g = m.groupdict()
        if key == 'money':
            c = sum(int(a) * self.coin_units.get(u, 0) for a, u in self.R['coin'].findall(g['coins']))
            if not c:
                return False
            self.money.append({'ts': ts, 'copper': c, 'share': text.startswith('Your share')})
            return
        if key == 'loot':
            self._add_loot({'ts': ts, 'who': self._who(g['who']), 'item': _item_from(raw, g['item']), 'count': to_int(g['count'] or 1) or 1})
            return
        if key == 'item_received':
            if g['who'] != 'You':  # someone else receiving an item is group loot; your own is quests and vendors
                self._add_loot({'ts': ts, 'who': self._who(g['who']), 'item': _item_from(raw, g['item']), 'count': to_int(g['count'] or 1) or 1})
            return
        if key == 'won':
            it = item_of(raw) or _item_from(raw, g['item'])
            if not it or not it.get('name'):
                return False
            entry = {'ts': ts, 'who': self._who(g['who']), 'item': it, 'count': 1, 'won': True}
            if g['who'] == 'You':
                self._infer_you(ts, it.get('name'))
            if g.get('val'):
                entry['roll'] = {'type': g['type'], 'val': int(g['val'])}
            self._add_loot(entry)
            return
        if key == 'created':
            if not g['item'] or len(g['item']) > 80:
                return False
            self.crafted.append({'ts': ts, 'who': self._who(g['who']), 'item': _item_from(raw, g['item']), 'count': to_int(g['count'] or 1) or 1})
            return
        if key == 'roll':
            self._roll(ts, {'ts': ts, 'who': clean_name(g['who']), 'val': int(g['val']), 'lo': int(g['lo']), 'hi': int(g['hi'])})
            return
        if key == 'group_roll':
            it = _item_from(raw[raw.find(' for ') + 5:], g['item'])
            ikey = 'ng:' + it['name']
            s = self._group_sessions.get(ikey)
            if s is None or ts - s['end'] >= 120000:
                s = {'key': ikey, 'start': ts, 'end': ts, 'hi': 100, 'rolls': [], 'item': it, 'kind': 'group'}
                self.roll_sessions.append(s)
                self._group_sessions[ikey] = s
            s['end'] = ts
            s['rolls'].append({'ts': ts, 'who': clean_name(g['who']), 'val': int(g['val']), 'lo': 1, 'hi': 100, 'type': g['type']})
            self._infer_you(ts, it['name'])
            return
        if key in ('roll_choice', 'passed', 'all_passed'):
            self.roll_choices.append({'ts': ts, 'who': self._who(g.get('who') or 'Everyone'), 'type': g.get('type') or 'Pass',
                                      'item': _item_from(raw, g['item'])})
            return
        if key == 'reset':
            self.resets.append({'ts': ts, 'instance': g['instance'], 'ok': True})
        elif key == 'reset_failed':
            self.resets.append({'ts': ts, 'instance': g['instance'], 'ok': False, 'why': g['why']})
        elif key == 'honor':
            self.honor.append({'ts': ts, 'amount': int(g['amount'])})
        elif key == 'honor_kill':
            self.honor.append({'ts': ts, 'amount': int(g['amount'] or g['amount2']), 'target': g['target'],
                               'rank': (g.get('rank') or g.get('rank2') or '').strip() or None})
        elif key in ('rep_up', 'rep_up_old'):
            self.reputation.append({'ts': ts, 'faction': g['faction'], 'amount': to_int(g.get('amount')) or None, 'up': g['dir'] == 'increased'})
        elif key == 'xp_kill':
            self.xp.append({'ts': ts, 'amount': int(g['amount']), 'target': g['target'], 'bonus': g.get('bonus')})
        elif key == 'xp':
            self.xp.append({'ts': ts, 'amount': int(g['amount']), 'bonus': g.get('bonus')})
        elif key == 'quest_accepted':
            self.quests.append({'ts': ts, 'quest': g['quest'], 'done': False})
        elif key == 'quest_done':
            self.quests.append({'ts': ts, 'quest': g['quest'], 'done': True})
        elif key == 'level_up':
            self.levels.append({'ts': ts, 'level': int(g['level'])})
        elif key == 'achievement':
            self.achievements.append({'ts': ts, 'who': clean_name(g['who']), 'what': g['what'].strip('[]')})
        elif key == 'afk_on':
            self.status.append({'ts': ts, 'state': 'busy' if g['kind'] in ('Busy', 'DND') else 'away', 'text': g['text']})
        elif key == 'afk_off':
            self.status.append({'ts': ts, 'state': 'back', 'text': ''})
        elif key in ('online', 'offline'):
            self.presence.append({'ts': ts, 'who': clean_name(g['who']), 'online': key == 'online'})
        elif key in ('joins', 'leaves'):
            self.group.append({'ts': ts, 'who': clean_name(g['who']), 'joined': key == 'joins'})
        elif key in ('you_leave', 'you_join'):
            self.group.append({'ts': ts, 'who': self.me or 'You', 'joined': key == 'you_join'})
        elif key == 'others_money':
            c = sum(int(a) * self.coin_units.get(u, 0) for a, u in self.R['coin'].findall(g['coins']))
            self.others_money.append({'ts': ts, 'who': clean_name(g['who']), 'copper': c})
        elif key == 'currency':
            self.currency.append({'ts': ts, 'item': _item_from(raw, g['item']), 'count': to_int(g['count'] or 1) or 1})
        elif key == 'skill_up':
            self.skills.append({'ts': ts, 'skill': g['skill'], 'level': int(g['level'])})
        elif key == 'discovered':
            self.discovered.append({'ts': ts, 'zone': g['zone']})
        elif key == 'disenchanted':
            self.disenchants.append({'ts': ts, 'who': clean_name(g['who']), 'item': _item_from(raw, g['item'])})
        elif key == 'loot_master':
            self.loot_settings.append({'ts': ts, 'what': 'master', 'value': clean_name(g['who'])})
        elif key == 'loot_method':
            self.loot_settings.append({'ts': ts, 'what': 'method', 'value': g['method']})
        elif key == 'loot_threshold':
            self.loot_settings.append({'ts': ts, 'what': 'threshold', 'value': g['quality']})
        elif key == 'difficulty':
            self.loot_settings.append({'ts': ts, 'what': 'difficulty', 'value': f"{g['what']}: {g['level']}", 'reset_all': bool(g.get('note'))})
        elif key == 'died':
            self.deaths.append({'ts': ts, 'who': clean_name(g['who'])})
        elif key == 'you_died':
            self.deaths.append({'ts': ts, 'who': self.me or 'You'})
        self._sys(ts, text, key)

    def _roll(self, ts, roll):
        s = self.session
        if s is None or ts - s['end'] > 30000 or s['hi'] != roll['hi']:
            call = self.last_item_call if self.last_item_call and ts - self.last_item_call['ts'] < 60000 else None
            s = self.session = {'start': ts, 'end': ts, 'hi': roll['hi'], 'rolls': [], 'item': call['item'] if call else None, 'kind': 'roll', '_who': set()}
            if call:
                self.last_item_call = None
            self.roll_sessions.append(s)
        s['end'] = ts
        seen = s.setdefault('_who', set())
        if roll['who'] in seen:
            roll['again'] = True  # rolled twice: only the first counts
        seen.add(roll['who'])
        s['rolls'].append(roll)


def roll_winner(s):
    if s.get('kind') == 'group':
        counted = [r for r in s['rolls'] if not r.get('again')]
    else:
        counted = [r for r in s['rolls'] if not r.get('again') and r['lo'] == 1 and r['hi'] == s['hi']]
    if not counted:
        return None
    if s.get('kind') == 'group':
        need = [r for r in counted if r.get('type') == 'Need']
        counted = need or counted
    best = counted[0]
    for r in counted[1:]:
        if r['val'] > best['val']:
            best = r
    return best
"""Item lookups by name: quality, item id (for Wowhead links) and the game-style tooltip.

The chat log only has item names, so names are all there is to go on. Raidscribe_items.dat (next to the app)
holds about 30,000 TBC items. The AutoLog addon's loot records add exact ids and qualities on top.
Random-enchant items ("Darkcrest Sabatons of the Champion") are found through their base name.
"""

ITEMS_FILE = 'Raidscribe_items.dat'
OLD_ITEMS_FILE = 'Leyline_items.dat'   # the same file from before the app was renamed


def wowhead_url(info, name):
    if info and info.get('id'):
        return f"https://www.wowhead.com/tbc/item={info['id']}"
    return 'https://www.wowhead.com/tbc/search?q=' + urllib.parse.quote(name)


class ItemDB:
    def __init__(self):
        self.by_name = {}     # name -> [id, name, q, ilvl, tooltip]
        self.learned = {}     # name -> {'id', 'q'} from the addon (exact, beats the file)
        self.ready = False
        self.error = None
        self.count = 0
        self._cache = {}

    def find_file(self, *dirs):
        for name in (ITEMS_FILE, OLD_ITEMS_FILE):
            for d in dirs:
                if d:
                    p = os.path.join(d, name)
                    if os.path.isfile(p):
                        return p
        return None

    def load(self, path):
        try:
            with open(path, 'rb') as fh:
                data = json.loads(zlib.decompress(fh.read()).decode('utf-8'))
            self.by_name = {row[1]: row for row in data['items']}
            self.count = len(self.by_name)
            self._cache = {}
            self.ready = True
        except Exception as ex:
            self.error = f'{path}: {ex}'

    def load_async(self, path, done=None):
        def run():
            self.load(path)
            if done:
                done()
        threading.Thread(target=run, daemon=True).start()

    def learn(self, events):
        """Exact ids and qualities from the addon's loot records."""
        n = 0
        for e in events or ():
            if e.get('e') == 'loot' and e.get('name') and (e.get('item') or e.get('q') is not None):
                old = self.learned.get(e['name'])
                new = {'id': e.get('item'), 'q': e.get('q')}
                if old != new:
                    self.learned[e['name']] = new
                    n += 1
        if n:
            self._cache = {}

    def info(self, name):
        """{'id', 'q', 'name', 'base', 'ilvl', 'tooltip'} or None when the item isn't known."""
        if not name:
            return None
        if name in self._cache:
            return self._cache[name]
        out = None
        row = self.by_name.get(name)
        base = name
        if row is None:
            # random enchants add " of the Owl" / " of Stamina" to a base item; try shorter and shorter names
            cut = name
            while ' of ' in cut:
                cut = cut[:cut.rfind(' of ')]
                row = self.by_name.get(cut)
                if row:
                    base = cut
                    break
        if row:
            out = {'id': row[0], 'q': row[2], 'name': name, 'base': base, 'ilvl': row[3], 'tooltip': row[4]}
        got = self.learned.get(name)
        if got:
            out = dict(out or {'name': name, 'base': name, 'ilvl': None, 'tooltip': None})
            if got.get('id'):
                out['id'] = got['id']
            if got.get('q') is not None:
                out['q'] = got['q']
        if len(self._cache) > 20000:
            self._cache = {}
        self._cache[name] = out
        return out

    def quality(self, name, q=None):
        if q is not None:
            return q
        i = self.info(name)
        return i.get('q') if i else None


ITEMS = ItemDB()
# ======================================================================
#  Watcher: reads the Logs folder in the background, keeps parsers fed.
# ======================================================================



CHUNK = 8 << 20
CACHE_VERSION = 10   # bump whenever parsing changes, so saved results from older versions are read again
NAME_TIME = re.compile(r'WoWCombatLog-(\d{2})(\d{2})(\d{2})_(\d{2})(\d{2})(\d{2})', re.I)


def is_combat(name):
    n = name.lower()
    return n.startswith('wowcombatlog') and n.endswith('.txt')


def is_chat(name):
    n = name.lower()
    return n.startswith('wowchatlog') and n.endswith('.txt')


def real_size(path):
    """File size from an open handle. Windows can report a stale size for files another program is still writing."""
    with open(path, 'rb') as fh:
        return fh.seek(0, 2)


def file_order(path):
    m = NAME_TIME.search(os.path.basename(path))
    if m:
        mo, d, y, h, mi, s = (int(x) for x in m.groups())
        try:
            return datetime(2000 + y, mo, d, h, mi, s).timestamp()
        except ValueError:
            pass
    return os.path.getmtime(path)


class Tail:
    """Reads a growing text file line by line from a byte offset."""

    def __init__(self, path, parser, offset=0):
        self.path, self.parser, self.offset, self.rem = path, parser, offset, b''
        self.gone = False
        self.bad_lines = 0
        self.first_error = None

    def read(self, lock, progress=None, limit=None):
        """Feeds every complete new line to the parser. Returns True if anything was read."""
        size = real_size(self.path)
        if size < self.offset:
            return None  # file was replaced or truncated
        if size == self.offset:
            return False
        with open(self.path, 'rb') as fh:
            fh.seek(self.offset)
            while self.offset < size:
                data = fh.read(min(CHUNK, size - self.offset))
                if not data:
                    break
                self.offset += len(data)
                buf = self.rem + data
                cut = buf.rfind(b'\n')
                if cut < 0:
                    self.rem = buf
                    continue
                self.rem = buf[cut + 1:]
                text = buf[:cut + 1].decode('utf-8', 'replace')
                with lock:
                    feed = self.parser.feed
                    for line in text.splitlines():
                        if line:
                            try:
                                feed(line)
                            except Exception:
                                # one odd line must never cost the lines after it
                                self.bad_lines += 1
                                if self.first_error is None:
                                    self.first_error = f'{self.path}: {line[:300]!r}\n{traceback.format_exc()}'
                if progress:
                    progress(self.offset / max(1, size))
        return True


class Watcher(threading.Thread):
    def __init__(self, folder, cache_dir, combat_cls, chat_cls):
        super().__init__(daemon=True)
        self.folder = folder
        self.cache_dir = cache_dir
        self.Combat, self.Chat = combat_cls, chat_cls
        self.q = queue.Queue()
        self.lock = threading.RLock()
        self.sources = []     # finished logs: snapshots
        self.active = None    # Tail on the newest combat log
        self.chat = None      # Tail on the chat log
        self.version = 0
        self.backfill = None    # (done, total) while older logs are read in the background
        self.versions = {'combat': 0, 'fights': 0, 'chat': 0, 'addon': 0}  # what changed, so the window redraws only what it must
        self.last_chat = 0
        self.last_read = 0
        self.loaded = False
        self.running = True
        self.done = set()     # combat logs already read in full (in sources)
        self.queued = set()   # combat logs found later and being read in the background
        self.sizes = {}       # their size at the last look
        self.addon_events = []   # what the Raidscribe AutoLog addon recorded (rosters, lockouts, loot)
        self.addon_files = []
        self.addon_stamp = None

    def post(self, *msg):
        self.q.put(msg)

    # ---- cache ----
    def cache_path(self, key):
        return os.path.join(self.cache_dir, hashlib.md5(f'v{CACHE_VERSION}|{key}'.encode()).hexdigest() + '.pkl')

    def cache_get(self, key):
        try:
            with open(self.cache_path(key), 'rb') as fh:
                return pickle.load(fh)
        except Exception:
            return None

    def cache_put(self, key, snap):
        try:
            os.makedirs(self.cache_dir, exist_ok=True)
            tmp = self.cache_path(key) + '.tmp'
            with open(tmp, 'wb') as fh:
                pickle.dump(snap, fh, protocol=pickle.HIGHEST_PROTOCOL)
            os.replace(tmp, self.cache_path(key))
        except Exception:
            pass

    def cache_prune(self, keep_keys):
        keep = {os.path.basename(self.cache_path(k)) for k in keep_keys}
        try:
            for n in os.listdir(self.cache_dir):
                if n.endswith('.pkl') and n not in keep:
                    os.remove(os.path.join(self.cache_dir, n))
        except Exception:
            pass

    # ---- folder ----
    def list_logs(self):
        combat, chat = [], []
        for n in os.listdir(self.folder):
            p = os.path.join(self.folder, n)
            if is_combat(n):
                combat.append(p)
            elif is_chat(n):
                chat.append(p)
        combat.sort(key=file_order)
        chat.sort(key=os.path.getmtime)
        return combat, chat

    def me(self):
        with self.lock:
            sets = [s['players'] for s in self.sources] + ([self.active.parser.players] if self.active else [])
            for players in reversed(sets):
                for p in players.values():
                    if p.get('mine'):
                        return p['name']
        return None

    def open_active(self, path, label):
        year = datetime.fromtimestamp(os.path.getmtime(path)).year
        t = Tail(path, self.Combat(year, os.path.basename(path)))
        t.read(self.lock, lambda pct: self.post('progress', label, pct))
        with self.lock:
            self.active = t

    def open_chat(self, path):
        year = datetime.fromtimestamp(os.path.getmtime(path)).year
        t = Tail(path, self.Chat(year, self.me()))
        t.read(self.lock, lambda pct: self.post('progress', 'Reading chat log', pct))
        with self.lock:
            self.chat = t

    def load(self):
        """Gets the window going fast: saved results for old logs, then the newest log and the chat log, then
        'loaded'. Old logs that were never read before (or need reading again after an update) are read
        afterwards in the background, newest first, while the live log is already being followed."""
        combat, chat = self.list_logs()
        newest = combat.pop() if combat else None
        keep, todo = [], []
        for path in combat:
            try:
                st = os.stat(path)
            except OSError:
                continue
            key = f'{os.path.basename(path)}|{st.st_size}|{int(st.st_mtime)}'
            keep.append(key)
            snap = self.cache_get(key)
            with self.lock:
                self.done.add(path)
                if snap is not None:
                    self.sources.append(snap)
            if snap is None:
                todo.append((path, key, st))
        self.cache_prune(keep)
        if newest:
            self.open_active(newest, f'Reading {os.path.basename(newest)}')
        if chat:
            self.open_chat(chat[-1])
        self.load_addon()
        self.last_read = time.time()
        self.loaded = True
        self.version += 1
        self.post('loaded')
        if todo:
            self.backfill = (0, len(todo))
            threading.Thread(target=self.read_older, args=(todo[::-1],), daemon=True).start()

    def read_older(self, todo):
        for i, (path, key, st) in enumerate(todo):
            if not self.running:
                return
            self.backfill = (i, len(todo))
            try:
                year = datetime.fromtimestamp(st.st_mtime).year
                t = Tail(path, self.Combat(year, os.path.basename(path)))
                t.read(threading.RLock())
                t.parser.finish()
                snap = t.parser.snapshot()
                self.cache_put(key, snap)
            except FileNotFoundError:
                continue
            except Exception:
                self.post('warn', f'Couldn\u2019t read {os.path.basename(path)}:\n' + traceback.format_exc())
                continue
            with self.lock:
                self.sources.append(snap)
                self.versions['combat'] += 1
                self.versions['fights'] += 1
                self.version += 1
            self.post('changed', dict(self.versions))
        self.backfill = None
        self.post('changed', dict(self.versions))

    def drop_active(self, cache=True):
        """Moves the current combat log into history (when WoW starts a new one, or the file is deleted)."""
        old = self.active
        with self.lock:
            old.parser.finish()
            snap = old.parser.snapshot()
            self.sources.append(snap)
            self.done.add(old.path)
            self.active = None
        if cache:
            try:
                st = os.stat(old.path)
                self.cache_put(f'{os.path.basename(old.path)}|{st.st_size}|{int(st.st_mtime)}', snap)
            except OSError:
                pass

    def load_addon(self):
        """Re-reads the addon's saved data when WoW has written it (on logout or /reload). Returns True if it changed."""
        try:
            files = find_saved_files(self.folder)
            stamp = tuple((f, os.path.getmtime(f), os.path.getsize(f)) for f in files)
        except Exception:
            return False
        if stamp == self.addon_stamp:
            return False
        warnings = []
        events = load_events(self.folder, warnings)
        with self.lock:
            self.addon_events, self.addon_files, self.addon_stamp = events, files, stamp
        for w in warnings:
            self.post('warn', 'Addon data: ' + str(w))
        return True

    def report_bad_lines(self):
        for t in (self.active, self.chat):
            if t and t.first_error and not getattr(t, 'reported', False):
                t.reported = True
                self.post('warn', f'Skipped {t.bad_lines} line(s) that could not be read. First one:\n{t.first_error}')

    def tail(self):
        changed = False
        if self.active:
            p = self.active.parser
            before = (p.handled, len(p.fights), p.cur is not None)
            try:
                r = self.active.read(self.lock)
            except FileNotFoundError:
                # the log was deleted: keep everything already read, stop watching it
                self.drop_active(cache=False)
                r, changed = False, True
                self.versions['combat'] += 1
                self.versions['fights'] += 1
            if r is None:  # log cleared or replaced: read it again from the start
                self.open_active(self.active.path, 'Re-reading combat log')
                changed = True
                self.versions['combat'] += 1
                self.versions['fights'] += 1
            elif r:
                self.last_read = time.time()
            if self.active:
                with self.lock:
                    p = self.active.parser
                    p.tick(time.time() * 1000)
                    if (p.handled, len(p.fights), p.cur is not None) != before:
                        changed = True
                        self.versions['combat'] += 1
                        if len(p.fights) != before[1]:
                            self.versions['fights'] += 1  # a fight finished: the summaries change
        if self.chat and not self.chat.gone:
            try:
                r = self.chat.read(self.lock)
            except FileNotFoundError:
                self.chat.gone = True  # keep the messages already read; pick the file up again if WoW recreates it
                r = False
            if r is None:
                with self.lock:
                    self.chat.offset, self.chat.rem = 0, b''
                r = self.chat.read(self.lock)
            if r:
                if not self.chat.parser.me:
                    self.chat.parser.me = self.me()
                changed = True
                self.last_chat = time.time()
                self.versions['chat'] += 1
                self.post('chat')
        return changed

    def rescan(self):
        if not os.path.isdir(self.folder):
            return False
        combat, chat = self.list_logs()
        changed = False
        if chat:
            newest = chat[-1]
            if not self.chat:
                self.open_chat(newest)
                changed = True
            elif self.chat.gone or self.chat.path != newest:
                # carry on in the new or recreated file, keeping what was read so far
                with self.lock:
                    self.chat.path, self.chat.offset, self.chat.rem, self.chat.gone = newest, 0, b'', False
                changed = True
        fresh = [p for p in combat if p not in self.done]
        if fresh and (not self.active or self.active.path != fresh[-1]):
            if self.active:
                self.drop_active()
            self.open_active(fresh[-1], 'Reading new combat log')
            changed = True
        # logs copied in alongside it (several at once, or older ones): read them in the background too.
        # On a PC WoW writes one log at a time, but on a phone logs arrive in batches.
        extra = [p for p in fresh if (not self.active or p != self.active.path) and p not in self.queued]
        if extra:
            todo = []
            for path in extra:
                try:
                    st = os.stat(path)
                except OSError:
                    continue
                size = (st.st_size, int(st.st_mtime))
                if self.sizes.get(path) != size:   # still being copied: wait until it stops growing
                    self.sizes[path] = size
                    continue
                self.queued.add(path)
                with self.lock:
                    self.done.add(path)
                todo.append((path, f'{os.path.basename(path)}|{st.st_size}|{int(st.st_mtime)}', st))
            if todo:
                threading.Thread(target=self.read_older, args=(todo[::-1],), daemon=True).start()
        return changed

    def run(self):
        while self.running and not os.path.isdir(self.folder):
            self.post('missing')
            time.sleep(3)
        if not self.running:  # stopped while waiting (another folder was picked)
            return
        self.post('found')
        try:
            self.load()
        except Exception:
            self.post('error', traceback.format_exc())
        n = 0
        while self.running:
            try:
                changed = self.tail()
                self.report_bad_lines()
                n += 1
                if n % 5 == 0 and self.rescan():
                    changed = True
                    self.versions['combat'] += 1
                    self.versions['fights'] += 1
                    self.versions['chat'] += 1
                if n % 15 == 0 and self.load_addon():
                    changed = True
                    self.versions['addon'] += 1
                if changed:
                    self.version += 1
                    self.post('changed', dict(self.versions))
            except Exception:
                # WoW may be mid-write or the folder briefly unavailable: try again next second
                self.post('warn', traceback.format_exc())
            time.sleep(1)
# ======================================================================
#  Activities: what you were doing (raid, dungeon, PvP, farming), sessions,
#  summaries, history and the text/report data used for sharing.
#  Pure data, no UI.
# ======================================================================



SESSION_GAP = 2 * 3600_000   # this long with nothing happening starts a new session
DISCORD_LIMIT = 1900         # Discord's message limit is 2000 characters; leave room

# instance ID -> (name, kind, size). TBC content plus the older raids people still run.
CATALOG = {
    # TBC raids
    532: ('Karazhan', 'raid', 10), 565: ("Gruul's Lair", 'raid', 25), 544: ("Magtheridon's Lair", 'raid', 25),
    548: ('Serpentshrine Cavern', 'raid', 25), 550: ('Tempest Keep', 'raid', 25), 534: ('Hyjal Summit', 'raid', 25),
    564: ('Black Temple', 'raid', 25), 568: ("Zul'Aman", 'raid', 10), 580: ('Sunwell Plateau', 'raid', 25),
    # older raids
    409: ('Molten Core', 'raid', 40), 469: ('Blackwing Lair', 'raid', 40), 509: ("Ruins of Ahn'Qiraj", 'raid', 20),
    531: ("Temple of Ahn'Qiraj", 'raid', 40), 309: ("Zul'Gurub", 'raid', 20), 249: ("Onyxia's Lair", 'raid', 40), 533: ('Naxxramas', 'raid', 40),
    # TBC dungeons
    543: ('Hellfire Ramparts', 'dungeon', 5), 542: ('The Blood Furnace', 'dungeon', 5), 540: ('The Shattered Halls', 'dungeon', 5),
    547: ('The Slave Pens', 'dungeon', 5), 546: ('The Underbog', 'dungeon', 5), 545: ('The Steamvault', 'dungeon', 5),
    557: ('Mana-Tombs', 'dungeon', 5), 558: ('Auchenai Crypts', 'dungeon', 5), 556: ('Sethekk Halls', 'dungeon', 5),
    555: ('Shadow Labyrinth', 'dungeon', 5), 560: ('Old Hillsbrad Foothills', 'dungeon', 5), 269: ('The Black Morass', 'dungeon', 5),
    554: ('The Mechanar', 'dungeon', 5), 553: ('The Botanica', 'dungeon', 5), 552: ('The Arcatraz', 'dungeon', 5),
    585: ("Magisters' Terrace", 'dungeon', 5),
    # battlegrounds and arenas
    489: ('Warsong Gulch', 'battleground', 10), 529: ('Arathi Basin', 'battleground', 15), 30: ('Alterac Valley', 'battleground', 40),
    566: ('Eye of the Storm', 'battleground', 15), 559: ('Nagrand Arena', 'arena', 5), 562: ("Blade's Edge Arena", 'arena', 5),
    572: ('Ruins of Lordaeron', 'arena', 5),
}
for _k, _v in CLASSIC_INSTANCES.items():
    CATALOG.setdefault(_k, _v)
KIND_LABEL = {'raid': 'Raid', 'dungeon': 'Dungeon', 'battleground': 'Battleground', 'arena': 'Arena', 'instance': 'Instance'}
KIND_ORDER = ['raid', 'dungeon', 'battleground', 'arena', 'instance']


# ---------------------------------------------------------------- helpers

def fight_dur(f):
    return max(1000, f['end'] - f['start'])


def dur(ms):
    s = max(0, round(ms / 1000))
    if s >= 3600:
        return f'{s // 3600}h {s % 3600 // 60:02d}m'
    return f'{s // 60}:{s % 60:02d}'


def span(ms):
    """A length of time people read at a glance: 45s, 13m, 1h 23m (not 13:21, which looks like a clock time)."""
    s = max(0, round(ms / 1000))
    if s < 60:
        return f'{s}s'
    m = round(s / 60)
    if m < 60:
        return f'{m}m'
    return f'{m // 60}h {m % 60:02d}m'


def plural(n, word):
    return f"{n} {word}{'' if n == 1 else 's'}"


def fmt(n):
    if n >= 1e6:
        return f'{n / 1e6:.2f}M'
    if n >= 1e4:
        return f'{n / 1e3:.1f}k'
    return f'{round(n):,}'


def gold(copper):
    copper = int(round(copper))
    sign = '-' if copper < 0 else ''
    copper = abs(copper)
    g, s = copper // 10000, copper % 10000 // 100
    return f'{sign}{g:,}g {s}s' if g else f'{sign}{s}s {copper % 100}c'


def day_label(ts):
    d = datetime.fromtimestamp(ts / 1000)
    return d.strftime('%a, %b ') + str(d.day)


def clock(ts):
    return datetime.fromtimestamp(ts / 1000).strftime('%I:%M %p').lstrip('0')


def week_start(ts):
    """Weekly reset week, starting Tuesday (US realms)."""
    d = datetime.fromtimestamp(ts / 1000)
    start = (d - timedelta(days=(d.weekday() - 1) % 7)).replace(hour=0, minute=0, second=0, microsecond=0)
    return int(start.timestamp() * 1000)


def kind_of(run, fights):
    info = CATALOG.get(run.get('instance_id'))
    if info:
        return info[1]
    name = (run.get('name') or '').lower()
    if 'arena' in name:
        return 'arena'
    sizes = [f.get('size') or 0 for f in fights if f['kind'] == 'boss']
    if sizes:
        return 'raid' if max(sizes) > 5 else 'dungeon'
    players = len({g for f in fights for g in f['players']})
    return 'raid' if players > 5 else 'dungeon' if fights else 'instance'


# ---------------------------------------------------------------- model

class Model:
    """Everything the summary screens and exports need, built from the parsed logs."""

    def __init__(self, fights, runs, players, by_id, cp=None, addon_events=None, me=None, items=None):
        self.fights, self.runs, self.players, self.by_id = fights, runs, players, by_id
        self.items = items  # ItemDB: quality and id by item name (the chat log only has names)
        self.cp = cp
        self.events = addon_events or []
        self.me = me
        self.annotate_runs()
        self.assign_loot()
        self._run_cache = {}

    # ---- runs ----
    def run_fights(self, run):
        return [self.by_id[i] for i in run['fights'] if i in self.by_id]

    def annotate_runs(self):
        enter = [e for e in self.events if e.get('e') == 'enter']
        pvp = [e for e in self.events if e.get('e') == 'pvp']
        for r in self.runs:
            fights = self.run_fights(r)
            r['kind'] = kind_of(r, fights)
            info = CATALOG.get(r.get('instance_id'))
            if info and r.get('name') in (None, '', 'Instance'):
                r['name'] = info[0]
            # the addon knows the difficulty and lockout (exact), when it's installed
            near = [e for e in enter if e.get('id') == r.get('instance_id') and r['start'] - 3600_000 <= e['ts'] <= r['end']]
            if near:
                e = near[-1]
                r['difficulty_name'] = e.get('diffName')
                r['lockout'] = e.get('lockout')
                if e.get('type') in ('arena', 'pvp'):
                    r['kind'] = 'arena' if e.get('type') == 'arena' else 'battleground'
            if r['kind'] in ('battleground', 'arena'):
                # the first result recorded after this match started (a later one belongs to the next match)
                res = [e for e in pvp if e.get('id') == r.get('instance_id') and r['start'] <= e['ts'] <= r['end'] + 600_000]
                r['result'] = None if not res else ('win' if res[0].get('win') else 'loss' if res[0].get('win') is False else None)

    LOOT_AFTER = 300_000  # loot up to 5 minutes after a run's last fight still belongs to it

    _loot_cache = (None, None)

    def all_loot(self):
        """Every looted item, with names resolved. Reused between redraws until the chat log or addon data grows."""
        cp = self.cp
        key = (id(cp), len(cp.loot) if cp else 0, len(self.events), bool(self.items and self.items.ready), self.me)
        if Model._loot_cache[0] == key:
            return Model._loot_cache[1]
        out = self._all_loot()
        Model._loot_cache = (key, out)
        return out

    def _all_loot(self):
        q = self.items.quality if self.items else (lambda name, q=None: q)
        if self.cp and self.cp.loot:
            return [{'ts': l['ts'], 'who': self.name_of(l['who'], l['ts']), 'mine': l['who'] == 'You', 'name': l['item']['name'],
                     'q': q(l['item']['name'], l['item']['q']), 'count': l['count'], 'won': bool(l.get('won')), 'roll': l.get('roll')} for l in self.cp.loot]
        return [{'ts': e['ts'], 'who': (e.get('who') or '').split('-')[0], 'name': e.get('name') or f"item {e.get('item')}",
                 'q': q(e.get('name'), e.get('q')), 'count': e.get('n') or 1, 'won': False, 'roll': None} for e in self.events if e.get('e') == 'loot']

    def assign_loot(self):
        """Every item belongs to exactly one place: the run it dropped in, or nowhere (farming/world)."""
        import bisect
        self.loot_run = {}
        self.run_loot = {}
        spans = sorted(((r['start'] - 60_000, r['end'] + self.LOOT_AFTER, r['id']) for r in self.runs))
        starts = [a for a, _, _ in spans]
        self.loot = self.all_loot()
        for i, l in enumerate(self.loot):
            owner = None
            k = bisect.bisect_right(starts, l['ts'])
            while k > 0:  # the latest run that started before the item and still covers it wins
                k -= 1
                a, b, rid = spans[k]
                if l['ts'] <= b:
                    owner = rid
                    break
                if l['ts'] - a > 48 * 3600_000:
                    break
            self.loot_run[i] = owner
            if owner:
                self.run_loot.setdefault(owner, []).append(l)

    def loot_of_run(self, run):
        # raids: blue and better; dungeons: green and better (what the group rolls on); anything rolled for counts too
        low = 2 if run.get('kind') == 'dungeon' else 3
        return [l for l in self.run_loot.get(run['id'], ()) if l['q'] is None or l['q'] >= low or l.get('won')]

    # ---- sessions (days played) ----
    @property
    def sessions(self):
        if not hasattr(self, '_sessions'):
            self._sessions = self.build_sessions()
        return self._sessions

    def build_sessions(self):
        """Groups everything into sittings: anything closer together than SESSION_GAP is one session."""
        points = [(f['start'], f['end']) for f in self.fights]
        cp = self.cp
        if cp:
            points += [(l['ts'], l['ts']) for l in cp.loot if self.is_mine(l['who'])]
            points += [(m['ts'], m['ts']) for m in cp.money]
        points += [(e['ts'], e['ts']) for e in self.events if e.get('e') in ('login', 'logout', 'enter', 'leave', 'money', 'loot')]
        if not points:
            return []
        points.sort()
        sessions = []
        cur = None
        for a, b in points:
            if cur is None or a - cur['end'] > SESSION_GAP:
                cur = {'start': a, 'end': b}
                sessions.append(cur)
            else:
                cur['end'] = max(cur['end'], b)
        for i, s in enumerate(sessions):
            s['id'] = f"s{s['start']}"
            s['runs'] = [r for r in self.runs if s['start'] <= r['start'] <= s['end']]
            s['world_fights'] = [f for f in self.fights if not f.get('run_id') and s['start'] <= f['start'] <= s['end']]
        return sessions

    def session_of(self, run):
        return next((s for s in self.sessions if run in s['runs']), None)

    def is_mine(self, who):
        return who in ('You', self.me) if self.me else who == 'You'

    def you_at(self, ts):
        """Which of your characters was playing at that moment: the addon knows exactly, the chat log sometimes."""
        import bisect
        if not hasattr(self, '_chars'):
            chars = sorted((e['ts'], e['c'].split('-')[0]) for e in self.events if e.get('c') and e.get('ts'))
            self._chars = chars
            self._char_ts = [t for t, _ in chars]
        k = bisect.bisect_right(self._char_ts, ts)
        if k and ts - self._chars[k - 1][0] < 12 * 3600_000:
            return self._chars[k - 1][1]
        got = self.cp.you_at(ts) if self.cp and hasattr(self.cp, 'you_at') else None
        return got or self.me

    def name_of(self, who, ts):
        return (self.you_at(ts) or 'You') if who == 'You' else who

    def in_any_run(self, ts):
        return any(r['start'] - 60_000 <= ts <= r['end'] + 120_000 for r in self.runs)

    # ---- run summary ----
    def run_summary(self, run, scope='boss'):
        """All the numbers for one instance run: bosses, players, deaths, loot.
        scope 'boss' totals boss fights (or everything when there were none), 'all' totals every fight."""
        fights = self.run_fights(run)
        bosses_by_id, order = {}, []
        for f in fights:
            if f['kind'] != 'boss':
                continue
            key = f.get('encounter_id') or f['name']
            if key not in bosses_by_id:
                bosses_by_id[key] = {'id': key, 'name': f['name'], 'attempts': []}
                order.append(bosses_by_id[key])
            bosses_by_id[key]['attempts'].append(f)
        for b in order:
            kill = next((a for a in b['attempts'] if a['success']), None)
            b['kill'] = kill
            b['wipes'] = [a for a in b['attempts'] if not a['success']]
        end = max([run['end']] + [f['end'] for f in fights]) if fights else run['end']
        boss_fights = [f for f in fights if f['kind'] == 'boss']
        counted = boss_fights if scope == 'boss' and boss_fights else fights   # dungeons/PvP without boss lines use everything

        agg = {}
        for f in counted:
            d = fight_dur(f)
            for g, st in f['players'].items():
                a = agg.setdefault(g, {'guid': g, 'name': st['name'], 'dmg': 0, 'heal': 0, 'time': 0, 'deaths': 0, 'interrupts': 0,
                                       'dispels': 0, 'cons': 0, 'cons_by': {}, 'avoid': 0, 'taken': 0,
                                       'cds_by': {}, 'int_by': {}, 'kicked': {}, 'taken_by': {}})
                a['dmg'] += st['dmg']; a['heal'] += st['heal']; a['time'] += d; a['deaths'] += st['deaths']
                a['interrupts'] += st['interrupts']; a['dispels'] += st['dispels']; a['avoid'] += st['avoid']; a['taken'] += st['taken']
                for k, v in st['cons'].items():
                    a['cons'] += v
                    a['cons_by'][k] = a['cons_by'].get(k, 0) + v
                for src_key, dst_key in (('cds', 'cds_by'), ('int_by', 'int_by'), ('kicked', 'kicked'), ('taken_by', 'taken_by')):
                    for k, v in (st.get(src_key) or {}).items():
                        a[dst_key][k] = a[dst_key].get(k, 0) + v
        for a in agg.values():
            a['dps'] = a['dmg'] / max(1, a['time'] / 1000)
            a['hps'] = a['heal'] / max(1, a['time'] / 1000)
            p = self.players.get(a['guid']) or {}
            a['cls'] = p.get('cls')
        players = sorted(agg.values(), key=lambda a: -a['dmg'])
        deaths = [dict(d, fight=f['name'], fight_id=f['id'], at=d['ts'] - f['start']) for f in fights for d in f['deaths']]
        loot = self.loot_of_run(run)
        kills = [b for b in order if b['kill'] and b['id'] not in HOLIDAY_ENCS]
        holiday = [(b['name'], sum(1 for a in b['attempts'] if a['success'])) for b in order if b['kill'] and b['id'] in HOLIDAY_ENCS]
        first_pull = min((f['start'] for f in fights), default=run['start'])
        last_kill = max((b['kill']['end'] for b in kills), default=None)
        wipes = [a for b in order for a in b['wipes']]
        roster = self.roster_for(run, end)
        return {
            'run': run, 'kind': run.get('kind', 'instance'), 'name': run['name'], 'start': run['start'], 'end': end,
            'bosses': order, 'kills': len(kills), 'known_bosses': self.known_bosses(run), 'wipes': len(wipes),
            'wipe_time': sum(fight_dur(f) for f in wipes), 'clear_time': (last_kill - first_pull) if last_kill else None,
            'players': players, 'deaths': deaths, 'loot': loot, 'fights': fights, 'roster': roster,
            'difficulty': run.get('difficulty_name'), 'result': run.get('result'),
            'trash_time': sum(fight_dur(f) for f in fights if f['kind'] == 'trash'),
            'scope': 'boss' if counted is boss_fights and boss_fights else 'all', 'counted': counted,
            'records': self.records_set_in(run, order), 'holiday': holiday,
        }

    def known_bosses(self, run):
        info = INSTANCE_BOSSES.get(run.get('instance_id'))
        return len(info[1]) if info else 0

    def roster_for(self, run, end):
        """Who was there: the addon's roster if it recorded one, otherwise everyone seen in the fights."""
        rosters = [e for e in self.events if e.get('e') == 'roster']
        before = [e for e in rosters if run['start'] - 7200_000 <= e['ts'] <= run['start'] + 60_000]
        during = [e for e in rosters if run['start'] + 60_000 < e['ts'] <= end]
        snaps = before[-1:] + during  # the group as it was when the run started, plus anyone who joined
        names = []
        if snaps:
            for e in snaps:
                for m in e.get('members') or []:
                    n = (m.get('n') or '').split('-')[0]
                    if n and n not in names:
                        names.append(n)
        else:
            seen = {}
            for f in self.run_fights(run):
                for g, st in f['players'].items():
                    seen.setdefault(st['name'], 0)
                    seen[st['name']] += 1
            names = sorted(seen)
        return names

    # ---- records ----
    def records(self):
        """Fastest kill per boss, and each player's best DPS per boss, over all logs."""
        if hasattr(self, '_records'):
            return self._records
        kills, dps = {}, {}
        for f in self.fights:
            if f['kind'] != 'boss' or not f['success']:
                continue
            key = f.get('encounter_id') or f['name']
            d = fight_dur(f)
            if key not in kills or d < kills[key]['time']:
                kills[key] = {'time': d, 'fight_id': f['id'], 'ts': f['start'], 'name': f['name']}
            sec = d / 1000
            for g, st in f['players'].items():
                v = st['dmg'] / sec
                k = (st['name'], key)
                if v > 0 and (k not in dps or v > dps[k]['dps']):
                    dps[k] = {'dps': v, 'fight_id': f['id'], 'ts': f['start'], 'boss': f['name'], 'name': st['name']}
        self._records = {'kills': kills, 'dps': dps}
        return self._records

    def records_set_in(self, run, bosses):
        """Records broken in this run, compared with earlier kills only: faster kills, and personal-best DPS."""
        kills_by_boss = {}
        for f in self.fights:
            if f['kind'] == 'boss' and f['success']:
                kills_by_boss.setdefault(f.get('encounter_id') or f['name'], []).append(f)
        out, personal = [], []
        for b in bosses:
            k = b.get('kill')
            if not k:
                continue
            earlier = [f for f in kills_by_boss.get(k.get('encounter_id') or k['name'], []) if f['start'] < k['start']]
            if not earlier:
                continue  # a first kill isn't a record yet
            if fight_dur(k) < min(fight_dur(f) for f in earlier):
                out.append(f"Fastest {k['name']} kill: {dur(fight_dur(k))} (was {dur(min(fight_dur(f) for f in earlier))})")
            sec = fight_dur(k) / 1000
            for st in k['players'].values():
                prev = [ps['dmg'] / (fight_dur(f) / 1000) for f in earlier for ps in f['players'].values() if ps['name'] == st['name'] and ps['dmg'] > 0]
                now = st['dmg'] / sec
                if prev and now > max(prev):
                    personal.append((now / max(prev) - 1, f"{st['name']}: best DPS on {k['name']}, {round(now):,} (up {round(100 * (now / max(prev) - 1))}%)"))
        personal.sort(key=lambda x: -x[0])
        return out + [t for _, t in personal[:5]]

    # ---- session summary ----
    def session_summary(self, s):
        runs = [self.run_summary(r) for r in s['runs']]
        cp = self.cp
        money_in = money_out = 0
        farm_loot = []
        if cp:
            for m in cp.money:
                if s['start'] - 60_000 <= m['ts'] <= s['end'] + 60_000:
                    money_in += m['copper']
            farm_loot = [l for i, l in enumerate(self.loot) if s['start'] - 60_000 <= l['ts'] <= s['end'] + 60_000
                         and l.get('mine') and self.loot_run.get(i) is None]
        addon_money = [e for e in self.events if e.get('e') == 'money' and s['start'] - 60_000 <= e['ts'] <= s['end'] + 60_000]
        money_net = None
        if addon_money:  # the addon sees every change (quests, vendors, mail, repairs), not just looted coins
            money_net = sum(e.get('d', 0) for e in addon_money)
            money_out = -sum(e.get('d', 0) for e in addon_money if e.get('d', 0) < 0)
            if not cp:
                money_in = sum(e.get('d', 0) for e in addon_money if e.get('d', 0) > 0)
        within = lambda lst: [e for e in (getattr(cp, lst, None) or []) if s['start'] - 60_000 <= e['ts'] <= s['end'] + 60_000] if cp else []
        honor = sum(e['amount'] for e in within('honor'))
        rep = {}
        for e in within('reputation'):
            rep[e['faction']] = rep.get(e['faction'], 0) + (e['amount'] if e.get('up', True) else -e['amount'])
        quests = sum(1 for e in within('quests') if e.get('done'))
        badges = {}
        for e in within('currency'):
            badges[e['item']['name']] = badges.get(e['item']['name'], 0) + e['count']
        in_runs = sum(r['end'] - r['start'] for r in runs)
        total = max(1, s['end'] - s['start'])
        outside = max(0, total - in_runs)
        by_kind = {}
        for r in runs:
            by_kind.setdefault(r['kind'], []).append(r)
        pvp = [r for r in runs if r['kind'] in ('battleground', 'arena')]
        return {
            'session': s, 'start': s['start'], 'end': s['end'], 'duration': total, 'runs': runs, 'by_kind': by_kind,
            'kills': sum(r['kills'] for r in runs if r['kind'] in ('raid', 'dungeon')),
            'wipes': sum(r['wipes'] for r in runs if r['kind'] in ('raid', 'dungeon')),
            'deaths': sum(len(r['deaths']) for r in runs) + sum(len(f['deaths']) for f in s['world_fights']),
            'money_in': money_in, 'money_out': money_out, 'money_net': money_net,
            'honor': honor, 'reputation': sorted(rep.items(), key=lambda kv: -kv[1]), 'quests_done': quests, 'currency': badges, 'gold_per_hour': money_in / (total / 3600_000) if total > 600_000 else None,
            'farm_loot': farm_loot, 'outside_time': outside, 'world_fights': len(s['world_fights']),
            'pvp': {'matches': len(pvp), 'wins': sum(1 for r in pvp if r['result'] == 'win'), 'losses': sum(1 for r in pvp if r['result'] == 'loss')},
        }

    # ---- history ----
    def weeks(self):
        """Per reset week: raids, kills, wipes, who came, what dropped."""
        weeks = {}
        for r in self.runs:
            w = weeks.setdefault(week_start(r['start']), {'start': week_start(r['start']), 'runs': [], 'kills': 0, 'wipes': 0, 'attendance': {}, 'loot': []})
            sm = self.run_summary_cached(r)
            w['runs'].append(sm)
            if sm['kind'] in ('raid', 'dungeon'):
                w['kills'] += sm['kills']
                w['wipes'] += sm['wipes']
            if sm['kind'] == 'raid':
                for n in sm['roster']:
                    w['attendance'][n] = w['attendance'].get(n, 0) + 1
                w['loot'] += sm['loot']
        return [weeks[k] for k in sorted(weeks, reverse=True)]

    def run_summary_cached(self, r, scope='boss'):
        key = (r['id'], len(r['fights']), r['end'], scope)
        if key not in self._run_cache:
            self._run_cache[key] = self.run_summary(r, scope)
        return self._run_cache[key]

    # ---- one player in one run ----
    def player_summary(self, run, guid, scope='boss'):
        """One person's night: their totals and ranks, every fight, top abilities, deaths, consumables and loot."""
        sm = self.run_summary_cached(run, scope)
        me = next((p for p in sm['players'] if p['guid'] == guid), None)
        if me is None:
            return None
        dealers = [p for p in sm['players'] if p['dmg'] > 0]
        healers = sorted([p for p in sm['players'] if p['heal'] > 0], key=lambda p: -p['hps'])
        dealers.sort(key=lambda p: -p['dps'])
        rank_d = next((i + 1 for i, p in enumerate(dealers) if p['guid'] == guid), None)
        rank_h = next((i + 1 for i, p in enumerate(healers) if p['guid'] == guid), None)
        seen, rows = {}, []
        dmg_by, heal_by = {}, {}
        for f in sm['counted']:
            st = f['players'].get(guid)
            key = f.get('encounter_id') or f['name']
            if f['kind'] == 'boss':
                seen[key] = seen.get(key, 0) + 1
            if not st:
                continue
            sec = fight_dur(f) / 1000
            rows.append({'fight': f, 'name': f['name'] or 'Trash', 'kind': f['kind'], 'success': f.get('success'), 'attempt': seen.get(key) if f['kind'] == 'boss' else None,
                         'time': fight_dur(f), 'dmg': st['dmg'], 'dps': st['dmg'] / sec, 'heal': st['heal'], 'hps': st['heal'] / sec,
                         'deaths': st['deaths'], 'taken': st['taken'], 'boss_hp': f.get('boss_hp')})
            for k, v in (st.get('dmg_by') or {}).items():
                dmg_by[k] = dmg_by.get(k, 0) + v
            for k, v in (st.get('heal_by') or {}).items():
                heal_by[k] = heal_by.get(k, 0) + v
        deaths = [d for d in sm['deaths'] if d.get('guid') == guid]
        loot = [l for l in sm['loot'] if l['who'] == me['name']]
        return {'run': run, 'run_summary': sm, 'guid': guid, 'player': me, 'name': me['name'], 'cls': me.get('cls'),
                'start': sm['start'], 'end': sm['end'], 'kind': sm['kind'], 'scope': sm['scope'],
                'rank_dps': rank_d, 'of_dps': len(dealers), 'rank_hps': rank_h, 'of_hps': len(healers),
                'fights': rows, 'dmg_by': sorted(dmg_by.items(), key=lambda kv: -kv[1]), 'heal_by': sorted(heal_by.items(), key=lambda kv: -kv[1]),
                'deaths': deaths, 'loot': loot, 'cons_by': sorted(me['cons_by'].items(), key=lambda kv: -kv[1])}

    def raid_nights(self):
        """One entry per raid night (a raid instance on a date) with who was there, oldest first."""
        nights = {}
        for r in self.runs:
            if r.get('kind') != 'raid':
                continue
            sm = self.run_summary_cached(r)
            key = (datetime.fromtimestamp(sm['start'] / 1000).date(), sm['name'])
            n = nights.setdefault(key, {'start': sm['start'], 'name': sm['name'], 'roster': set()})
            n['roster'].update(sm['roster'])
            n['start'] = min(n['start'], sm['start'])
        return sorted(nights.values(), key=lambda n: n['start'])

    def attendance(self):
        """Raid attendance across all raid nights."""
        raids = [self.run_summary_cached(r) for r in self.runs if r.get('kind') == 'raid']
        nights = {}
        for sm in raids:
            key = (datetime.fromtimestamp(sm['start'] / 1000).date(), sm['name'])
            nights.setdefault(key, set()).update(sm['roster'])
        total = len(nights)
        counts = {}
        for names in nights.values():
            for n in names:
                counts[n] = counts.get(n, 0) + 1
        return total, sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))

    def loot_by_player(self):
        out = {}
        for r in self.runs:
            if r.get('kind') != 'raid':
                continue
            for l in self.run_summary_cached(r)['loot']:
                out.setdefault(l['who'], []).append(dict(l, raid=r['name']))
        return sorted(out.items(), key=lambda kv: (-len(kv[1]), kv[0]))

    def player_history(self):
        """Every player's raid boss kills over time: per kill DPS/HPS, per week, per boss."""
        if hasattr(self, '_phist'):
            return self._phist
        out = {}
        for r in self.runs:
            if r.get('kind') != 'raid':  # raid bosses only: a level 70 soloing an old dungeon boss would swamp the numbers
                continue
            for f in self.run_fights(r):
                if f['kind'] != 'boss' or not f['success'] or f.get('encounter_id') in HOLIDAY_ENCS:
                    continue
                sec = fight_dur(f) / 1000
                wk = week_start(f['start'])
                for g, st in f['players'].items():
                    p = self.players.get(g) or {}
                    name = st['name']
                    h = out.setdefault(name, {'name': name, 'cls': p.get('cls'), 'kills': [], 'weeks': {}, 'bosses': {}, 'runs': set()})
                    if p.get('cls'):
                        h['cls'] = p['cls']
                    k = {'ts': f['start'], 'boss': f['name'], 'run': r['name'], 'run_id': r['id'], 'fight_id': f['id'], 'kind': r.get('kind'),
                         'dmg': st['dmg'], 'heal': st['heal'], 'dps': st['dmg'] / sec, 'hps': st['heal'] / sec, 'time': sec, 'deaths': st['deaths']}
                    h['kills'].append(k)
                    h['runs'].add(r['id'])
                    w = h['weeks'].setdefault(wk, {'dmg': 0, 'heal': 0, 'time': 0, 'kills': 0})
                    w['dmg'] += st['dmg']; w['heal'] += st['heal']; w['time'] += sec; w['kills'] += 1
                    h['bosses'].setdefault(f['name'], []).append(k)
        for h in out.values():
            t = sum(k['time'] for k in h['kills']) or 1
            h['dmg'] = sum(k['dmg'] for k in h['kills'])
            h['heal'] = sum(k['heal'] for k in h['kills'])
            h['dps'], h['hps'] = h['dmg'] / t, h['heal'] / t
            h['healer'] = h['heal'] > h['dmg']
            key = 'hps' if h['healer'] else 'dps'
            h['best'] = max(h['kills'], key=lambda k: k[key]) if h['kills'] else None
            h['trend'] = [(wk, (w['heal'] if h['healer'] else w['dmg']) / max(1, w['time'])) for wk, w in sorted(h['weeks'].items())]
            h['runs'] = len(h['runs'])
        self._phist = out
        return out

    def week_top(self, wk_start, n=3):
        """The best average DPS and HPS on boss kills in one reset week."""
        dps, hps = [], []
        for h in self.player_history().values():
            w = h['weeks'].get(wk_start)
            if not w or not w['time']:
                continue
            if w['dmg'] > w['heal']:
                dps.append((w['dmg'] / w['time'], h))
            elif w['heal']:
                hps.append((w['heal'] / w['time'], h))
        return sorted(dps, key=lambda x: -x[0])[:n], sorted(hps, key=lambda x: -x[0])[:n]

    def boss_history(self):
        """Every boss you've fought: kills, wipes, best and latest kill time."""
        out = {}
        for f in self.fights:
            if f['kind'] != 'boss':
                continue
            if f.get('encounter_id') in HOLIDAY_ENCS:
                continue
            key = f.get('encounter_id') or f['name']
            b = out.setdefault(key, {'name': f['name'], 'kills': [], 'wipes': 0, 'pulls': [], 'weeks': {}})
            b['pulls'].append(f)
            w = b['weeks'].setdefault(week_start(f['start']), {'kills': 0, 'wipes': 0, 'best': None})
            if f['success']:
                b['kills'].append(f)
                w['kills'] += 1
                w['best'] = min(fight_dur(f), w['best'] or fight_dur(f))
            else:
                b['wipes'] += 1
                w['wipes'] += 1
        for b in out.values():
            b['best'] = min((fight_dur(k) for k in b['kills']), default=None)
            b['latest'] = fight_dur(b['kills'][-1]) if b['kills'] else None
        return sorted(out.values(), key=lambda b: (-(b['pulls'][-1]['start'] if b['pulls'] else 0)))


# ---------------------------------------------------------------- sharing: Discord text

def _cut(lines, limit=DISCORD_LIMIT):
    out, n = [], 0
    for l in lines:
        if n + len(l) + 1 > limit:
            out.append('…')
            break
        out.append(l)
        n += len(l) + 1
    return '\n'.join(out)


def run_header(sm):
    bits = [day_label(sm['start']), span(sm['end'] - sm['start'])]
    if sm['kind'] in ('raid', 'dungeon') and sm['bosses']:
        bits.append(f"{sm['kills']}/{sm['known_bosses']} bosses" if sm['known_bosses'] else plural(sm['kills'], 'boss').replace('bosss', 'bosses'))
        if sm['wipes']:
            bits.append(plural(sm['wipes'], 'wipe'))
    for name, n in sm.get('holiday') or ():
        bits.append(f"{name} ×{n}" if n > 1 else name)
    if sm.get('result'):
        bits.append('Win' if sm['result'] == 'win' else 'Loss')
    title = (sm.get('difficulty') + ' ' if sm.get('difficulty') and sm['kind'] == 'dungeon' and 'Heroic' in (sm.get('difficulty') or '') else '') + sm['name']
    return title, bits


def _fits(lines, block, limit=DISCORD_LIMIT):
    return len('\n'.join(lines + block)) <= limit


def group_table(players, kind='raid'):
    """The whole group as a fixed-width table (Discord shows code blocks in a monospace font)."""
    if not players:
        return []
    nw = min(16, max(6, max(len(p['name']) for p in players)))
    heals = any(p['heal'] for p in players)
    head = f"{'Player':<{nw}} {'DPS':>6} {'Damage':>7}" + (f" {'HPS':>5} {'Healing':>7}" if heals else '') + f" {'Died':>4}"
    out = ['```', head]
    for p in players:
        dps = f"{round(p['dps']):,}" if p['dmg'] else '–'
        dmg = fmt(p['dmg']) if p['dmg'] else '–'
        line = f"{p['name'][:nw]:<{nw}} {dps:>6} {dmg:>7}"
        if heals:
            hps = f"{round(p['hps']):,}" if p['heal'] else '–'
            heal = fmt(p['heal']) if p['heal'] else '–'
            line += f" {hps:>5} {heal:>7}"
        line += f" {p['deaths'] or '–':>4}"
        out.append(line)
    out.append('```')
    return out


def discord_run(sm, top=None):
    """The whole group's night: bosses, every player's numbers, deaths and loot."""
    title, bits = run_header(sm)
    lines = [f"**{title}** · " + ' · '.join(bits)]
    if sm['bosses']:
        lines.append('')
        for b in sm['bosses']:
            pips = ''.join('✅' if a['success'] else '❌' for a in b['attempts'])
            extra = []
            if b['kill']:
                extra.append(f"{dur(fight_dur(b['kill']))}")
            wipes = [f"{round(a['boss_hp'] * 100)}%" for a in b['wipes'] if a.get('boss_hp') is not None]
            if wipes:
                extra.append('wipes at ' + ', '.join(wipes))
            lines.append(f"{pips} {b['name']}" + (f" — {' · '.join(extra)}" if extra else ''))
    players = sorted(sm['players'], key=lambda p: -p['dps'])
    if top:
        players = players[:top]
    table = group_table(players, sm['kind'])
    while table and not _fits(lines + [''], table) and len(players) > 5:
        players = players[:-1]  # very big raids: drop the bottom rows rather than break the table
        table = group_table(players, sm['kind'])
    if table:
        scope = 'boss fights' if sm.get('scope') == 'boss' else 'all fights'
        lines += ['', f'**Group** ({scope})'] + table
    if sm['records'] and _fits(lines, ['🏆 ' + ' · '.join(sm['records'][:4])]):
        lines.append('🏆 ' + ' · '.join(sm['records'][:4]))
    if sm['loot']:
        block = ['**Loot**']
        for l in sm['loot']:
            line = f"• {l['name']} → {l['who']}"
            if not _fits(lines, block + [line, '• …and more']):
                block.append(f"• …and {len(sm['loot']) - len(block) + 1} more")
                break
            block.append(line)
        if len(block) > 1 and _fits(lines, [''] + block):
            lines += [''] + block
    return _cut(lines)


def player_header(ps):
    sm = ps['run_summary']
    title, bits = run_header(sm)
    cls = (ps.get('cls') or '').title()
    return f"{ps['name']}" + (f" ({cls})" if cls else ''), f"{title} · {day_label(sm['start'])}"


def discord_player(ps):
    """One person's numbers for one run, ready to paste."""
    me = ps['player']
    who, where = player_header(ps)
    lines = [f"**{who}** · {where}"]
    bits = []
    if me['dmg']:
        bits.append(f"DPS **{round(me['dps']):,}**" + (f" (#{ps['rank_dps']} of {ps['of_dps']})" if ps['rank_dps'] else '') + f" · {fmt(me['dmg'])} damage")
    if me['heal']:
        bits.append(f"HPS **{round(me['hps']):,}**" + (f" (#{ps['rank_hps']} of {ps['of_hps']})" if ps['rank_hps'] else '') + f" · {fmt(me['heal'])} healing")
    bits.append(f"Deaths {me['deaths']}" + (f" · Interrupts {me['interrupts']}" if me['interrupts'] else '') + (f" · Dispels {me['dispels']}" if me['dispels'] else ''))
    lines += bits
    boss_rows = [r for r in ps['fights'] if r['kind'] == 'boss']
    if boss_rows:
        lines.append('')
        for r in boss_rows:
            mark = '✅' if r['success'] else '❌'
            val = f"{round(r['dps']):,} dps" if r['dmg'] >= r['heal'] else f"{round(r['hps']):,} hps"
            lines.append(f"{mark} {r['name']}" + (f" #{r['attempt']}" if (r['attempt'] or 1) > 1 else '') + f" — {val}" + (' 💀' if r['deaths'] else ''))
    total_d = sum(v for _, v in ps['dmg_by']) or 1
    if ps['dmg_by']:
        lines += ['', '**Damage by ability** ' + ' · '.join(f"{k} {round(100 * v / total_d)}%" for k, v in ps['dmg_by'][:5])]
    total_h = sum(v for _, v in ps['heal_by']) or 1
    if ps['heal_by']:
        lines.append('**Healing by ability** ' + ' · '.join(f"{k} {round(100 * v / total_h)}%" for k, v in ps['heal_by'][:5]))
    if ps['cons_by']:
        lines.append('**Consumables** ' + ', '.join(f"{k} ×{v}" for k, v in ps['cons_by'][:6]))
    if ps['deaths']:
        lines.append('**Deaths** ' + ', '.join(f"{d['fight']} ({d.get('spell') or '?'})" for d in ps['deaths'][:6]))
    if ps['loot']:
        lines.append('**Loot** ' + ', '.join(l['name'] for l in ps['loot'][:8]))
    return _cut(lines)


def discord_session(ss):
    s = ss['session']
    lines = [f"**Session · {day_label(ss['start'])}** · {clock(ss['start'])}–{clock(ss['end'])} · {span(ss['duration'])}"]
    for kind in KIND_ORDER:
        for sm in ss['by_kind'].get(kind, []):
            title, bits = run_header(sm)
            lines.append(f"• **{title}** · " + ' · '.join(bits[1:]))
    if ss['money_in']:
        g = f"💰 {gold(ss['money_in'])} looted"
        if ss['gold_per_hour']:
            g += f" ({gold(ss['gold_per_hour'])}/hour)"
        lines.append(g)
    if ss['pvp']['matches']:
        p = ss['pvp']
        lines.append(f"⚔️ {p['matches']} PvP match{'es' if p['matches'] != 1 else ''}" + (f" · {p['wins']}W {p['losses']}L" if p['wins'] or p['losses'] else ''))
    progress = []
    if ss.get('honor'):
        progress.append(f"{ss['honor']:,} honor")
    for faction, n in (ss.get('reputation') or [])[:3]:
        progress.append(f"{'+' if n >= 0 else ''}{n:,} {faction}")
    for name, n in (ss.get('currency') or {}).items():
        progress.append(f"+{n} {name}")
    if ss.get('quests_done'):
        progress.append(plural(ss['quests_done'], 'quest'))
    if progress:
        lines.append('📈 ' + ' · '.join(progress))
    epics = [l for sm in ss['runs'] for l in sm['loot'] if (l['q'] or 0) >= 4] + [l for l in ss['farm_loot'] if (l['q'] or 0) >= 4]
    if epics:
        lines.append('🟣 ' + ', '.join(f"{l['name']} → {l['who']}" for l in epics[:8]))
    return _cut(lines)


# ---------------------------------------------------------------- sharing: reports and spreadsheets

def cell_spec(text, color=None, bold=False):
    return {'text': str(text), 'color': color, 'bold': bold}


def report_run(sm, class_color=lambda c: None, quality_color=lambda q: None):
    title, bits = run_header(sm)
    doc = {'title': title, 'subtitle': ' · '.join(bits), 'generated': datetime.now().strftime('%Y-%m-%d %H:%M'), 'stats': [], 'sections': []}
    st = doc['stats']
    if sm['bosses']:
        st.append({'value': f"{sm['kills']}" + (f"/{sm['known_bosses']}" if sm['known_bosses'] else ''), 'label': 'Bosses killed', 'tone': None})
        st.append({'value': str(sm['wipes']), 'label': 'Wipes', 'tone': 'wipe' if sm['wipes'] else None})
        st.append({'value': dur(sm['wipe_time']), 'label': 'Time spent on wipes', 'tone': None})
    if sm.get('result'):
        st.append({'value': 'Win' if sm['result'] == 'win' else 'Loss', 'label': 'Result', 'tone': 'kill' if sm['result'] == 'win' else 'wipe'})
    st.append({'value': str(len(sm['deaths'])), 'label': 'Deaths', 'tone': None})
    st.append({'value': span(sm['end'] - sm['start']), 'label': 'Total time', 'tone': None})
    if sm['bosses']:
        doc['sections'].append({'title': 'Bosses', 'kind': 'bosses', 'bosses': [
            {'name': b['name'], 'attempts': [{'kill': a['success'], 'hp': a.get('boss_hp'), 'duration': dur(fight_dur(a))} for a in b['attempts']],
             'note': f"{dur(fight_dur(b['kill']))} kill" if b['kill'] else ('not killed' if b['attempts'] else '')} for b in sm['bosses']]})
    rows = []
    for p in sm['players']:
        c = class_color(p['cls'])
        z = lambda v, txt=None: (txt if txt is not None else f'{v:,}') if v else '–'
        rows.append([cell_spec(p['name'], c, True), z(p['dmg'], f"{round(p['dps']):,}"), z(p['dmg'], fmt(p['dmg'])), z(p['heal'], f"{round(p['hps']):,}"),
                     z(p['heal'], fmt(p['heal'])), z(p['deaths']), z(p['interrupts']), z(p['dispels']), z(p['cons']), z(p['avoid'], fmt(p['avoid']))])
    doc['sections'].append({'title': 'Raid members' if sm['kind'] == 'raid' else 'Group', 'kind': 'table',
                            'columns': [{'label': 'Player', 'align': 'left'}] + [{'label': l, 'align': 'right'} for l in
                                        ['DPS', 'Damage', 'HPS', 'Healing', 'Deaths', 'Interrupts', 'Dispels', 'Consumables', 'Avoidable dmg']],
                            'rows': rows, 'note': 'DPS and HPS cover boss fights' if sm.get('scope') == 'boss' else 'DPS and HPS cover every fight'})
    if sm['deaths']:
        doc['sections'].append({'title': 'Deaths', 'kind': 'table', 'columns': [{'label': 'Fight', 'align': 'left'}, {'label': 'Time', 'align': 'right'},
                                {'label': 'Player', 'align': 'left'}, {'label': 'Killed by', 'align': 'left'}],
                                'rows': [[d['fight'], dur(d['at']), cell_spec(d['name'], None, True), f"{d.get('spell') or '?'} ({d.get('killer') or '?'})"] for d in sm['deaths']]})
    if sm['loot']:
        doc['sections'].append({'title': 'Loot', 'kind': 'table', 'columns': [{'label': 'Time', 'align': 'left'}, {'label': 'Item', 'align': 'left'}, {'label': 'Looted by', 'align': 'left'}],
                                'rows': [[clock(l['ts']), cell_spec(f"[{l['name']}]", quality_color(l['q']), True), l['who']] for l in sm['loot']]})
    if sm['records']:
        doc['sections'].append({'title': 'Records set', 'kind': 'list', 'items': sm['records']})
    if sm['roster']:
        doc['sections'].append({'title': 'Who was there', 'kind': 'text', 'text': ', '.join(sm['roster'])})
    return doc


def sheets_run(sm):
    players = [[p['name'], p['cls'] or '', round(p['dps']), p['dmg'], round(p['hps']), p['heal'], p['deaths'], p['interrupts'], p['dispels'], p['cons'], p['avoid'], p['taken']]
               for p in sm['players']]
    fights = [[f['name'], 'Boss' if f['kind'] == 'boss' else 'Trash', ('Kill' if f['success'] else 'Wipe') if f['kind'] == 'boss' else '',
               datetime.fromtimestamp(f['start'] / 1000).strftime('%H:%M:%S'), round(fight_dur(f) / 1000),
               round(f['boss_hp'] * 100) if f.get('boss_hp') is not None and not f['success'] else '', len(f['deaths']),
               sum(s['dmg'] for s in f['players'].values())] for f in sm['fights']]
    per_fight = []
    for f in sm['fights']:
        sec = fight_dur(f) / 1000
        for s in f['players'].values():
            per_fight.append([f['name'], datetime.fromtimestamp(f['start'] / 1000).strftime('%H:%M:%S'), s['name'], s['dmg'], round(s['dmg'] / sec),
                              s['heal'], round(s['heal'] / sec), s['taken'], s['deaths'], s['interrupts'], s['dispels']])
    deaths = [[d['fight'], round(d['at'] / 1000), d['name'], d.get('spell') or '', d.get('killer') or '', d.get('amount') or 0] for d in sm['deaths']]
    loot = [[datetime.fromtimestamp(l['ts'] / 1000).strftime('%H:%M:%S'), l['name'], l['who'], l['count']] for l in sm['loot']]
    return [
        ('Players', ['Player', 'Class', 'DPS', 'Damage', 'HPS', 'Healing', 'Deaths', 'Interrupts', 'Dispels', 'Consumables', 'Avoidable damage', 'Damage taken'], players),
        ('Fights', ['Fight', 'Type', 'Result', 'Start', 'Seconds', 'Boss health left %', 'Deaths', 'Damage'], fights),
        ('Per fight', ['Fight', 'Start', 'Player', 'Damage', 'DPS', 'Healing', 'HPS', 'Damage taken', 'Deaths', 'Interrupts', 'Dispels'], per_fight),
        ('Deaths', ['Fight', 'Seconds in', 'Player', 'Killed by spell', 'Killed by', 'Last hit'], deaths),
        ('Loot', ['Time', 'Item', 'Looted by', 'Count'], loot),
    ]


def report_session(ss, quality_color=lambda q: None):
    doc = {'title': f"Session · {day_label(ss['start'])}", 'subtitle': f"{clock(ss['start'])} – {clock(ss['end'])} · {span(ss['duration'])}",
           'generated': datetime.now().strftime('%Y-%m-%d %H:%M'), 'stats': [], 'sections': []}
    raids = len(ss['by_kind'].get('raid', []))
    dungeons = len(ss['by_kind'].get('dungeon', []))
    doc['stats'] = [{'value': str(raids), 'label': 'Raids', 'tone': None}, {'value': str(dungeons), 'label': 'Dungeons', 'tone': None},
                    {'value': str(ss['kills']), 'label': 'Bosses killed', 'tone': None},
                    {'value': str(ss['wipes']), 'label': 'Wipes', 'tone': 'wipe' if ss['wipes'] else None},
                    {'value': gold(ss['money_in']), 'label': 'Gold looted', 'tone': None}]
    rows = []
    for kind in KIND_ORDER:
        for sm in ss['by_kind'].get(kind, []):
            title, bits = run_header(sm)
            rows.append([KIND_LABEL.get(kind, kind), cell_spec(title, None, True), clock(sm['start']), ' · '.join(bits[1:])])
    if rows:
        doc['sections'].append({'title': 'What you did', 'kind': 'table', 'columns': [{'label': 'Type', 'align': 'left'}, {'label': 'Where', 'align': 'left'},
                                {'label': 'Started', 'align': 'left'}, {'label': 'Result', 'align': 'left'}], 'rows': rows})
    if ss['money_in'] or ss['farm_loot']:
        items = []
        if ss['money_in']:
            items.append(f"Gold looted: {gold(ss['money_in'])}" + (f" ({gold(ss['gold_per_hour'])} per hour)" if ss['gold_per_hour'] else ''))
        if ss['money_out']:
            items.append(f"Gold spent: {gold(ss['money_out'])}")
        if ss.get('money_net') is not None:
            items.append(f"Net change in your gold: {gold(ss['money_net'])}")
        items += [cell_spec(f"[{l['name']}]" + (f" ×{l['count']}" if l['count'] > 1 else ''), quality_color(l['q']), True) for l in ss['farm_loot'][:40]]
        doc['sections'].append({'title': 'Farming', 'kind': 'list', 'items': items})
    return doc


def sheets_session(ss):
    runs = []
    for sm in ss['runs']:
        runs.append([KIND_LABEL.get(sm['kind'], sm['kind']), sm['name'], datetime.fromtimestamp(sm['start'] / 1000).strftime('%Y-%m-%d %H:%M'),
                     round((sm['end'] - sm['start']) / 60000), sm['kills'], sm['wipes'], len(sm['deaths']), len(sm['loot']), sm.get('result') or ''])
    loot = [[datetime.fromtimestamp(l['ts'] / 1000).strftime('%H:%M:%S'), l['name'], l['who'], l['count']] for sm in ss['runs'] for l in sm['loot']]
    loot += [[datetime.fromtimestamp(l['ts'] / 1000).strftime('%H:%M:%S'), l['name'], l['who'], l['count']] for l in ss['farm_loot']]
    return [('Runs', ['Type', 'Where', 'Started', 'Minutes', 'Bosses killed', 'Wipes', 'Deaths', 'Loot', 'Result'], runs),
            ('Loot', ['Time', 'Item', 'Looted by', 'Count'], loot)]


def report_player(ps, class_color=lambda c: None, quality_color=lambda q: None):
    me = ps['player']
    who, where = player_header(ps)
    doc = {'title': who, 'subtitle': where, 'generated': datetime.now().strftime('%Y-%m-%d %H:%M'), 'stats': [], 'sections': [],
           'title_color': class_color(ps.get('cls'))}
    st = doc['stats']
    if me['dmg']:
        st.append({'value': f"{round(me['dps']):,}", 'label': 'DPS' + (f" · #{ps['rank_dps']} of {ps['of_dps']}" if ps['rank_dps'] else ''), 'tone': None})
        st.append({'value': fmt(me['dmg']), 'label': 'Damage', 'tone': None})
    if me['heal']:
        st.append({'value': f"{round(me['hps']):,}", 'label': 'HPS' + (f" · #{ps['rank_hps']} of {ps['of_hps']}" if ps['rank_hps'] else ''), 'tone': None})
        st.append({'value': fmt(me['heal']), 'label': 'Healing', 'tone': None})
    st.append({'value': str(me['deaths']), 'label': 'Deaths', 'tone': 'wipe' if me['deaths'] else None})
    z = lambda v, txt=None: (txt if txt is not None else f'{v:,}') if v else '–'
    rows = []
    for r in ps['fights']:
        res = ('Kill' if r['success'] else 'Wipe') if r['kind'] == 'boss' else 'Trash'
        rows.append([cell_spec(r['name'] + (f" #{r['attempt']}" if (r['attempt'] or 1) > 1 else ''), None, True), res, dur(r['time']),
                     z(r['dmg'], f"{round(r['dps']):,}"), z(r['dmg'], fmt(r['dmg'])), z(r['heal'], f"{round(r['hps']):,}"), z(r['heal'], fmt(r['heal'])), z(r['deaths'])])
    if rows:
        doc['sections'].append({'title': 'Fights', 'kind': 'table', 'columns': [{'label': 'Fight', 'align': 'left'}, {'label': 'Result', 'align': 'left'}] +
                                [{'label': l, 'align': 'right'} for l in ('Time', 'DPS', 'Damage', 'HPS', 'Healing', 'Deaths')], 'rows': rows})
    for title, items in (('Damage by ability', ps['dmg_by']), ('Healing by ability', ps['heal_by'])):
        total = sum(v for _, v in items) or 1
        if items:
            doc['sections'].append({'title': title, 'kind': 'table', 'columns': [{'label': 'Ability', 'align': 'left'}, {'label': 'Amount', 'align': 'right'}, {'label': 'Share', 'align': 'right'}],
                                    'rows': [[k, fmt(v), f'{100 * v / total:.0f}%'] for k, v in items[:15]]})
    if ps['deaths']:
        doc['sections'].append({'title': 'Deaths', 'kind': 'table', 'columns': [{'label': 'Fight', 'align': 'left'}, {'label': 'Time', 'align': 'right'}, {'label': 'Killed by', 'align': 'left'}],
                                'rows': [[d['fight'], dur(d['at']), f"{d.get('spell') or '?'} ({d.get('killer') or '?'})"] for d in ps['deaths']]})
    if ps['cons_by']:
        doc['sections'].append({'title': 'Consumables', 'kind': 'list', 'items': [f'{k} ×{v}' for k, v in ps['cons_by']]})
    if ps['loot']:
        doc['sections'].append({'title': 'Loot', 'kind': 'list', 'items': [cell_spec(f"[{l['name']}]", quality_color(l['q']), True) for l in ps['loot']]})
    return doc


def sheets_player(ps):
    fights = [[r['name'], r['attempt'] or '', ('Kill' if r['success'] else 'Wipe') if r['kind'] == 'boss' else 'Trash',
               datetime.fromtimestamp(r['fight']['start'] / 1000).strftime('%H:%M:%S'), round(r['time'] / 1000), r['dmg'], round(r['dps']),
               r['heal'], round(r['hps']), r['taken'], r['deaths']] for r in ps['fights']]
    abil = [['Damage', k, v] for k, v in ps['dmg_by']] + [['Healing', k, v] for k, v in ps['heal_by']]
    deaths = [[d['fight'], round(d['at'] / 1000), d.get('spell') or '', d.get('killer') or '', d.get('amount') or 0] for d in ps['deaths']]
    return [('Fights', ['Fight', 'Attempt', 'Result', 'Start', 'Seconds', 'Damage', 'DPS', 'Healing', 'HPS', 'Damage taken', 'Deaths'], fights),
            ('Abilities', ['Type', 'Ability', 'Amount'], abil),
            ('Deaths', ['Fight', 'Seconds in', 'Killed by spell', 'Killed by', 'Last hit'], deaths),
            ('Consumables', ['Item', 'Count'], [[k, v] for k, v in ps['cons_by']]),
            ('Loot', ['Item', 'Count'], [[l['name'], l['count']] for l in ps['loot']])]


def discord_week(wk, top):
    """One reset week, ready to paste: what you ran, kills and wipes, the best performers, who came."""
    dps, hps = top
    end = datetime.fromtimestamp(wk['start'] / 1000) + timedelta(days=6)
    lines = [f"**Week of {day_label(wk['start'])} – {end.strftime('%a, %b ')}{end.day}** · {plural(wk['kills'], 'kill')} · {plural(wk['wipes'], 'wipe')}"]
    for sm in sorted(wk['runs'], key=lambda r: r['start']):
        if sm['kind'] not in ('raid', 'dungeon'):
            continue
        title, bits = run_header(sm)
        lines.append(f"• **{title}** · " + ' · '.join(bits))
    if dps:
        lines += ['', '**Top damage on bosses** ' + ' · '.join(f"{i + 1}. {h['name']} {round(v):,}" for i, (v, h) in enumerate(dps))]
    if hps:
        lines.append('**Top healing on bosses** ' + ' · '.join(f"{i + 1}. {h['name']} {round(v):,}" for i, (v, h) in enumerate(hps)))
    if wk['attendance']:
        lines += ['', '**Raiders** ' + ', '.join(sorted(wk['attendance']))]
    if wk['loot']:
        lines.append(f"**Raid drops** {len(wk['loot'])}")
    return _cut(lines)
# ======================================================================
#  SavedVariables reader: what the Raidscribe AutoLog addon recorded in game
#  (instance entries, lockouts, rosters, loot, money, boss and PvP results).
#  WoW writes WTF/Account/<ACCOUNT>/SavedVariables/Raidscribe_AutoLog.lua on logout or /reload.
# ======================================================================


SAVED_NAME = 'Raidscribe_AutoLog.lua'
SAVED_VAR = 'RaidscribeAutoLogDB'
OLD_SAVED = ('Leyline_AutoLog.lua', 'LeylineAutoLogDB')   # the addon before the app was renamed

# one pass over the file: whitespace and '--' comments are skipped, every other token lands in group 1,
# anything unexpected in group 2
_TOKENS = re.compile(r'''\s+|--[^\n]*|("(?:[^"\\]|\\.|\\\n)*"|'(?:[^'\\]|\\.|\\\n)*'|-?(?:0[xX][0-9a-fA-F]+|(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?|inf\b|nan\b)|[A-Za-z_]\w*|[{}\[\]=,;])|(\S)''', re.S)
_BLOCK_COMMENT = re.compile(r'--\[(=*)\[.*?\]\1\]', re.S)

_ESC = {'n': 10, 't': 9, 'r': 13, 'a': 7, 'b': 8, 'f': 12, 'v': 11, '\\': 92, '"': 34, "'": 39, '\n': 10}


def _unescape(body):
    if '\\' not in body:
        return body
    out = bytearray()
    i, n = 0, len(body)
    while i < n:
        c = body[i]
        if c != '\\':
            j = body.find('\\', i)
            if j < 0:
                j = n
            out += body[i:j].encode('utf-8', 'surrogateescape')
            i = j
            continue
        i += 1
        if i >= n:
            break
        c = body[i]
        if c.isdigit():  # \ddd decimal byte
            j = i
            while j < n and j < i + 3 and body[j].isdigit():
                j += 1
            out.append(int(body[i:j]) & 0xFF)
            i = j
        elif c == 'x' and i + 2 < n + 1:
            try:
                out.append(int(body[i + 1:i + 3], 16))
                i += 3
            except ValueError:
                out += b'x'
                i += 1
        elif c == 'z':  # skip following whitespace
            i += 1
            while i < n and body[i].isspace():
                i += 1
        else:
            out.append(_ESC.get(c, ord(c) if ord(c) < 128 else 63))
            i += 1
    return out.decode('utf-8', 'replace')


def _number(s):
    t = s.lower()
    if t.lstrip('-') in ('inf', 'nan'):
        return float(t)
    if 'x' in t:
        return int(t, 16)
    if '.' in t or 'e' in t:
        v = float(t)
        return int(v) if v.is_integer() and abs(v) < 2 ** 53 and 'e' not in t else v
    return int(t)


class _Parser:
    """Recursive-descent parser over a flat token list (strings kept with their quotes)."""

    def __init__(self, text):
        if '--[' in text:
            text = _BLOCK_COMMENT.sub(' ', text)
        toks = []
        self.damaged = None
        for tok, bad in _TOKENS.findall(text):
            if bad:
                # a cut-off string or stray bytes: everything before this point is still good
                self.damaged = bad
                break
            if tok:
                toks.append(tok)
        self.toks = toks
        self.i = 0
        self.truncated = False

    def value(self):
        toks, i = self.toks, self.i
        if i >= len(toks):
            self.truncated = True
            return None
        t = toks[i]
        self.i = i + 1
        c = t[0]
        if c == '{':
            return self.table()
        if c == '"' or c == "'":
            return _unescape(t[1:-1])
        if c.isdigit() or c == '-' or c == '.':
            return _number(t)
        if t == 'true':
            return True
        if t == 'false':
            return False
        if t == 'nil':
            return None
        if t == 'inf' or t == 'nan':
            return float(t)
        raise ValueError(f'unexpected {t!r}')

    def table(self):
        toks = self.toks
        n_toks = len(toks)
        d = {}
        n = 0
        while True:
            i = self.i
            if i >= n_toks:  # file cut off mid-table: keep what we have
                self.truncated = True
                break
            t = toks[i]
            if t == '}':
                self.i = i + 1
                break
            if t == ',' or t == ';':
                self.i = i + 1
                continue
            if t == '[':
                self.i = i + 1
                key = self.value()
                if not self.expect(']') or not self.expect('='):
                    break
                val = self.value()
            elif i + 1 < n_toks and toks[i + 1] == '=' and (t[0].isalpha() or t[0] == '_'):
                key = t
                self.i = i + 2
                val = self.value()
            else:
                n += 1
                key, val = n, self.value()
            if isinstance(key, float) and key.is_integer():
                key = int(key)
            if val is not None:
                d[key] = val
            if self.truncated:
                break
        if d:
            m = len(d)
            if all(type(k) is int for k in d) and min(d) == 1 and max(d) == m:
                return [d[k] for k in range(1, m + 1)]
        return d

    def expect(self, op):
        i = self.i
        if i >= len(self.toks):
            self.truncated = True
            return False
        if self.toks[i] != op:
            raise ValueError(f'expected {op!r}, got {self.toks[i]!r}')
        self.i = i + 1
        return True

    def chunk(self):
        out = {}
        toks = self.toks
        while self.i < len(toks):
            name = toks[self.i]
            if not (name[0].isalpha() or name[0] == '_'):
                raise ValueError(f'expected a variable name, got {name!r}')
            self.i += 1
            if not self.expect('='):
                break
            out[name] = self.value()
            if self.truncated:
                break
        return out


def parse_lua_table(text):
    """Parses a SavedVariables file: one or more `Name = value` assignments. Returns {name: value}.
    Tables whose keys are exactly 1..n become lists, other tables dicts, an empty table {}.
    A file cut off part-way returns everything up to the cut."""
    p = _Parser(text)
    return p.chunk()


def find_saved_files(logs_dir):
    """Raidscribe_AutoLog.lua for every WoW account, found from the Logs folder (<wow>/_anniversary_/Logs)."""
    roots = []
    for base in (os.path.abspath(logs_dir), os.path.realpath(logs_dir)):
        root = os.path.dirname(base.rstrip('\\/'))
        if root not in roots:
            roots.append(root)
    found = []
    for root in roots:
        for name in (SAVED_NAME, OLD_SAVED[0]):
            for path in sorted(glob.glob(os.path.join(root, 'WTF', 'Account', '*', 'SavedVariables', name))):
                if path not in found and os.path.isfile(path):
                    # an account with the renamed addon's file skips the old one (the new file has everything)
                    if name == OLD_SAVED[0] and os.path.isfile(os.path.join(os.path.dirname(path), SAVED_NAME)):
                        continue
                    found.append(path)
    return found


def load_events(logs_dir, warnings=None):
    """Every recorded event from every account, oldest first. Each is a dict with 'ts' (epoch ms) and
    'account' added. Never raises: unreadable or half-written files are skipped or read up to the damage,
    with a note in `warnings` (a list, if given) and the log."""
    def warn(msg):
        logging.getLogger('raidscribe').warning(msg)
        if warnings is not None:
            warnings.append(msg)

    events = []
    for path in find_saved_files(logs_dir):
        account = os.path.basename(os.path.dirname(os.path.dirname(path)))
        try:
            with open(path, encoding='utf-8', errors='replace') as fh:
                text = fh.read()
        except OSError as ex:
            warn(f'Could not read {path}: {ex}')
            continue
        try:
            p = _Parser(text)
            data = p.chunk()
            if p.damaged is not None:
                warn(f'{path} has something unreadable in it ({p.damaged!r}); read everything before that point.')
            elif p.truncated:
                warn(f'{path} looks cut off (WoW may still be writing it); read what was there.')
        except Exception as ex:
            warn(f'Could not understand {path}: {ex}')
            continue
        db = data.get(SAVED_VAR) or data.get(OLD_SAVED[1])
        if not isinstance(db, dict):
            continue
        raw = db.get('events') or []
        if isinstance(raw, dict):  # a list with gaps comes back as a dict
            raw = [raw[k] for k in sorted(k for k in raw if isinstance(k, int))]
        if (p.truncated or p.damaged is not None) and raw:
            raw = raw[:-1]  # the event WoW was writing when the file was cut off is incomplete
        for ev in raw:
            if isinstance(ev, dict) and isinstance(ev.get('t'), (int, float)) and ev.get('e'):
                ev = dict(ev)
                ev['ts'] = int(ev['t'] * 1000)
                ev['account'] = account
                if isinstance(ev.get('members'), dict):
                    ev['members'] = list(ev['members'].values())
                events.append(ev)
    events.sort(key=lambda e: e['t'])  # stable: same-second events keep their order
    return events
# ======================================================================
#  Exports: PNG images, screen capture, clipboard, CSV, XLSX, HTML reports.
#  Standard library only.
# ======================================================================


IS_WINDOWS = sys.platform.startswith('win')


# ---------------------------------------------------------------- PNG

def encode_png(width, height, rows):
    """rows: list of bytes, each width*3 RGB. Returns PNG file bytes."""
    raw = b''.join(b'\x00' + bytes(r[:width * 3]) for r in rows[:height])

    def chunk(kind, data):
        c = struct.pack('>I', len(data)) + kind + data
        return c + struct.pack('>I', zlib.crc32(kind + data) & 0xffffffff)
    ihdr = struct.pack('>IIBBBBB', width, height, 8, 2, 0, 0, 0)
    return b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', ihdr) + chunk(b'IDAT', zlib.compress(raw, 6)) + chunk(b'IEND', b'')


def write_png(path, width, height, rows):
    with open(path, 'wb') as fh:
        fh.write(encode_png(width, height, rows))
    return path


# ---------------------------------------------------------------- screen capture

def _parse_ppm(data):
    """Minimal P6 parser. Returns (w, h, rows)."""
    if data[:2] != b'P6':
        return None
    tokens, i = [], 2
    while len(tokens) < 3:
        while data[i:i + 1].isspace():
            i += 1
        if data[i:i + 1] == b'#':
            while data[i:i + 1] not in (b'\n', b''):
                i += 1
            continue
        j = i
        while not data[j:j + 1].isspace():
            j += 1
        tokens.append(int(data[i:j]))
        i = j
    i += 1  # single whitespace after maxval
    w, h, maxval = tokens
    stride = w * 3
    if maxval > 255:  # 16-bit samples, big-endian: keep the high byte
        pix = data[i:i + stride * h * 2][0::2]
    elif maxval == 255:
        pix = data[i:i + stride * h]
    else:
        return None
    return w, h, [pix[y * stride:(y + 1) * stride] for y in range(h)]


def _crop(w, h, rows, x, y, cw, ch):
    x, y = max(0, x), max(0, y)
    cw, ch = min(cw, w - x), min(ch, h - y)
    if cw <= 0 or ch <= 0:
        return None
    return cw, ch, [rows[y + r][x * 3:(x + cw) * 3] for r in range(ch)]


def _capture_x11(widget):
    widget.update_idletasks()
    x, y = widget.winfo_rootx(), widget.winfo_rooty()
    w, h = widget.winfo_width(), widget.winfo_height()
    fd, tmp = tempfile.mkstemp(suffix='.ppm')
    os.close(fd)
    try:
        subprocess.run(['import', '-window', 'root', '-crop', f'{w}x{h}+{x}+{y}', '+repage', '-depth', '8', 'ppm:' + tmp],
                       check=True, capture_output=True, timeout=20)
        with open(tmp, 'rb') as fh:
            got = _parse_ppm(fh.read())
        if not got:
            return None
        gw, gh, rows = got
        return _crop(gw, gh, rows, 0, 0, w, h)
    except Exception:
        return None
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass


if IS_WINDOWS:
    import ctypes
    from ctypes import wintypes

    _user32 = ctypes.WinDLL('user32', use_last_error=True)
    _gdi32 = ctypes.WinDLL('gdi32', use_last_error=True)
    _kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)

    class BITMAPINFOHEADER(ctypes.Structure):
        _fields_ = [('biSize', wintypes.DWORD), ('biWidth', wintypes.LONG), ('biHeight', wintypes.LONG),
                    ('biPlanes', wintypes.WORD), ('biBitCount', wintypes.WORD), ('biCompression', wintypes.DWORD),
                    ('biSizeImage', wintypes.DWORD), ('biXPelsPerMeter', wintypes.LONG), ('biYPelsPerMeter', wintypes.LONG),
                    ('biClrUsed', wintypes.DWORD), ('biClrImportant', wintypes.DWORD)]

    class BITMAPINFO(ctypes.Structure):
        _fields_ = [('bmiHeader', BITMAPINFOHEADER), ('bmiColors', wintypes.DWORD * 3)]

    def _sig(fn, res, *args):
        fn.restype = res
        fn.argtypes = list(args)
        return fn

    HGDIOBJ = wintypes.HANDLE
    _GetDC = _sig(_user32.GetDC, wintypes.HDC, wintypes.HWND)
    _ReleaseDC = _sig(_user32.ReleaseDC, ctypes.c_int, wintypes.HWND, wintypes.HDC)
    _GetParent = _sig(_user32.GetParent, wintypes.HWND, wintypes.HWND)
    _GetAncestor = _sig(_user32.GetAncestor, wintypes.HWND, wintypes.HWND, wintypes.UINT)
    _GetWindowRect = _sig(_user32.GetWindowRect, wintypes.BOOL, wintypes.HWND, ctypes.POINTER(wintypes.RECT))
    _GetClientRect = _sig(_user32.GetClientRect, wintypes.BOOL, wintypes.HWND, ctypes.POINTER(wintypes.RECT))
    _ClientToScreen = _sig(_user32.ClientToScreen, wintypes.BOOL, wintypes.HWND, ctypes.POINTER(wintypes.POINT))
    _PrintWindow = _sig(_user32.PrintWindow, wintypes.BOOL, wintypes.HWND, wintypes.HDC, wintypes.UINT)
    _CreateCompatibleDC = _sig(_gdi32.CreateCompatibleDC, wintypes.HDC, wintypes.HDC)
    _CreateCompatibleBitmap = _sig(_gdi32.CreateCompatibleBitmap, wintypes.HBITMAP, wintypes.HDC, ctypes.c_int, ctypes.c_int)
    _SelectObject = _sig(_gdi32.SelectObject, HGDIOBJ, wintypes.HDC, HGDIOBJ)
    _DeleteObject = _sig(_gdi32.DeleteObject, wintypes.BOOL, HGDIOBJ)
    _DeleteDC = _sig(_gdi32.DeleteDC, wintypes.BOOL, wintypes.HDC)
    _BitBlt = _sig(_gdi32.BitBlt, wintypes.BOOL, wintypes.HDC, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                   wintypes.HDC, ctypes.c_int, ctypes.c_int, wintypes.DWORD)
    _GetDIBits = _sig(_gdi32.GetDIBits, ctypes.c_int, wintypes.HDC, wintypes.HBITMAP, wintypes.UINT, wintypes.UINT,
                      ctypes.c_void_p, ctypes.POINTER(BITMAPINFO), wintypes.UINT)
    _OpenClipboard = _sig(_user32.OpenClipboard, wintypes.BOOL, wintypes.HWND)
    _CloseClipboard = _sig(_user32.CloseClipboard, wintypes.BOOL)
    _EmptyClipboard = _sig(_user32.EmptyClipboard, wintypes.BOOL)
    _SetClipboardData = _sig(_user32.SetClipboardData, wintypes.HANDLE, wintypes.UINT, wintypes.HANDLE)
    _RegisterClipboardFormatW = _sig(_user32.RegisterClipboardFormatW, wintypes.UINT, wintypes.LPCWSTR)
    _GlobalAlloc = _sig(_kernel32.GlobalAlloc, wintypes.HGLOBAL, wintypes.UINT, ctypes.c_size_t)
    _GlobalLock = _sig(_kernel32.GlobalLock, wintypes.LPVOID, wintypes.HGLOBAL)
    _GlobalUnlock = _sig(_kernel32.GlobalUnlock, wintypes.BOOL, wintypes.HGLOBAL)
    _GlobalFree = _sig(_kernel32.GlobalFree, wintypes.HGLOBAL, wintypes.HGLOBAL)

    GA_ROOT = 2
    PW_RENDERFULLCONTENT = 2
    SRCCOPY = 0x00CC0020
    DIB_RGB_COLORS = 0
    BI_RGB = 0
    CF_DIB = 8
    GMEM_MOVEABLE = 0x0002

    def _grab_hdc(src_dc, w, h, draw):
        """Creates a bitmap, calls draw(mem_dc), returns top-down RGB rows."""
        mem = _CreateCompatibleDC(src_dc)
        bmp = _CreateCompatibleBitmap(src_dc, w, h)
        old = _SelectObject(mem, bmp)
        try:
            if not draw(mem):
                return None
            bi = BITMAPINFO()
            bi.bmiHeader.biSize = ctypes.sizeof(BITMAPINFOHEADER)
            bi.bmiHeader.biWidth = w
            bi.bmiHeader.biHeight = -h  # top-down
            bi.bmiHeader.biPlanes = 1
            bi.bmiHeader.biBitCount = 32
            bi.bmiHeader.biCompression = BI_RGB
            buf = ctypes.create_string_buffer(w * h * 4)
            _SelectObject(mem, old)
            old = None
            if _GetDIBits(mem, bmp, 0, h, buf, ctypes.byref(bi), DIB_RGB_COLORS) != h:
                return None
            data = buf.raw
            rows = []
            for y in range(h):
                line = data[y * w * 4:(y + 1) * w * 4]
                rgb = bytearray(w * 3)
                rgb[0::3] = line[2::4]
                rgb[1::3] = line[1::4]
                rgb[2::3] = line[0::4]
                rows.append(bytes(rgb))
            return rows
        finally:
            if old is not None:
                _SelectObject(mem, old)
            _DeleteObject(bmp)
            _DeleteDC(mem)

    def _capture_windows(widget):
        widget.update_idletasks()
        hwnd = wintypes.HWND(widget.winfo_id())
        top = _GetAncestor(hwnd, GA_ROOT) or _GetParent(hwnd) or hwnd
        wrect = wintypes.RECT()
        _GetWindowRect(top, ctypes.byref(wrect))
        tw, th = wrect.right - wrect.left, wrect.bottom - wrect.top
        if tw <= 0 or th <= 0:
            return None
        sdc = _GetDC(None)
        try:
            rows = _grab_hdc(sdc, tw, th, lambda mem: bool(_PrintWindow(top, mem, PW_RENDERFULLCONTENT)))
            # widget position inside the whole window (window rect includes the frame)
            wr = wintypes.RECT()
            _GetWindowRect(hwnd, ctypes.byref(wr))
            x, y = wr.left - wrect.left, wr.top - wrect.top
            w, h = wr.right - wr.left, wr.bottom - wr.top
            if rows:
                got = _crop(tw, th, rows, x, y, w, h)
                if got and any(any(r) for r in got[2][::max(1, len(got[2]) // 8)]):
                    return got
            # PrintWindow can come back black (e.g. some GPU setups): copy from the screen instead
            rows = _grab_hdc(sdc, w, h, lambda mem: bool(_BitBlt(mem, 0, 0, w, h, sdc, wr.left, wr.top, SRCCOPY)))
            return (w, h, rows) if rows else None
        finally:
            _ReleaseDC(None, sdc)

    def _set_clip(fmt, data):
        h = _GlobalAlloc(GMEM_MOVEABLE, len(data))
        if not h:
            return False
        p = _GlobalLock(h)
        if not p:
            _GlobalFree(h)
            return False
        ctypes.memmove(p, data, len(data))
        _GlobalUnlock(h)
        if not _SetClipboardData(fmt, h):
            _GlobalFree(h)  # ownership only passes to the system on success
            return False
        return True


def dib_bytes(width, height, rows):
    """CF_DIB payload: BITMAPINFOHEADER + 24-bit bottom-up BGR with 4-byte row padding."""
    header = struct.pack('<IiiHHIIiiII', 40, width, height, 1, 24, 0, 0, 2835, 2835, 0, 0)
    pad = (4 - (width * 3) % 4) % 4
    out = bytearray(header)
    for r in reversed(rows[:height]):
        line = bytearray(width * 3)
        line[0::3] = r[2:width * 3:3]
        line[1::3] = r[1:width * 3:3]
        line[2::3] = r[0:width * 3:3]
        out += line + b'\x00' * pad
    return bytes(out)


def capture_widget(widget):
    """Pixels of a widget as shown on screen: (width, height, rows) or None."""
    try:
        if IS_WINDOWS:
            return _capture_windows(widget)
        return _capture_x11(widget)
    except Exception:
        return None


# ---------------------------------------------------------------- clipboard

def copy_image_to_clipboard(width, height, rows, png_bytes=None):
    if not IS_WINDOWS:
        return False
    try:
        dib = dib_bytes(width, height, rows)
        png = png_bytes or encode_png(width, height, rows)
        for _ in range(10):  # another program may hold the clipboard for a moment
            if _OpenClipboard(None):
                break
            import time
            time.sleep(0.05)
        else:
            return False
        try:
            _EmptyClipboard()
            ok = _set_clip(CF_DIB, dib)
            fmt = _RegisterClipboardFormatW('PNG')
            if fmt:
                _set_clip(fmt, png)
            return bool(ok)
        finally:
            _CloseClipboard()
    except Exception:
        return False


def copy_text_to_clipboard(root, text):
    try:
        root.clipboard_clear()
        root.clipboard_append(text)
        root.update()
        return True
    except Exception:
        return False


# ---------------------------------------------------------------- files

_BAD = re.compile(r'[<>:"/\\|?*\x00-\x1f]')
_RESERVED = {'CON', 'PRN', 'AUX', 'NUL'} | {f'COM{i}' for i in range(1, 10)} | {f'LPT{i}' for i in range(1, 10)}


def safe_filename(s):
    s = _BAD.sub(' ', str(s))
    s = re.sub(r'\s+', ' ', s).strip().rstrip('. ')
    if not s:
        s = 'report'
    if s.split('.')[0].upper() in _RESERVED:
        s = '_' + s
    return s[:120].rstrip('. ')


def write_csv(path, header, rows):
    with open(path, 'w', encoding='utf-8-sig', newline='') as fh:
        w = csv.writer(fh)
        w.writerow([_plain(c) for c in header])
        for r in rows:
            w.writerow([_plain(c) for c in r])
    return path


def _plain(c):
    if isinstance(c, dict):
        return c.get('text', '')
    return '' if c is None else c


def _col_letter(i):
    s = ''
    i += 1
    while i:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s


_XML_BAD = re.compile('[\x00-\x08\x0b\x0c\x0e-\x1f]')


def _x(s):
    return xml_escape(_XML_BAD.sub('', str(s)), {'"': '&quot;'})


def _sheet_names(names):
    out, seen = [], set()
    for n in names:
        n = re.sub(r'\s+', ' ', re.sub(r'[\[\]:*?/\\]', ' ', str(n))).strip().strip("'")[:31].strip() or 'Sheet'
        base, k = n, 2
        while n.lower() in seen:
            suf = f' ({k})'
            n = base[:31 - len(suf)] + suf
            k += 1
        seen.add(n.lower())
        out.append(n)
    return out


def write_xlsx(path, sheets):
    """sheets: list of (name, header, rows). Numbers stay numbers; header is bold; top row frozen."""
    names = _sheet_names([s[0] for s in sheets])
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml',
                   '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                   '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
                   '<Default Extension="xml" ContentType="application/xml"/>'
                   '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
                   '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
                   + ''.join(f'<Override PartName="/xl/worksheets/sheet{i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' for i in range(len(sheets)))
                   + '</Types>')
        z.writestr('_rels/.rels',
                   '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
                   '</Relationships>')
        z.writestr('xl/workbook.xml',
                   '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>'
                   + ''.join(f'<sheet name="{_x(n)}" sheetId="{i + 1}" r:id="rId{i + 1}"/>' for i, n in enumerate(names))
                   + '</sheets></workbook>')
        z.writestr('xl/_rels/workbook.xml.rels',
                   '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   + ''.join(f'<Relationship Id="rId{i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{i + 1}.xml"/>' for i in range(len(sheets)))
                   + f'<Relationship Id="rId{len(sheets) + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
                   '</Relationships>')
        z.writestr('xl/styles.xml',
                   '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
                   '<fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts>'
                   '<fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>'
                   '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
                   '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
                   '<cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
                   '<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/></cellXfs>'
                   '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
                   '</styleSheet>')
        for i, (_, header, rows) in enumerate(sheets):
            all_rows = [list(header)] + [list(r) for r in rows]
            ncols = max((len(r) for r in all_rows), default=1)
            widths = [8] * ncols
            out = []
            for ri, row in enumerate(all_rows):
                cells = []
                for ci, c in enumerate(row):
                    v = _plain(c)
                    ref = f'{_col_letter(ci)}{ri + 1}'
                    style = ' s="1"' if ri == 0 else ''
                    if isinstance(v, bool):
                        v = str(v)
                    if isinstance(v, (int, float)) and v == v and v not in (float('inf'), float('-inf')):
                        cells.append(f'<c r="{ref}"{style}><v>{v!r}</v></c>' if isinstance(v, float) else f'<c r="{ref}"{style}><v>{v}</v></c>')
                        widths[ci] = max(widths[ci], len(f'{v:,}' if isinstance(v, int) else f'{v:.2f}') + 2)
                    else:
                        s = str(v)
                        cells.append(f'<c r="{ref}"{style} t="inlineStr"><is><t xml:space="preserve">{_x(s)}</t></is></c>')
                        widths[ci] = max(widths[ci], min(60, len(s) + 2))
                out.append(f'<row r="{ri + 1}">' + ''.join(cells) + '</row>')
            cols = ''.join(f'<col min="{ci + 1}" max="{ci + 1}" width="{w}" customWidth="1"/>' for ci, w in enumerate(widths))
            z.writestr(f'xl/worksheets/sheet{i + 1}.xml',
                       '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                       '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
                       '<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>'
                       f'<cols>{cols}</cols><sheetData>' + ''.join(out) + '</sheetData></worksheet>')
    return path


# ---------------------------------------------------------------- HTML report

_CSS = '''
:root{--bg:#12111c;--surface:#191827;--surface2:#211f33;--line:#2c2a44;--text:#e9e7f5;--muted:#9895b4;--faint:#6f6c8c;
--arcane:#a593ff;--kill:#4fc790;--wipe:#ec5b72;--kill-soft:rgba(79,199,144,.16);--wipe-soft:rgba(236,91,114,.16);color-scheme:dark}
@media (prefers-color-scheme: light){:root{--bg:#f5f4fa;--surface:#fff;--surface2:#f0eef8;--line:#e1def0;--text:#1d1b2f;--muted:#66637f;
--faint:#9a97b2;--arcane:#6b57e3;--kill:#1c9a60;--wipe:#d23a54;--kill-soft:rgba(28,154,96,.12);--wipe-soft:rgba(210,58,84,.10);color-scheme:light}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font:14px/1.5 "Segoe UI Variable Text","Segoe UI",system-ui,sans-serif;
font-variant-numeric:tabular-nums}main{max-width:1100px;margin:0 auto;padding:32px 24px 60px}
h1{font-size:28px;margin:0 0 4px;letter-spacing:-.01em}.sub{color:var(--muted);margin:0 0 24px}.gen{color:var(--faint);font-size:12px;margin-top:30px}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:1px;background:var(--line);border:1px solid var(--line);
border-radius:12px;overflow:hidden;margin-bottom:24px}.stat{background:var(--surface);padding:14px 16px}.stat .v{font-size:22px;font-weight:650}
.stat .l{color:var(--muted);font-size:12.5px}.kill{color:var(--kill)}.wipe{color:var(--wipe)}
section{background:var(--surface);border:1px solid var(--line);border-radius:12px;padding:16px 18px;margin-bottom:20px;break-inside:avoid}
h2{font-size:16px;margin:0 0 10px}table{width:100%;border-collapse:collapse}th{font-size:12.5px;color:var(--muted);text-align:left;font-weight:600;
padding:7px 10px;border-bottom:1px solid var(--line)}td{padding:7px 10px;border-bottom:1px solid var(--surface2)}tr:last-child td{border-bottom:0}
.r{text-align:right}.note{color:var(--faint);font-size:12.5px;margin:10px 0 0}ul{margin:0;padding-left:20px}li{margin:3px 0}
.boss{display:grid;grid-template-columns:minmax(140px,220px) 1fr auto;gap:14px;align-items:center;padding:8px 0;border-top:1px solid var(--surface2)}
.boss:first-of-type{border-top:0}.pips{display:flex;gap:6px;flex-wrap:wrap}.pip{position:relative;width:46px;height:26px;border-radius:7px;
display:inline-grid;place-items:center;font-size:11px;font-weight:700;overflow:hidden}.pip.k{background:var(--kill);color:#fff}
.pip.w{background:var(--wipe-soft);color:var(--wipe)}.pip.w i{position:absolute;left:0;top:0;bottom:0;background:var(--wipe);opacity:.28}
.pip span{position:relative}.bn{font-weight:600}.bt{color:var(--muted);font-size:13px;text-align:right}.text{white-space:pre-wrap}
@media print{body{background:#fff;color:#000}section,.stat{background:#fff}}
'''


def _cell(c):
    if isinstance(c, dict):
        text = html.escape(str(c.get('text', '')))
        style = ''
        if c.get('color') and re.fullmatch(r'#[0-9a-fA-F]{3,8}', str(c['color'])):
            style += f'color:{c["color"]};'
        if c.get('bold'):
            style += 'font-weight:600;'
        return f'<span style="{style}">{text}</span>' if style else text
    if isinstance(c, float):
        return html.escape(f'{c:,.1f}')
    if isinstance(c, int) and not isinstance(c, bool):
        return html.escape(f'{c:,}')
    return html.escape('' if c is None else str(c))


def render_html(doc):
    e = html.escape
    out = ['<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">',
           f'<title>{e(str(doc.get("title", "Raidscribe report")))}</title><style>{_CSS}</style></head><body><main>',
           f'<h1>{e(str(doc.get("title", "")))}</h1>']
    if doc.get('subtitle'):
        out.append(f'<p class="sub">{e(str(doc["subtitle"]))}</p>')
    stats = doc.get('stats') or []
    if stats:
        out.append('<div class="stats">')
        for s in stats:
            tone = s.get('tone') if s.get('tone') in ('kill', 'wipe') else ''
            out.append(f'<div class="stat"><div class="v {tone}">{e(str(s.get("value", "")))}</div><div class="l">{e(str(s.get("label", "")))}</div></div>')
        out.append('</div>')
    for sec in doc.get('sections') or []:
        out.append('<section>')
        if sec.get('title'):
            out.append(f'<h2>{e(str(sec["title"]))}</h2>')
        kind = sec.get('kind')
        if kind == 'table':
            cols = sec.get('columns') or []
            out.append('<table><thead><tr>' + ''.join(
                f'<th class="{"r" if c.get("align") == "right" else ""}">{e(str(c.get("label", "")))}</th>' for c in cols) + '</tr></thead><tbody>')
            for row in sec.get('rows') or []:
                out.append('<tr>' + ''.join(
                    f'<td class="{"r" if i < len(cols) and cols[i].get("align") == "right" else ""}">{_cell(c)}</td>' for i, c in enumerate(row)) + '</tr>')
            out.append('</tbody></table>')
            if sec.get('note'):
                out.append(f'<p class="note">{e(str(sec["note"]))}</p>')
        elif kind == 'list':
            out.append('<ul>' + ''.join(f'<li>{_cell(i)}</li>' for i in sec.get('items') or []) + '</ul>')
        elif kind == 'text':
            out.append(f'<div class="text">{e(str(sec.get("text", "")))}</div>')
        elif kind == 'bosses':
            for b in sec.get('bosses') or []:
                pips = []
                for a in b.get('attempts') or []:
                    d = e(str(a.get('duration', '')))
                    if a.get('kill'):
                        pips.append(f'<span class="pip k" title="Kill {d}"><span>&#10003;</span></span>')
                    else:
                        hp = a.get('hp')
                        pct = f'{round(hp * 100)}%' if isinstance(hp, (int, float)) else '&#10005;'
                        width = round(max(0, min(1, hp)) * 100) if isinstance(hp, (int, float)) else 100
                        pips.append(f'<span class="pip w" title="Wipe {d}"><i style="width:{width}%"></i><span>{pct}</span></span>')
                out.append(f'<div class="boss"><span class="bn">{e(str(b.get("name", "")))}</span><span class="pips">{"".join(pips)}</span>'
                           f'<span class="bt">{e(str(b.get("note", "")))}</span></div>')
        out.append('</section>')
    out.append(f'<p class="gen">{e(str(doc.get("generated") or "Made with Raidscribe, " + datetime.now().strftime("%Y-%m-%d %H:%M")))}</p>')
    out.append('</main></body></html>')
    return ''.join(out)


def write_report(folder, base_name, doc, sheets=None, image=None):
    """Writes <base>.html, optional <base>.xlsx + csv/<sheet>.csv, optional <base>.png. Returns {kind: path}."""
    os.makedirs(folder, exist_ok=True)
    base = safe_filename(base_name)
    paths = {}
    p = os.path.join(folder, base + '.html')
    with open(p, 'w', encoding='utf-8') as fh:
        fh.write(render_html(doc))
    paths['html'] = p
    if sheets:
        paths['xlsx'] = write_xlsx(os.path.join(folder, base + '.xlsx'), sheets)
        cdir = os.path.join(folder, 'csv')
        os.makedirs(cdir, exist_ok=True)
        paths['csv'] = []
        for name, (_, header, rows) in zip(_sheet_names([s[0] for s in sheets]), sheets):
            paths['csv'].append(write_csv(os.path.join(cdir, safe_filename(name) + '.csv'), header, rows))
    if image:
        p = os.path.join(folder, base + '.png')
        if isinstance(image, (bytes, bytearray)):  # a finished PNG (the Android app draws its own)
            with open(p, 'wb') as fh:
                fh.write(image)
            paths['png'] = p
        else:
            w, h, rows = image
            paths['png'] = write_png(p, w, h, rows)
    return paths


def open_folder(path):
    try:
        if IS_WINDOWS:
            os.startfile(path)  # noqa
            return True
        for cmd in ('xdg-open', 'open'):
            from shutil import which
            if which(cmd):
                subprocess.Popen([cmd, path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return True
    except Exception:
        pass
    return False
# ======================================================================
#  Core: everything the screens need that isn't drawing (shared by the PC window and the Android app)
# ======================================================================



PALETTES = {
    'dark': dict(bg='#12111c', surface='#191827', surface2='#211f33', line='#2c2a44', line_soft='#24223a', text='#e9e7f5', muted='#9895b4',
                 faint='#6f6c8c', arcane='#a593ff', kill='#4fc790', wipe='#ec5b72', warn='#e9b44c', bar=.17, on_accent='#ffffff'),
    'light': dict(bg='#f5f4fa', surface='#ffffff', surface2='#f0eef8', line='#e1def0', line_soft='#ebe9f5', text='#1d1b2f', muted='#66637f',
                  faint='#9a97b2', arcane='#6b57e3', kill='#1c9a60', wipe='#d23a54', warn='#b97d0c', bar=.16, on_accent='#ffffff'),
}


CLASS_COLOR = {'WARRIOR': '#C69B6D', 'PALADIN': '#F48CBA', 'HUNTER': '#AAD372', 'ROGUE': '#FFF468', 'PRIEST': '#F2F2F2', 'SHAMAN': '#0070DD',
               'MAGE': '#3FC7EB', 'WARLOCK': '#8788EE', 'DRUID': '#FF7C0A', 'DEATHKNIGHT': '#C41E3A'}


QUALITY = {'dark': ['#9d9d9d', None, '#1eff00', '#2f8fff', '#b048f8', '#ff8000', '#e6cc80'],
           'light': ['#8a8a8a', None, '#12a000', '#0a6fd6', '#8a2be2', '#d96a00', '#a8894a']}


CHANNEL = {'dark': {'raid': '#ff7f00', 'raidwarning': '#ff4709', 'party': '#a8a8ff', 'guild': '#40ff40', 'officer': '#40c040', 'whisper': '#ff80ff', 'yell': '#ff4040',
                    'instance': '#ff7f00', 'channel': '#ffc0c0', 'say': '#e9e7f5', 'system': '#e9d36a'},
           'light': {'raid': '#c25e00', 'raidwarning': '#d43a00', 'party': '#5050d0', 'guild': '#1f8a1f', 'officer': '#1f7a1f', 'whisper': '#b03fb0', 'yell': '#d02020',
                     'instance': '#c25e00', 'channel': '#b3566a', 'say': '#1d1b2f', 'system': '#8a6d00'}}


CHANNEL_SHORT = {'LookingForGroup': 'LFG', 'LocalDefense': 'Defense', 'WorldDefense': 'Defense', 'GuildRecruitment': 'Recruiting',
                 'Raid Warning': 'Warning', 'Raid Leader': 'Raid lead', 'Party Leader': 'Party lead', 'Instance Leader': 'Instance',
                 'Battleground Leader': 'BG lead', 'Battleground': 'BG', 'System': 'System'}


def fmt_bytes(n):
    for unit in ('bytes', 'KB', 'MB', 'GB'):
        if n < 1024 or unit == 'GB':
            return f'{n:,.0f} {unit}' if unit == 'bytes' else f'{n:.1f} {unit}'
        n /= 1024


def mix(a, b, t):
    """Blend colour a over b with opacity t."""
    a, b = a.lstrip('#'), b.lstrip('#')
    ca = [int(a[i:i + 2], 16) for i in (0, 2, 4)]
    cb = [int(b[i:i + 2], 16) for i in (0, 2, 4)]
    return '#' + ''.join(f'{round(x * t + y * (1 - t)):02x}' for x, y in zip(ca, cb))


def fmt_int(n):
    return f'{round(n):,}'


def mins(ms):
    """19m 34s: a length of time that can't be mistaken for a clock time."""
    s = max(0, round(ms / 1000))
    if s >= 3600:
        return f'{s // 3600}h {s % 3600 // 60:02d}m'
    return f'{s // 60}m {s % 60:02d}s' if s >= 60 else f'{s}s'


def day(ts):
    d = datetime.fromtimestamp(ts / 1000)
    return d.strftime('%a, %b ') + str(d.day)


def day_key(ts):
    return datetime.fromtimestamp(ts / 1000).date()


class Settings:
    def __init__(self, path):
        self.path = path
        self.d = {}
        try:
            with open(path, encoding='utf-8') as fh:
                self.d = json.load(fh)
        except Exception:
            pass

    def get(self, k, default):
        return self.d.get(k, default)

    def set(self, k, v):
        self.d[k] = v
        try:
            os.makedirs(os.path.dirname(self.path), exist_ok=True)
            with open(self.path, 'w', encoding='utf-8') as fh:
                json.dump(self.d, fh)
        except Exception:
            pass


class Core:
    """Data for the screens: the indexes built from the logs, summaries, history and reports. The screen class
    (Tk on a PC, the HTML app on Android) provides show_toast() and log_error()."""

    def snapshot(self):
        """Builds the indexes the views read. Call with the watcher lock held.
        Skipped when nothing was read since last time (clicks and redraws reuse what's there)."""
        w = self.w
        key = (tuple(sorted((getattr(w, 'versions', None) or {}).items())), len(w.sources), w.active.path if w.active else None,
               w.chat is not None, ITEMS.ready, self.state, getattr(w, 'version', 0))
        if key == getattr(self, '_snap_key', None) and hasattr(self, 'model'):
            return
        self._snap_key = key
        self._derived = {}
        fights, runs, players = [], [], {}
        for s in w.sources:
            players.update(s['players'])
            fights.extend(s['fights'])
            runs.extend(s['runs'])
        live = None
        if w.active:
            p = w.active.parser
            players.update(p.players)
            fights.extend(p.fights)
            runs.extend(r for r in p.runs if r['fights'])
            live = p.cur
        fights.sort(key=lambda f: f['start'])
        runs.sort(key=lambda r: r['start'])
        self.by_id = {f['id']: f for f in fights}
        if live:
            self.by_id[live['id']] = live
        runs = self.merge_runs(runs)
        self.fights, self.runs, self.players, self.live = fights, runs, players, live
        self.run_by_id = {r['id']: r for r in runs}
        self.cp = w.chat.parser if w.chat else None
        self.addon_events = list(getattr(w, 'addon_events', []) or [])
        ITEMS.learn(self.addon_events)
        classes = dict(self.saved_classes)
        for src in w.sources:
            classes.update(src.get('classes') or {})
        if w.active:
            classes.update(getattr(w.active.parser, 'classes', None) or {})
        for e in self.addon_events:
            if e.get('e') == 'roster':
                for mb in e.get('members') or []:
                    n = (mb.get('n') or '').split('-')[0]
                    if n and mb.get('cls'):
                        classes[n] = mb['cls']
        for p in players.values():
            if p.get('cls'):
                classes[p['name']] = p['cls']
            elif classes.get(p['name']):
                p['cls'] = classes[p['name']]
        self.name_class = classes
        me = next((p['name'] for p in players.values() if p.get('mine')), None)
        self.me = me
        self.model = Model(fights, self.runs, players, self.by_id, self.cp, self.addon_events, me, items=ITEMS)
        self.runs = self.model.runs

    def merge_runs(self, runs):
        """WoW starts a new log file whenever logging is switched back on (a corpse run, a /reload, a crash).
        Runs of the same instance that follow on closely belong together, unless a boss died twice (a new lockout)."""
        merged, self.run_alias, self.attempt = [], {}, {}
        for r in runs:
            m = merged[-1] if merged else None
            pvp = CATALOG.get(r['instance_id'], ('', ''))[1] in ('battleground', 'arena')
            if m and not pvp and m['instance_id'] == r['instance_id'] and r['start'] - m['end'] < 3 * 3600_000 and not (set(m['killed']) & set(r['killed'])):
                m['fights'] = m['fights'] + r['fights']
                m['killed'] = m['killed'] + r['killed']
                m['wipes'] += r['wipes']
                m['end'] = max(m['end'], r['end'])
                self.run_alias[r['id']] = m['id']
            else:
                merged.append(dict(r))  # a copy: the originals belong to the parser and the cache
                self.run_alias[r['id']] = r['id']
        for m in merged:  # attempt numbers count across the whole merged run
            seen = {}
            for fid in sorted(m['fights'], key=lambda i: self.by_id[i]['start'] if i in self.by_id else 0):
                f = self.by_id.get(fid)
                if f and f['kind'] == 'boss':
                    seen[f.get('encounter_id')] = seen.get(f.get('encounter_id'), 0) + 1
                    self.attempt[fid] = seen[f.get('encounter_id')]
        return merged

    def run_of(self, f):
        rid = f.get('run_id')
        return self.run_by_id.get(self.run_alias.get(rid, rid)) if rid else None

    def player(self, guid):
        return self.players.get(guid) or {'name': '?', 'cls': None}

    def bosses_of(self, run):
        info = INSTANCE_BOSSES.get(run['instance_id'])
        fights = [self.by_id[i] for i in run['fights'] if i in self.by_id]
        order, seen = [], {}
        if info:
            for bid, name in info[1]:
                b = {'id': bid, 'name': name, 'attempts': []}
                order.append(b)
                seen[bid] = b
        for f in fights:
            if f['kind'] != 'boss':
                continue
            b = seen.get(f.get('encounter_id'))
            if b is None:
                b = {'id': f.get('encounter_id'), 'name': f['name'], 'attempts': []}
                order.append(b)
                seen[f.get('encounter_id')] = b
            b['attempts'].append(f)
            if f['name']:
                b['name'] = f['name']
        return order, (len(info[1]) if info else 0), fights

    def save_names(self):
        """Keeps the classes of everyone seen, so names stay coloured after old logs are deleted."""
        if len(self.name_class) <= self.saved_classes_n:
            return
        keep = dict(list(self.name_class.items())[-20000:])
        try:
            os.makedirs(self.data_dir, exist_ok=True)
            tmp = self.names_file + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as fh:
                json.dump({'v': 2, 'names': keep}, fh, ensure_ascii=False)
            os.replace(tmp, self.names_file)
            self.saved_classes = keep
            self.saved_classes_n = len(keep)
        except Exception:
            pass

    def watch_words(self):
        return [w.strip().lower() for w in self.watch if w.strip()]

    def watch_matches(self):
        """Messages mentioning a watched word. Only new messages are checked each time."""
        cp = self.w.chat.parser if self.w.chat else None
        words = self.watch_words()
        if not cp or not words:
            return []
        key = (id(cp), tuple(words))
        if key != getattr(self, '_watch_key', None) or len(cp.messages) < getattr(self, '_watch_pos', 0):
            self._watch_key, self._watch_pos, self._watch_hits = key, 0, []
        msgs = cp.messages
        for m in msgs[self._watch_pos:]:
            if m['ch'] != 'system':
                t = m['text'].lower()
                if any(w in t for w in words):
                    self._watch_hits.append(m)
        self._watch_pos = len(msgs)
        return self._watch_hits

    def fight_badge(self, f):
        if f.get('live'):
            return 'live', 'In combat'
        if f['kind'] == 'trash':
            return 'trash', 'Trash'
        if f['success']:
            return 'kill', 'Kill'
        hp = f.get('boss_hp')
        return 'wipe', 'Wipe' + (f' at {round(hp * 100)}%' if hp is not None else '')

    def list_dir(self, d):
        try:
            return os.listdir(d)
        except OSError:
            return []

    def scope_for(self, r):
        return self.run_scope if r.get('kind') in ('raid', 'dungeon') else 'all'  # PvP has no boss fights

    def activity_items(self):
        """Progress lines from the chat log: honor, reputation, experience, quests, resets, levels, achievements."""
        cp = self.cp if hasattr(self, 'cp') else None
        if not cp:
            return []
        key = (id(cp), (getattr(self.w, 'versions', None) or {}).get('chat'), len(cp.messages))
        if getattr(self, '_act_key', None) == key:
            return self._act_items
        out = []
        for e in getattr(cp, 'honor', []):
            out.append((e['ts'], 'Honor', f"+{e['amount']:,} honor" + (f" ({e['target']})" if e.get('target') else ''), 'warn'))
        for e in getattr(cp, 'reputation', []):
            out.append((e['ts'], 'Reputation', f"{'+' if e.get('up', True) else '−'}{e['amount']:,} {e['faction']}", 'kill' if e.get('up', True) else 'wipe'))
        for e in getattr(cp, 'xp', []):
            out.append((e['ts'], 'Experience', f"+{e['amount']:,} experience" + (f" from {e['target']}" if e.get('target') else ''), None))
        for e in getattr(cp, 'quests', []):
            out.append((e['ts'], 'Quest', ('Completed ' if e.get('done') else 'Accepted ') + e['quest'], 'kill' if e.get('done') else None))
        for e in getattr(cp, 'resets', []):
            out.append((e['ts'], 'Reset', f"{e['instance']} reset" + ('' if e.get('ok', True) else ' failed'), None))
        for e in getattr(cp, 'levels', []):
            out.append((e['ts'], 'Level up', f"Reached level {e['level']}", 'kill'))
        for e in getattr(cp, 'achievements', []):
            out.append((e['ts'], 'Achievement', f"{e.get('who', '')} earned {e.get('what', '')}".strip(), 'kill'))
        for e in getattr(cp, 'skills', []):
            out.append((e['ts'], 'Skill', f"{e['skill']} {e['level']}", None))
        for e in getattr(cp, 'currency', []):
            out.append((e['ts'], 'Currency', f"+{e['count']} {e['item']['name']}", 'warn'))
        for e in getattr(cp, 'discovered', []):
            out.append((e['ts'], 'Discovered', e['zone'], None))
        out.sort(key=lambda x: x[0])
        self._act_key, self._act_items = key, out
        return out

    def where_was(self, ts):
        """The instance someone was in at that moment (from the combat log), if any."""
        for r in reversed(self.runs):
            if r['start'] - 60000 <= ts <= r['end'] + 300000:
                return r['name']
        return ''

    def documents_dir(self):
        if self.phone:  # the shared Documents folder other apps can see, not Python's private home
            for d in ('/storage/emulated/0/Documents', '/sdcard/Documents'):
                if os.path.isdir(d):
                    return d
        try:
            import ctypes
            from ctypes import wintypes
            buf = ctypes.create_unicode_buffer(wintypes.MAX_PATH)
            if ctypes.windll.shell32.SHGetFolderPathW(None, 5, None, 0, buf) == 0 and buf.value:  # 5 = My Documents
                return buf.value
        except Exception:
            pass
        return os.path.join(os.path.expanduser('~'), 'Documents')

    def kind_mark(self, kind):
        return {'raid': 'kill', 'dungeon': 'kill', 'battleground': 'trash', 'arena': 'trash'}.get(kind, 'trash')

    def run_line(self, r):
        sm = self.model.run_summary_cached(r)
        bits = [day(r['start'])]
        if sm['kind'] in ('raid', 'dungeon'):
            if sm.get('holiday') and not sm['kills']:
                bits += [f"{n} ×{c}" if c > 1 else n for n, c in sm['holiday']]
            else:
                bits.append(f"{sm['kills']}/{sm['known_bosses']} bosses" if sm['known_bosses'] else plural(sm['kills'], 'boss').replace('bosss', 'bosses'))
            if sm['wipes']:
                bits.append(plural(sm['wipes'], 'wipe'))
        else:
            bits.append(KIND_LABEL.get(sm['kind'], ''))
            if sm.get('result'):
                bits.append('Win' if sm['result'] == 'win' else 'Loss')
        return sm, ' · '.join(bits)

    def session_line(self, s):
        ss = self.model.session_summary(s)
        parts = []
        for kind in KIND_ORDER:
            runs = ss['by_kind'].get(kind, [])
            if not runs:
                continue
            if kind == 'raid':
                parts += [r['name'] for r in runs]
            else:
                parts.append(f"{len(runs)} {KIND_LABEL[kind].lower()}{'s' if len(runs) > 1 else ''}")
        if ss['money_in'] >= 10000:
            parts.append(gold(ss['money_in']))
        return ss, ', '.join(parts) or 'Out in the world'

    def summary_for(self, kind, obj):
        if kind == 'run':
            return self.model.run_summary(obj, self.scope_for(obj))
        if kind == 'player':
            r, guid = obj
            return self.model.player_summary(r, guid, self.scope_for(r))
        if kind == 'week':
            return dict(obj, top=self.model.week_top(obj['start']))
        return self.model.session_summary(obj)

    def report_folder(self, kind, sm):
        when = datetime.fromtimestamp(sm['start'] / 1000)
        if kind == 'week':
            return os.path.join(self.report_dir, safe_filename(f"{when:%Y-%m-%d} Week")), 'Week recap'
        if kind == 'player':
            run = sm['run_summary']['name']
            return (os.path.join(self.report_dir, safe_filename(f"{when:%Y-%m-%d %H%M} {run}")),
                    safe_filename(f"{run} - {sm['name']}"))
        name = sm['name'] if kind == 'run' else 'Session'
        return os.path.join(self.report_dir, safe_filename(f"{when:%Y-%m-%d %H%M} {name}")), safe_filename(name)

    def save_report(self, kind, obj, open_after=False, quiet=False, image=None):
        try:
            sm = self.summary_for(kind, obj)
            folder, base = self.report_folder(kind, sm)
            if sm is None:
                raise ValueError('nothing to save')
            if kind == 'run':
                doc = report_run(sm, self.class_color_report, self.quality_color_report)
                sheets = sheets_run(sm)
            elif kind == 'player':
                doc = report_player(sm, self.class_color_report, self.quality_color_report)
                sheets = sheets_player(sm)
            elif kind == 'week':
                # a week is the recap text and its picture
                os.makedirs(folder, exist_ok=True)
                with open(os.path.join(folder, base + '.txt'), 'w', encoding='utf-8') as fh:
                    fh.write(discord_week(sm, sm['top']) + '\n')
                if image:
                    if isinstance(image, (bytes, bytearray)):
                        with open(os.path.join(folder, base + '.png'), 'wb') as fh:
                            fh.write(image)
                    else:
                        write_png(os.path.join(folder, base + '.png'), *image)
                if open_after:
                    open_folder(folder)
                if not quiet:
                    self.show_toast(f'Saved to {folder}')
                return folder
            else:
                doc = report_session(sm, self.quality_color_report)
                sheets = sheets_session(sm)
            write_report(folder, base, doc, sheets, image=image)
            if open_after:
                open_folder(folder)
            if not quiet:
                self.show_toast(f'Report saved to {folder}')
            return folder
        except Exception:
            self.log_error(traceback.format_exc())
            if not quiet:
                self.show_toast('Couldn’t save the report. Details are in errors.log.')
            return None

    def class_color_report(self, cls):
        return CLASS_COLOR.get(cls)

    @staticmethod
    def quality_color_report(q):
        return QUALITY['dark'][q] if q is not None and 0 <= q < 7 else None

    def auto_export(self):
        """Saves a report for each finished instance session (run), once, without being asked."""
        if not self.auto_save or self.state != 'ready' or not hasattr(self, 'model'):
            return
        now = time.time() * 1000
        baseline = self.cfg.get('export_baseline', None)
        if baseline is None:  # first start: don't flood the folder with every old log
            self.cfg.set('export_baseline', now)
            return
        done = set(self.cfg.get('exported', []))
        new = []
        live_run = self.live.get('run_id') if self.live else None
        loot_seen = dict(self.cfg.get('exported_loot', {}))
        updated = 0
        for r in self.model.runs:
            key = 'run:' + r['id']
            if r['end'] < baseline or now - r['end'] < 20 * 60_000 or r['id'] == live_run:
                continue
            n = len(self.model.loot_of_run(r))
            if key in done:
                # WoW may only write the chat log when you log out: when a run's loot turns up later, save its report again
                if n > loot_seen.get(key, 0) and now - r['end'] < 3 * 86400_000 and self.save_report('run', r, quiet=True):
                    loot_seen[key] = n
                    updated += 1
                continue
            if self.save_report('run', r, quiet=True):
                new.append(key)
                loot_seen[key] = n
        if new or updated:
            self.cfg.set('exported', (list(done) + new)[-2000:])
            self.cfg.set('exported_loot', dict(list(loot_seen.items())[-500:]))
            what = [f"saved {len(new)} report{'s' if len(new) > 1 else ''}"] if new else []
            if updated:
                what.append(f"added loot to {updated} saved report{'s' if updated > 1 else ''}")
            self.show_toast(f"{' and '.join(what).capitalize()} in {self.report_dir}")

    # ---- what goes in a player's drop-down, the same on the phone and the PC
    def item(self, name, q=None, count=None):
        info = ITEMS.info(name)
        return {'name': name, 'q': ITEMS.quality(name, q), 'count': count if count and count > 1 else None}

    def extras(self, cons, cds, int_by, kicked, dispels, taken, taken_by, avoid):
        """What goes in a player's drop-down: consumables, cooldowns and utility, interrupts, dispels, damage taken."""
        order = {'defensive': 0, 'cooldown': 1, 'utility': 2}
        out = {'cons': [dict(self.item(k), n=v) for k, v in sorted(cons.items(), key=lambda kv: (-kv[1], kv[0]))],
               'cds': [[k, v, NOTABLE.get(k, 'utility')] for k, v in sorted(cds.items(), key=lambda kv: (order.get(NOTABLE.get(kv[0]), 3), -kv[1], kv[0]))],
               'ints': sum(int_by.values()) if int_by else 0,
               'int_by': [[k, v] for k, v in sorted(int_by.items(), key=lambda kv: -kv[1])],
               'kicked': [[k, v] for k, v in sorted(kicked.items(), key=lambda kv: -kv[1])[:6]],
               'dispels': dispels,
               'taken': fmt(taken) if taken else None,
               'taken_by': [[k, fmt(v), (round(100 * v / taken) if taken else 0)] for k, v in sorted(taken_by.items(), key=lambda kv: -kv[1])[:5]],
               'avoid': fmt(avoid) if avoid else None}
        return out

    def death_row(self, d, f):
        return {'fight': f['name'] or 'Trash', 'fight_id': f['id'], 'boss': f['kind'] == 'boss', 'at': dur(d['ts'] - f['start']),
                'clock': clock(d['ts']), 'spell': d.get('spell') or 'unknown', 'killer': d.get('killer'),
                'amount': fmt_int(d['amount']) if d.get('amount') else None,
                'recap': [{'ago': f"-{(d['ts'] - e['ts']) / 1000:.1f}s", 'dmg': e['t'] == 'd', 'amount': fmt_int(e['amount']),
                           'spell': e.get('spell') or '', 'src': e.get('src'), 'crit': bool(e.get('crit')),
                           'overkill': fmt_int(e['overkill']) if e.get('overkill') else None} for e in (d.get('recap') or [])[-10:]]}

    def script_dir(self):
        p = sys.argv[0] if sys.argv and sys.argv[0] else ''
        return os.path.dirname(os.path.abspath(p)) if p and os.path.isfile(p) else os.getcwd()
# ======================================================================
#  Window
# ======================================================================



# The Raidscribe mark (a quill still drawing the fight's damage line) on its dark tile, as small PNGs by size:
# the window icon and the logo in the top bar. Same art as the phone's launcher icon.
MARK_PNG = {
    16: 'iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAABrUlEQVR4nKSTSyiEURTH//czhDxmCNOQx0JiLDTlWR5lobBAspGlhdhJoaw8ZlIeJdl5RZYeWUgWFvIIeSUyGHmMR/F9zKPPDHPdSalp+Mzw39xzO+d3z//UPTIwKRTRpexoBiVqQiCHhCiFAEIPWajj+Zt5IperyjjCTeMPclBHuU9gQMgIQGK8AVVRanA0FLa3p3gZBUkmHoLMPmqr++BHUjA4UcT6kmSOwaGewKlJBRgdPEB0VC42d2YYy3jGcp7AWZoK6NrHwT9SGK/sOLqY+crJfoMTEzLR3NiLO6MF+iMLTi8XYLbeev5AW9MwRPEdu1sCzBYeqzv9LnnJEWoqOyEPC8LGygMcdl+sbHfj1f7sUiPpoKS4isH3sJo4rO31wGBcdqtxc5CnicBkRw4SYjW4NghsdhFL663Y109924SEKWKoMyhMV2JPz0PbkAbDtRmRygqIFju6RibxYr7CT+IY/ZypDkdhhhKzPfl4erFBO3aCs/NFtAzoJGEnyxyo1oZasrPqtBvwXnT9/8skiqZj/4DgbXaPY+scwr6ov2TPz3V21tcLgnHuAwAA//8yMOqhAAAABklEQVQDAGvboDEkQH1uAAAAAElFTkSuQmCC',
    20: 'iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAYAAACNiR0NAAACbElEQVR4nKSVS0hUURjH/+fc651H6lyttDRbhBjkQgmpTQ8VSwQRpAdh9FgEtXFnFKVBoeCiFgURQQulcJHlLmy0muyxMKmZyULGzGkGm8bKcZpxxnlxT+daCpLmHecH9y7O950ffy73fEfEX7IyN9WAslaAbCEEMjTAGPz8PQ6FNE8HJnrVNUF9skz5baC4RQjJ4zI9NKL28j0bQViDUZ8pzkaCL4gs51dQQp4hRRhjisJYNeWyc0iBNUYTystaeFpCBUqbKFeXYpXU7mtE4/FH+PbDNh+zVOTqXCRJXm4RmpvuIRqW8N76HaPu3j8F7qJIkm1Fe3DzmhmSLhOfHCGMfjHzYImFupiEa07WdqkTiYQC25spJGLAx88PFvVoTjgvk3QiXlo8UOI6WEc64Q+6FvVpSkiJiJazd6A3iBh4OoFYSEIo4sXbkY5/e7UIjx64DDnbgGHrT0xNMlBBwKt3V6EoseSFOikddbVH4HIGMOYII02U8Np2HU7P8yX7lxXeaCqDnJGGmsrTiMcZbEM+CESCZagVdsfd5bYt/Q3rywtQt7cAvmAMGTklGBxwA4oR/YMXMebuw/9YSLhO1uH2hR0oLEjHqfpCtHd8wMHKzSjeYIdIetDVe2hFmQrJlvO96h9+v3031st65GTrMROOY+fJx2jYX4JIXEGPZRiaYGxSPXq2xsNbqw06ARVn+nH+RDFc3pm5elefHUnBXcRkyqvaXpRlDoQT1OkJYbWo44sBVUI0Ghz/NZtm9AcTu5ACBOTKtP9rhzqxEYkEnxhEYzco1TOwtXy2abwCmIuLHvLDfcwX8HSra78BAAD//9txaMwAAAAGSURBVAMAWozc2rF215UAAAAASUVORK5CYII=',
    24: 'iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAACxUlEQVR4nLSWb0gTYRzHv3c3580k1xiKUyfUi1BDBMUKShRD30goRhZhfyQMwyhMEnsVQdYbi6DIehFBVlgvynyRM3TIRoVWkhMyXeDc+SdnOd10ue3uem4yUpLVvPV5c797nofP736/+/OcAqtQq5MqaVCloLCLnOoQHpMQ8U6A+MLpnHgYHKRWxImpNMXcI2ERIkOXIPLVTueUjQ5koehHEZRLFBFnqxQwarXuBE3RZxBBYlV6+HwufTQbO04TeQUihD45EycPtYNVbiZtESG5FRDFLNIjyIFhlKg5fgt6XQ7MpveYnR9amSBu8tBQCZBBTmYJWluGkJWVB+uwG5aRx78niVsBGZSXNKDqWC08Sz70d9vh83oxNmVes4bGBgnKaWIwdo2D5mMwYuskXfGvWbehClbLTcYJeH+yROyBxfr0j7VhV7B9225UHV2RD336Dsc0jyiFAn2WO1hw2+UnuHC2BTQD2O1uWL+4EcVEY9IxgMHRtnXXh5Wg8sAV6JI0cC148eGtAwxY8LwXPX2XyawgL4FWo0d52ZFA3G0YJ/IY+PllGN40rtuaICFvcqKWxZKHx/yiDwf3NyCaZdDbzUH0q+AVPHhlrsPETH8oRegK2pvzcb0uOxCnp2VjcGAWPxwiacsSOnpr/ioPWUFZfgriNSoU5qqQm6FFStwIeiw6cNMWmD82Y2GRw79AabYki8GT+sp0FOQk4PBFM5407cHw2DziYpVQsgXISJ3Cpbs2dJiMCAdKo06alr4ZO3do0XZ1L7iZRdI3Crr4GOw7/Rp+v4ib9dU4f+MBrNxcWHLy9n2TKujcxDLFhtuFeG604/5LK55dy8NXzoVTTX2QiUEhiEJL2lZN8ajNhebWz4HRikYTSQ7ZSO7ARiBVQQ7FiCDkAtvnnFxp4DH1+YVzZGAZEUN0U8tirRSt2cr+x2/LLwAAAP//7uaXpgAAAAZJREFUAwBbRBBzXjP0BgAAAABJRU5ErkJggg==',
    28: 'iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAADjUlEQVR4nLSWaUhUURTH//fNmxmXmTczKpU1ZAtGC+1G0WoRWFFh0QJRCdlCRaRGhRSUEAUtWF+iD1EU9KXFCG1xinbTzNREQ00zbdxG1DeLkzPOzOu+F07FlMs48/t03rv38uO8c97lsPgDLYWBKhUE8yAIM0DIMPiDIJjo2VIIKPDAlslTepdIb6Dj9CuJDFdpOBKBpUlwY2enxfjYK4zgohMgkz1BEKHSVaKUaDQanYxRV9B30QguTS43pjKEqJKCKZsauwlhyhFiOJJhhO1USBskCGi4YUhNzsZY/RLYHS3SO9HF0E4KuHDjmnScO/EcdguHvOJLvxeoiyWExCBAxI6di6MpVxAVpUNOVg0sVhPazdXeddHFIEDMn7MB50/fxih9FAwP68AyalTWZfvsYxEAli/agYP7T4KVE7x98R0uh5Jm40F1/WOfvUPOUJSlHMiQZBVlbWhrdYNlFSivuYtuJ++zf0gZrk1Ixe7kNHpn0J/MaEVVhQVymQq2rlYUll/+5xm/M5wUu8grs3f1IP91syQTeVd2CT2uH4EVpuzNlGQiuTlfpSYRaTR9RE2D4b/n/BImrjiE0THDpfiloZ7ek2FgGAYutwOvik73eXbQNVSrIrFty34p/lRsQke7ADltEo/Hhaf5x8Fb6/s8P+gMD+27jrBwOYz1VtRW2mjdQqXMct+lo67xRb/n+xXGTY7AuYOzpJgQBjOmT4PV4kDBW9okbLgke/QmbUAykX4/6Zl9MxEbw6Hoczu+tExGaIgb2ffqoJBp4eyx40neYRhb32Og+GQYwSm88bK44ZKsnXfgyPYpWDw3Hjr7WYTKWdQan+GOYeugZD5CjtYm++JSZJ1djFAlg93rJ6DqmxlJJ/MQqVUibrwAp9OJkspUGPLTYbY1YLCwdOBppcWRejwzbTa4MDkixylw/3w8Jo7RIOXCB5TXmnEzpwMxo4xYmHwdfkNdJEKnF2eZhKTV45CxZzp2nSqgtXHjRsYCNJnsmJ+c692v4+TotPRgCOSyAjylqhB5gii7+bAWT983Sytbjr2B2/P37iHKILqIVjtiDAFbkhiv1z54ZUSwEATwAlwzpTFRq41exxBZFoKIR/Ak8nzTA+n67e62VYYouEL6Xy+lj2oEFnEQ3sybG3PEB1nv226HpUYZwlwjUDjpeOyg30BNuzcc/vBr1M+jRbtFR/1tvNlU3rv0EwAA//85FgeQAAAABklEQVQDAHIHTmxY5VoEAAAAAElFTkSuQmCC',
    32: 'iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAEKklEQVR4nLxXf0xbVRT+Lq/0N10LW5oImCWMHxtogUAcc3QumfKP2SZTomLi0AUhksCiMzgmyUwW3TRxbnOJJsZFY8wyNDMzuGEYywxKaoCyNKsjk1lGkTI6WmFdafv6PH3tujFwA0r7/fPOeT/u991zzz3vHgnuQ6omfb3AoQYCWwsI6xhjaYgBgiA4AXYZTLjMeJy4+a+9597n7B5brtNl7Kcv3iJSDnEAieFJyMeTk6PvkeuPCtBq0w1JDCfJzUUCQEIGBOBVl8s+kCSqYMJLiSIP8zFDmJPs1JRHNggc+5VuJiGBoCgEKQrFnFylaSHyUiQA25/+CGp5AUZv9ISiwCgBGC09ChFn5GaV4VDr71BK8tFrPXr3gcDyJAJYHkN8IJHI0Vj7BTYZN+PbExaMjHVS6APR5wxCnoTIVyAOMJZV442aVqSmKfH9ySvQKHX489qZ2S8xppcgDtj1yieo3P48jQ9c+GUYvE+KW54hON2Dc95d9swPke94LkxuGZjA2KgPCply7uwjWNYINNV+iYqKZ0TbMebBQO8ENGodeN6PQdvPiKuAvU2nUF6+XrT9viA6froGrWal6FuutsHrcyFuAg60tKO4+LGof7ptECqlVrRdU9dhshz/329jzoGqbftmkXeeswFBBZIl4bmdN+2HP3AbcREgk6pRVfla1Df3jWNinIdcKhd9KyXe2IT5gWPEJKCx9nOo1MmiPXJ9GtZLk1DKVKI/5RnHb/2HHzrGkgWszjTAaDSKttcTwIWOYagj6+71udF+sQkzfvdDx1lyEjbWHQMXObacbrs6i/zH8/XzFp35sOAIbDVmRO00XSZyc1eL9lnabhxTkhgOt247F0W+YAEvbHkUR/aUYnd1nuiXP1ElVrpekwPum0HIZbIweVftosgXLKBuR454bXxxLfSpchTml8AxYsOg1U1lViVm+6mOl2nP27BYzCtg26bMqL25VI+sjBRY/gpXsuad+SjOmYJhFe0AqQ0/dL6OLtrrHq8TS8EcAS01Bfj07RJ82FAk+nWV2fDOBFC9r5vquRvPlmdjpdSEi31efHe2Hg7nJcQCTiFPqacFVYecjYZVOPBmmLhgjRaGHB02FurxdfsQOnr+wd+j08hKfwrd/VfQ/NkZyngeMUEQHJxCsWILmWu0Kcn45v0nKZuTUNHQiWS6bo0sRcNBExWWAIbpD+eaGkJblxUzsZKHwFg3HcmCZoakitZdj0OfpsC7x/owZJ/G3uNmBIJBOkjwsN+4W8vPUSSWCyK3RpORTZO1HN1TIg2F9J0j/UgMhOkAz4rE8yi1ZM1kfIAEIigIu6kzOnznQMzptOl/0FG9CAkANSXmSZe9hEz+zjbk6cYGWpODYgMZP2KeuqFDxFUW4gzdm9MSRNrzndQ0rFvm9txK7flX97fn/wEAAP//sVuY3QAAAAZJREFUAwAuK5WJWsVfuQAAAABJRU5ErkJggg==',
    40: 'iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAFuUlEQVR4nMyYe0xTdxTHv/dSaKUtbUEo0AEijjgHc6JO4jbm4jKnmdNlcw808UXQPRJmRrYZSfZw2ZzTmCUuwyxhKCKOuE2nRFSmAx9TUB4CIgwEBITCpIUCLYX27tzbWaiCAivF7x/N75z++rufnN/9nZ7fEWEYqVSalxkO8zgGUQyYKHL5w7lq5sAV0jMK6Rn5Ol3TsaEmMXc7FAp1KMuK9hPUfLhQBHvBau1f1dGhrR3sdxtseCseiWNZ9gjBhcHFomcGsQy7XiyRa00mQxHuBlQpNBsZltlDUz0wYWI8GIZZJhETZK/hsuDhPxQKv6lurPtVMqV4KMR1W6x9T3R0tN5gyWJY1j3t4YHjxUiJaR8/YL29NPNcfSCGUlhINJ6fvctuE9PTPJvIyiKaxcRJLvPFB/F7UFYkQkH5NofvBDYiXYAJkJubB9at3IF9yQXQNnphkkSEBu0FhzkMg2gRAy56iHQ4rgqbMhdJiSnwD1DifG4jjD0smlrP8kCO4giQvGq4UG8sS8Kq2Hi4U2hqqvSoruyAt3Iy/r558p65lHJCRHCRWEaErZuPImp2hGAbOs3Iya5FoH8gdJ11FMEr90aQ5BJAhZcfvv08G0HBvnZf+k9l8Pez/b2XVGUMCcdr3A9waHAUknedc4DL3F8Bb5UPHRQ3mMwdqKzLGvb34xpB/jBs/yITntKBx+T9cRMWswgymUSwr1UfhsViGnaNcYtgUMAMfP1phgPc9Wu3UV/bRXBegt1r7kZxZdp91xkXQD75bt/6G+ReYrtP127CudMNUHr52H2F11Noi/VwOeCXW45AqfJ08KWnlsJ38kBGM3Q3o6Qy44FrOf0dXB+7E+HhQQ6+jL3l8PdVg2pNweY4K84UbIXVan7gek4FDAuZg+WvrHDw5WTX0f+UGGLxwHYXVaShUZs/ojWdusWb3t0NkftAQistaUNLkwnSSXK777a+GvllySNe02mAz0bHImyaxm63anuQf6EZCrnK7jP26nH8XCKsXN+I13Ua4JrYjx3sg/vK4OczcCj4lJKVl4DO7kaMRk55B6MiFyNQ422301JKoQkIsNt0W0P2+Q/R2l6O0WrUEYwMU+Kpx30cfItfWG8fnzh2A2KRJzw8bHevvj4jss5uomLgMsaiUQFKPNyQ+tl8ZG6LweL5tghxHPDkzFnCuPCKFrfb+qj4lAm20aTD4TPxaGj5C2PVqABXLAyGj9KWLjavtZVNC59ZDZncA7eaunD1civkUqXgb9fX4FDOGrTpKvB/NKp3MP61R+3jYH8Z4pZPgzp0KdTMARw8oYaPKkJIwlerfsal0u/Rf58iYKQaNoJJ6yKwYRDQ0hgNgtRS6AxmgqkTfAlvT8e0KVJ4u1/ER6tP0ftWikOn1uB88U6nwPEaMoKbVk5H3Ks2uCA/TyT9UIJ3Xg8X7ANUBScfqsKL0QHUKhFDYiygbVRgR3onMk/GUQQtcKZEtKJ28L1kZrgKCW89Zp+waslUipwnZoTa3q3UozUw9PRjV3oF3ly0BDxP9NqD963pxixiYwmu+I49Scziu8Q5wvj33AbszaoRxs/NtpXmv5yup2j1CuO047WoabiEI7kp4wPHi9hEHKzFDNhFvL1lXSSmBMhQSyfyk91F6DFZYDRasPG/7f3x12qH3yfsHFtuG6l4NhEsKOZ7XNNDvITt5PXeN5cEOF7bqFS61dYj5Lvr9Z1wqYiNSo9AT5WKvaiUukd+9f4s5FKyzcypx0SL4lGu02GuUBupZOoIqpOu0NVvAnuDA6LdMjP9/bPau1quCQ1Mk7m7VSKRd9FN/iU8BKJ2cKKus/koP7Z3WKntepE6my0UxQUT1WWlyOkJboNe37Tnju+e+7xSGRDCwC3VBupSuD97zabYnp5/mgf7h21ryeWacHeWieEYLobMGL6RA2cCgbtJH3kMx+T1Wa15BsOtyqHm/QsAAP//8vXpjQAAAAZJREFUAwC9D/WiAzVtKAAAAABJRU5ErkJggg==',
    48: 'iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAHFklEQVR4nNRaCXBTZRD+3stLmzZNSXpftCKieM3QCtRbUEEFpQgKVRB11A4jHmhRAWWEcRhkdAYBHWQ8RkSBonJZrlIOAZFDuUppKU1p6UVKSdKmR5o0+d33Aq8JPaCFtOGbycv+m//9s7tv9+3++0dAB9DpdL0YC0zhwI3hONafWDEAp4FXwSx0KWeMy2dgaziuYYPJZKppbzbXFlOtjoj0VwozwfFpNFShZ2EFY0ub7PZ59fVVhst/bKWAThc7kiy+gshg+BZqncz5ktlcscGdqXCjuRBt3Gz6XspxXE9bvS340ydVpQp2WK2WPZeYsgI6XdwEjsMiEp6Dj4Jz4VF/laaYlDgq8cSLVhs7lIgs+lHADQDGYCd3GlFTU5HNiwzy+XdvFOFFkI8oeY5/S6T5oKDICNJpFHwYalUMHk6cTxTvxmWj1OrwKEGpEMb4st8PTnwOCaGTYK49L3oK2EW+KLOf4DdaICoVPog+8Ul4+7WvUJBnQ1lZHQ7lzSPhHR5zOJ4bzZNSA+BDoADF6xMXYOEX62A0CjhbUguFUAuzpbD1XOBega4q+IgDiVb/OP1HxMaFoiDfiP8OVCJUF4Lc4vVt30CyC+T9/vABiFYf9cxYKAUOVYYGZG3SQxOkgUYThKLSHW3eI8re46/O3tF3YGb6z7ipT6Q0bmhoxp9/FIAClKyvg+FCLmrqStu9v0cVGJyYghnTFkKlchUETgdD5poCNDU5ER0VJQYpjp9e0eEaPabAU49NwZS0jyhAWwJwV3YJDIZ6REdGQVAoUFdvgL50e4fr9IgCk8bNw/jnJ4J3y0s5R6pw4ngVwsPC4e/n5+LpV9NbydHhWt2uwPiUWUgdNxHuqbO8zIK/tpegV3AwgtSBEq/BakRu4e9XXK9bFXh62NuYNDHNQ3hLrQ2Za09THKgQotXJ/IMnlsJmr7/imjy6CcmJozH5jQ883EYM2g0UtMzBISw0TN5eGc16nNSvvap1u0WBmMhbMT19ARQKz4wpBq3pghUR4eH0W4soB3KW0NV5VWt3iwJzZmRAFeDprS1BGwalUinzz1Xn4EzFLlwtvB4Db77yDeJ6h3nw3IM2MCBA5jscNuw89Bk6A68qcG/SGIwc4bnVaC9oRfxzbDFMtUXoDLzqQmmvzgbv1jaw251tBq0IfdkOyror0Vl4TYHRT6YjOsbTwtmbi9oM2vrGauw80DnXuQSvKfD8mDSP8b/7K3H6lLFV0NrsDdi05z3Ymi3oCrwSA+NSPkFIaKA8Li6qwb49pdCRz7sHbXOzFRt3T8V5Ux66Cq8oMOKJF2TaZLRi84ZCalcGQturpdnndDZjy74PUVl9GNeCa3KhSSP6YMjACA9e35sGISLCJWiT1SHV9jxFclhIqDzHbm/ERnKbs5X7cK3o8hN4b0J/vJt6u0Q/kpaFkkpX3fLM8MlSrcMokW7OLISlzi6Vx/zFGsLSUIUte9OvyW3c0aUnoPJT4OWRN8vjWa/fLdODBj4gfe/bW4rS4lqE0+tSKbjsVGU8iTXZr1w34UV06QmkDk+AVtOylX58cDSS7wpD6fkQRIbaYDbk0YbcKW3IAyhhMXocR/N/kSpMh7MJ1xOKgIDg2egklsxIhiZQ6cEb0E+HoguD8NiAOtyiy4TB1BuMj6fMWkyvyanIL8684uakK+jQhRa8fw/2//QExg9LkHlPPxSL6DDXq/DTpcewcW+5RPdLCMaDSQ9Bq9gPQXBg7KN/U0m8DKu3ToDBmAtvoV0XmvpCfzw7NF6i57+TJPUwMrKKMXnsrRLPbGnC6m3F2H7wHEY+GEtBy0HNqiGWwRnbYvDl8kzy9RJ4Gwo6MJhBsnkoknR7CFl/oMfEYcnRSIgJwiNJrvbH9+v12H24CrX1dgRSV6FvXBxyCiLxW1YuFq5aSVvCGngb1JmrIRdi59yZQQEKLJrWIvyKzWdk+tkhvWV6WaZephdnnEKj9QIG37UdOw7vQneBWr3nyPKceNIhO/ncNxMRF6GW6AW/5pE183Fcb8LnbyXJN2ZknSH3aHmbWKgZdf9rW9HdEE8yeTrK3HWJIQZoykUrH6HepCi8iFVbSzD965aU/926QvgEGNvCaTQx/ZUCL2WWZXPul3zc0mDH8CnZVKdYPeb3i3cdEZ8+27XK8XrDyZr7KGw2SzXlgvtofMtZ6orFR6kx94cc5BS2DkJjjU36+AKoDb+ejly/lfZE9BRuExT8MV/pVF8JJHyTtQl9GxvLyqVEZrFUnKJYmIwbBCRrmii8SMs7VvHcNUAVLB5DDYEvg2GOyVy+8NKw1dmMVhszio4wl8MH/2pAln/RZCrf6M5sVQtJ/0WwsjsZY5nwEUiykEyXCy+iw9MxrTb6YR6KoYxDMmU9cQMQS7cEwatgdeQmFYzj9BzDQSccO8zmyt3tzf4fAAD//+1Tog8AAAAGSURBVAMA03+XI0FJP9sAAAAASUVORK5CYII=',
    64: 'iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAJ50lEQVR4nNxbCVRU1xn+3psZmMHZgAHZrKB4gg1Wqxa1VcpRYzQajbaGpI2tS7TxuOVUjRqNxx5N1VbbY4I9p1Vreno0WmNiFQvihkHrhlFBjbIIyDI4bDOsszDzcu8jzDDMoKAjs3zncHx3eeD/3/9+/3LfFaIHkMkiVAIBXmfBTuPADWAYqAAmmAxJ4B60AFwNx6GaAfPQAu6ExcIcr68vq+3uL2C6M0mpjEpiGawlj6/CO5Bh4bBVqy3LfNrEJypALo8aJWCxjax0ErwQxDIyzRasJRZxtas5XSpAqQyfyUBwiAjvBy8GUYLBwnHv6HTlXzgbFzjrDAyMWMKA/YxhGCG8HGQBhWSVZ4vFCq1eX+9gCQ4KUCoj32cZ9hMifLf4wRvA8MBksb/ssd7QkG031rGhUERMZBnmFJnNwgdBtoOJsZin19ar09v7rAoghBcrFOAGfYQPgwN0ra1cQkNDeR5tW1easP1e+LjwFGTFFSIh80l7m1dAkDxyNNkjP4cPIkgW79DHcdwkhSJ8BH3mSVAsUaQQBcTBx5AwZBkGRc5Dc0slGlpKrP1tnMj2JV7hEHFzKhnpmwIfQnBgP8xP3o17t1thNDdAXXPJ2bQpQcT22UC531RvD3baIRD4YfHcFOzadg4FDzgwLIvcwhRCfGaHuVRmi1I8XggB8wZ8AK9NWII5v1qBPn38ceTgPRhazAiQWlBZc73Ld8hGmCwk6omDF4c8gfIIbPzgEOIGx/Dt9BMFqNY0k20QhIKyL5/4LhF7GA0Tw+ClmDhuPhYv3ICAPiK+nX1Fjbz7tZBJZSSukaGo4vwT3yeBUZiQ7BSltxmAxF+GNSsOICHhx2gP2Isf6nA5qxT+/v5k9QPR1FKNyuo7eHJAz4QJyQR/eBFG/GgqVi3/K5SBthpMXa2eN32BUIjQkBBCfgweFJ3E07IZKrtXZXvv/GIz3k6eC7ZDCmfQm3HiyzyYTBaEh4VBSEpWFksr7hQc7tbv9BoFrFtxGImJP7Xr4yzAqdQCaOv0CFGFwN+vzZsXlp5DY4umW7/X4xXgJwrAHzek4uX4QQ5j/79YiuIiHRRyOaR9Aqz9OfkH0V14tAJCgqOxfdNxhEcEOoxRtr9xVY0AiQRBSts4Jb7HNXfQXXhs3h//UhJ27zjjVHhKeqf/Vwg/oQiqYJVdVeNu4RfoCTzSAgbFjMIf1u8n/t3xv8eT3tE84sMZhPYNIeGvbQ3rmyqQ/ygDPYHHWYAq6Af4eOMBp8JT0kunpKelpKeCSCSyG7+Sk0I8gBE9gUdZAA1wdm5Jg0zuPDShpFfyPenRvd8RldW5KOjh6lN4jAJoJrdj8xli1s6LUu2kJ+lEeu24dGsnngUeo4CVi/djwMAIp2Oax8086YkI6YV0Ij2K/JKMHjF/R3gEB4wZMQtJSYlOx5qbW/lIj5Je31B70qOwWMy4nPMpnhVuV0CQMgq/X/Znp3G7xczh5LE8NDUanZIexY17+9DYrMazwu1b4KPVn0Mqc16QyjxbAnV5IwLJnu9MehQ06Ll+dw+eB25VwJszNiAuLtrpWO5NDe7c1qBPQACUCkdiNJpacPryh+Ar/c8BtylAIQ/DW79c4HSsvKwBF86VwI8kN6rgYKdzsr7ZjobmCjwv3KaA3/1mJyQBjn++od5I9n0+6Okcze1Z1pGmKOs/KE6FK+AWEqSrP/ZnYx36aU5/4qs8vqDJk57QUUGVNXeRmb0FroJbFLB0QQpEfo5/OvN0MV/QDCIlLYlY7DCuayjFya+Xw9TaDFeh17dAWEgsxoxJcOinpPft3WprQbMzWgxanLiwDAajDq5EryvgvXl/IcGMvdPnSe9sG+nRgmZnGIxNZOVXkGyvDK5GryqAVneGDx9m12clPZa1FjQ7gtb30i+thKb2Ll4EXMoBgXIRdq0cifXz4iFzks6OH/dbEs3ZBHwa6RmNjUgle75ck40XBZdawKaFQzEjqR//LJcKsebTW3bjiWNm2LXPpj+0nuJ0Jj1a3Ei9sBzahmK8SLjMAqJCA6zCUyRPisEPY2wRHDX/wYNfsrY7n+J0hLrqNo5kzHnhwlO4TAELZsQ69G0kFtEOav5iSZvBdT7F6YgHJWn47/n3XM72XcElW0BBzubeejXaoX/0EBUmJoThzLVKjBg6ARKmGAJDDjnFibQ7xaFo0dfh4s2dpKaXjt6ESyzg11OiSTnLdlzTYrCdx6+fP4T/NzwsCnJkoZ/0DCaNvskLT09xKB6WncfnabN7XXiKbimAMvrWJcP4n9BAxwht3nSb+ec/qseGv920tmMipZg7bQD6hoghY9r6p47LwfiRV0geX4W0rFXEza2G3qiFO9AtBezdMBpvT47hf45sHweV0la0TH6lP0I6KGXPVwU4eq4UdwptAi1JHg5Oe564uVa+rakNQsblbLLqs8gRdibcCZZ+N/ekCQtnxmJUfIi13T9ciqN/SrQqYdEs25FVNSlX/+dM28dIm/fmWvtv5CciNjQbNTopdh2UYuy7B/Gv1IMkpm+BO0FlFwRIZHNJlVHlbAJ1Y3//cLRDv5JUcCYQcjMYzXjzlWhrf8rh+7h+r+1T/XLi3+Oi5YjtJ0d61iCSu4uxaMsRnM2+BLOlFZ4ABlwJS4qNlc4GxX4CpHxgn7Roam0rNjBKhu3Lh1vbzfpWHEgrtpu/9bO28HXO1Iv4yctFhPnr4EmgshMnxN1yNrjx3SEYEGULUA6kFeG1FedRRGp0znAooxi6JpNdX4m6CYs+voLcwhKs3Z0OdbUengQqOxMkD59M0rO0jgPUd+/9aIy1XUiytalEeD0xeeoFDm8dx7N7R4xdcAplGtfl6b0Cs3kKW1uvPkcvFbT3UQF3vD/cbt7S7dd44Sk0dXokr8tCsdpmCccvlHqd8JQAiexnqRs0kpp8ZvvAghkDCcnZ3NzmfTn4trje7mWqhNlrvkbGlQqculyOTf/IgdeB42U28aEwZzKtYkQi/kKULMB2+HDxlgb7jhU6fb+qzkD291V4IziOMzOt5vX0mY9F9cYmjVgiG8yAib9xv4b39Vdzq7Au5Sapv1vgayDZx7+J+e/5/rkNUmnfUFKQuMYwTH/4MDhwj0wm88jGxsoq2raGwo2NjzUWzjKLXiuBj4LKRsz/jXbhKewuTRkMjWqJv6yKWME0+CI4bqlWV2F3ouJwa4zeqhL7y2h0OMVXLk/xpMdxi+p0FQ4nqV1+TKpQRE4QsAz93Nqr7xER4WuIz5+t1ZY7/XJa0NWLBkNDkUAo+SfDCkjNihvmbfcIieAW4tX2m1rNM+vr1V3W1Lt5eTpyKJF/G5k8GV4AsuLppOa+uq7x8VO/m+nRqsrlUUEsy01nwbzumdfnLakc13RMp9N1O+38DgAA//8AevqiAAAABklEQVQDAGXro4x+CXM/AAAAAElFTkSuQmCC',
}


class Surface:
    """A canvas we draw a view on, with click and hover targets that are rebuilt on every render."""

    def __init__(self, app, parent, **kw):
        self.app = app
        self.cv = tk.Canvas(parent, highlightthickness=0, bd=0, **kw)
        self.actions = {}
        self.hovers = {}
        self.n = 0
        self.hot = None
        if app.phone:
            # touch: a tap runs what's under the finger; a drag scrolls (no hover on a phone)
            self.down = None
            self.cv.bind('<ButtonPress-1>', self.t_down)
            self.cv.bind('<B1-Motion>', self.t_move)
            self.cv.bind('<ButtonRelease-1>', self.t_up)
        else:
            self.cv.bind('<Button-1>', self.on_click)
            self.cv.bind('<Motion>', self.on_motion)
            self.cv.bind('<Leave>', lambda e: self.set_hot(None))

    def clear(self):
        self.cv.delete('all')
        self.actions.clear()
        self.hovers.clear()
        self.hot = None
        self.cv.configure(cursor='')

    def tag(self, fn=None):
        self.n += 1
        t = f'a{self.n}'
        if fn:
            self.actions[t] = fn
        return t

    def hover(self, tag, item, normal, hot):
        self.hovers[tag] = (item, normal, hot)

    def _tag_at(self, table):
        items = self.cv.find_withtag('current')
        if not items:
            return None
        for t in self.cv.gettags(items[0]):
            if t in table:
                return t
        return None

    def t_down(self, e):
        self.down = (e.x, e.y)
        self.dragging = False
        self.cv.scan_mark(0, e.y)

    def t_move(self, e):
        if not self.down:
            return
        if not self.dragging and abs(e.y - self.down[1]) > self.app.px(8):
            self.dragging = True
        if self.dragging:
            self.cv.scan_dragto(0, e.y, gain=1)

    def t_up(self, e):
        down, self.down = self.down, None
        if not down or self.dragging:
            return
        x, y = self.cv.canvasx(e.x), self.cv.canvasy(e.y)
        r = self.app.px(4)
        for item in reversed(self.cv.find_overlapping(x - r, y - r, x + r, y + r)):  # topmost first
            for t in self.cv.gettags(item):
                if t in self.actions:
                    self.app.root.after_idle(self.actions[t])
                    return

    def on_click(self, e):
        t = self._tag_at(self.actions)
        if t:
            self.app.root.after_idle(self.actions[t])

    def on_motion(self, e):
        t = self._tag_at(self.actions)
        self.cv.configure(cursor='hand2' if t else '')
        self.set_hot(t if t in self.hovers else None)

    def set_hot(self, t):
        if t == self.hot:
            return
        if self.hot in self.hovers:
            item, normal, _ = self.hovers[self.hot]
            self.cv.itemconfigure(item, fill=normal)
        self.hot = t
        if t in self.hovers:
            item, _, hot = self.hovers[t]
            self.cv.itemconfigure(item, fill=hot)
            self.cv.configure(cursor='hand2')

    # ---- drawing ----
    def rr(self, x1, y1, x2, y2, r, fill, outline='', width=1, tags=()):
        r = max(0, min(r, (x2 - x1) / 2, (y2 - y1) / 2))
        if r < 1:
            return self.cv.create_rectangle(x1, y1, x2, y2, fill=fill, outline=outline, width=width, tags=tags)
        pts = [x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r, x2, y2 - r, x2, y2, x2 - r, y2, x1 + r, y2, x1, y2, x1, y2 - r, x1, y1 + r, x1, y1]
        return self.cv.create_polygon(pts, smooth=True, fill=fill, outline=outline or '', width=width, tags=tags)

    def text(self, x, y, s, font, color, anchor='nw', tags=(), maxw=None, wrap=None):
        s = '' if s is None else str(s)
        if maxw is not None:
            s = self.app.clip(s, font, maxw)
        kw = {'width': wrap} if wrap else {}
        return self.cv.create_text(x, y, text=s, font=font, fill=color, anchor=anchor, tags=tags, **kw)


class App(Core):
    def __init__(self, root, watcher, logs_dir, data_dir, phone=False):
        self.root = root
        self.state_file = os.environ.get('RAIDSCRIBE_STATE_FILE') or None   # the automated Windows test reads this
        self._buttons = []
        if self.state_file:   # also every second, so scrolling and dialogs closing show up too
            def tick():
                self.write_state()
                root.after(1000, tick)
            root.after(1000, tick)
        # phone: Pydroid on Android (or RAIDSCRIBE_PHONE=1 to try it on a PC). Touch, bigger text, one column.
        self.phone = bool(phone or os.environ.get('RAIDSCRIBE_PHONE') == '1')
        self.narrow = self.phone
        self.menu_open = False
        self.right_left = None
        self.w = watcher
        self.logs_dir = logs_dir
        self.cfg = Settings(os.path.join(data_dir, 'settings.json'))
        self.data_dir = data_dir
        self.theme = self.cfg.get('theme', 'dark')
        self.tab = self.cfg.get('tab', 'combat')
        self.chat_view = self.cfg.get('chat_view', 'loot')
        self.fight_filter = self.cfg.get('fight_filter', 'boss')
        self.meter_tab = self.cfg.get('meter', 'damage')
        self.run_scope = self.cfg.get('run_scope', 'boss')
        self.sort = self.cfg.get('sort', ['dps', -1])
        self.loot_q = self.cfg.get('loot_q', 2)
        self.watch = self.cfg.get('watch', ['lfm kara', 'need healer'])
        self.sound = self.cfg.get('sound', True)
        self.view = ('current', None)
        self.open = set()
        self.msg_q, self.msg_ch, self.msg_limit = '', 'all', 300
        self.state = 'starting'  # starting | missing | loading | ready | error
        self.progress = ('Starting', 0.0)
        self.error = None
        self.seen_watch = None
        self.render_queued = False
        self.last_width = 0
        self.seen_version = -1
        self.instance_filter = self.cfg.get('instance_filter', 'all')
        self.history_tab = self.cfg.get('history_tab', 'weeks')
        self.auto_save = self.cfg.get('auto_save', True)
        self.report_dir = self.cfg.get('report_dir', None) or os.path.join(self.documents_dir(), 'Raidscribe Reports')
        self.addon_events = []
        self.loot_q_text = ''
        self.loot_who = self.cfg.get('loot_who', 'all')
        self.name_class = {}
        self.names_file = os.path.join(data_dir, 'names.json')
        try:
            with open(self.names_file, encoding='utf-8') as fh:
                data = json.load(fh)
            # older versions could pick the wrong class from a shared spell: start their list again
            self.saved_classes = data['names'] if isinstance(data, dict) and data.get('v') == 2 else {}
        except Exception:
            self.saved_classes = {}
        self.saved_classes_n = len(self.saved_classes)
        self.items_seen = False
        self.tip_win = None
        here = [os.path.dirname(os.path.abspath(p)) for p in (sys.argv[0] if sys.argv and sys.argv[0] else '', __file__) if p]
        here += [getattr(sys, '_MEIPASS', '')] if getattr(sys, '_MEIPASS', '') else []   # inside the installed Raidscribe.exe
        path = ITEMS.find_file(*(here + [data_dir]))
        if path:
            ITEMS.load_async(path)

        if self.phone:
            # lay the screen out as if it were about 400 points wide, whatever its pixel density
            sw = min(root.winfo_screenwidth(), root.winfo_screenheight())
            self.scale = max(1.0, sw / 400.0)
        else:
            self.scale = root.winfo_fpixels('1i') / 96.0
        self.setup_fonts()
        root.title('Raidscribe')
        root.minsize(self.px(380), self.px(520))
        self.build()
        self.apply_theme()
        root.after(120, self.pump)
        root.after(1000, self.tick)
        root.after(30_000, self.tick_export)

    # ---- basics ----
    def px(self, n):
        return int(round(n * self.scale))

    def setup_fonts(self):
        fams = set(tkfont.families(self.root))
        pick = lambda *names: next((n for n in names if n in fams), 'TkDefaultFont')
        base = pick('Segoe UI Variable Text', 'Segoe UI', 'Inter', 'Helvetica Neue', 'Roboto', 'Noto Sans', 'Droid Sans', 'DejaVu Sans')  # Roboto/Noto: Android
        semi = pick('Segoe UI Semibold', 'Segoe UI Variable Text Semibold', 'Inter SemiBold', 'Inter Semi Bold', 'Roboto Medium')
        disp = pick('Segoe UI Variable Display', 'Segoe UI', 'Inter Display', 'Inter', base)
        semi_ok = semi != 'TkDefaultFont'
        if self.phone:
            # sizes in screen pixels (Tk's point size depends on a DPI setting phones often get wrong); a touch bigger to read
            z = {10: 14.5, 9: 12.5, 8: 11, 20: 25, 12: 17, 16: 21}
            sz = lambda pt: -max(8, round(self.scale * z.get(pt, pt * 1.4)))
        else:
            sz = lambda pt: pt
        sb = (lambda size: tkfont.Font(family=semi, size=sz(size))) if semi_ok else (lambda size: tkfont.Font(family=base, size=sz(size), weight='bold'))
        self.F = {
            'base': tkfont.Font(family=base, size=sz(10)),
            'semi': sb(10),
            'small': tkfont.Font(family=base, size=sz(9)),
            'smallsemi': sb(9),
            'tiny': tkfont.Font(family=base, size=sz(8)),
            'h1': tkfont.Font(family=disp, size=sz(20), weight='bold'),
            'h2': sb(12),
            'stat': sb(16),
            'brand': tkfont.Font(family=disp, size=sz(12), weight='bold'),
            'mono': tkfont.Font(family=pick('Cascadia Mono', 'Consolas', 'DejaVu Sans Mono'), size=sz(9)),
        }
        self.line_h = {k: f.metrics('linespace') for k, f in self.F.items()}
        self._clip = {}
        self._mcache = {}

    def clip(self, s, font, maxw):
        if isinstance(font, str):
            if self.m(s, font) <= maxw:
                return s
            f = self.F[font]
        else:
            f = font
            if f.measure(s) <= maxw:
                return s
        key = (s, str(f), int(maxw))
        if key in self._clip:
            return self._clip[key]
        lo, hi = 0, len(s)
        while lo < hi:
            mid = (lo + hi + 1) // 2
            if f.measure(s[:mid] + '…') <= maxw:
                lo = mid
            else:
                hi = mid - 1
        out = s[:lo].rstrip() + '…'
        if len(self._clip) > 5000:
            self._clip.clear()
        self._clip[key] = out
        return out

    def m(self, s, font):
        k = (s, font)
        v = self._mcache.get(k)
        if v is None:
            if len(self._mcache) > 60000:
                self._mcache.clear()
            v = self._mcache[k] = self.F[font].measure(s)
        return v

    def apply_theme(self):
        P = dict(PALETTES[self.theme])
        P['arcane_soft'] = mix(P['arcane'], P['surface'], .14)
        P['arcane_soft_bg'] = mix(P['arcane'], P['bg'], .14)
        P['kill_soft'] = mix(P['kill'], P['surface'], .16)
        P['wipe_soft'] = mix(P['wipe'], P['surface'], .16)
        P['hover_bg'] = mix(P['text'], P['bg'], .05)
        P['hover_surface'] = mix(P['text'], P['surface'], .04)
        self.P = P
        self.root.configure(bg=P['bg'])
        for s in (self.top, self.nav, self.main):
            s.cv.configure(bg=P['bg'])
        for e in (self.search, self.watch_entry, self.loot_entry):
            e.configure(bg=P['surface'], fg=P['text'], insertbackground=P['text'], highlightbackground=P['line'], highlightcolor=P['arcane'],
                        selectbackground=P['arcane_soft'], selectforeground=P['text'])
        self.toast.configure(bg=P['surface'], fg=P['text'], highlightbackground=P['line'])
        self.render()

    def class_color(self, cls):
        if cls == 'PRIEST' and self.theme == 'light':
            return '#8d8aa6'
        if cls == 'ROGUE' and self.theme == 'light':
            return '#c9b800'
        return CLASS_COLOR.get(cls) or ('#a19eb8' if self.theme == 'light' else '#77748f')

    def quality_color(self, q):
        if q is None:
            return self.P['text']
        c = QUALITY[self.theme][q] if 0 <= q < 7 else None
        return c or self.P['text']

    # ---- layout ----
    def build(self):
        r = self.root
        self.top = Surface(self, r, height=self.px(56))
        self.top.cv.pack(side='top', fill='x')
        self.sep = tk.Frame(r, height=1)
        self.sep.pack(side='top', fill='x')
        body = tk.Frame(r, bd=0, highlightthickness=0)
        body.pack(side='top', fill='both', expand=True)
        self.body = body
        self.nav = Surface(self, body, width=self.px(280), yscrollincrement=self.px(20))
        self.nav.cv.pack(side='left', fill='y')
        self.vline = tk.Frame(body, width=1)
        self.vline.pack(side='left', fill='y')
        self.main = Surface(self, body, yscrollincrement=self.px(20))
        self.main.cv.pack(side='left', fill='both', expand=True)
        self.search = tk.Entry(self.main.cv, relief='flat', bd=0, highlightthickness=1, font=self.F['base'])
        self.watch_entry = tk.Entry(self.main.cv, relief='flat', bd=0, highlightthickness=1, font=self.F['base'])
        self.loot_entry = tk.Entry(self.main.cv, relief='flat', bd=0, highlightthickness=1, font=self.F['base'])
        self.loot_entry.bind('<KeyRelease>', self.on_loot_search)
        self.main.cv.bind('<Button-1>', lambda e: self.close_item(), add='+')
        self.root.bind('<Escape>', lambda e: self.close_item(), add='+')
        self.search.bind('<KeyRelease>', self.on_search)
        self.watch_entry.bind('<KeyRelease>', self.on_watch_words)
        self.toast = tk.Label(r, font=self.F['small'], padx=self.px(14), pady=self.px(10), justify='left', anchor='w',
                              highlightthickness=1, wraplength=self.px(340))
        for s in (self.nav, self.main):
            s.cv.bind('<Enter>', lambda e, s=s: self.bind_wheel(s))
        self.main.cv.bind('<Configure>', self.on_resize)
        self.root.bind('<Prior>', lambda e: self.main.cv.yview_scroll(-1, 'pages'))
        self.root.bind('<Next>', lambda e: self.main.cv.yview_scroll(1, 'pages'))
        self.root.bind('<Home>', lambda e: self.main.cv.yview_moveto(0) if not isinstance(self.root.focus_get(), tk.Entry) else None)

    def bind_wheel(self, s):
        self._wheel_surface = s

        def wheel(e):
            # scroll the panel under the pointer (sidebar or page); else the one the pointer was last over
            cv = self._wheel_surface.cv
            try:
                w = self.root.winfo_containing(e.x_root, e.y_root)
                for cand in (self.nav, self.main):
                    if w is not None and (str(w) == str(cand.cv) or str(w).startswith(str(cand.cv) + '.')):
                        cv = cand.cv
                        break
            except (tk.TclError, KeyError):
                pass
            if e.num == 4:
                d = -1
            elif e.num == 5:
                d = 1
            else:
                d = -1 if e.delta > 0 else 1
                if abs(e.delta) >= 240:
                    d *= abs(e.delta) // 120
            cv.yview_scroll(d * 3, 'units')
        self.root.bind_all('<MouseWheel>', wheel)
        self.root.bind_all('<Button-4>', wheel)
        self.root.bind_all('<Button-5>', wheel)

    def on_resize(self, e):
        if abs(e.width - self.last_width) > 2:
            self.last_width = e.width
            self.queue_render(60)

    # ---- data ----


    # ---- events ----
    def pump(self):
        """Handles messages from the watcher thread."""
        try:
            while True:
                msg = self.w.q.get_nowait()
                kind = msg[0]
                if kind == 'missing':
                    if self.state != 'missing':
                        self.state = 'missing'
                        self.render()
                elif kind == 'found':
                    self.state = 'loading'
                    self.render()
                elif kind == 'progress':
                    self.state = 'loading' if self.state != 'ready' else 'ready'
                    self.progress = (msg[1], msg[2])
                    self.draw_progress()
                elif kind == 'loaded':
                    self.state = 'ready'
                    self.render()
                    with self.w.lock:
                        self.seen_watch = len(self.watch_matches())
                elif kind == 'changed':
                    self.on_changed(msg[1] if len(msg) > 1 else None)
                elif kind == 'chat':
                    self.check_watch()
                elif kind == 'error':
                    self.state = 'error'
                    self.error = msg[1]
                    self.log_error(msg[1])
                    self.render()
                elif kind == 'warn':
                    self.log_error(msg[1])
        except Exception as ex:  # queue.Empty
            if ex.__class__.__name__ != 'Empty':
                self.log_error(traceback.format_exc())
        self.root.after(150, self.pump)

    def uses_chat(self):
        """Views that show something from the chat log (loot, rolls, messages)."""
        return self.tab == 'chat' or self.view[0] in ('run', 'player', 'session', 'history')

    def on_changed(self, vers):
        """New lines arrived. A finished fight redraws soon; chat-only changes (trade spam, mostly) redraw only views
        that show chat, at most every couple of seconds, so the window stays free to keep up with the combat log."""
        prev = getattr(self, 'drawn_versions', None) or {}
        if vers is None or vers.get('fights') != prev.get('fights') or vers.get('addon') != prev.get('addon'):
            # summaries only change when a fight finishes, not on every line written during one
            self.queue_render(300)
            self.root.after(1500, self.auto_export)
        elif vers.get('chat') != prev.get('chat') and self.uses_chat():
            self.queue_render(2000)

    def tick_export(self):
        try:
            self.auto_export()
        except Exception:
            self.log_error(traceback.format_exc())
        self.root.after(60_000, self.tick_export)

    def tick(self):
        """Refreshes the 'updated 5s ago' text without redrawing the whole bar."""
        status, dot = self.status_text()
        if getattr(self, 'status_item', None) and dot == getattr(self, 'status_dot', None):
            self.top.cv.itemconfigure(self.status_item, text=status)
        else:
            self.draw_top()
        if ITEMS.ready and not self.items_seen:  # item colours and links arrive a moment after start
            self.items_seen = True
            self.render(keep_scroll=True)
        self._ticks = getattr(self, '_ticks', 0) + 1
        if self._ticks % 60 == 0:
            self.save_names()
        self.root.after(1000, self.tick)


    def who_color(self, name, default=None):
        """A player's name in their class colour, when we know their class."""
        cls = self.name_class.get(name)
        return self.class_color(cls) if cls else (default or self.P['text'])

    def queue_render(self, delay=200):
        if self.render_queued:
            return
        self.render_queued = True

        def go():
            self.render_queued = False
            self.render(keep_scroll=True)
        self.root.after(delay, go)

    def log_error(self, text):
        # the same problem repeating every second shouldn't fill the disk: log each one once an hour
        seen = self.__dict__.setdefault('_logged', {})
        now = time.time()
        if now - seen.get(text, 0) < 3600:
            return
        seen[text] = now
        try:
            path = os.path.join(self.data_dir, 'errors.log')
            if os.path.exists(path) and os.path.getsize(path) > 1_000_000:
                with open(path, encoding='utf-8', errors='replace') as fh:
                    keep = fh.read()[-200_000:]
                with open(path, 'w', encoding='utf-8') as fh:
                    fh.write(keep)
        except Exception:
            pass
        try:
            os.makedirs(self.data_dir, exist_ok=True)
            with open(os.path.join(self.data_dir, 'errors.log'), 'a', encoding='utf-8') as fh:
                fh.write(f'--- {datetime.now():%Y-%m-%d %H:%M:%S}\n{text}\n')
        except Exception:
            pass

    def set(self, attr, value, key=None):
        setattr(self, attr, value)
        if key:
            self.cfg.set(key, value)
        self.render()

    def go(self, kind, ident=None):
        self.menu_open = False
        self.view = (kind, ident)
        self.render()
        self.main.cv.yview_moveto(0)

    def toggle(self, key):
        if key in self.open:
            self.open.discard(key)
        else:
            self.open.add(key)
        self.render(keep_scroll=True)

    def show_toast(self, text):
        if self.narrow:  # bottom centre, as wide as the screen allows
            self.toast.configure(text=text, wraplength=max(self.px(200), self.root.winfo_width() - self.px(60)))
            self.toast.place(relx=.5, rely=1.0, y=-self.px(24), anchor='s')
        else:
            self.toast.configure(text=text, wraplength=self.px(340))
            self.toast.place(relx=1.0, rely=1.0, x=-self.px(20), y=-self.px(20), anchor='se')
        self.toast.lift()
        if getattr(self, '_toast_job', None):
            self.root.after_cancel(self._toast_job)
        self._toast_job = self.root.after(6000, self.toast.place_forget)
        self.last_toast = text
        if self.state_file:
            self.root.after_idle(self.write_state)

    def chime(self):
        try:
            import winsound
            winsound.PlaySound('SystemNotification', winsound.SND_ALIAS | winsound.SND_ASYNC)
        except Exception:
            self.root.bell()

    # ---- watch list ----


    def check_watch(self):
        with self.w.lock:
            matches = self.watch_matches()
        if self.seen_watch is None:
            self.seen_watch = len(matches)
            return
        if len(matches) > self.seen_watch:
            m = matches[-1]
            if time.time() * 1000 - m['ts'] < 120000:
                self.show_toast(f"{m['who']}: {m['text']}")
                if self.sound:
                    self.chime()
        self.seen_watch = len(matches)

    def on_search(self, e=None):
        q = self.search.get()
        if q != self.msg_q:
            self.msg_q = q
            self.msg_limit = 300
            self.queue_render(150)

    def on_loot_search(self, e=None):
        q = self.loot_entry.get()
        if q != self.loot_q_text:
            self.loot_q_text = q
            self.queue_render(150)

    def on_watch_words(self, e=None):
        words = [w.strip() for w in self.watch_entry.get().split(',') if w.strip()]
        if words != self.watch:
            self.watch = words
            self.cfg.set('watch', words)
            with self.w.lock:
                self.seen_watch = len(self.watch_matches())
            self.queue_render(200)

    # ==================================================================
    #  Rendering
    # ==================================================================

    def apply_layout(self):
        """Phone or narrow window: no sidebar (it becomes the ☰ menu). Wide window: sidebar back."""
        w = self.root.winfo_width()
        narrow = self.phone or (w > 50 and w < self.px(760))
        if narrow == self.narrow and getattr(self, '_layout_done', False):
            return
        self._layout_done = True
        self.narrow = narrow
        if narrow:
            self.nav.cv.pack_forget()
            self.vline.pack_forget()
        else:
            self.menu_open = False
            self.nav.cv.pack(side='left', fill='y', before=self.main.cv)
            self.vline.pack(side='left', fill='y', before=self.main.cv)

    def render(self, keep_scroll=False):
        self.apply_layout()
        self._buttons = []
        try:
            with self.w.lock:
                self.snapshot()
                self.drawn_versions = dict(getattr(self.w, 'versions', {}) or {})
                top = self.main.cv.canvasy(0) if keep_scroll else 0
                self.draw_top()
                self.draw_nav()
                self.draw_main()
            if keep_scroll:
                bbox = self.main.cv.bbox('all')
                total = max(1, bbox[3] + self.px(80)) if bbox else 1
                self.main.cv.yview_moveto(top / total)
        except Exception:
            tb = traceback.format_exc()
            self.log_error(tb)
            self.main.clear()
            P = self.P
            self.main.text(self.px(32), self.px(28), 'Something went wrong drawing this view.', self.F['h2'], P['wipe'])
            self.main.text(self.px(32), self.px(60), tb[-1500:], self.F['mono'], P['muted'], wrap=self.main.cv.winfo_width() - self.px(64))
        self.sep.configure(bg=self.P['line_soft'])
        self.vline.configure(bg=self.P['line_soft'])
        if self.state_file:
            self.root.after_idle(self.write_state)

    def write_state(self):
        """For the automated Windows test only (RAIDSCRIBE_STATE_FILE set): what's on screen, as JSON, with the
        screen position of every button so the test can click them like a person would."""
        try:
            def texts(s):
                cv = s.cv
                return [cv.itemcget(i, 'text') for i in cv.find_all() if cv.type(i) == 'text' and cv.itemcget(i, 'text').strip()]
            buttons = []
            for s, label, x, y, w, h in self._buttons:
                cv = s.cv
                sx = cv.winfo_rootx() + (x - cv.canvasx(0))
                sy = cv.winfo_rooty() + (y - cv.canvasy(0))
                visible = 0 <= y - cv.canvasy(0) and y + h - cv.canvasy(0) <= cv.winfo_height()
                buttons.append({'label': label, 'x': int(sx + w / 2), 'y': int(sy + h / 2), 'visible': visible})
            targets = []
            for where, s in (('top', self.top), ('nav', self.nav), ('main', self.main)):
                cv = s.cv
                for i in cv.find_all():
                    if cv.type(i) != 'text' or not cv.itemcget(i, 'text').strip():
                        continue
                    b = cv.bbox(i)
                    if not b:
                        continue
                    cy = (b[1] + b[3]) / 2 - cv.canvasy(0)
                    targets.append({'where': where, 'text': cv.itemcget(i, 'text'), 'x': int(cv.winfo_rootx() + (b[0] + b[2]) / 2 - cv.canvasx(0)),
                                    'y': int(cv.winfo_rooty() + cy), 'visible': 0 <= cy <= cv.winfo_height()})
            state = {'state': self.state, 'logs_dir': self.logs_dir, 'view': list(self.view) if isinstance(self.view, tuple) else self.view,
                     'tab': self.tab, 'title': self.root.title(), 'version': globals().get('APP_VERSION', 'dev'),
                     'items': ITEMS.count, 'notices': self.notices_file(), 'toast': getattr(self, 'last_toast', None), 'top': texts(self.top), 'nav': texts(self.nav),
                     'main': texts(self.main)[:400], 'buttons': buttons, 'targets': targets[:1500], 'time': time.time()}
            tmp = self.state_file + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as fh:
                json.dump(state, fh, default=str)
            os.replace(tmp, self.state_file)
        except Exception:
            self.log_error(traceback.format_exc())

    # ---- top bar ----
    def mark_image(self, want):
        """The Raidscribe mark at the stored size nearest `want` pixels (kept, so Tk doesn't drop it)."""
        size = min(MARK_PNG, key=lambda k: abs(k - want))
        cache = self.__dict__.setdefault('_marks', {})
        if size not in cache:
            try:
                cache[size] = tk.PhotoImage(master=self.root, data=MARK_PNG[size])
            except tk.TclError:
                cache[size] = None
        return cache[size]

    def draw_top(self):
        s, P, px = self.top, self.P, self.px
        s.clear()
        W = max(s.cv.winfo_width(), px(900) if not self.narrow else px(300))
        H = px(56)
        cx = px(20)
        cy = H // 2
        if self.narrow:
            return self.draw_top_narrow(s, W, H)
        # logo: the Raidscribe mark
        mark = self.mark_image(px(26))
        if mark is not None:
            s.cv.create_image(cx, cy, image=mark, anchor='w')
        x = cx + (mark.width() if mark is not None else 0) + px(10)
        s.text(x, cy, 'Raidscribe', self.F['brand'], P['text'], anchor='w')
        x += self.m('Raidscribe', 'brand') + px(18)
        self.seg(s, x, cy - px(17), [('combat', 'Combat'), ('chat', 'Chat')], self.tab, lambda k: self.set('tab', k, 'tab'), big=True, base=P['bg'])
        # theme button
        bx = W - px(20) - px(34)
        t = s.tag(self.toggle_theme)
        bg = s.rr(bx, cy - px(17), bx + px(34), cy + px(17), px(9), P['surface'], P['line'], tags=(t,))
        s.hover(t, bg, P['surface'], P['hover_surface'])
        self.draw_theme_icon(s, bx + px(17), cy, t)
        # status
        status, dot = self.status_text()
        sx = bx - px(16)
        self.status_item, self.status_dot = None, dot
        if status:
            # leave room for the longest status so the dot doesn't jump as the text changes
            tx = sx - self.m('Fight in progress · updated 59m ago', 'small')
            self.status_item = s.text(tx, cy, status, self.F['small'], P['muted'], anchor='w')
            self.dot(s, tx - px(12), cy, dot)

    def draw_top_narrow(self, s, W, H):
        """Phone top bar: menu button, Combat/Chat, a status dot and the theme switch."""
        P, px = self.P, self.px
        cy = H // 2
        x = px(10)
        t = s.tag(lambda: (setattr(self, 'menu_open', not self.menu_open), self.render(), self.main.cv.yview_moveto(0)))
        bg = s.rr(x, cy - px(18), x + px(40), cy + px(18), px(9), P['arcane_soft_bg'] if self.menu_open else P['surface'], P['line'], tags=(t,))
        for i in (-1, 0, 1):
            s.cv.create_line(x + px(12), cy + i * px(6), x + px(28), cy + i * px(6), fill=P['text'], width=max(1, px(2)), tags=(t,))
        x += px(52)
        self.seg(s, x, cy - px(17), [('combat', 'Combat'), ('chat', 'Chat')], self.tab, lambda k: (setattr(self, 'menu_open', False), self.set('tab', k, 'tab')),
                 big=True, base=P['bg'])
        bx = W - px(10) - px(40)
        t = s.tag(self.toggle_theme)
        s.rr(bx, cy - px(18), bx + px(40), cy + px(18), px(9), P['surface'], P['line'], tags=(t,))
        self.draw_theme_icon(s, bx + px(20), cy, t)
        status, dot = self.status_text()
        self.status_item, self.status_dot = None, dot
        self.dot(s, bx - px(14), cy, dot)

    def draw_theme_icon(self, s, x, y, tag):
        P, px = self.P, self.px
        c = P['muted']
        if self.theme == 'dark':  # sun: switch to light
            r = px(4)
            s.cv.create_oval(x - r, y - r, x + r, y + r, outline=c, width=max(1, px(1.6)), tags=(tag,))
            for i in range(8):
                a = i * math.pi / 4
                s.cv.create_line(x + math.cos(a) * px(6.5), y + math.sin(a) * px(6.5), x + math.cos(a) * px(8.5), y + math.sin(a) * px(8.5),
                                 fill=c, width=max(1, px(1.6)), capstyle='round', tags=(tag,))
        else:  # moon
            r = px(7)
            s.cv.create_oval(x - r, y - r, x + r, y + r, fill=c, outline='', tags=(tag,))
            s.cv.create_oval(x - r + px(5), y - r - px(3), x + r + px(5), y + r - px(3), fill=P['surface'], outline='', tags=(tag,))

    def toggle_theme(self):
        self.theme = 'light' if self.theme == 'dark' else 'dark'
        self.cfg.set('theme', self.theme)
        self.apply_theme()

    def waiting_for_first_log(self):
        """WoW is installed (its _anniversary_ folder is there) but hasn't saved a log yet, so there's no Logs folder."""
        return bool(self.logs_dir) and not self.phone and os.path.basename(os.path.normpath(self.logs_dir)).lower() == 'logs' \
            and os.path.isdir(os.path.dirname(os.path.normpath(self.logs_dir)))

    def status_text(self):
        if self.state == 'missing':
            if not self.logs_dir:
                return 'Choose your WoW folder', 'off'
            return ('Waiting for the first log' if self.waiting_for_first_log() else 'Logs folder not found'), 'off'
        if self.state in ('starting', 'loading'):
            return 'Reading logs…', 'on'
        if self.state == 'error':
            return 'Couldn’t read the logs', 'off'
        live = self.live if hasattr(self, 'live') else None
        bf = getattr(self.w, 'backfill', None)
        if bf:
            return f'Reading older logs in the background ({bf[0] + 1} of {bf[1]}) · live log already followed', 'live' if live else 'on'
        if live:
            return f'Fight in progress · updated {self.ago(self.w.last_read)}', 'live'
        last = max(self.w.last_read or 0, getattr(self.w, 'last_chat', 0) or 0)
        quiet = time.time() - (self.w.last_read or 0)
        if self.w.last_read and quiet > 120:
            # the combat log only grows while logging is on (the addon turns it off 10 minutes after you leave an instance)
            q = int(quiet // 60)
            idle = f'no combat logged for {q}m' if q < 60 else f'no combat logged for {q // 60}h {q % 60:02d}m'
            chat = getattr(self.w, 'last_chat', 0)
            return (f'Watching · chat updated {self.ago(chat)} · {idle}' if chat else f'Watching · {idle}'), 'on'
        return f'Watching Logs · updated {self.ago(last)}', 'on'

    @staticmethod
    def ago(t):
        if not t:
            return 'never'
        s = int(time.time() - t)
        if s < 5:
            return 'just now'
        if s < 60:
            return f'{s}s ago'
        if s < 3600:
            return f'{s // 60}m ago'
        return datetime.fromtimestamp(t).strftime('%I:%M %p').lstrip('0')

    def dot(self, s, x, y, kind, tags=()):
        P, px = self.P, self.px
        r = px(4)
        col = {'live': P['wipe'], 'on': P['kill']}.get(kind, P['faint'])
        if kind in ('live', 'on'):
            rr = px(7)
            s.cv.create_oval(x - rr, y - rr, x + rr, y + rr, fill=mix(col, P['bg'], .22), outline='', tags=tags)
        s.cv.create_oval(x - r, y - r, x + r, y + r, fill=col, outline='', tags=tags)

    # ---- shared widgets ----
    def seg(self, s, x, y, options, current, on_pick, big=False, base=None, maxw=None):
        """Segmented control. Returns its width. Too wide for maxw (a phone): wrapping chips instead."""
        P, px = self.P, self.px
        h = px(34) if big else px(30)
        font = 'semi' if big else 'smallsemi'
        padx = px(14) if big else px(11)
        widths = [self.m(label, font) + 2 * padx for _, label in options]
        total = sum(widths) + px(6) + px(2) * (len(options) - 1)
        self.seg_bottom = y + h
        if maxw is not None and total > maxw:
            self.chips(s, x, y, options, current, on_pick, base or P['surface'], right=x + maxw)
            self.seg_bottom = self.chips_bottom
            return maxw
        s.rr(x, y, x + total, y + h, px(10), P['surface2'])
        bx = x + px(3)
        for (key, label), w in zip(options, widths):
            sel = key == current
            t = s.tag(lambda k=key: on_pick(k))
            bg = s.rr(bx, y + px(3), bx + w, y + h - px(3), px(8), P['surface'] if sel else P['surface2'], tags=(t,))
            if not sel:
                s.hover(t, bg, P['surface2'], mix(P['text'], P['surface2'], .05))
            s.text(bx + w / 2, y + h / 2, label, self.F[font], P['text'] if sel else P['muted'], anchor='center', tags=(t,))
            bx += w + px(2)
        return total

    def header_seg(self, pg, y0, options, current, on_pick):
        """Tabs for a page: beside the title on a PC, on their own row under it on a phone."""
        px = self.px
        if self.narrow:
            self.chips(pg.s, pg.x, pg.y - px(4), options, current, on_pick, self.P['bg'], right=pg.x + pg.w)
            pg.y = self.chips_bottom + px(18)
            return
        w = sum(self.m(l, 'smallsemi') + 2 * px(11) for _, l in options) + px(6) + px(2) * (len(options) - 1)
        self.seg(pg.s, pg.x + pg.w - w, y0 + px(4), options, current, on_pick)

    def chips(self, s, x, y, options, current, on_pick, base, right=None, left=None):
        """A row of filter chips; with right= they wrap onto more lines (self.chips_bottom says where they ended)."""
        P, px = self.P, self.px
        h = px(24)
        x_start = left if left is not None else x
        for key, label in options:
            sel = key == current
            w = self.m(label, 'small') + px(20)
            if right is not None and x + w > right and x > x_start:
                x, y = x_start, y + h + px(6)
            t = s.tag(lambda k=key: on_pick(k))
            fill = mix(P['arcane'], base, .14) if sel else base
            bg = s.rr(x, y, x + w, y + h, h / 2, fill, '' if sel else P['line'], tags=(t,))
            if not sel:
                s.hover(t, bg, base, mix(P['text'], base, .05))
            s.text(x + w / 2, y + h / 2, label, self.F['small'], P['text'] if sel else P['muted'], anchor='center', tags=(t,))
            x += w + px(6)
        self.chips_bottom = y + h
        return x

    def chips_width(self, options):
        return sum(self.m(l, 'small') + self.px(26) for _, l in options)

    def button(self, s, x, y, label, fn, primary=False, small=False, anchor='nw'):
        P, px = self.P, self.px
        font = 'smallsemi' if small else 'semi'
        w = self.m(label, font) + (px(20) if small else px(28))
        h = px(28) if small else px(36)
        if anchor == 'ne':
            x -= w
        t = s.tag(fn)
        if self.state_file:
            self._buttons.append((s, label, x, y, w, h))
        fill = P['arcane'] if primary else P['surface']
        bg = s.rr(x, y, x + w, y + h, px(9), fill, '' if primary else P['line'], tags=(t,))
        s.hover(t, bg, fill, mix('#ffffff', fill, .12) if primary else P['hover_surface'])
        s.text(x + w / 2, y + h / 2, label, self.F[font], P['on_accent'] if primary else P['text'], anchor='center', tags=(t,))
        return w, h

    def badge(self, s, x, y, kind, label):
        P, px = self.P, self.px
        fg = {'kill': P['kill'], 'wipe': P['wipe'], 'live': P['wipe'], 'trash': P['muted']}[kind]
        bg = {'kill': mix(P['kill'], P['bg'], .16), 'wipe': mix(P['wipe'], P['bg'], .16), 'live': mix(P['wipe'], P['bg'], .16), 'trash': P['surface2']}[kind]
        extra = px(14) if kind == 'live' else 0
        w = self.m(label, 'smallsemi') + px(20) + extra
        h = px(24)
        s.rr(x, y, x + w, y + h, h / 2, bg)
        if kind == 'live':
            self.dot(s, x + px(13), y + h / 2, 'live')
        s.text(x + px(10) + extra, y + h / 2, label, self.F['smallsemi'], fg, anchor='w')
        return w


    def name_color(self, guid):
        p = self.players.get(guid)
        return self.class_color(p['cls']) if p and p.get('cls') else self.P['text']

    # ---- page frame for the main canvas ----
    class Page:
        def __init__(self, app):
            self.app = app
            self.s = app.main
            W = app.main.cv.winfo_width()
            if W < 50:
                W = app.px(1100)
            pad = app.px(14) if app.narrow else app.px(32)
            self.x = pad
            self.w = min(W - 2 * pad, app.px(1180))
            self.y = app.px(18) if app.narrow else app.px(28)

        def gap(self, n):
            self.y += self.app.px(n)

    def finish_main(self, pg):
        cv = self.main.cv
        cv.configure(scrollregion=(0, 0, cv.winfo_width(), pg.y + self.px(60)))

    def header(self, pg, title, badge=None, subs=(), crumb=None, title_color=None):
        s, P, px = pg.s, self.P, self.px
        if crumb:
            label, fn = crumb
            t = s.tag(fn)
            s.text(pg.x, pg.y, '‹ ' + label, self.F['small'], P['muted'], tags=(t,))
            pg.gap(24)
        tw = self.m(title, 'h1')
        room = pg.w - (px(90) if self.narrow else px(200))
        s.text(pg.x, pg.y, self.clip(title, 'h1', room), self.F['h1'], title_color or P['text'])
        if badge:
            self.badge(s, pg.x + min(tw, room) + px(12), pg.y + (self.line_h['h1'] - px(24)) / 2, *badge)
        pg.y += self.line_h['h1'] + px(6)
        x = pg.x
        for sub in subs:
            sw = self.m(sub, 'base')
            if x > pg.x and x + sw > pg.x + pg.w:  # wrap onto the next line on narrow screens
                x = pg.x
                pg.y += self.line_h['base'] + px(2)
            if x == pg.x and sw > pg.w:  # a sentence longer than the screen: wrap it, and start the next one on a new line
                i = s.text(x, pg.y, sub, self.F['base'], P['muted'], wrap=pg.w)
                pg.y = s.cv.bbox(i)[3] - self.line_h['base']
                x = pg.x + pg.w
                continue
            s.text(x, pg.y, sub, self.F['base'], P['muted'])
            x += sw + px(16)
        if subs:
            pg.y += self.line_h['base']
        pg.gap(16 if self.narrow else 22)

    def stats(self, pg, items):
        """items: (value, label, color, suffix)"""
        s, P, px = pg.s, self.P, self.px
        n = len(items)
        cols = n if pg.w / n >= px(150) else 2
        rows = (n + cols - 1) // cols
        cell_h = px(70)
        x0, y0 = pg.x, pg.y
        s.rr(x0, y0, x0 + pg.w, y0 + rows * cell_h, px(12), P['surface'], P['line_soft'])
        cw = pg.w / cols
        for c in range(1, cols):
            s.cv.create_line(x0 + c * cw, y0 + 1, x0 + c * cw, y0 + rows * cell_h - 1, fill=P['line_soft'])
        for r in range(1, rows):
            s.cv.create_line(x0 + 1, y0 + r * cell_h, x0 + pg.w - 1, y0 + r * cell_h, fill=P['line_soft'])
        for i, (value, label, color, suffix) in enumerate(items):
            r, c = divmod(i, cols)
            cx, cy = x0 + c * cw, y0 + r * cell_h
            s.text(cx + px(16), cy + px(13), value, self.F['stat'], color or P['text'])
            if suffix:
                s.text(cx + px(16) + self.m(value, 'stat'), cy + px(13), suffix, self.F['stat'], P['faint'])
            s.text(cx + px(16), cy + px(13) + self.line_h['stat'] + px(1), label, self.F['small'], P['muted'], maxw=cw - px(28))
        pg.y = y0 + rows * cell_h
        pg.gap(24)

    def panel(self, pg, title=None, right=None, body=None):
        """Draws a card: title row, then body(pg). right(x_right, y_mid) draws controls on the title row."""
        s, P, px = pg.s, self.P, self.px
        y0 = pg.y
        first = s.cv.create_line(0, 0, 0, 0, fill='')  # marker: the card goes below everything drawn after this
        pg.y += px(16)
        pad = px(12) if self.narrow else px(18)
        if title or right:
            row_h = px(30)
            if title:
                s.text(pg.x + pad, pg.y + row_h / 2, title, self.F['h2'], P['text'], anchor='w')
            if right:
                if self.narrow and title:
                    pg.y += row_h + px(4)  # no room beside the title on a phone: controls go underneath
                    self.right_left = pg.x + pad
                right(pg.x + pg.w - pad, pg.y, row_h)
                self.right_left = None
            pg.y += row_h + px(10)
        inner = Inner(pg, pad)
        body(inner)
        pg.y = inner.y + px(16)
        card = s.rr(pg.x, y0, pg.x + pg.w, pg.y, px(12), P['surface'], P['line_soft'])
        s.cv.tag_lower(card, first)
        pg.gap(22)

    def empty(self, pg, text, title=None):
        s, P, px = pg.s, self.P, self.px
        pg.gap(10)
        if title:
            s.text(pg.x, pg.y, title, self.F['h2'], P['text'])
            pg.y += self.line_h['h2'] + px(6)
        item = s.text(pg.x, pg.y, text, self.F['base'], P['muted'], wrap=min(pg.w, px(640)))
        bb = s.cv.bbox(item)
        pg.y = bb[3] + px(16) if bb else pg.y + px(30)

    # ==================================================================
    #  Sidebar
    # ==================================================================

    def draw_nav(self, menu_pg=None):
        """The sidebar; on a phone the same list is drawn full width as the ☰ menu (menu_pg)."""
        P, px = self.P, self.px
        if menu_pg is None:
            if self.narrow:
                return
            s = self.nav
            s.clear()
            W = px(280)
            y = px(14)
            self._nav_x0, self._nav_x1 = px(12), W - px(12)
        else:
            s = menu_pg.s
            W = menu_pg.x + menu_pg.w + px(12)
            y = menu_pg.y
            self._nav_x0, self._nav_x1 = menu_pg.x - px(8), menu_pg.x + menu_pg.w + px(8)
        if self.state not in ('ready',) and not getattr(self, 'fights', None):
            if menu_pg is None:
                s.cv.configure(scrollregion=(0, 0, 1, 1))
            return
        x0, x1 = self._nav_x0, self._nav_x1
        if self.tab == 'combat':
            # a session is one instance visit, from walking in to walking out
            y = self.nav_head(s, y, 'Sessions')
            opts = [('all', 'All'), ('raid', 'Raids'), ('dungeon', 'Dungeons'), ('pvp', 'PvP')]
            self.chips(s, x0 + px(8), y - px(2), opts, self.instance_filter, lambda k: self.set('instance_filter', k, 'instance_filter'), P['bg'])
            y += px(32)
            want = {'all': None, 'raid': ('raid',), 'dungeon': ('dungeon',), 'pvp': ('battleground', 'arena')}[self.instance_filter]
            runs = [r for r in reversed(self.runs) if want is None or r.get('kind') in want]
            if not runs:
                y = self.nav_day(s, y, 'None yet')
            for r in runs[:self.cfg.get('nav_runs', 12)]:
                sm, line = self.run_line(r)
                mark = 'kill' if sm['kills'] or sm.get('result') == 'win' else 'wipe' if sm['bosses'] or sm.get('result') == 'loss' else 'trash'
                v = self.view
                cur = v == ('run', r['id']) or (v[0] == 'player' and str(v[1]).split('|')[0] == r['id']) or \
                    (v[0] == 'fight' and v[1] in self.by_id and (self.run_of(self.by_id[v[1]]) or {}).get('id') == r['id'])
                y = self.nav_item(s, y, r['name'], line, cur, lambda i=r['id']: self.go('run', i), mark=mark)
            if len(runs) > self.cfg.get('nav_runs', 12):
                t = s.tag(lambda: (self.cfg.set('nav_runs', 1000), self.render()))
                s.text(x0 + px(12), y + px(4), f'Show all {len(runs)}', self.F['small'], P['arcane'], tags=(t,))
                y += px(26)
            y = self.nav_head(s, y + px(6), 'More')
            y = self.nav_item(s, y, 'History', 'Weeks, bosses, players, attendance, loot', self.view[0] in ('history', 'phist'), lambda: self.go('history'))
            y = self.nav_item(s, y, 'Settings', 'Logs folder, reports, theme, about', self.view[0] == 'settings', lambda: self.go('settings'))
        else:
            cp = self.cp
            y = self.nav_head(s, y, 'Chat log')
            items = [('loot', 'Loot', len(cp.loot) if cp else 0, 'items'), ('rolls', 'Rolls', len(cp.roll_sessions) if cp else 0, 'roll-offs'),
                     ('activity', 'Activity', len(self.activity_items()), 'events'),
                     ('watch', 'Watch list', len(self.watch_matches()), 'matches'), ('messages', 'All messages', len(cp.messages) if cp else 0, 'lines')]
            for k, label, n, unit in items:
                y = self.nav_item(s, y, label, f'{n:,} {unit}', self.chat_view == k,
                                  lambda k=k: (setattr(self, 'menu_open', False), self.set('chat_view', k, 'chat_view'), self.main.cv.yview_moveto(0)))
        if menu_pg is None:
            s.cv.configure(scrollregion=(0, 0, W, y + px(30)))
        else:
            menu_pg.y = y + px(20)

    def nav_head(self, s, y, label):
        s.text(self._nav_x0 + self.px(8), y + self.px(4), label, self.F['smallsemi'], self.P['muted'])
        return y + self.px(26)

    def nav_day(self, s, y, label):
        s.text(self._nav_x0 + self.px(10), y + self.px(6), label, self.F['small'], self.P['faint'])
        return y + self.px(26)

    def nav_item(self, s, y, title, sub, current, fn, dot=None, mark=None):
        P, px = self.P, self.px
        x0, x1 = self._nav_x0, self._nav_x1
        h = px(54) if self.phone else px(48)
        t = s.tag(fn)
        fill = P['arcane_soft_bg'] if current else P['bg']
        bg = s.rr(x0, y, x1, y + h, px(8), fill, tags=(t,))
        if not current:
            s.hover(t, bg, P['bg'], P['hover_bg'])
        tx = x0 + px(12)
        if dot:
            self.dot(s, tx + px(2), y + h / 2, dot, tags=(t,))
            tx += px(16)
        elif mark:
            mx, my, r = tx, y + h / 2 - px(4), px(8)
            if mark == 'trash':
                s.cv.create_rectangle(mx, my, mx + r, my + r, outline=P['faint'], width=max(1, px(1.5)), tags=(t,))
            else:
                s.rr(mx, my, mx + r, my + r, px(2), P['kill'] if mark == 'kill' else P['wipe'], tags=(t,))
            tx += px(18)
        maxw = x1 - tx - px(8)
        s.text(tx, y + px(7), title, self.F['semi'], P['text'], tags=(t,), maxw=maxw)
        s.text(tx, y + px(7) + self.line_h['semi'], sub, self.F['small'], P['muted'], tags=(t,), maxw=maxw)
        return y + h + px(2)

    # ==================================================================
    #  Main area
    # ==================================================================

    def draw_main(self):
        s = self.main
        s.clear()
        self.search.place_forget()
        self.watch_entry.place_forget()
        self.loot_entry.place_forget()
        pg = App.Page(self)
        if getattr(self, 'browse_dir', None):  # the phone's log-file browser sits over whatever page was open
            self.view_browse(pg, self.browse_dir)
            self.finish_main(pg)
            return
        if self.narrow and self.menu_open and self.state not in ('missing', 'error', 'starting', 'loading'):
            self.draw_nav(menu_pg=pg)  # the phone's ☰ menu: runs, History, Settings (or the chat pages)
            self.finish_main(pg)
            return
        if self.state == 'missing':
            self.view_missing(pg)
        elif self.state == 'error':
            self.view_error(pg)
        elif self.state in ('starting', 'loading'):
            self.view_loading(pg)
        elif self.tab == 'combat':
            kind, ident = self.view
            if kind == 'history':
                self.view_history(pg)
            elif kind == 'settings':
                self.view_settings(pg)
            elif kind == 'phist':
                self.view_player_history(pg, ident)
            elif kind == 'player' and str(ident).split('|')[0] in self.run_by_id:
                self.view_player(pg, ident)
            elif kind == 'run' and ident in self.run_by_id:
                self.view_run(pg, self.run_by_id[ident])
            elif kind == 'fight' and ident in self.by_id:
                self.view_fight(pg, self.by_id[ident])
            elif self.runs:
                self.view = ('run', self.runs[-1]['id'])  # nothing picked yet: the latest run
                self.view_run(pg, self.runs[-1])
            else:
                self.no_runs(pg)
        else:
            self.view_chat(pg)
        self.finish_main(pg)

    def draw_progress(self):
        if self.state != 'loading':
            return
        self.render()

    def view_loading(self, pg):
        s, P, px = pg.s, self.P, self.px
        label, pct = self.progress
        x, w = pg.x + max(0, (pg.w - px(560)) / 2), min(pg.w, px(560))
        pg.y = px(120)
        s.text(x, pg.y, 'Reading your logs', self.F['h1'], P['text'])
        pg.y += self.line_h['h1'] + px(16)
        s.rr(x, pg.y, x + w, pg.y + px(6), px(3), P['surface2'])
        if pct > 0:
            s.rr(x, pg.y, x + max(px(6), w * pct), pg.y + px(6), px(3), P['arcane'])
        pg.y += px(16)
        s.text(x, pg.y, label, self.F['base'], P['muted'])
        pg.y += px(40)
        s.text(x, pg.y, 'Older logs are saved after the first read, so this is quicker next time.', self.F['small'], P['faint'])
        pg.y += px(30)

    def no_runs(self, pg):
        """Nothing to show yet: what goes here, where Raidscribe is looking, and a way to point it somewhere else."""
        s, P, px = pg.s, self.P, self.px
        combat = [n for n in self.list_dir(self.logs_dir) if n.lower().startswith('wowcombatlog') and n.lower().endswith('.txt')]
        if combat:
            text = ('Raids, dungeons and PvP show up here once you run one with combat logging on: a summary of the whole run, '
                    'everyone\u2019s damage and healing, every boss and every pull. The logs here don\u2019t have an instance run in them yet.')
        else:
            text = 'No WoW combat logs (WoWCombatLog-….txt) in this folder yet' + (
                '. Copy them here from your PC\u2019s  World of Warcraft\\_anniversary_\\Logs  folder, or pick a log file wherever you saved it.'
                if self.phone else '. Turn on combat logging in game, or pick a log file somewhere else.')
        self.empty(pg, text, 'No runs yet')
        s.rr(pg.x, pg.y, pg.x + pg.w, pg.y + px(34), px(8), P['surface2'])
        s.text(pg.x + px(12), pg.y + px(17), self.logs_dir, self.F['mono'], P['text'], anchor='w', maxw=pg.w - px(24))
        pg.y += px(46)
        self.folder_buttons(s, pg.x, pg.y)
        pg.y += px(54)

    def folder_buttons(self, s, x, y, small=False):
        """Pick a log file… and, on a PC, Choose folder… side by side. Returns where the row ends."""
        w, _ = self.button(s, x, y, 'Pick a log file…', self.pick_logs_dir, primary=not small, small=small)
        x += w + self.px(8)
        if not self.phone:
            w, _ = self.button(s, x, y, 'Choose WoW folder…', self.pick_wow_folder, small=small)
            x += w + self.px(8)
        return x


    def view_missing(self, pg):
        s, P, px = pg.s, self.P, self.px
        x, w = pg.x + max(0, (pg.w - px(620)) / 2), min(pg.w, px(620))
        pg.y = px(90)
        if not self.logs_dir and not self.phone:
            # first start on a PC where WoW wasn't found: ask where it is
            mark = self.mark_image(px(56))
            if mark is not None:
                s.cv.create_image(x, pg.y, image=mark, anchor='nw')
                pg.y += mark.height() + px(18)
            i = s.text(x, pg.y, 'Where’s World of Warcraft?', self.F['h1'], P['text'], wrap=w)
            pg.y = s.cv.bbox(i)[3] + px(14)
            for t in ('Raidscribe reads the combat and chat logs WoW saves in  World of Warcraft\\_anniversary_\\Logs, '
                      'but it couldn’t find WoW on this PC.',
                      'Choose your World of Warcraft folder (or the Logs folder inside it), or pick one of your log files. '
                      'Raidscribe remembers it and reads every log in that folder, including new ones while you play.'):
                i = s.text(x, pg.y, t, self.F['base'], P['muted'], wrap=w)
                pg.y = s.cv.bbox(i)[3] + px(12)
            pg.y += px(6)
            w1, _ = self.button(s, x, pg.y, 'Choose WoW folder…', self.pick_wow_folder, primary=True)
            self.button(s, x + w1 + px(8), pg.y, 'Pick a log file…', self.pick_logs_dir)
            pg.y += px(54)
            return
        waiting = self.waiting_for_first_log()
        i = s.text(x, pg.y, 'Waiting for WoW’s first log' if waiting else 'Can’t find your Logs folder', self.F['h1'], P['text'], wrap=w)
        pg.y = s.cv.bbox(i)[3] + px(14)
        i = s.text(x, pg.y, 'Found World of Warcraft. Its logs will go in:' if waiting else 'Raidscribe is looking for:', self.F['base'], P['muted'])
        pg.y += self.line_h['base'] + px(6)
        s.rr(x, pg.y, x + w, pg.y + px(36), px(8), P['surface2'])
        s.text(x + px(12), pg.y + px(18), self.logs_dir, self.F['mono'], P['text'], anchor='w', maxw=w - px(24))
        pg.y += px(52)
        if self.phone:
            here = os.path.dirname(os.path.abspath(sys.argv[0])) if sys.argv and sys.argv[0] else ''
            steps = ['WoW writes its logs on your PC, in  World of Warcraft\\_anniversary_\\Logs. Copy the WoWCombatLog-….txt '
                     'and WoWChatLog.txt files from there to this phone.',
                     'Easiest: put them in the same folder as Raidscribe.pyw' + (f' ({here})' if here else '') + '. Raidscribe looks there by itself.',
                     'Or tap the button below and pick one of the log files wherever you saved it.']
            for t in steps:
                i = s.text(x, pg.y, t, self.F['base'], P['muted'], wrap=w)
                pg.y = s.cv.bbox(i)[3] + px(10)
        else:
            i = s.text(x, pg.y, 'WoW creates this folder the first time it saves a log. Type /combatlog in game (and /chatlog for chat), '
                       'pull something, and this window picks it up within a few seconds.', self.F['base'], P['muted'], wrap=w)
            pg.y = s.cv.bbox(i)[3] + px(14)
            i = s.text(x, pg.y, 'If WoW is installed somewhere else, choose its folder or pick one of its log files.', self.F['base'], P['muted'], wrap=w)
            pg.y = s.cv.bbox(i)[3] + px(14)
        self.folder_buttons(s, x, pg.y)
        pg.y += px(54)

    def view_error(self, pg):
        s, P, px = pg.s, self.P, self.px
        s.text(pg.x, pg.y, 'Couldn’t read the logs', self.F['h1'], P['text'])
        pg.y += self.line_h['h1'] + px(10)
        i = s.text(pg.x, pg.y, f'Details were saved to {os.path.join(self.data_dir, "errors.log")}. Send me that file and I can fix it.', self.F['base'], P['muted'], wrap=pg.w)
        pg.y = s.cv.bbox(i)[3] + px(14)
        i = s.text(pg.x, pg.y, (self.error or '')[-2000:], self.F['mono'], P['faint'], wrap=pg.w)
        pg.y = s.cv.bbox(i)[3] + px(14)

    # ---- one fight (opened from a run) ----
    def view_fight(self, pg, f):
        P, px = self.P, self.px
        run = self.run_of(f)
        crumb = (f"{run['name']}, {day(run['start'])}", lambda i=run['id']: self.go('run', i)) if run else None
        subs = [f"{day(f['start'])}, {clock(f['start'])}", dur(fight_dur(f))]
        attempt = self.attempt.get(f['id'], f.get('attempt'))
        if attempt:
            subs.append(f"Attempt {attempt}")
        if f.get('targets', 0) > 1:
            subs.append(f"{f['targets']} enemy types")
        self.header(pg, f['name'] or ('Trash' if f['kind'] == 'trash' else 'Boss'), self.fight_badge(f), subs, crumb)
        sec = fight_dur(f) / 1000
        dmg = sum(s['dmg'] for s in f['players'].values())
        heal = sum(s['heal'] for s in f['players'].values())
        ints = sum(s['interrupts'] for s in f['players'].values())
        nd = len(f['deaths'])
        self.stats(pg, [(fmt_int(dmg / sec), 'Raid DPS', None, None), (fmt_int(heal / sec), 'Raid HPS', None, None),
                        (str(nd), 'Deaths', P['wipe'] if nd else None, None), (str(ints), 'Interrupts', None, None)])
        tabs = [('damage', 'Damage'), ('healing', 'Healing'), ('taken', 'Damage taken'), ('deaths', f"Deaths ({nd})" if nd else 'Deaths'), ('utility', 'Utility')]

        def right(xr, y, h):
            pass

        def body(inner):
            self.seg(pg.s, inner.x, inner.y, tabs, self.meter_tab, lambda k: self.set('meter_tab', k, 'meter'), maxw=inner.w)
            inner.y = self.seg_bottom + px(14)
            if self.meter_tab == 'deaths':
                self.deaths_list(inner, f)
            elif self.meter_tab == 'utility':
                self.utility_table(inner, f)
            else:
                self.meter(inner, f, self.meter_tab, sec)
        self.panel(pg, None, None, body)
        self.fight_chat(pg, f)

    def meter(self, pg, f, tab, sec):
        s, P, px = pg.s, self.P, self.px
        key = {'damage': 'dmg', 'healing': 'heal', 'taken': 'taken'}[tab]
        by = {'damage': 'dmg_by', 'healing': 'heal_by', 'taken': 'taken_by'}[tab]
        rows = sorted(((g, st) for g, st in f['players'].items() if st[key] > 0), key=lambda kv: -kv[1][key])
        if not rows:
            msg = {'healing': 'No healing in this fight.', 'taken': 'Nobody took damage.'}.get(tab, 'No damage yet.')
            s.text(pg.x, pg.y + px(10), msg, self.F['base'], P['muted'])
            pg.y += px(40)
            return
        top = rows[0][1][key]
        total = sum(st[key] for _, st in rows)
        h = px(36)
        w = pg.w
        for i, (g, st) in enumerate(rows):
            pl = self.player(g)
            col = self.class_color(pl.get('cls'))
            okey = f"{f['id']}:{tab}:{g}"
            t = s.tag(lambda k=okey: self.toggle(k))
            y = pg.y
            hit = s.cv.create_rectangle(pg.x, y, pg.x + w, y + h, fill=P['surface'], outline='', tags=(t,))
            bw = max(px(6), w * st[key] / top)
            bar_fill = mix(col, P['surface'], P['bar'])
            bar = s.rr(pg.x, y, pg.x + bw, y + h, px(8), bar_fill, tags=(t,))
            s.hover(t, bar, bar_fill, mix(col, P['surface'], P['bar'] + .08))
            s.rr(pg.x, y + px(6), pg.x + px(3), y + h - px(6), px(2), col, tags=(t,))
            s.text(pg.x + px(26), y + h / 2, str(i + 1), self.F['tiny'], P['faint'], anchor='e', tags=(t,))
            pct_x = pg.x + w - px(10)
            if self.narrow:  # columns sized to what they hold, so names keep as much room as possible
                s.text(pct_x, y + h / 2, f"{100 * st[key] / total:.0f}%", self.F['small'], P['faint'], anchor='e', tags=(t,))
                ps_x = pct_x - self.m('100%', 'small') - px(10)
                v_x = ps_x - self.m('9,999/s', 'base') - px(10)
                v_w = self.m('999.9k', 'semi') + px(10)
            else:
                s.text(pct_x, y + h / 2, f"{100 * st[key] / total:.1f}%", self.F['small'], P['faint'], anchor='e', tags=(t,))
                ps_x = pct_x - px(62)
                v_x = ps_x - px(92)
                v_w = px(100)
            s.text(ps_x, y + h / 2, f"{fmt_int(st[key] / sec)}/s", self.F['base'], P['muted'], anchor='e', tags=(t,))
            s.text(v_x, y + h / 2, fmt(st[key]), self.F['semi'], P['text'], anchor='e', tags=(t,))
            name = pl['name']
            nx = pg.x + px(38)
            nmax = v_x - nx - v_w - px(30)
            s.text(nx, y + h / 2, name, self.F['semi'], col if pl.get('cls') else self.who_color(name), anchor='w', tags=(t,), maxw=nmax)
            mx = nx + min(self.m(name, 'semi'), nmax) + px(7)
            died = [d for d in f['deaths'] if d['guid'] == g]
            if died:
                s.text(mx, y + h / 2, '✕', self.F['smallsemi'], P['wipe'], anchor='w', tags=(t,))
                mx += self.m('✕', 'smallsemi') + px(6)
            is_open = okey in self.open
            s.text(mx, y + h / 2, '▾' if is_open else '▸', self.F['small'], P['faint'], anchor='w', tags=(t,))
            mx += self.m('▸', 'small') + px(8)
            if tab == 'healing' and st['heal'] and not self.narrow:
                oh = round(100 * st['overheal'] / (st['overheal'] + st['heal']))
                s.text(mx, y + h / 2, f'{oh}% overheal', self.F['small'], P['faint'], anchor='w', tags=(t,))
            pg.y += h + px(4)
            if is_open:
                self.breakdown(pg, st, by, key, col, f, tab)
                more = self.extras(st['cons'], st.get('cds') or {}, st.get('int_by') or {}, st.get('kicked') or {}, st['dispels'],
                                   st['taken'], st.get('taken_by') or {}, st['avoid'])
                pg.y = self.player_drop(s, pg.x + px(38), pg.y, pg.w - px(38), more, [self.death_row(d, f) for d in died], okey)
        pg.y += px(6)
        i = s.text(pg.x, pg.y, 'Click a player for their abilities, consumables, cooldowns and damage taken.', self.F['small'], P['faint'], wrap=pg.w)
        pg.y = s.cv.bbox(i)[3] + px(4)

    def breakdown(self, pg, st, by, key, col, f, tab):
        s, P, px = pg.s, self.P, self.px
        x0 = pg.x + px(38)
        w = pg.w - px(38)
        items = sorted(st[by].items(), key=lambda kv: -kv[1])[:10]
        top = items[0][1] if items else 1
        pg.gap(2)
        for name, v in items:
            s.text(x0, pg.y, name, self.F['small'], P['muted'], maxw=w - px(170))
            s.text(x0 + w - px(62), pg.y, fmt(v), self.F['small'], P['text'], anchor='ne')
            s.text(x0 + w - px(10), pg.y, f'{100 * v / max(1, st[key]):.0f}%', self.F['small'], P['faint'], anchor='ne')
            yb = pg.y + self.line_h['small'] + px(2)
            s.rr(x0, yb, x0 + max(px(4), (w - px(10)) * v / top), yb + px(4), px(2), mix(col, P['surface'], .7))
            pg.y = yb + px(9)
        if tab == 'healing' and self.narrow and st['heal']:  # the meter row has no room for it on a phone
            s.text(x0, pg.y, 'Overheal', self.F['small'], P['muted'])
            s.text(x0 + w - px(62), pg.y, f"{round(100 * st['overheal'] / (st['overheal'] + st['heal']))}%", self.F['small'], P['text'], anchor='ne')
            pg.y += self.line_h['small'] + px(6)
        if tab == 'damage':
            s.text(x0, pg.y, 'Active time', self.F['small'], P['muted'])
            s.text(x0 + w - px(62), pg.y, f"{min(100, round(100 * st['active'] / fight_dur(f)))}%", self.F['small'], P['text'], anchor='ne')
            pg.y += self.line_h['small'] + px(6)
        pg.gap(8)

    # ---- a player's drop-down (same sections as the phone): deaths, consumables, cooldowns, interrupts, damage taken
    def drop_flow(self, s, x0, y, w, pieces, line_font='base', gap=None):
        """Draws pieces left to right, wrapping at w. A piece is ('text', str, font, colour) or ('item', name, q, count).
        Returns the y below the last line."""
        px = self.px
        gap = px(10) if gap is None else gap
        lh = max(self.line_h['semi'], self.line_h[line_font]) + px(3)
        x = x0
        for piece in pieces:
            if piece[0] == 'item':
                _, name, q, n = piece
                need = self.m(f'[{name}]', 'semi') + (px(4) + self.m(f'×{n}', 'base') if n and n > 1 else 0)
            else:
                need = self.m(piece[1], piece[2])
            if x > x0 and x + need > x0 + w:
                x, y = x0, y + lh
            if piece[0] == 'item':
                self.item_link(s, x, y, name, q, maxw=w, count=n if n and n > 1 else None)
            else:
                s.text(x, y + (self.line_h['semi'] - self.line_h[piece[2]]) / 2, piece[1], self.F[piece[2]], piece[3], maxw=w)
            x += need + gap
        return y + lh

    def drop_recap(self, s, x, y, w, recap):
        """The last hits and heals before a death (rows from death_row): time, amount, ability, who, crit, overkill."""
        P, px = self.P, self.px
        for e in recap:
            s.text(x, y, e['ago'], self.F['small'], P['faint'])
            s.text(x + px(104), y, ('−' if e['dmg'] else '+') + e['amount'], self.F['small'], P['wipe'] if e['dmg'] else P['kill'], anchor='ne')
            tx = x + px(116)
            s.text(tx, y, e['spell'], self.F['small'], P['text'], maxw=w - px(120))
            tx += self.m(e['spell'], 'small') + px(8)
            extra = ' · '.join(b for b in (e.get('src'), 'crit' if e.get('crit') else '', f"{e['overkill']} overkill" if e.get('overkill') else '') if b)
            if extra and tx < x + w - px(40):
                s.text(tx, y, extra, self.F['small'], P['muted'], maxw=x + w - tx)
            y += self.line_h['small'] + px(3)
        return y + px(4)

    def player_drop(self, s, x0, y, w, x, deaths, key_base, full=None):
        """A player's drop-down under their meter row, the same as on the phone. full: (run id, guid) on a run's page,
        which adds 'Whole run, trash included', 'Open this fight' on each death and 'Full summary'. Returns the y below it."""
        P, px = self.P, self.px
        top = y
        pad = px(14)
        cx, cw = x0 + pad, w - pad
        sections = []
        if deaths:
            sections.append('deaths')
        if x['cons']:
            sections.append('cons')
        if x['cds']:
            sections.append('cds')
        if x['ints'] or x['dispels']:
            sections.append('ints')
        if x['taken']:
            sections.append('taken')
        if not sections and not full:
            return y   # on a fight's page the abilities above are enough
        y += px(2)
        if full:
            s.text(cx, y, 'Whole run, trash included', self.F['tiny'], P['faint'])
            y += self.line_h['tiny'] + px(4)

        def title(text, right=None):
            nonlocal y
            s.text(cx, y, text, self.F['smallsemi'], P['muted'])
            if right:
                s.text(cx + self.m(text, 'smallsemi') + px(8), y, right, self.F['small'], P['muted'])
            y += self.line_h['smallsemi'] + px(4)

        for n, sec in enumerate(sections):
            if n:
                s.cv.create_line(cx, y, cx + cw, y, fill=P['line_soft'])
                y += px(8)
            if sec == 'deaths':
                title(f'Deaths ({len(deaths)})' if len(deaths) > 1 else 'Death')
                for i, d in enumerate(deaths):
                    k = f'{key_base}:d:{i}'
                    is_open = k in self.open
                    t = s.tag(lambda k=k: self.toggle(k))
                    row_top = y
                    hit = s.cv.create_rectangle(cx - px(4), y - px(2), cx + cw, y, fill=P['surface'], outline='', tags=(t,))
                    s.text(cx, y, d['fight'], self.F['semi'], P['text'], tags=(t,), maxw=cw - px(160))
                    s.text(cx + min(self.m(d['fight'], 'semi'), cw - px(160)) + px(8), y + px(2), f"{d['at']} in · {d['clock']}", self.F['small'], P['faint'], tags=(t,))
                    if d.get('amount'):
                        s.text(cx + cw, y, d['amount'], self.F['semi'], P['wipe'], anchor='ne', tags=(t,))
                    y += self.line_h['semi'] + px(1)
                    what = d['spell'] + (f" from {d['killer']}" if d.get('killer') else '')
                    s.text(cx, y, what, self.F['base'], P['text'] if not d.get('killer') else P['muted'], tags=(t,), maxw=cw - px(30))
                    s.text(cx + min(self.m(what, 'base'), cw - px(30)) + px(8), y, '▾' if is_open else '▸', self.F['small'], P['faint'], tags=(t,))
                    y += self.line_h['base'] + px(6)
                    s.cv.coords(hit, cx - px(4), row_top - px(2), cx + cw, y - px(2))
                    s.hover(t, hit, P['surface'], P['hover_surface'])
                    if is_open:
                        y = self.drop_recap(s, cx + px(12), y, cw - px(12), d['recap'])
                        if full:
                            lt = s.tag(lambda fid=d['fight_id']: (setattr(self, 'meter_tab', 'deaths'), self.go('fight', fid)))
                            li = s.text(cx + px(12), y, 'Open this fight ›', self.F['smallsemi'], P['arcane'], tags=(lt,))
                            s.hover(lt, li, P['arcane'], mix('#ffffff', P['arcane'], .35) if self.theme == 'dark' else mix('#000000', P['arcane'], .25))
                            y += self.line_h['smallsemi'] + px(8)
            elif sec == 'cons':
                title('Consumables')
                y = self.drop_flow(s, cx, y, cw, [('item', c['name'], c['q'], c['n']) for c in x['cons']], gap=px(14)) + px(2)
            elif sec == 'cds':
                title('Cooldowns and utility')
                label_w = px(86)
                for kind, label in (('defensive', 'Defensive'), ('cooldown', 'Cooldowns'), ('utility', 'Utility')):
                    lst = [c for c in x['cds'] if c[2] == kind]
                    if not lst:
                        continue
                    s.text(cx, y + (self.line_h['semi'] - self.line_h['small']) / 2, label, self.F['small'], P['faint'])
                    pieces = []
                    for j, (name, cnt, _) in enumerate(lst):
                        pieces.append(('text', f'{name} ×{cnt}' + (' ·' if j < len(lst) - 1 else ''), 'base', P['text']))
                    y = self.drop_flow(s, cx + label_w, y, cw - label_w, pieces, gap=px(6))
                y += px(2)
            elif sec == 'ints':
                title('Interrupts' if x['ints'] else 'Dispels')
                if x['ints']:
                    pieces = [('text', str(x['ints']), 'semi', P['text']), ('text', 'with', 'small', P['faint'])]
                    for j, (k, v) in enumerate(x['int_by']):
                        pieces.append(('text', f'{k} ×{v}' + (',' if j < len(x['int_by']) - 1 else ''), 'base', P['text']))
                    y = self.drop_flow(s, cx, y, cw, pieces, gap=px(6))
                    if x['kicked']:
                        pieces = [('text', 'Stopped', 'small', P['faint'])] + [
                            ('text', f'{k} ×{v}' + (',' if j < len(x['kicked']) - 1 else ''), 'small', P['muted']) for j, (k, v) in enumerate(x['kicked'])]
                        y = self.drop_flow(s, cx, y, cw, pieces, line_font='small', gap=px(6))
                if x['dispels']:
                    y = self.drop_flow(s, cx, y, cw, [('text', 'Dispels', 'small', P['faint']), ('text', str(x['dispels']), 'semi', P['text'])], gap=px(6))
                y += px(2)
            elif sec == 'taken':
                title('Damage taken', x['taken'])
                for name, amount, share in x['taken_by']:
                    s.text(cx, y, name, self.F['small'], P['muted'], maxw=cw - px(150))
                    s.text(cx + cw - px(52), y, amount, self.F['small'], P['text'], anchor='ne')
                    s.text(cx + cw - px(4), y, f'{share}%', self.F['small'], P['faint'], anchor='ne')
                    yb = y + self.line_h['small'] + px(2)
                    s.rr(cx, yb, cx + max(px(4), (cw - px(4)) * max(2, share) / 100), yb + px(4), px(2), mix(P['wipe'], P['surface'], .55))
                    y = yb + px(9)
                if x.get('avoid'):
                    y = self.drop_flow(s, cx, y, cw, [('text', 'Avoidable', 'small', P['faint']), ('text', x['avoid'], 'semi', P['wipe'])], gap=px(6))
                y += px(2)
        if not sections:
            s.text(cx, y, 'Nothing else to show for this player.', self.F['small'], P['muted'])
            y += self.line_h['small'] + px(8)
        if full:
            rid, guid = full
            lt = s.tag(lambda: self.go('player', f'{rid}|{guid}'))
            li = s.text(cx, y, 'Full summary ›', self.F['smallsemi'], P['arcane'], tags=(lt,))
            s.hover(lt, li, P['arcane'], mix('#ffffff', P['arcane'], .35) if self.theme == 'dark' else mix('#000000', P['arcane'], .25))
            y += self.line_h['smallsemi'] + px(6)
        s.cv.create_line(x0 + px(1), top + px(2), x0 + px(1), y - px(2), fill=P['line'], width=max(1, px(2)))
        return y + px(8)

    def deaths_list(self, pg, f):
        s, P, px = pg.s, self.P, self.px
        if not f['deaths']:
            s.text(pg.x, pg.y + px(10), 'Nobody died.', self.F['base'], P['muted'])
            pg.y += px(40)
            return
        for i, d in enumerate(f['deaths']):
            if i:
                s.cv.create_line(pg.x, pg.y, pg.x + pg.w, pg.y, fill=P['line_soft'])
            key = f"{f['id']}:death:{d['guid']}:{d['ts']}"
            is_open = key in self.open
            t = s.tag(lambda k=key: self.toggle(k))
            y = pg.y + px(10)
            hit = s.cv.create_rectangle(pg.x, pg.y + 1, pg.x + pg.w, y + self.line_h['base'] + px(8), fill=P['surface'], outline='', tags=(t,))
            s.hover(t, hit, P['surface'], P['hover_surface'])
            s.text(pg.x, y, dur(d['ts'] - f['start']), self.F['small'], P['muted'], tags=(t,))
            x = pg.x + px(56)
            if self.narrow:  # name and amount, then what killed them on a second line
                s.text(x, y, d['name'], self.F['semi'], self.name_color(d['guid']), tags=(t,), maxw=pg.w - px(150))
                s.text(x + self.m(d['name'], 'semi') + px(6), y + px(2), '▾' if is_open else '▸', self.F['small'], P['faint'], tags=(t,))
                if d.get('amount'):
                    s.text(pg.x + pg.w, y, fmt_int(d['amount']), self.F['base'], P['wipe'], anchor='ne', tags=(t,))
                y2 = y + self.line_h['semi'] + px(2)
                what = (d.get('spell') or 'unknown') + (f" from {d['killer']}" if d.get('killer') else '')
                i2 = s.text(x, y2, what, self.F['small'], P['muted'], tags=(t,), wrap=pg.x + pg.w - x)
                bb = s.cv.bbox(i2)
                bottom = bb[3] if bb else y2 + self.line_h['small']
                s.cv.coords(hit, pg.x, pg.y + 1, pg.x + pg.w, bottom + px(8))
                pg.y = bottom + px(10)
            else:
                parts = [(d['name'], 'semi', self.name_color(d['guid'])), (' died to ', 'base', P['muted']), (d.get('spell') or 'unknown', 'base', P['text'])]
                if d.get('killer'):
                    parts.append((f" from {d['killer']}", 'base', P['muted']))
                parts.append(('  ▾' if is_open else '  ▸', 'small', P['faint']))
                for txt, font, color in parts:
                    s.text(x, y, txt, self.F[font], color, tags=(t,))
                    x += self.m(txt, font)
                if d.get('amount'):
                    s.text(pg.x + pg.w, y, fmt_int(d['amount']), self.F['base'], P['text'], anchor='ne', tags=(t,))
                pg.y = y + self.line_h['base'] + px(10)
            if is_open and self.narrow:
                self.recap_narrow(pg, d)
            elif is_open:
                for e in (d.get('recap') or [])[-10:]:
                    ex = pg.x + px(56)
                    s.text(ex, pg.y, f"-{(d['ts'] - e['ts']) / 1000:.1f}s", self.F['small'], P['faint'])
                    dmg = e['t'] == 'd'
                    s.text(ex + px(130), pg.y, ('−' if dmg else '+') + fmt_int(e['amount']), self.F['small'], P['wipe'] if dmg else P['kill'], anchor='ne')
                    tx = ex + px(146)
                    s.text(tx, pg.y, e.get('spell') or '', self.F['small'], P['text'])
                    tx += self.m(e.get('spell') or '', 'small') + px(6)
                    if e.get('src'):
                        s.text(tx, pg.y, e['src'], self.F['small'], P['muted'])
                        tx += self.m(e['src'], 'small') + px(6)
                    if e.get('crit'):
                        s.text(tx, pg.y, 'crit', self.F['small'], P['faint'])
                        tx += self.m('crit', 'small') + px(6)
                    if e.get('overkill'):
                        s.text(tx, pg.y, f"{fmt_int(e['overkill'])} overkill", self.F['small'], P['wipe'])
                    pg.y += self.line_h['small'] + px(3)
                pg.gap(8)

    def recap_narrow(self, pg, d):
        """The last hits before a death, two short lines each so they fit a phone."""
        s, P, px = pg.s, self.P, self.px
        ex = pg.x + px(56)
        for e in (d.get('recap') or [])[-10:]:
            dmg = e['t'] == 'd'
            s.text(ex, pg.y, f"-{(d['ts'] - e['ts']) / 1000:.1f}s", self.F['small'], P['faint'])
            ax = ex + self.m('-10.0s', 'small') + px(10)
            amt = ('−' if dmg else '+') + fmt_int(e['amount'])
            s.text(ax, pg.y, amt, self.F['smallsemi'], P['wipe'] if dmg else P['kill'])
            sx = ax + self.m(amt, 'smallsemi') + px(8)
            s.text(sx, pg.y, e.get('spell') or '', self.F['small'], P['text'], maxw=pg.x + pg.w - sx)
            extra = [x for x in (e.get('src'), 'crit' if e.get('crit') else '', f"{fmt_int(e['overkill'])} overkill" if e.get('overkill') else '') if x]
            pg.y += self.line_h['small'] + px(1)
            if extra:
                s.text(ax, pg.y, ' · '.join(extra), self.F['tiny'], P['muted'], maxw=pg.x + pg.w - ax)
                pg.y += self.line_h['tiny'] + px(1)
            pg.y += px(4)
        pg.gap(8)

    def table(self, pg, cols, rows, sort=None, row_fns=None, primary=None):
        """cols: (key, label, flexible, align[, short label]). rows: lists of (text, color, font[, on_click]).
        row_fns: one callable per row, run when the row is clicked (the row lights up on hover).
        Columns size to their contents; when space is tight, headings shorten, then flexible columns give way."""
        s, P, px = pg.s, self.P, self.px
        n = len(cols)
        arrow = self.m(' ↓', 'smallsemi')

        def natural(use_short, pad):
            out = []
            for i, c in enumerate(cols):
                label = (c[4] if use_short and len(c) > 4 else c[1])
                w = self.m(label, 'smallsemi') + (arrow if sort is not None and c[0] else 0)
                for row in rows:
                    txt, font = row[i][0], row[i][2]
                    w = max(w, self.m(txt, font))
                out.append(w + pad)
            return out

        short, pad = False, px(20)
        widths = natural(short, pad)
        if sum(widths) > pg.w:
            short = True
            widths = natural(short, pad)
        if sum(widths) > pg.w:
            pad = px(12)
            widths = natural(short, pad)
        flex = [i for i, c in enumerate(cols) if c[2]] or [0]
        over = sum(widths) - pg.w
        if self.narrow and over > 0 and sum(max(0, widths[i] - px(96)) for i in flex) < over:
            return self.table_cards(pg, cols, rows, row_fns, primary if primary is not None else flex[0])
        if over > 0:  # flexible columns (names, items) give way first, down to a readable minimum
            for i in flex:
                give = min(over, max(0, widths[i] - px(96)))
                widths[i] -= give
                over -= give
        if over > 0:  # still too wide: everything shrinks a little and long text gets an ellipsis
            k = pg.w / sum(widths)
            widths = [w * k for w in widths]
        elif sum(widths) < pg.w:
            extra = (pg.w - sum(widths)) / len(flex)
            for i in flex:
                widths[i] += extra
        hh = px(34)
        half = pad / 2
        x = pg.x
        for c, w in zip(cols, widths):
            key, align = c[0], c[3]
            label = c[4] if short and len(c) > 4 else c[1]
            active = sort is not None and key and sort[0] == key
            text = label + ((' ↓' if sort[1] < 0 else ' ↑') if active else '')
            tags = (s.tag(lambda k=key: self.sort_by(k)),) if sort is not None and key else ()
            color = P['text'] if active else P['muted']
            if align == 'e':
                s.text(x + w - half, pg.y + hh / 2, text, self.F['smallsemi'], color, anchor='e', tags=tags)
            else:
                s.text(x + half, pg.y + hh / 2, text, self.F['smallsemi'], color, anchor='w', tags=tags)
            x += w
        pg.y += hh
        s.cv.create_line(pg.x, pg.y, pg.x + pg.w, pg.y, fill=P['line'])
        rh = px(36)
        for r, row in enumerate(rows):
            x = pg.x
            rt = ()
            if row_fns and row_fns[r]:
                t = s.tag(row_fns[r])
                bg = s.cv.create_rectangle(pg.x, pg.y + 1, pg.x + pg.w, pg.y + rh - 1, fill=P['surface'], outline='', tags=(t,))
                s.hover(t, bg, P['surface'], P['hover_surface'])
                rt = (t,)
            for c, w, cell in zip(cols, widths, row):
                txt, color, font = cell[0], cell[1], cell[2]
                tags = (s.tag(cell[3]),) if len(cell) > 3 and cell[3] else rt
                if c[3] == 'e':
                    s.text(x + w - half, pg.y + rh / 2, txt, self.F[font], color, anchor='e', maxw=w - pad, tags=tags)
                else:
                    s.text(x + half, pg.y + rh / 2, txt, self.F[font], color, anchor='w', maxw=w - pad, tags=tags)
                x += w
            pg.y += rh
            if r < len(rows) - 1:
                s.cv.create_line(pg.x, pg.y, pg.x + pg.w, pg.y, fill=P['line_soft'])

    def table_cards(self, pg, cols, rows, row_fns, primary):
        """A table too wide for a phone: each row becomes a small card, its main cell on top and the rest as
        'Heading value' pairs underneath."""
        s, P, px = pg.s, self.P, self.px
        for r, row in enumerate(rows):
            y0 = pg.y
            rt = ()
            if row_fns and row_fns[r]:
                t = s.tag(row_fns[r])
                rt = (t,)
            bg = s.cv.create_rectangle(pg.x, y0, pg.x + pg.w, y0 + 1, fill=P['surface'], outline='', tags=rt)
            y = y0 + px(8)
            cell = row[primary]
            tags = (s.tag(cell[3]),) if len(cell) > 3 and cell[3] else rt
            s.text(pg.x, y, cell[0], self.F['semi'], cell[1], tags=tags, maxw=pg.w)
            y += self.line_h['semi'] + px(3)
            x = pg.x
            for i, (c, cell) in enumerate(zip(cols, row)):
                if i == primary or cell[0] in ('–', '') or not (c[4] if len(c) > 4 else c[1]):
                    continue
                label = (c[1] if len(c[1]) <= 12 else c[4] if len(c) > 4 else c[1])
                lw = self.m(label + ' ', 'small')
                vw = self.m(cell[0], 'small')
                if x > pg.x and x + lw + vw > pg.x + pg.w:
                    x = pg.x
                    y += self.line_h['small'] + px(3)
                vtags = (s.tag(cell[3]),) if len(cell) > 3 and cell[3] else rt
                s.text(x, y, label, self.F['small'], P['faint'], tags=rt)
                s.text(x + lw, y, cell[0], self.F['small'], cell[1] if cell[1] not in (P['faint'],) else P['muted'], tags=vtags, maxw=pg.x + pg.w - x - lw)
                x += lw + vw + px(14)
            y += self.line_h['small'] + px(8)
            s.cv.coords(bg, pg.x, y0, pg.x + pg.w, y)
            pg.y = y
            if r < len(rows) - 1:
                s.cv.create_line(pg.x, pg.y, pg.x + pg.w, pg.y, fill=P['line_soft'])

    def sort_by(self, key):
        self.sort = [key, -self.sort[1] if self.sort[0] == key else -1]
        self.cfg.set('sort', self.sort)
        self.render(keep_scroll=True)

    def utility_table(self, pg, f):
        P, px = self.P, self.px
        rows = sorted(f['players'].items(), key=lambda kv: (-(kv[1]['interrupts'] + kv[1]['dispels']), -kv[1]['avoid']))
        if not rows:
            pg.s.text(pg.x, pg.y + px(10), 'Nothing here yet.', self.F['base'], P['muted'])
            pg.y += px(40)
            return
        cols = [('', 'Player', False, 'w'), ('', 'Interrupts', False, 'e', 'Kicks'), ('', 'Dispels', False, 'e', 'Disp.'), ('', 'Consumables', True, 'w', 'Pots'), ('', 'Avoidable damage', False, 'e', 'Avoid')]
        out = []
        for g, st in rows:
            cons = ', '.join(f"{n}{' ×' + str(c) if c > 1 else ''}" for n, c in st['cons'].items())
            z = lambda v: P['text'] if v else P['faint']
            out.append([(self.player(g)['name'], self.name_color(g), 'semi'),
                        (str(st['interrupts']), z(st['interrupts']), 'base'),
                        (str(st['dispels']), z(st['dispels']), 'base'),
                        (cons or '–', z(cons), 'base'),
                        ((f"{fmt(st['avoid'])} ({st['avoid_hits']} hits)" if st['avoid'] else '–'), P['wipe'] if st['avoid'] else P['faint'], 'base')])
        self.table(pg, cols, out, primary=0)

    def fight_chat(self, pg, f):
        cp = self.cp
        if not cp:
            return
        P, px = self.P, self.px
        lo, hi = f['start'] - 5000, f['end'] + 5000
        msgs = [m for m in cp.messages if lo <= m['ts'] <= hi and m['ch'] in ('raid', 'raidwarning', 'party', 'yell', 'say')][-60:]
        loot = [l for l in cp.loot if f['kind'] == 'boss' and f['success'] and f['end'] <= l['ts'] <= f['end'] + 300000 and (l['item']['q'] is None or l['item']['q'] >= 3)]
        if loot:
            self.panel(pg, 'Loot', None, lambda inner: self.loot_table(inner, loot))
        if msgs:
            self.panel(pg, 'Chat during the fight', None, lambda inner: self.msg_rows(inner, msgs, since=f['start']))

    # ---- run summary ----
    def view_run(self, pg, r):
        """One instance visit, summed up: totals, everyone's damage and healing (click a player for their deaths,
        consumables, cooldowns and damage taken), boss by boss, every pull (click one for that fight), loot and records."""
        P, px = self.P, self.px
        bosses, known, fights = self.bosses_of(r)
        kills = [b for b in bosses if any(a['success'] for a in b['attempts']) and b['id'] not in HOLIDAY_ENCS]
        deaths = sum(len(f['deaths']) for f in fights)
        end = max([r['end']] + [f['end'] for f in fights])
        sm = self.model.run_summary_cached(r, self.scope_for(r))
        kind = r.get('kind', 'instance')
        pvp = kind in ('battleground', 'arena')
        subs = [KIND_LABEL.get(kind, 'Instance') + (f" · {sm['difficulty']}" if sm.get('difficulty') else ''),
                f"{day(r['start'])}, {clock(r['start'])} – {clock(end)}", f"{span(end - r['start'])} total"]
        badge = None
        if sm.get('result'):
            badge = ('kill', 'Win') if sm['result'] == 'win' else ('wipe', 'Loss')
        elif known and len(kills) >= known:
            badge = ('kill', 'Cleared')
        self.header(pg, r['name'], badge, subs)
        self.action_bar(pg, 'run', r)

        counted = sm['counted']
        sec = max(1, sum(fight_dur(f) for f in counted) / 1000)
        dmg = sum(p['dmg'] for p in sm['players'])
        heal = sum(p['heal'] for p in sm['players'])
        if pvp:
            stats = [(fmt(dmg), 'Damage done', None, None), (fmt(heal), 'Healing done', None, None),
                     (str(deaths), 'Deaths', P['wipe'] if deaths else None, None), (span(end - r['start']), 'Match length', None, None)]
        else:
            stats = [(str(len(kills)), 'Bosses killed', None, f'/{known}' if known else None),
                     (str(sm['wipes']), 'Wipes', P['wipe'] if sm['wipes'] else None, None),
                     (mins(sm['clear_time']) if sm['clear_time'] else mins(end - r['start']), 'Clear time' if sm['clear_time'] else 'Time inside', None, None),
                     (fmt_int(dmg / sec), 'Raid DPS' if kind == 'raid' else 'Group DPS', None, None),
                     (fmt_int(heal / sec), 'Raid HPS' if kind == 'raid' else 'Group HPS', None, None),
                     (str(deaths), 'Deaths', P['wipe'] if deaths else None, None)]
        self.stats(pg, stats)
        self.run_meters(pg, r, sm, kind, dmg, heal, fights)
        if not pvp and bosses:
            self.boss_panel(pg, bosses)
        self.run_pulls(pg, r, fights)
        self.run_loot(pg, r, fights, end, sm)
        if sm['records']:
            def recs(inner):
                for line in sm['records']:
                    inner.s.text(inner.x, inner.y, '🏆  ' + line, self.F['base'], P['text'])
                    inner.y += self.line_h['base'] + px(6)
            self.panel(pg, 'Records set', None, recs)

    def run_meters(self, pg, r, sm, kind, dmg_total, heal_total, fights):
        """Damage and healing side by side: every player with a bar, their total, per second and share. Click a
        player for their drop-down: deaths (and what killed them), consumables, cooldowns, interrupts, damage taken."""
        P, px = self.P, self.px
        scope = sm.get('scope', 'all')
        # the drop-downs cover the whole run, trash included (that's where people often die), like on the phone
        details = {}
        whole = self.model.run_summary_cached(r, 'all')
        for p in whole['players']:
            details[p['guid']] = self.extras(p['cons_by'], p.get('cds_by') or {}, p.get('int_by') or {}, p.get('kicked') or {}, p['dispels'],
                                             p['taken'], p.get('taken_by') or {}, p['avoid'] if kind == 'raid' else 0)
        died = {}
        for f in fights:
            for d in f['deaths']:
                died.setdefault(d['guid'], []).append(self.death_row(d, f))

        def right(xr, y, h):
            if kind not in ('raid', 'dungeon'):
                return
            opts = [('boss', 'Boss fights'), ('all', 'Everything')]
            w = sum(self.m(l, 'smallsemi') + 2 * px(11) for _, l in opts) + px(6) + px(2)
            self.seg(pg.s, xr - w, y, opts, self.run_scope, lambda k: self.set('run_scope', k, 'run_scope'))

        def column(inner, x, w, title, total, rows, key, rate):
            s = inner.s
            y = inner.y
            s.text(x, y, title, self.F['h2'], P['text'])
            s.text(x + w, y + px(3), f"{fmt(total)} total", self.F['base'], P['muted'], anchor='ne')
            y += self.line_h['h2'] + px(10)
            if not rows:
                s.text(x, y, 'None.', self.F['base'], P['faint'])
                return y + self.line_h['base']
            top = rows[0][key] or 1
            rh = px(30)
            for i, p in enumerate(rows):
                okey = f"pd:{title}:{p['guid']}"
                is_open = okey in self.open
                t = s.tag(lambda k=okey: self.toggle(k))
                col = self.class_color(p['cls']) if p.get('cls') else self.who_color(p['name'], P['muted'])
                hit = s.cv.create_rectangle(x, y, x + w, y + rh, fill=P['surface'], outline='', tags=(t,))
                s.hover(t, hit, P['surface'], P['hover_surface'])
                bar_x = x + px(24)
                s.rr(bar_x, y + px(2), bar_x + max(px(4), (w - px(24)) * p[key] / top), y + rh - px(2), px(6), mix(col, P['surface'], P['bar']), tags=(t,))
                s.text(x + px(16), y + rh / 2, str(i + 1), self.F['tiny'], P['faint'], anchor='e', tags=(t,))
                share = f"{100 * p[key] / max(1, total):.0f}%"
                s.text(x + w - px(6), y + rh / 2, share, self.F['small'], P['faint'], anchor='e', tags=(t,))
                rx = x + w - px(6) - px(40)
                s.text(rx, y + rh / 2, fmt_int(p[rate]), self.F['base'], P['muted'], anchor='e', tags=(t,))
                vx = rx - px(64)
                s.text(vx, y + rh / 2, fmt(p[key]), self.F['semi'], P['text'], anchor='e', tags=(t,))
                nmax = vx - bar_x - px(70) - px(34)
                s.text(bar_x + px(8), y + rh / 2, p['name'], self.F['semi'], col, anchor='w', tags=(t,), maxw=nmax)
                mx = bar_x + px(8) + min(self.m(p['name'], 'semi'), nmax) + px(7)
                deaths = died.get(p['guid'], [])
                if deaths:   # died at least once in this run
                    s.text(mx, y + rh / 2, '✕' if len(deaths) == 1 else f'✕{len(deaths)}', self.F['smallsemi'], P['wipe'], anchor='w', tags=(t,))
                    mx += self.m('✕' if len(deaths) == 1 else f'✕{len(deaths)}', 'smallsemi') + px(6)
                s.text(mx, y + rh / 2, '▾' if is_open else '▸', self.F['small'], P['faint'], anchor='w', tags=(t,))
                y += rh + px(3)
                if is_open:
                    x_ = details.get(p['guid']) or self.extras({}, {}, {}, {}, 0, 0, {}, 0)
                    y = self.player_drop(s, x + px(24), y + px(2), w - px(24), x_, deaths, okey, full=(r['id'], p['guid']))
            return y

        def body(inner):
            dmg = sorted([p for p in sm['players'] if p['dmg'] > 0], key=lambda p: -p['dmg'])
            heal = sorted([p for p in sm['players'] if p['heal'] > 0], key=lambda p: -p['heal'])
            # healing lists only real healing: a few points from a leech or a bandage doesn't make someone a healer
            heal = [p for p in heal if p['heal'] >= 0.02 * max(1, heal_total)] or heal
            if inner.w >= px(820):
                gap = px(28)
                cw = (inner.w - gap) / 2
                y1 = column(inner, inner.x, cw, 'Damage', dmg_total, dmg, 'dmg', 'dps')
                y2 = column(inner, inner.x + cw + gap, cw, 'Healing', heal_total, heal, 'heal', 'hps')
                inner.y = max(y1, y2)
            else:
                inner.y = column(inner, inner.x, inner.w, 'Damage', dmg_total, dmg, 'dmg', 'dps') + px(18)
                inner.y = column(inner, inner.x, inner.w, 'Healing', heal_total, heal, 'heal', 'hps')
            inner.y += px(12)
            note = (f"Per second is over the time each player was in the {'boss fights' if scope == 'boss' else 'fights'}. "
                    "Click a player for their deaths, consumables, cooldowns and damage taken.")
            i = inner.s.text(inner.x, inner.y, note, self.F['small'], P['faint'], wrap=inner.w)
            inner.y = inner.s.cv.bbox(i)[3]
        self.panel(pg, 'Damage and healing', right, body)

    def boss_panel(self, pg, bosses):
        """Each boss: every pull (click one for that fight), kill time, and who did the most on the kill."""
        P, px = self.P, self.px

        def legend(xr, y, h):
            if self.narrow:
                pg.s.text(self.right_left or xr, y + h / 2, 'Tap a box for that pull. Red: boss health left.', self.F['small'], P['muted'], anchor='w')
            else:
                pg.s.text(xr, y + h / 2, 'Each box is a pull: click it for that fight. Red ones show the boss health left.', self.F['small'], P['muted'], anchor='e')

        def body(inner):
            s = inner.s
            name_w = 0 if self.narrow else px(220)
            for i, b in enumerate(bosses):
                if i:
                    s.cv.create_line(inner.x, inner.y, inner.x + inner.w, inner.y, fill=P['line_soft'])
                pending = not b['attempts']
                inner.y += px(10)
                cy = inner.y + px(14)
                if self.narrow:  # name on its own line, the pulls underneath
                    s.text(inner.x, cy, b['name'], self.F['base' if pending else 'semi'], P['faint'] if pending else P['text'], anchor='w', maxw=inner.w - px(120))
                    cy += px(32)
                else:
                    s.text(inner.x, cy, b['name'], self.F['base' if pending else 'semi'], P['faint'] if pending else P['text'], anchor='w', maxw=name_w - px(12))
                x = inner.x + name_w
                pw, ph = px(46), px(28)
                if pending:
                    s.cv.create_rectangle(x, cy - ph / 2, x + pw, cy + ph / 2, outline=P['line'], dash=(3, 3), width=max(1, px(1.2)))
                kill = None
                for a in b['attempts']:
                    t = s.tag(lambda i=a['id']: self.go('fight', i))
                    if a['success']:
                        kill = a
                        bg = s.rr(x, cy - ph / 2, x + pw, cy + ph / 2, px(7), P['kill'], tags=(t,))
                        s.hover(t, bg, P['kill'], mix('#ffffff', P['kill'], .15))
                        s.text(x + pw / 2, cy, '✓', self.F['semi'], '#ffffff', anchor='center', tags=(t,))
                    else:
                        hp = a.get('boss_hp')
                        soft = mix(P['wipe'], P['surface'], .16)
                        bg = s.rr(x, cy - ph / 2, x + pw, cy + ph / 2, px(7), soft, tags=(t,))
                        s.hover(t, bg, soft, mix(P['wipe'], P['surface'], .26))
                        if hp is not None and hp > 0:
                            s.rr(x, cy - ph / 2, x + max(px(5), pw * hp), cy + ph / 2, px(7), mix(P['wipe'], P['surface'], .36), tags=(t,))
                        s.text(x + pw / 2, cy, f'{round(hp * 100)}%' if hp is not None else '✕', self.F['smallsemi'], P['wipe'], anchor='center', tags=(t,))
                    x += pw + px(6)
                    if x + pw > inner.x + inner.w - (px(4) if self.narrow else px(110)):
                        break
                wipes = sum(1 for a in b['attempts'] if not a['success'])
                right = (f"{dur(fight_dur(kill))} kill" + (f" · {plural(wipes, 'wipe')}" if wipes else '')) if kill else (f"{plural(wipes, 'wipe')}" if wipes else '')
                s.text(inner.x + inner.w, cy - (px(32) if self.narrow else 0), right, self.F['small'], P['muted'], anchor='e')
                inner.y = cy + ph / 2 + px(6)
                best = kill or (max(b['attempts'], key=fight_dur) if b['attempts'] else None)
                if best:
                    inner.y = self.top_line(inner, best, inner.x + name_w)
                inner.y += px(8)
        self.panel(pg, 'Boss by boss', legend, body)

    def top_line(self, inner, f, x0):
        """The best three on damage and healing in one fight, in class colours."""
        P, px = self.P, self.px
        s = inner.s
        sec = fight_dur(f) / 1000
        stats = list(f['players'].items())
        y = inner.y
        for label, key in (('Damage', 'dmg'), ('Healing', 'heal')):
            top = sorted([kv for kv in stats if kv[1][key] > 0], key=lambda kv: -kv[1][key])[:3]
            if not top:
                continue
            x = x0
            s.text(x, y, label, self.F['small'], P['faint'])
            x += px(60)
            for g, st in top:
                nm = self.player(g)['name']
                col = self.name_color(g) if self.player(g).get('cls') else self.who_color(nm, P['text'])
                v = fmt_int(st[key] / sec)
                need = self.m(nm, 'smallsemi') + px(5) + self.m(v, 'small')
                if x + need > inner.x + inner.w:
                    if not self.narrow:
                        break
                    x = x0 + px(60)
                    y += self.line_h['small'] + px(2)
                s.text(x, y, nm, self.F['smallsemi'], col)
                x += self.m(nm, 'smallsemi') + px(5)
                s.text(x, y, v, self.F['small'], P['muted'])
                x += self.m(v, 'small') + px(16)
            y += self.line_h['small'] + px(3)
        return y

    def run_deaths(self, pg, fights):
        """Every death in the run, pull by pull: who, when, and what killed them."""
        P, px = self.P, self.px
        pulls = [f for f in fights if f['deaths']]
        if not pulls:
            return
        total = sum(len(f['deaths']) for f in pulls)
        limit = 1000 if 'deaths:all' in self.open else 24

        def right(xr, y, h):
            pg.s.text(xr, y + h / 2, plural(total, 'death'), self.F['small'], P['muted'], anchor='e')

        def body(inner):
            s = inner.s
            shown = 0
            for f in pulls:
                if shown >= limit:
                    break
                t = s.tag(lambda i=f['id']: (setattr(self, 'meter_tab', 'deaths'), self.go('fight', i)))
                res = ('' if f['kind'] != 'boss' else ' · kill' if f['success'] else ' · wipe')
                s.text(inner.x, inner.y, f"{f['name'] or 'Trash'}{res}", self.F['smallsemi'], P['muted'], tags=(t,))
                s.text(inner.x + inner.w, inner.y, clock(f['start']), self.F['small'], P['faint'], anchor='ne')
                inner.y += self.line_h['smallsemi'] + px(4)
                for d in f['deaths']:
                    if shown >= limit:
                        break
                    shown += 1
                    x = inner.x + px(14)
                    s.text(x, inner.y, dur(d['ts'] - f['start']), self.F['small'], P['faint'], tags=(t,))
                    x += px(52)
                    pl = self.players.get(d['guid']) or {}
                    col = self.class_color(pl['cls']) if pl.get('cls') else self.who_color(d['name'])
                    s.text(x, inner.y, d['name'], self.F['semi'], col, tags=(t,))
                    what = (d.get('spell') or 'unknown') + (f" from {d['killer']}" if d.get('killer') else '')
                    if d.get('amount'):
                        s.text(inner.x + inner.w, inner.y, fmt_int(d['amount']), self.F['base'], P['wipe'], anchor='ne', tags=(t,))
                    if self.narrow:
                        inner.y += self.line_h['semi'] + px(1)
                        s.text(x, inner.y, what, self.F['small'], P['text'], tags=(t,), maxw=inner.x + inner.w - x)
                        inner.y += self.line_h['small'] + px(6)
                        continue
                    x += max(px(130), self.m(d['name'], 'semi') + px(12))
                    s.text(x, inner.y, what, self.F['base'], P['text'], tags=(t,), maxw=inner.x + inner.w - x - px(90))
                    inner.y += self.line_h['semi'] + px(4)
                inner.y += px(8)
            if total > shown:
                t = s.tag(lambda: self.toggle('deaths:all'))
                s.text(inner.x, inner.y, f'Show all {total}', self.F['small'], P['arcane'], tags=(t,))
                inner.y += self.line_h['small'] + px(4)
        self.panel(pg, 'Deaths', right, body)

    def run_utility(self, pg, r, sm, kind):
        """Interrupts, dispels, consumables, avoidable damage and damage taken, per player."""
        P, px = self.P, self.px
        rows = [p for p in sm['players'] if p['interrupts'] or p['dispels'] or p['cons'] or p['avoid'] or p['taken']]
        if not rows:
            return
        rows.sort(key=lambda p: (-(p['interrupts'] + p['dispels']), -p['cons'], p['name'].lower()))
        cols = [('', 'Player', False, 'w'), ('', 'Interrupts', False, 'e', 'Kicks'), ('', 'Dispels', False, 'e', 'Disp.'),
                ('', 'Consumables', True, 'w', 'Pots'), ('', 'Damage taken', False, 'e', 'Taken')]
        if kind == 'raid':
            cols.append(('', 'Avoidable damage', False, 'e', 'Avoid'))
        out, fns = [], []
        for p in rows:
            z = lambda v, txt=None: ((txt if txt is not None else str(v)), P['text'], 'base') if v else ('–', P['faint'], 'base')
            cons = ', '.join(f"{n}{' ×' + str(c) if c > 1 else ''}" for n, c in sorted(p['cons_by'].items(), key=lambda kv: -kv[1]))
            col = self.class_color(p['cls']) if p.get('cls') else self.who_color(p['name'])
            row = [(p['name'], col, 'semi'), z(p['interrupts']), z(p['dispels']), (cons or '–', P['text'] if cons else P['faint'], 'base'),
                   z(p['taken'], fmt(p['taken']))]
            if kind == 'raid':
                row.append((fmt(p['avoid']) if p['avoid'] else '–', P['wipe'] if p['avoid'] else P['faint'], 'base'))
            out.append(row)
            fns.append(lambda g=p['guid']: self.go('player', f"{r['id']}|{g}"))

        def body(inner):
            self.table(inner, cols, out, row_fns=fns, primary=0)
            if kind == 'raid':
                inner.y += px(10)
                i = inner.s.text(inner.x, inner.y, 'Avoidable damage counts raid mechanics you can move out of, like Flame Wreath, infernals and Cave In.',
                                 self.F['small'], P['faint'], wrap=inner.w)
                inner.y = inner.s.cv.bbox(i)[3]
        self.panel(pg, 'Utility', None, body)

    def run_pulls(self, pg, r, fights):
        """Every pull in the run, trash included. Click one to see that fight on its own."""
        P, px = self.P, self.px
        if not fights:
            return
        limit = 1000 if 'pulls:all' in self.open else 30

        def right(xr, y, h):
            pg.s.text(xr, y + h / 2, plural(len(fights), 'pull'), self.F['small'], P['muted'], anchor='e')

        def body(inner):
            cols = [('', 'Time', False, 'w'), ('', 'Fight', True, 'w'), ('', 'Result', False, 'w'), ('', 'Length', False, 'e'),
                    ('', 'Group DPS', False, 'e', 'DPS'), ('', 'Deaths', False, 'e', 'Died')]
            out, fns = [], []
            for f in fights[:limit]:
                sec = fight_dur(f) / 1000
                dps = sum(st['dmg'] for st in f['players'].values()) / sec
                if f['kind'] == 'boss':
                    res = ('Kill', P['kill'], 'semi') if f['success'] else ((f"Wipe {round(f['boss_hp'] * 100)}%" if f.get('boss_hp') is not None else 'Wipe'), P['wipe'], 'semi')
                else:
                    res = ('Trash', P['faint'], 'base')
                nd = len(f['deaths'])
                out.append([(clock(f['start']), P['muted'], 'base'), (f['name'] or 'Trash', P['text'], 'semi' if f['kind'] == 'boss' else 'base'), res,
                            (dur(fight_dur(f)), P['muted'], 'base'), (fmt_int(dps), P['text'], 'base'),
                            (str(nd) if nd else '–', P['wipe'] if nd else P['faint'], 'base')])
                fns.append(lambda i=f['id']: self.go('fight', i))
            self.table(inner, cols, out, row_fns=fns, primary=1)
            if len(fights) > limit:
                inner.y += px(8)
                t = inner.s.tag(lambda: self.toggle('pulls:all'))
                inner.s.text(inner.x, inner.y, f'Show all {len(fights)}', self.F['small'], P['arcane'], tags=(t,))
                inner.y += self.line_h['small'] + px(4)
        self.panel(pg, 'Fight by fight', right, body)

    def view_player(self, pg, ident):
        """One player's run: their totals and rank, every fight, abilities, deaths, consumables and loot."""
        P, px = self.P, self.px
        rid, _, guid = str(ident).partition('|')
        r = self.run_by_id[rid]
        ps = self.model.player_summary(r, guid, self.scope_for(r))
        crumb = (r['name'], lambda: self.go('run', rid))
        if not ps:
            self.header(pg, self.player(guid)['name'], None, [r['name']], crumb=crumb)
            return self.empty(pg, 'This player has no numbers in the fights counted here. Try “Everything” on the run page.')
        me = ps['player']
        cls = (ps.get('cls') or '').title()
        subs = [s for s in (cls, f"{r['name']} · {day(r['start'])}", 'Boss fights' if ps['scope'] == 'boss' else 'All fights') if s]
        self.header(pg, ps['name'], None, subs, crumb=crumb, title_color=self.class_color(ps['cls']) if ps.get('cls') else None)
        self.action_bar(pg, 'player', (r, guid))
        stats = []
        if me['dmg']:
            stats.append((fmt_int(me['dps']), 'DPS', None, f" #{ps['rank_dps']}/{ps['of_dps']}" if ps['rank_dps'] else None))
            stats.append((fmt(me['dmg']), 'Damage done', None, None))
        if me['heal']:
            stats.append((fmt_int(me['hps']), 'HPS', None, f" #{ps['rank_hps']}/{ps['of_hps']}" if ps['rank_hps'] else None))
            stats.append((fmt(me['heal']), 'Healing done', None, None))
        stats.append((str(me['deaths']), 'Deaths', P['wipe'] if me['deaths'] else None, None))
        if me['interrupts'] or me['dispels']:
            stats.append((f"{me['interrupts']} / {me['dispels']}", 'Interrupts / dispels', None, None))
        self.stats(pg, stats)

        def fights_body(inner):
            if not ps['fights']:
                inner.s.text(inner.x, inner.y + px(4), 'No fights.', self.F['base'], P['muted'])
                inner.y += px(30)
                return
            cols = [('', 'Fight', True, 'w'), ('', 'Result', False, 'w'), ('', 'Time', False, 'e'), ('', 'DPS', False, 'e'), ('', 'Damage', False, 'e', 'Dmg'),
                    ('', 'HPS', False, 'e'), ('', 'Healing', False, 'e', 'Heal'), ('', 'Died', False, 'e')]
            out, fns = [], []
            for row in ps['fights']:
                f = row['fight']
                if row['kind'] == 'boss':
                    res = ('Kill', P['kill'], 'semi') if row['success'] else (f"Wipe {round(row['boss_hp'] * 100)}%" if row.get('boss_hp') is not None else 'Wipe', P['wipe'], 'semi')
                else:
                    res = ('Trash', P['faint'], 'base')
                z = lambda v, txt: (txt, P['text'], 'base') if v else ('–', P['faint'], 'base')
                name = row['name'] + (f" #{row['attempt']}" if (row['attempt'] or 1) > 1 else '')
                out.append([(name, P['text'], 'semi' if row['kind'] == 'boss' else 'base'), res, (dur(row['time']), P['muted'], 'base'),
                            z(row['dmg'], fmt_int(row['dps'])), z(row['dmg'], fmt(row['dmg'])), z(row['heal'], fmt_int(row['hps'])), z(row['heal'], fmt(row['heal'])),
                            ('💀' if row['deaths'] else '–', P['wipe'] if row['deaths'] else P['faint'], 'base')])
                fns.append(lambda i=f['id']: self.go('fight', i))
            self.table(inner, cols, out, row_fns=fns)
        self.panel(pg, 'Fight by fight', None, fights_body)

        def bars(inner, items, col):
            total = sum(v for _, v in items) or 1
            top = items[0][1] if items else 1
            for name, v in items[:12]:
                inner.s.text(inner.x, inner.y, name, self.F['base'], P['text'], maxw=inner.w - px(170))
                inner.s.text(inner.x + inner.w - px(56), inner.y, fmt(v), self.F['base'], P['text'], anchor='ne')
                inner.s.text(inner.x + inner.w, inner.y, f'{100 * v / total:.0f}%', self.F['base'], P['muted'], anchor='ne')
                yb = inner.y + self.line_h['base'] + px(3)
                inner.s.rr(inner.x, yb, inner.x + max(px(4), (inner.w - px(70)) * v / top), yb + px(5), px(2), mix(col, P['surface'], .75))
                inner.y = yb + px(12)
        if ps['dmg_by']:
            self.panel(pg, 'Damage by ability', None, lambda inner: bars(inner, ps['dmg_by'], P['wipe']))
        if ps['heal_by']:
            self.panel(pg, 'Healing by ability', None, lambda inner: bars(inner, ps['heal_by'], P['kill']))
        if ps['deaths']:
            def deaths_body(inner):
                for d in ps['deaths']:
                    t = inner.s.tag(lambda i=d['fight_id']: self.go('fight', i))
                    if self.narrow:  # fight and time, then what killed them
                        when = f"{dur(d['at'])} in"
                        inner.s.text(inner.x + inner.w, inner.y, when, self.F['small'], P['muted'], anchor='ne', tags=(t,))
                        inner.s.text(inner.x, inner.y, d['fight'], self.F['semi'], P['text'], tags=(t,), maxw=inner.w - self.m(when, 'small') - px(10))
                        inner.y += self.line_h['semi'] + px(1)
                        i = inner.s.text(inner.x, inner.y, f"{d.get('spell') or 'Unknown'}" + (f" from {d['killer']}" if d.get('killer') else '') +
                                         (f" ({fmt(d['amount'])})" if d.get('amount') else ''), self.F['small'], P['wipe'], tags=(t,), wrap=inner.w)
                        inner.y = inner.s.cv.bbox(i)[3] + px(10)
                        continue
                    inner.s.text(inner.x, inner.y, d['fight'], self.F['semi'], P['text'], tags=(t,))
                    inner.s.text(inner.x + px(220), inner.y, f"{dur(d['at'])} in", self.F['base'], P['muted'], tags=(t,))
                    inner.s.text(inner.x + px(320), inner.y, f"{d.get('spell') or 'Unknown'}" + (f" from {d['killer']}" if d.get('killer') else '') +
                                 (f" ({fmt(d['amount'])})" if d.get('amount') else ''), self.F['base'], P['wipe'], tags=(t,), maxw=inner.w - px(320))
                    inner.y += self.line_h['semi'] + px(8)
            self.panel(pg, 'Deaths', None, deaths_body)
        if ps['cons_by'] or ps['loot']:
            def extra(inner):
                if ps['cons_by']:
                    inner.s.text(inner.x, inner.y, 'Consumables', self.F['smallsemi'], P['muted'])
                    inner.y += self.line_h['smallsemi'] + px(6)
                    for k, v in ps['cons_by']:
                        self.item_link(inner.s, inner.x, inner.y, k, font='base', maxw=inner.w - px(50))
                        inner.s.text(inner.x + inner.w, inner.y, f'×{v}', self.F['base'], P['muted'], anchor='ne')
                        inner.y += self.line_h['base'] + px(5)
                    inner.y += px(8)
                if ps['loot']:
                    inner.s.text(inner.x, inner.y, 'Loot', self.F['smallsemi'], P['muted'])
                    inner.y += self.line_h['smallsemi'] + px(6)
                    for l in ps['loot']:
                        self.item_link(inner.s, inner.x, inner.y, l['name'], l['q'], maxw=inner.w - self.m(clock(l['ts']), 'base') - px(14))
                        inner.s.text(inner.x + inner.w, inner.y, clock(l['ts']), self.F['base'], P['muted'], anchor='ne')
                        inner.y += self.line_h['semi'] + px(5)
            self.panel(pg, 'Consumables and loot', None, extra)


    def run_loot(self, pg, r, fights, end, sm=None):
        loot = (sm or self.model.run_summary_cached(r))['loot']
        if not loot:
            return
        kills = [f for f in fights if f['kind'] == 'boss' and f['success']]

        def source(ts):
            k = [f for f in kills if f['end'] <= ts and ts - f['end'] < 600000]
            return k[-1]['name'] if k else ''

        def right(xr, y, h):
            pg.s.text(xr, y + h / 2, f"{len(loot)} item{'s' if len(loot) > 1 else ''}", self.F['small'], self.P['muted'], anchor='e')
        self.panel(pg, 'Loot', right, lambda inner: self.loot_table(inner, loot, source))

    def loot_table(self, pg, loot, source=None):
        P, px = self.P, self.px
        if self.narrow:
            return self.loot_list_narrow(pg, loot, source)
        cols = [('', 'Time', False, 'w'), ('', 'Item', True, 'w'), ('', 'Looted by', False, 'w')]
        if source:
            cols.append(('', 'From', True, 'w'))
        rows = []
        for l in loot:
            name = l['item']['name'] if 'item' in l else l['name']
            q = l['item']['q'] if 'item' in l else l.get('q')
            item = f"[{name}]" + (f" ×{l['count']}" if l['count'] > 1 else '')
            row = [(clock(l['ts']), P['muted'], 'base'), (item, self.quality_color(ITEMS.quality(name, q)), 'semi', lambda n=name: self.show_item(n)),
                   (l['who'], self.who_color(l['who']), 'semi')]
            if source:
                row.append((source(l['ts']), P['muted'], 'base'))
            rows.append(row)
        self.table(pg, cols, rows)

    def loot_list_narrow(self, pg, loot, source=None):
        """Loot on a phone: the item on its own line (tap for the tooltip), then when, who and where from."""
        s, P, px = pg.s, self.P, self.px
        for i, l in enumerate(loot):
            if i:
                s.cv.create_line(pg.x, pg.y, pg.x + pg.w, pg.y, fill=P['line_soft'])
            y = pg.y + px(8)
            name = l['item']['name'] if 'item' in l else l['name']
            q = l['item']['q'] if 'item' in l else l.get('q')
            self.item_link(s, pg.x, y, name, q, font='semi', maxw=pg.w - px(40), count=l.get('count'))
            y += self.line_h['semi'] + px(3)
            x = pg.x
            s.text(x, y, clock(l['ts']), self.F['small'], P['faint'])
            x += self.m(clock(l['ts']), 'small') + px(10)
            s.text(x, y, l['who'], self.F['smallsemi'], self.who_color(l['who']), maxw=pg.x + pg.w - x)
            x += self.m(l['who'], 'smallsemi') + px(10)
            src = source(l['ts']) if source else ''
            if src and x < pg.x + pg.w - px(60):
                s.text(x, y, src, self.F['small'], P['muted'], maxw=pg.x + pg.w - x)
            pg.y = y + self.line_h['small'] + px(8)

    # ---- chat ----
    def view_chat(self, pg):
        cp = self.cp
        if not cp:
            return self.empty(pg, 'Type /chatlog in game to start saving chat (the Raidscribe AutoLog addon keeps it on for you). '
                                  'WoW writes it to WoWChatLog.txt in the same Logs folder and it shows up here automatically.', 'No chat log yet')
        {'rolls': self.chat_rolls, 'watch': self.chat_watch, 'messages': self.chat_messages, 'activity': self.chat_activity}.get(self.chat_view, self.chat_loot)(pg, cp)


    def chat_activity(self, pg, cp):
        P, px = self.P, self.px
        self.header(pg, 'Activity', None, ['Honor, reputation, experience, quests and resets, from your chat log'])
        items = self.activity_items()
        if not items:
            return self.empty(pg, 'Nothing yet. Honor, reputation and quest lines show up here as you play with chat logging on.')
        honor = sum(e['amount'] for e in getattr(cp, 'honor', []))
        xp = sum(e['amount'] for e in getattr(cp, 'xp', []))
        quests = sum(1 for e in getattr(cp, 'quests', []) if e.get('done'))
        rep = {}
        for e in getattr(cp, 'reputation', []):
            rep[e['faction']] = rep.get(e['faction'], 0) + (e['amount'] if e.get('up', True) else -e['amount'])
        top = sorted(rep.items(), key=lambda kv: -kv[1])
        stats = [(f'{honor:,}', 'Honor in this log', P['warn'] if honor else None, None), (f'{quests:,}', 'Quests completed', None, None)]
        if xp:
            stats.append((fmt(xp), 'Experience', None, None))
        if top:
            stats.append((f'+{top[0][1]:,}', top[0][0], P['kill'], None))
        self.stats(pg, stats)
        groups = []
        for it in items[::-1][:600]:
            if not groups or groups[-1][0] != day_key(it[0]):
                groups.append((day_key(it[0]), it[0], []))
            groups[-1][2].append(it)
        tone = {'warn': P['warn'], 'kill': P['kill'], 'wipe': P['wipe']}
        for _, ts, rows in groups:
            def body(inner, rows=rows):
                for i, (t, kind, text, color) in enumerate(rows):
                    if i:
                        inner.s.cv.create_line(inner.x, inner.y, inner.x + inner.w, inner.y, fill=P['line_soft'])
                    y = inner.y + px(6)
                    if self.narrow:  # time and kind, then the line itself at full width
                        inner.s.text(inner.x, y, clock(t), self.F['small'], P['faint'])
                        inner.s.text(inner.x + self.m('12:00 PM', 'small') + px(10), y, kind, self.F['small'], P['muted'])
                        y += self.line_h['small'] + px(1)
                        it = inner.s.text(inner.x, y, text, self.F['base'], tone.get(color, P['text']), wrap=inner.w)
                        inner.y = inner.s.cv.bbox(it)[3] + px(6)
                        continue
                    inner.s.text(inner.x, y, clock(t), self.F['small'], P['faint'])
                    inner.s.text(inner.x + px(80), y, kind, self.F['small'], P['muted'])
                    inner.s.text(inner.x + px(190), y, text, self.F['base'], tone.get(color, P['text']), maxw=inner.w - px(190))
                    inner.y = y + self.line_h['base'] + px(6)
            self.panel(pg, day(ts), None, body)

    def chat_loot(self, pg, cp):
        P, px = self.P, self.px
        q = self.loot_q
        y0 = pg.y
        self.header(pg, 'Loot', None, ['Everything you and your group looted, newest first. Click an item for its tooltip.'])
        opts = [(4, 'Epic'), (3, 'Rare+'), (2, 'Uncommon+'), (0, 'All')]
        self.header_seg(pg, y0, opts, q, lambda k: self.set('loot_q', k, 'loot_q'))
        qual = lambda l: ITEMS.quality(l['item']['name'], l['item']['q'])
        gold_in = sum(m['copper'] for m in cp.money)
        epics = sum(1 for l in cp.loot if (qual(l) or 0) >= 4)
        rares = sum(1 for l in cp.loot if (qual(l) or 0) == 3)
        self.stats(pg, [(gold(gold_in) if gold_in else '–', 'Gold looted in this log', P['warn'] if gold_in else None, None),
                        (str(epics), 'Epics', self.quality_color(4) if epics else None, None), (str(rares), 'Rares', self.quality_color(3) if rares else None, None),
                        (str(len(cp.loot)), 'Items in total', None, None)])
        # search box and who filter
        pg.s.text(pg.x, pg.y, 'Search items or players', self.F['small'], P['muted'])
        pg.y += self.line_h['small'] + px(6)
        sw = pg.w if self.narrow else min(px(360), pg.w)
        self.place_entry(self.loot_entry, pg, pg.x, pg.y, sw, self.loot_q_text)
        who_opts = [('all', 'Everyone'), ('me', 'Just me'), ('won', 'Rolled for')]
        if self.narrow:  # the filter goes under the search box
            pg.y += px(34) + px(10)
            self.chips(pg.s, pg.x, pg.y, who_opts, self.loot_who, lambda k: self.set('loot_who', k, 'loot_who'), P['bg'], right=pg.x + pg.w)
            pg.y = self.chips_bottom + px(18)
        else:
            self.chips(pg.s, pg.x + sw + px(14), pg.y + px(5), who_opts, self.loot_who, lambda k: self.set('loot_who', k, 'loot_who'), P['bg'])
            pg.y += px(34) + px(18)
        text = self.loot_q_text.strip().lower()
        rolls = {}
        for sess in cp.roll_sessions:
            if sess.get('item'):
                for rr in sess['rolls']:
                    rolls[(sess['item']['name'], rr['who'])] = rr
        loot = []
        for l in reversed(cp.loot):
            lq = qual(l)
            if q and lq is not None and lq < q:
                continue
            if self.loot_who == 'me' and l['who'] != 'You':
                continue
            if self.loot_who == 'won' and not l.get('won'):
                continue
            if text and text not in l['item']['name'].lower() and text not in self.model.name_of(l['who'], l['ts']).lower():
                continue
            loot.append(l)
            if len(loot) >= 500:
                break
        if not loot:
            return self.empty(pg, 'Nothing matches.' if text or self.loot_who != 'all' else 'No loot at this quality yet.')
        groups = []
        for l in loot:
            if not groups or groups[-1][0] != day_key(l['ts']):
                groups.append((day_key(l['ts']), l['ts'], []))
            groups[-1][2].append(l)
        for _, ts, items in groups:
            def body(inner, items=items):
                for i, l in enumerate(items):
                    if i:
                        inner.s.cv.create_line(inner.x, inner.y, inner.x + inner.w, inner.y, fill=P['line_soft'])
                    y = inner.y + px(9)
                    if self.narrow:
                        self.loot_row_narrow(inner, l, y, rolls)
                        continue
                    inner.s.text(inner.x, y, clock(l['ts']), self.F['base'], P['faint'])
                    x = inner.x + px(84)
                    x += self.item_link(inner.s, x, y, l['item']['name'], l['item']['q'], maxw=inner.w - px(420), count=l['count'])
                    who = self.model.name_of(l['who'], l['ts'])
                    wx = inner.x + inner.w - px(150)
                    t = inner.s.tag(lambda n=who: (self.loot_entry.delete(0, 'end'), self.loot_entry.insert(0, n), self.on_loot_search()))
                    inner.s.text(wx, y, who, self.F['semi'], self.who_color(who), tags=(t,), maxw=px(150))
                    roll = l.get('roll') or (rolls.get((l['item']['name'], who)) if l.get('won') else None)
                    note = (f"won · {roll['type']} {roll['val']}" if roll.get('type') else f"won · rolled {roll['val']}") if roll else 'won the roll' if l.get('won') else ''
                    where = self.where_was(l['ts'])
                    side = ' · '.join(x for x in (where, note) if x)
                    if side:
                        inner.s.text(wx - px(16), y, side, self.F['small'], P['muted'], anchor='ne', maxw=max(px(40), wx - px(16) - x - px(20)))
                    inner.y = y + self.line_h['semi'] + px(9)
            self.panel(pg, day(ts), None, body)

    def loot_row_narrow(self, inner, l, y, rolls):
        """A chat Loot row on a phone: the item, then time · who (tap to search them) · where · roll."""
        s, P, px = inner.s, self.P, self.px
        self.item_link(s, inner.x, y, l['item']['name'], l['item']['q'], maxw=inner.w - px(40), count=l['count'])
        y += self.line_h['semi'] + px(2)
        x = inner.x
        s.text(x, y, clock(l['ts']), self.F['small'], P['faint'])
        x += self.m(clock(l['ts']), 'small') + px(10)
        who = self.model.name_of(l['who'], l['ts'])
        t = s.tag(lambda n=who: (self.loot_entry.delete(0, 'end'), self.loot_entry.insert(0, n), self.on_loot_search()))
        s.text(x, y - px(1), who, self.F['smallsemi'], self.who_color(who), tags=(t,), maxw=inner.x + inner.w - x)
        x += self.m(who, 'smallsemi') + px(10)
        roll = l.get('roll') or (rolls.get((l['item']['name'], who)) if l.get('won') else None)
        note = (f"won · {roll['type']} {roll['val']}" if roll.get('type') else f"won · rolled {roll['val']}") if roll else 'won the roll' if l.get('won') else ''
        side = ' · '.join(v for v in (self.where_was(l['ts']), note) if v)
        if side and x < inner.x + inner.w - px(40):
            s.text(x, y, side, self.F['small'], P['muted'], maxw=inner.x + inner.w - x)
        inner.y = y + self.line_h['small'] + px(9)


    def chat_rolls(self, pg, cp):
        P, px = self.P, self.px
        self.header(pg, 'Rolls', None, ['Need/Greed rolls and /roll roll-offs, with the winner worked out. Re-rolls don’t count.'])
        sessions = cp.roll_sessions[::-1][:200]
        if not sessions:
            return self.empty(pg, 'No rolls in the chat log yet. They show up when someone types /roll.')
        won = [l for l in cp.loot if l.get('won')]

        def winner_fn(sess):
            # for Need/Greed the game says who won (it settles ties itself); /roll roll-offs are worked out here
            if sess.get('kind') == 'group' and sess.get('item'):
                got = next((l for l in won if l['item']['name'] == sess['item']['name'] and -5000 <= l['ts'] - sess['end'] <= 180_000), None)
                if got:
                    who = self.model.name_of(got['who'], got['ts'])
                    return next((r for r in sess['rolls'] if r['who'] == who), None) or {'who': who, 'val': None}
            return roll_winner(sess)

        def body(inner):
            for i, sess in enumerate(sessions):
                if i:
                    inner.s.cv.create_line(inner.x, inner.y, inner.x + inner.w, inner.y, fill=P['line_soft'])
                y = inner.y + px(12)
                w = winner_fn(sess)
                tie = w is not None and w.get('val') is not None and any(not r.get('again') and r['val'] == w['val'] and r['who'] != w['who'] for r in sess['rolls'])
                if self.narrow:  # item, then winner and when, then the rolls wrapping at full width
                    if sess.get('item'):
                        self.item_link(inner.s, inner.x, y, sess['item']['name'], sess['item']['q'], maxw=inner.w)
                    else:
                        inner.s.text(inner.x, y, f"Roll 1–{sess['hi']}", self.F['semi'], P['text'])
                    y += self.line_h['semi'] + px(2)
                    when = f"{day(sess['start'])}, {clock(sess['start'])}"
                    inner.s.text(inner.x + inner.w, y, when, self.F['small'], P['faint'], anchor='ne')
                    if w:
                        x = inner.x
                        inner.s.text(x, y - px(1), w['who'], self.F['smallsemi'], self.who_color(w['who']), maxw=inner.w - self.m(when, 'small') - px(70))
                        x += min(self.m(w['who'], 'smallsemi'), inner.w - self.m(when, 'small') - px(70))
                        inner.s.text(x, y, ' wins' + (' · tie' if tie else ''), self.F['small'], P['wipe'] if tie else P['muted'])
                    y += self.line_h['small'] + px(8)
                    right_edge = inner.x + inner.w
                else:
                    right_edge = inner.x + inner.w - px(160)
                    if sess.get('item'):
                        self.item_link(inner.s, inner.x, y, sess['item']['name'], sess['item']['q'], maxw=inner.w - px(220))
                    else:
                        inner.s.text(inner.x, y, f"Roll 1–{sess['hi']}", self.F['semi'], P['text'])
                    if w:
                        txt = ' wins' + ('  · tie' if tie else '')
                        tx = inner.x + inner.w - self.m(txt, 'semi')
                        inner.s.text(inner.x + inner.w, y, txt, self.F['semi'], P['wipe'] if tie else P['muted'], anchor='ne')
                        inner.s.text(tx, y, w['who'], self.F['semi'], self.who_color(w['who']), anchor='ne')
                    inner.s.text(inner.x + inner.w, y + self.line_h['semi'], f"{day(sess['start'])}, {clock(sess['start'])}", self.F['small'], P['faint'], anchor='ne')
                    y += self.line_h['semi'] + px(8)
                x = inner.x
                for r in sorted(sess['rolls'], key=lambda r: -r['val']):
                    label = f"{r['who']} {r['val']}" + (f" {r['type']}" if r.get('type') else '')
                    tw = self.m(label, 'small') + px(16)
                    if x > inner.x and x + tw > right_edge:
                        x = inner.x
                        y += px(28)
                    win = r is w
                    bg = mix(P['kill'], P['surface'], .16) if win else P['surface2']
                    inner.s.rr(x, y, x + tw, y + px(22), px(6), bg)
                    inner.s.text(x + tw / 2, y + px(11), label, self.F['smallsemi' if win else 'small'],
                                 P['kill'] if win else P['faint'] if r.get('again') else mix(self.who_color(r['who'], P['muted']), P['surface2'], .8), anchor='center')
                    if r.get('again'):
                        inner.s.cv.create_line(x + px(6), y + px(11), x + tw - px(6), y + px(11), fill=P['faint'])
                    x += tw + px(6)
                inner.y = y + px(22) + px(12)
        self.panel(pg, None, None, body)

    def place_entry(self, entry, pg, x, y, w, value):
        px = self.px
        if entry.get() != value and self.root.focus_get() is not entry:
            entry.delete(0, 'end')
            entry.insert(0, value)
        pg.s.cv.create_window(x, y, window=entry, anchor='nw', width=w, height=px(34))

    def chat_watch(self, pg, cp):
        P, px = self.P, self.px
        self.header(pg, 'Watch list', None, ['Messages that mention any of your words. New ones pop up while you play.'])
        s = pg.s
        s.text(pg.x, pg.y, 'Words to watch for, separated by commas', self.F['small'], P['muted'])
        pg.y += self.line_h['small'] + px(6)
        ew = pg.w if self.narrow else pg.w - px(170)
        self.place_entry(self.watch_entry, pg, pg.x, pg.y, ew, ', '.join(self.watch))
        # sound toggle (under the box on a phone)
        if self.narrow:
            pg.y += px(34) + px(10)
            tx = pg.x
        else:
            tx = pg.x + ew + px(20)
        t = s.tag(lambda: self.set('sound', not self.sound, 'sound'))
        tw, th = px(36), px(20)
        ty = pg.y + px(7)
        on = self.sound
        s.rr(tx, ty, tx + tw, ty + th, th / 2, P['arcane'] if on else P['surface2'], '' if on else P['line'], tags=(t,))
        kx = tx + tw - th / 2 if on else tx + th / 2
        s.cv.create_oval(kx - px(7), ty + th / 2 - px(7), kx + px(7), ty + th / 2 + px(7), fill='#ffffff', outline='' if on else P['line'], tags=(t,))
        s.text(tx + tw + px(10), ty + th / 2, 'Sound', self.F['base'], P['text'], anchor='w', tags=(t,))
        pg.y += px(34) + px(20)
        words = self.watch_words()
        matches = self.watch_matches()[::-1][:300]
        if not words:
            return self.empty(pg, 'Add a word or two above to start watching.')
        if not matches:
            return self.empty(pg, 'Nothing yet for those words.')
        self.panel(pg, None, None, lambda inner: self.msg_rows(inner, matches, words=words))

    def chat_messages(self, pg, cp):
        P, px = self.P, self.px
        self.header(pg, 'All messages')
        pg.y -= px(10)
        pg.s.text(pg.x, pg.y, 'Search names or words', self.F['small'], P['muted'])
        pg.y += self.line_h['small'] + px(6)
        sw = min(px(360), pg.w)
        if self.narrow and self.msg_q.strip():  # leave room for "Clear search" beside the box
            sw = pg.w - self.m('Clear search', 'small') - px(24)
        self.place_entry(self.search, pg, pg.x, pg.y, sw, self.msg_q)
        s = pg.s
        opts = [('all', 'All'), ('social', 'No Trade/LFG'), ('raid', 'Raid'), ('party', 'Party'), ('guild', 'Guild'), ('whisper', 'Whispers'), ('channel', 'Trade & LFG'), ('say', 'Say & yell'), ('system', 'System')]
        top = pg.y
        pg.y += px(34) + px(12)
        self.chips(s, pg.x, pg.y, opts, self.msg_ch, lambda k: (setattr(self, 'msg_limit', 300), self.set('msg_ch', k)), P['bg'], right=pg.x + pg.w)
        pg.y = self.chips_bottom + px(18)
        if self.msg_q.strip():
            t = s.tag(lambda: self.filter_messages(''))
            s.text(pg.x + sw + px(14), top + px(17), 'Clear search', self.F['small'], P['arcane'], anchor='w', tags=(t,))
        q = self.msg_q.strip().lower()
        ch = self.msg_ch
        match_ch = lambda m: (ch == 'all' or m['ch'] == ch or (ch == 'raid' and m['ch'] == 'raidwarning') or (ch == 'say' and m['ch'] == 'yell')
                              or (ch == 'party' and m['ch'] == 'instance') or (ch == 'social' and m['ch'] not in ('channel', 'system')))
        out = []
        for m in reversed(cp.messages):
            if match_ch(m) and (not q or q in m['text'].lower() or q in m['who'].lower()):
                out.append(m)
                if len(out) >= self.msg_limit:
                    break
        if not out:
            return self.empty(pg, 'No messages match.')

        def body(inner):
            self.msg_rows(inner, out, words=[q] if q else None, days=True)
            if len(out) >= self.msg_limit:
                inner.y += px(10)
                self.button(inner.s, inner.x, inner.y, 'Show more', lambda: (setattr(self, 'msg_limit', self.msg_limit + 300), self.render(keep_scroll=True)), small=True)
                inner.y += px(28)
        self.panel(pg, None, None, body)

    def msg_rows(self, pg, msgs, since=None, words=None, days=False):
        s, P, px = pg.s, self.P, self.px
        chan = CHANNEL[self.theme]
        last_day = None
        time_w, pill_w = px(68), px(96)
        if self.narrow:
            time_w = (self.m('0:00:00', 'small') if since else self.m('12:00 PM', 'small')) + px(10)
        text_x = pg.x + time_w + pill_w + px(12)
        wrap = pg.x + pg.w - text_x
        for i, m in enumerate(msgs):
            if days:
                dk = day_key(m['ts'])
                if dk != last_day:
                    if i:
                        pg.y += px(10)
                    s.text(pg.x, pg.y, day(m['ts']), self.F['smallsemi'], P['muted'])
                    s.cv.create_line(pg.x + self.m(day(m['ts']), 'smallsemi') + px(10), pg.y + self.line_h['smallsemi'] / 2, pg.x + pg.w,
                                     pg.y + self.line_h['smallsemi'] / 2, fill=P['line_soft'])
                    pg.y += self.line_h['smallsemi'] + px(6)
                    last_day = dk
                elif i:
                    s.cv.create_line(pg.x if self.narrow else text_x, pg.y, pg.x + pg.w, pg.y, fill=P['line_soft'])
            elif i:
                s.cv.create_line(pg.x, pg.y, pg.x + pg.w, pg.y, fill=P['line_soft'])
            y = pg.y + px(7)
            s.text(pg.x, y + px(1), dur(m['ts'] - since) if since else clock(m['ts']), self.F['small'], P['faint'])
            # the channel as a small coloured tag
            if m['ch'] == 'whisper':
                label = 'To' if m.get('out') else 'Whisper'
            else:
                name = m.get('ch_name') or ''
                label = CHANNEL_SHORT.get(name) or name.split(' - ')[0]
            ccol = chan.get(m['ch'], P['muted'])
            label = self.clip(label, 'smallsemi', pill_w - px(16))
            lw = self.m(label, 'smallsemi') + px(14)
            px0 = pg.x + time_w
            s.rr(px0, y, px0 + lw, y + self.line_h['smallsemi'] + px(3), px(5), mix(ccol, P['surface'], .14))
            s.text(px0 + px(7), y + px(1), label, self.F['smallsemi'], ccol)
            # message text: tinted for the channels you're talking in, plain for public channels
            tint = m['ch'] in ('whisper', 'party', 'raid', 'raidwarning', 'guild', 'officer', 'instance', 'yell')
            tcol = mix(ccol, P['text'], .55) if tint else (P['muted'] if m['ch'] == 'system' else P['text'])
            who = m.get('who') or ''
            if self.narrow:
                # phone: time, channel and name on one line, the message underneath at full width
                if who:
                    nx = px0 + lw + px(8)
                    t = s.tag(lambda n=who: self.filter_messages(n))
                    s.text(nx, y, who, self.F['semi'], self.who_color(who, P['text']), tags=(t,), maxw=pg.x + pg.w - nx)
                ty = y + max(self.line_h['semi'], self.line_h['smallsemi'] + px(3)) + px(3)
                if '[' in m['text']:
                    bottom = self.flow(s, pg.x, ty, pg.w, m, '', tcol, words)
                else:
                    item = s.text(pg.x, ty, m['text'], self.F['base'], tcol, wrap=pg.w)
                    if words:
                        self.mark_words(s, item, pg.x, ty, pg.w, m, words)
                    bb = s.cv.bbox(item)
                    bottom = bb[3] if bb else ty + self.line_h['base']
            elif '[' in m['text']:
                bottom = self.flow(s, text_x, y, wrap, m, who, tcol, words)
            elif who:
                # fast path: the message as one wrapped text item, the name drawn over its indented start
                item = s.text(text_x, y, self.indent(who + ': ', m['text']), self.F['base'], tcol, wrap=wrap)
                t = s.tag(lambda n=who: self.filter_messages(n))
                s.text(text_x, y, who + ':', self.F['semi'], self.who_color(who, P['text']), tags=(t,))
                if words:
                    self.mark_words(s, item, text_x, y, wrap, m, words)
                bb = s.cv.bbox(item)
                bottom = bb[3] if bb else y + self.line_h['base']
            else:
                item = s.text(text_x, y, m['text'], self.F['base'], tcol, wrap=wrap)
                if words:
                    self.mark_words(s, item, text_x, y, wrap, m, words)
                bb = s.cv.bbox(item)
                bottom = bb[3] if bb else y + self.line_h['base']
            pg.y = bottom + px(7)

    def flow(self, s, x0, y, width, m, who, tcol, words=None):
        """Lays out "Name: message" word by word, so the name can be class-coloured and clickable and
        [Item Name]s in the text become item links. Returns the bottom of the last line."""
        P, px = self.P, self.px
        lh = self.line_h['base'] + px(2)
        x, line_top = x0, y
        space = self.m(' ', 'base')
        if who:
            col = self.who_color(who, P['text'])
            t = s.tag(lambda n=who: self.filter_messages(n))
            label = who + ':'
            s.text(x, y, label, self.F['semi'], col, tags=(t,))
            x += self.m(label, 'semi') + space
        text = m['text']
        parts = []
        i = 0
        while i < len(text):
            j = text.find('[', i)
            if j < 0:
                parts.append(('t', text[i:]))
                break
            k = text.find(']', j)
            if k < 0:
                parts.append(('t', text[i:]))
                break
            if j > i:
                parts.append(('t', text[i:j]))
            name = text[j + 1:k]
            parts.append(('i' if ITEMS.info(name) else 't', name if ITEMS.info(name) else text[j:k + 1]))
            i = k + 1
        hl = mix(P['arcane'], P['surface'], .22)
        for kind, val in parts:
            if kind == 'i':
                w = self.m(f'[{val}]', 'base')
                if x + w > x0 + width and x > x0:
                    x, y = x0, y + lh
                self.item_link(s, x, y, val, font='base', maxw=width)
                x += min(w, width) + space
                continue
            for word in val.split(' '):
                if not word:
                    continue
                w = self.m(word, 'base')
                if x + w > x0 + width and x > x0:
                    x, y = x0, y + lh
                if words and any(wd in word.lower() for wd in words):
                    r = s.cv.create_rectangle(x - 1, y, x + w + 1, y + self.line_h['base'], fill=hl, outline='')
                s.text(x, y, word if w <= width else self.clip(word, 'base', width), self.F['base'], tcol)
                x += w + space
        return y + self.line_h['base']

    def filter_messages(self, name):
        """Click a name in chat: show only that person's messages."""
        self.msg_q = name
        self.msg_limit = 300
        self.search.delete(0, 'end')
        self.search.insert(0, name)
        self.tab, self.chat_view = 'chat', 'messages'
        self.render()
        self.main.cv.yview_moveto(0)

    def indent(self, prefix, text):
        """Pads the message so it starts after the bold speaker name drawn on top of it."""
        target = self.m(prefix, 'semi')
        sp = self.m(' ', 'base') or 1
        return ' ' * int(round(target / sp)) + text

    def mark_words(self, s, item, x, y, wrap, m, words):
        """Highlights search words that sit on the first line (good enough for short chat lines)."""
        P = self.P
        full = s.cv.itemcget(item, 'text')
        low = full.lower()
        for w in words:
            start = low.find(w)
            if start < 0:
                continue
            pre = full[:start]
            if self.m(pre + w, 'base') > wrap:
                continue
            hx = x + self.m(pre, 'base')
            r = s.cv.create_rectangle(hx - 1, y, hx + self.m(full[start:start + len(w)], 'base') + 1, y + self.line_h['base'],
                                      fill=mix(P['arcane'], P['surface'], .22), outline='')
            s.cv.tag_lower(r, item)

    def loot_rows(self, pg, loot):
        self.loot_table(pg, loot)


    # ==================================================================
    #  Sessions, history, sharing, settings
    # ==================================================================


    # ---- item links and tooltips ----
    def item_link(self, s, x, y, name, q=None, font='semi', anchor='nw', maxw=None, count=None):
        """[Item Name] in its quality colour; click it for the game-style tooltip. Returns the width drawn."""
        q = ITEMS.quality(name, q)
        col = self.quality_color(q)
        t = s.tag(lambda n=name: self.show_item(n))
        label = f'[{name}]'
        if maxw is not None:
            label = self.clip(label, font, maxw)
        i = s.text(x, y, label, self.F[font], col, anchor=anchor, tags=(t,))
        s.hover(t, i, col, mix('#ffffff', col, .45) if self.theme == 'dark' else mix('#000000', col, .3))
        w = self.m(label, font)
        if count and count > 1:
            s.text(x + w + self.px(4), y, f'×{count}', self.F['base'], self.P['muted'], anchor=anchor)
            w += self.px(4) + self.m(f'×{count}', 'base')
        return w

    TIP = {'bg': '#070816', 'edge': '#5d6080', 'text': '#ffffff', 'g': '#1eff00', 'y': '#ffd100', 'i': '#9d9d9d', 'f': '#8a8aa8', 'r': '#ffffff', '': '#ffffff'}
    TIP_Q = ['#9d9d9d', '#ffffff', '#1eff00', '#0070dd', '#a335ee', '#ff8000', '#e6cc80']

    def close_item(self):
        if self.tip_win is not None:
            try:
                self.tip_win.destroy()
            except Exception:
                pass
            self.tip_win = None

    def show_item(self, name):
        """An item tooltip that looks like the game's, with a link to the item on Wowhead."""
        self.close_item()
        info = ITEMS.info(name)
        px, T = self.px, self.TIP
        if self.phone:
            # phones: a card laid over the app (pop-up windows don't behave on Android)
            win = tk.Frame(self.root, bg=T['bg'], highlightthickness=0, bd=0)
            W = int(min(px(330), self.root.winfo_width() - px(24)))
        else:
            win = tk.Toplevel(self.root)
            win.overrideredirect(True)
            try:
                win.attributes('-topmost', True)
            except Exception:
                pass
            W = px(330)
        self.tip_win = win
        cv = Surface(self, win, bg=T['bg'], width=W, height=px(100))
        cv.cv.pack()
        x, y, w = px(14), px(12), W - px(28)
        q = info.get('q') if info else None
        title = cv.text(x, y, name, self.F['h2'], self.TIP_Q[q] if q is not None and 0 <= q < 7 else T['text'], wrap=w)
        y = cv.cv.bbox(title)[3] + px(4)
        lines = (info or {}).get('tooltip') or []
        last_y = None
        for text, style in lines:
            text = text.strip()
            if not text:
                continue
            if style == 'r' and last_y is not None:
                cv.text(x + w, last_y, text, self.F['base'], T['text'], anchor='ne')
                continue
            font = 'small' if style == 'f' else 'base'
            i = cv.text(x, y, text, self.F[font], T.get(style, T['text']), wrap=w - (px(40) if style == '' else 0))
            last_y = y
            y = cv.cv.bbox(i)[3] + px(2)
        if info and info.get('base') and info['base'] != name:
            y += px(4)
            i = cv.text(x, y, f"Random enchant ({name[len(info['base']):].strip()}): those extra stats aren't shown here.", self.F['small'], T['f'], wrap=w)
            y = cv.cv.bbox(i)[3] + px(2)
        if not info:
            i = cv.text(x, y, 'Raidscribe has no details for this item. Wowhead will.', self.F['base'], T['f'], wrap=w)
            y = cv.cv.bbox(i)[3] + px(2)
        y += px(10)
        bx = x

        def btn(label, fn, primary=False):
            nonlocal bx
            tw = self.m(label, 'smallsemi') + px(20)
            t = cv.tag(fn)
            fill = '#2a2c55' if primary else '#15172c'
            hot = '#3a3d72' if primary else '#22243f'
            bg = cv.rr(bx, y, bx + tw, y + px(26), px(6), fill, T['edge'], tags=(t,))
            cv.hover(t, bg, fill, hot)
            cv.text(bx + tw / 2, y + px(13), label, self.F['smallsemi'], T['text'], anchor='center', tags=(t,))
            bx += tw + px(8)

        def open_web():
            url = wowhead_url(info, name)
            try:
                ok = webbrowser.open(url)
            except Exception:
                ok = False
            self.close_item()
            if not ok:  # no browser reachable (can happen on a phone): hand over the link instead
                copied = copy_text_to_clipboard(self.root, url)
                self.show_toast('Couldn\u2019t open the browser; Wowhead link copied.' if copied else 'Couldn\u2019t open the browser.')

        def copy_name():
            ok = copy_text_to_clipboard(self.root, name)
            self.close_item()
            self.show_toast('Item name copied.' if ok else 'Couldn\u2019t reach the clipboard.')
        btn('Wowhead \u2197', open_web, primary=True)
        btn('Copy name', copy_name)
        btn('Close', self.close_item)
        y += px(26) + px(12)
        cv.cv.create_rectangle(1, 1, W - 1, y - 1, outline=T['edge'])
        cv.cv.configure(height=y)
        if self.phone:
            rw, rh = self.root.winfo_width(), self.root.winfo_height()
            win.place(x=int((rw - W) / 2), y=int(max(px(64), min((rh - y) / 3, rh - y - px(12)))))
            win.tkraise()
            return
        # next to the mouse, kept on screen
        mx, my = self.root.winfo_pointerx(), self.root.winfo_pointery()
        sw, sh = self.root.winfo_screenwidth(), self.root.winfo_screenheight()
        gx = mx + px(16) if mx + px(16) + W < sw else max(0, mx - W - px(16))
        gy = min(max(0, my - px(10)), max(0, sh - y - px(40)))
        win.geometry(f'{W}x{int(y)}+{int(gx)}+{int(gy)}')
        win.bind('<Escape>', lambda e: self.close_item())

    # ---- actions ----
    def action_bar(self, pg, kind, obj):
        """The three sharing buttons, top right of a run or session."""
        px = self.px
        buttons = [('Save report', lambda: self.save_report(kind, obj, open_after=True), False),
                   ('Copy image', lambda: self.share_image(kind, obj), False),
                   ('Copy summary', lambda: self.share_text(kind, obj), True)]
        if self.phone:
            buttons = [b for b in buttons if b[0] != 'Copy image']
        if self.narrow:
            x, y = pg.x, pg.y - px(8)
            for label, fn, primary in buttons[::-1]:
                w, h = self.button(pg.s, x, y, label, fn, primary=primary, small=True)
                x += w + px(8)
            pg.y = y + px(28) + px(16)
            return
        x = pg.x + pg.w
        y = pg.y - px(70)
        for label, fn, primary in buttons:
            w, h = self.button(pg.s, x, y, label, fn, primary=primary, small=True, anchor='ne')
            x -= w + px(8)


    def share_text(self, kind, obj):
        sm = self.summary_for(kind, obj)
        if sm is None:
            return self.show_toast('Nothing to copy for this player in the fights counted.')
        text = (discord_run(sm) if kind == 'run' else discord_player(sm) if kind == 'player' else discord_week(sm, sm['top']) if kind == 'week'
                else discord_session(sm))
        ok = copy_text_to_clipboard(self.root, text)
        who = f"{sm['name']}\u2019s summary" if kind == 'player' else 'Summary'
        self.show_toast(f'{who} copied. Paste it into Discord with Ctrl+V.' if ok else 'Couldn’t reach the clipboard. Try again.')


    # ---- the share card ----
    def share_image(self, kind, obj):
        """Opens a preview of the summary card, then copies it to the clipboard as an image."""
        sm = self.summary_for(kind, obj)
        if sm is None:
            return self.show_toast('Nothing to show for this player in the fights counted.')
        if getattr(self, 'card_win', None) is not None:
            try:
                self.card_win.destroy()
            except Exception:
                pass
        P, px = self.P, self.px
        win = tk.Toplevel(self.root)
        self.card_win = win
        win.title('Raidscribe · share image')
        win.configure(bg=P['bg'])
        win.resizable(False, False)
        card = Surface(self, win, bg=P['bg'])
        h = self.draw_card(card, kind, sm)
        card.cv.configure(width=px(720), height=h)
        card.cv.pack(side='top')
        bar = Surface(self, win, bg=P['bg'], height=px(56), width=px(720))
        bar.cv.pack(side='top', fill='x')
        state = {'image': None}

        def draw_bar(msg):
            bar.clear()
            bar.text(px(20), px(28), msg, self.F['small'], P['muted'], anchor='w')
            x = px(720) - px(20)
            w, _ = self.button(bar, x, px(14), 'Close', win.destroy, small=True, anchor='ne')
            x -= w + px(8)
            w, _ = self.button(bar, x, px(14), 'Save image', save, small=True, anchor='ne')
            x -= w + px(8)
            self.button(bar, x, px(14), 'Copy again', copy, primary=True, small=True, anchor='ne')

        def grab():
            win.lift()
            win.update()
            img = capture_widget(card.cv)
            if img:
                state['image'] = img
            return img

        def copy():
            img = state['image'] or grab()
            if img and copy_image_to_clipboard(img[0], img[1], img[2], encode_png(*img)):
                draw_bar('Copied. Paste it into Discord with Ctrl+V.')
            elif img:
                draw_bar('Couldn’t reach the clipboard here. Use Save image instead.')
            else:
                draw_bar('Couldn’t capture the card. Keep this window on top and try again.')

        def save():
            img = state['image'] or grab()
            if not img:
                draw_bar('Couldn’t capture the card. Keep this window on top and try again.')
                return
            folder = self.save_report(kind, obj, open_after=True, quiet=True, image=img)
            draw_bar(f'Saved with the report in {folder}' if folder else 'Couldn’t save. Details are in errors.log.')

        draw_bar('Copying…')
        win.after(350, copy)

    def draw_card(self, s, kind, sm):
        """The picture people see in Discord: compact, readable at a glance. Returns its height."""
        P, px = self.P, self.px
        W = px(720)
        x, y = px(28), px(26)
        w = W - px(56)
        title_col = P['text']
        if kind == 'run':
            title, bits = run_header(sm)
        elif kind == 'player':
            title, where = player_header(sm)
            bits = [where, 'Boss fights' if sm['scope'] == 'boss' else 'All fights']
            title_col = self.class_color(sm['cls']) if sm.get('cls') else P['text']
        elif kind == 'week':
            title, bits = f"Week of {day(sm['start'])}", [plural(sm['kills'], 'boss kill'), plural(sm['wipes'], 'wipe')]
        else:
            title, bits = f"Session · {day(sm['start'])}", [f"{clock(sm['start'])} – {clock(sm['end'])}", span(sm['duration'])]
        s.text(x, y, title, self.F['h1'], title_col, maxw=w)
        y += self.line_h['h1'] + px(2)
        s.text(x, y, ' · '.join(bits), self.F['base'], P['muted'], maxw=w)
        y += self.line_h['base'] + px(18)
        if kind == 'run':
            if sm['bosses']:
                for b in sm['bosses'][:12]:
                    cy = y + px(14)
                    s.text(x, cy, b['name'], self.F['semi'], P['text'], anchor='w', maxw=px(250))
                    bx = x + px(260)
                    for a in b['attempts'][:8]:
                        if a['success']:
                            s.rr(bx, cy - px(12), bx + px(40), cy + px(12), px(6), P['kill'])
                            s.text(bx + px(20), cy, '✓', self.F['semi'], '#ffffff', anchor='center')
                        else:
                            hp = a.get('boss_hp')
                            s.rr(bx, cy - px(12), bx + px(40), cy + px(12), px(6), mix(P['wipe'], P['bg'], .18))
                            s.text(bx + px(20), cy, f'{round(hp * 100)}%' if hp is not None else '✕', self.F['tiny'], P['wipe'], anchor='center')
                        bx += px(46)
                    if b['kill']:
                        s.text(x + w, cy, dur(fight_dur(b['kill'])), self.F['small'], P['muted'], anchor='e')
                    y += px(32)
                y += px(12)
            y = self.card_group(s, x, y, w, sm)
            if sm['loot']:
                s.text(x, y, 'Loot', self.F['smallsemi'], P['muted'])
                y += self.line_h['smallsemi'] + px(6)
                for l in sm['loot'][:8]:
                    item = f"[{l['name']}]"
                    s.text(x, y, item, self.F['semi'], self.quality_color(l['q']), maxw=w - px(160))
                    s.text(x + w, y, l['who'], self.F['base'], self.who_color(l['who'], P['muted']), anchor='ne')
                    y += self.line_h['semi'] + px(4)
                if len(sm['loot']) > 8:
                    s.text(x, y, f"and {len(sm['loot']) - 8} more", self.F['small'], P['faint'])
                    y += self.line_h['small'] + px(4)
                y += px(8)
        elif kind == 'player':
            y = self.card_player(s, x, y, w, sm)
        elif kind == 'week':
            y = self.card_week(s, x, y, w, sm)
        else:
            for kind_ in KIND_ORDER:
                for r in sm['by_kind'].get(kind_, []):
                    t, b = run_header(r)
                    s.text(x, y, t, self.F['semi'], P['text'], maxw=px(300))
                    s.text(x + px(310), y, ' · '.join(b[1:]), self.F['base'], P['muted'], maxw=w - px(310))
                    y += self.line_h['semi'] + px(6)
            if sm['money_in']:
                y += px(8)
                g = f"{gold(sm['money_in'])} looted" + (f" · {gold(sm['gold_per_hour'])} per hour" if sm['gold_per_hour'] else '')
                s.text(x, y, g, self.F['semi'], P['warn'])
                y += self.line_h['semi'] + px(6)
            epics = [l for r in sm['runs'] for l in r['loot'] if (l['q'] or 0) >= 4] + [l for l in sm['farm_loot'] if (l['q'] or 0) >= 4]
            for l in epics[:6]:
                s.text(x, y, f"[{l['name']}]", self.F['semi'], self.quality_color(l['q']), maxw=w - px(160))
                s.text(x + w, y, l['who'], self.F['base'], P['muted'], anchor='ne')
                y += self.line_h['semi'] + px(4)
        y += px(10)
        s.cv.create_line(x, y, x + w, y, fill=P['line_soft'])
        y += px(10)
        mark = self.mark_image(px(22))
        if mark is not None:
            s.cv.create_image(x, y + self.line_h['smallsemi'] // 2, image=mark, anchor='w')
        s.text(x + (mark.width() + px(8) if mark is not None else 0), y, 'Raidscribe', self.F['smallsemi'], P['arcane'])
        y += self.line_h['smallsemi'] + px(18)
        s.rr(px(6), px(6), W - px(6), y - px(4), px(14), '', P['line_soft'])
        return y

    def card_group(self, s, x, y, w, sm):
        """Everyone in the group, one row each, in class colours."""
        P, px = self.P, self.px
        players = sorted(sm['players'], key=lambda p: -p['dps'])
        if not players:
            return y
        heals = any(p['heal'] for p in players)
        cols = [('DPS', 'dps', True), ('Damage', 'dmg', False)] + ([('HPS', 'hps', True), ('Healing', 'heal', False)] if heals else []) + [('Died', 'deaths', None)]
        cw = px(78)
        xs = [x + w - (len(cols) - 1 - i) * cw for i in range(len(cols))]
        s.text(x, y, 'Group' + (' · boss fights' if sm.get('scope') == 'boss' else ' · all fights'), self.F['smallsemi'], P['muted'])
        for (label, _, _), cx in zip(cols, xs):
            s.text(cx, y, label, self.F['smallsemi'], P['muted'], anchor='ne')
        y += self.line_h['smallsemi'] + px(6)
        top = max(p['dps'] for p in players) or 1
        for i, p in enumerate(players):
            rh = self.line_h['semi'] + px(6)
            if p['dmg']:
                s.rr(x, y + px(1), x + max(px(3), (xs[0] - cw - x - px(10)) * p['dps'] / top), y + rh - px(2), px(4),
                     mix(self.class_color(p['cls']) if p.get('cls') else P['muted'], P['bg'], .14))
            s.text(x + px(8), y + px(3), p['name'], self.F['semi'], self.class_color(p['cls']) if p.get('cls') else self.who_color(p['name']), maxw=xs[0] - cw - x - px(20))
            for (label, key, rate), cx in zip(cols, xs):
                v = p[key]
                base = p['dmg'] if key in ('dps', 'dmg') else p['heal'] if key in ('hps', 'heal') else v
                txt = '–' if not base else (fmt_int(v) if rate else fmt(v) if rate is False else str(v))
                s.text(cx, y + px(3), txt, self.F['base'], P['faint'] if txt == '–' else (P['wipe'] if key == 'deaths' else P['text']), anchor='ne')
            y += rh
        return y + px(14)

    def card_player(self, s, x, y, w, ps):
        P, px = self.P, self.px
        me = ps['player']
        boxes = []
        if me['dmg']:
            boxes.append((fmt_int(me['dps']), 'DPS' + (f" · #{ps['rank_dps']} of {ps['of_dps']}" if ps['rank_dps'] else '')))
            boxes.append((fmt(me['dmg']), 'Damage'))
        if me['heal']:
            boxes.append((fmt_int(me['hps']), 'HPS' + (f" · #{ps['rank_hps']} of {ps['of_hps']}" if ps['rank_hps'] else '')))
            boxes.append((fmt(me['heal']), 'Healing'))
        boxes.append((str(me['deaths']), 'Deaths'))
        bw = w / len(boxes)
        for i, (v, label) in enumerate(boxes):
            bx = x + i * bw
            s.text(bx, y, v, self.F['stat'], P['wipe'] if label == 'Deaths' and me['deaths'] else P['text'])
            s.text(bx, y + self.line_h['stat'], label, self.F['small'], P['muted'])
        y += self.line_h['stat'] + self.line_h['small'] + px(16)
        bosses = [r for r in ps['fights'] if r['kind'] == 'boss']
        if bosses:
            s.text(x, y, 'Boss fights', self.F['smallsemi'], P['muted'])
            y += self.line_h['smallsemi'] + px(6)
            for r in bosses[:14]:
                ok = r['success']
                s.rr(x, y + px(2), x + px(12), y + px(14), px(3), P['kill'] if ok else P['wipe'])
                s.text(x + px(20), y, r['name'] + (f" #{r['attempt']}" if (r['attempt'] or 1) > 1 else ''), self.F['semi'], P['text'], maxw=px(300))
                val = f"{fmt_int(r['dps'])} dps" if r['dmg'] >= r['heal'] else f"{fmt_int(r['hps'])} hps"
                s.text(x + w - px(70), y, val, self.F['base'], P['text'], anchor='ne')
                s.text(x + w, y, dur(r['time']), self.F['small'], P['muted'], anchor='ne')
                y += self.line_h['semi'] + px(5)
            y += px(10)
        for head, items in (('Damage by ability', ps['dmg_by']), ('Healing by ability', ps['heal_by'])):
            if not items:
                continue
            total = sum(v for _, v in items) or 1
            s.text(x, y, head, self.F['smallsemi'], P['muted'])
            y += self.line_h['smallsemi'] + px(6)
            for k, v in items[:5]:
                s.text(x, y, k, self.F['base'], P['text'], maxw=w - px(140))
                s.text(x + w, y, f'{100 * v / total:.0f}%', self.F['base'], P['muted'], anchor='ne')
                y += self.line_h['base'] + px(4)
            y += px(10)
        if ps['loot']:
            s.text(x, y, 'Loot', self.F['smallsemi'], P['muted'])
            y += self.line_h['smallsemi'] + px(6)
            for l in ps['loot'][:6]:
                s.text(x, y, f"[{l['name']}]", self.F['semi'], self.quality_color(l['q']), maxw=w)
                y += self.line_h['semi'] + px(4)
            y += px(8)
        return y

    def card_week(self, s, x, y, w, wk):
        P, px = self.P, self.px
        for sm in sorted([r for r in wk['runs'] if r['kind'] in ('raid', 'dungeon')], key=lambda r: r['start']):
            t, b = run_header(sm)
            s.text(x, y, day(sm['start']), self.F['small'], P['faint'])
            s.text(x + px(100), y, t, self.F['semi'], P['text'], maxw=px(260))
            s.text(x + w, y, ' · '.join(b[1:]), self.F['base'], P['muted'], anchor='ne', maxw=w - px(380))
            y += self.line_h['semi'] + px(6)
        dps, hps = wk['top']
        cw = (w - px(24)) / 2
        top_y = y + px(12)
        bottom = top_y
        for i, (head, lst) in enumerate((('Top damage on bosses', dps), ('Top healing on bosses', hps))):
            if not lst:
                continue
            cx, cy = x + i * (cw + px(24)), top_y
            s.text(cx, cy, head, self.F['smallsemi'], P['muted'])
            cy += self.line_h['smallsemi'] + px(6)
            for v, h in lst:
                s.text(cx, cy, h['name'], self.F['semi'], self.class_color(h['cls']) if h.get('cls') else P['text'], maxw=cw - px(80))
                s.text(cx + cw, cy, fmt_int(v), self.F['base'], P['text'], anchor='ne')
                cy += self.line_h['semi'] + px(4)
            bottom = max(bottom, cy)
        y = bottom + px(10)
        if wk['attendance']:
            i = s.text(x, y, 'Raiders: ' + ', '.join(sorted(wk['attendance'])), self.F['small'], P['muted'], wrap=w)
            y = s.cv.bbox(i)[3] + px(8)
        return y

    # ---- automatic reports ----

    # ---- views ----
    # ---- history ----
    def sparkline(self, s, x, y, w, h, values, color, dot=True):
        """A small trend line; the latest value gets a dot."""
        vals = [v for v in values if v is not None]
        if len(vals) < 2:
            if vals:  # one value: a dot where the line will start
                s.cv.create_oval(x - self.px(3), y + h / 2 - self.px(3), x + self.px(3), y + h / 2 + self.px(3), fill=color, outline='')
            return
        lo, hi = min(vals), max(vals)
        rng = (hi - lo) or 1
        n = len(values)
        pts = []
        for i, v in enumerate(values):
            if v is None:
                continue
            pts += [x + w * i / (n - 1), y + h - h * (v - lo) / rng]
        s.cv.create_line(*pts, fill=color, width=max(1, self.px(1.6)), smooth=False)
        if dot:
            s.cv.create_oval(pts[-2] - self.px(3), pts[-1] - self.px(3), pts[-2] + self.px(3), pts[-1] + self.px(3), fill=color, outline='')

    def view_history(self, pg):
        P, px = self.P, self.px
        y0 = pg.y
        self.header(pg, 'History', None, ['Everything Raidscribe has read, week by week. Weeks start on Tuesday, when raids reset.'])
        tabs = [('weeks', 'Weeks'), ('bosses', 'Bosses'), ('players', 'Players'), ('attendance', 'Attendance'), ('loot', 'Loot')]
        if self.history_tab not in dict(tabs):
            self.history_tab = 'weeks'
        self.header_seg(pg, y0, tabs, self.history_tab, lambda k: self.set('history_tab', k, 'history_tab'))
        {'bosses': self.history_bosses, 'players': self.history_players, 'attendance': self.history_attendance,
         'loot': self.history_loot}.get(self.history_tab, self.history_weeks)(pg)

    def history_weeks(self, pg):
        """A recap per reset week, each one copyable for Discord."""
        P, px = self.P, self.px
        m = self.model
        weeks = [wk for wk in m.weeks() if any(sm['kind'] in ('raid', 'dungeon') for sm in wk['runs'])]
        if not weeks:
            return self.empty(pg, 'Nothing yet. Each week you raid or run dungeons gets a recap here.')
        for wk in weeks:
            top = m.week_top(wk['start'])
            runs = sorted([sm for sm in wk['runs'] if sm['kind'] in ('raid', 'dungeon')], key=lambda r: r['start'])

            def right(xr, y, h, wk=wk):
                x = xr
                btns = (('Copy image', lambda wk=wk: self.share_image('week', wk), False),
                        ('Copy summary', lambda wk=wk: self.share_text('week', wk), True))
                if self.phone:
                    btns = btns[1:]
                for label, fn, primary in btns:
                    bw, _ = self.button(pg.s, x, y + px(1), label, fn, primary=primary, small=True, anchor='ne')
                    x -= bw + px(8)

            def body(inner, wk=wk, top=top, runs=runs):
                s = inner.s
                raids = sum(1 for sm in runs if sm['kind'] == 'raid')
                dung = len(runs) - raids
                bits = [plural(raids, 'raid'), plural(dung, 'dungeon'), plural(wk['kills'], 'boss kill'), plural(wk['wipes'], 'wipe')]
                i = s.text(inner.x, inner.y, ' · '.join(bits), self.F['base'], P['muted'], wrap=inner.w)
                inner.y = s.cv.bbox(i)[3] + px(10)
                if self.narrow:
                    return self.week_body_narrow(inner, wk, top, runs)
                for sm in runs:
                    t = s.tag(lambda rid=sm['run']['id']: self.go('run', rid))
                    title, b = run_header(sm)
                    row = s.cv.create_rectangle(inner.x, inner.y, inner.x + inner.w, inner.y + px(30), fill=P['surface'], outline='', tags=(t,))
                    s.hover(t, row, P['surface'], P['hover_surface'])
                    s.text(inner.x, inner.y + px(15), day(sm['start']), self.F['small'], P['faint'], anchor='w', tags=(t,))
                    s.text(inner.x + px(110), inner.y + px(15), title, self.F['semi'], P['text'], anchor='w', tags=(t,), maxw=px(280))
                    s.text(inner.x + inner.w, inner.y + px(15), ' · '.join(b[1:]), self.F['small'], P['muted'], anchor='e', tags=(t,))
                    inner.y += px(32)
                dps, hps = top
                if dps or hps:
                    inner.y += px(8)
                    for label, lst in (('Top damage on bosses', dps), ('Top healing on bosses', hps)):
                        if not lst:
                            continue
                        x = inner.x
                        s.text(x, inner.y, label, self.F['small'], P['faint'])
                        x += px(150)
                        for v, h in lst:
                            col = self.class_color(h['cls']) if h.get('cls') else self.who_color(h['name'])
                            s.text(x, inner.y, h['name'], self.F['smallsemi'], col)
                            x += self.m(h['name'], 'smallsemi') + px(5)
                            s.text(x, inner.y, fmt_int(v), self.F['small'], P['muted'])
                            x += self.m(fmt_int(v), 'small') + px(18)
                        inner.y += self.line_h['small'] + px(4)
                if wk['attendance']:
                    inner.y += px(6)
                    txt = 'Raiders: ' + ', '.join(f"{n}{' ×' + str(c) if c > 1 else ''}" for n, c in sorted(wk['attendance'].items(), key=lambda kv: (-kv[1], kv[0])))
                    i = s.text(inner.x, inner.y, txt, self.F['small'], P['muted'], wrap=inner.w)
                    inner.y = s.cv.bbox(i)[3] + px(2)
            self.panel(pg, f"Week of {day(wk['start'])}", right, body)

    def week_body_narrow(self, inner, wk, top, runs):
        """A week's recap on a phone: two-line run rows, then the top players wrapping under each heading."""
        s, P, px = inner.s, self.P, self.px
        for sm in runs:
            t = s.tag(lambda rid=sm['run']['id']: self.go('run', rid))
            title, b = run_header(sm)
            y0 = inner.y
            row = s.cv.create_rectangle(inner.x, y0, inner.x + inner.w, y0 + 1, fill=P['surface'], outline='', tags=(t,))
            s.hover(t, row, P['surface'], P['hover_surface'])
            y = y0 + px(5)
            s.text(inner.x, y, title, self.F['semi'], P['text'], tags=(t,), maxw=inner.w - px(16))
            s.text(inner.x + inner.w, y + px(2), '›', self.F['semi'], P['faint'], anchor='ne', tags=(t,))
            y += self.line_h['semi'] + px(1)
            s.text(inner.x, y, ' · '.join([day(sm['start'])] + list(b[1:])), self.F['small'], P['muted'], tags=(t,), maxw=inner.w)
            y += self.line_h['small'] + px(5)
            s.cv.coords(row, inner.x, y0, inner.x + inner.w, y)
            inner.y = y + px(2)
        dps, hps = top
        for label, lst in (('Top damage on bosses', dps), ('Top healing on bosses', hps)):
            if not lst:
                continue
            inner.y += px(8)
            s.text(inner.x, inner.y, label, self.F['small'], P['faint'])
            inner.y += self.line_h['small'] + px(2)
            x = inner.x
            for v, h in lst:
                col = self.class_color(h['cls']) if h.get('cls') else self.who_color(h['name'])
                w = self.m(h['name'], 'smallsemi') + px(5) + self.m(fmt_int(v), 'small')
                if x > inner.x and x + w > inner.x + inner.w:
                    x = inner.x
                    inner.y += self.line_h['small'] + px(2)
                s.text(x, inner.y, h['name'], self.F['smallsemi'], col)
                s.text(x + self.m(h['name'], 'smallsemi') + px(5), inner.y, fmt_int(v), self.F['small'], P['muted'])
                x += w + px(14)
            inner.y += self.line_h['small'] + px(2)
        if wk['attendance']:
            inner.y += px(8)
            txt = 'Raiders: ' + ', '.join(f"{n}{' ×' + str(c) if c > 1 else ''}" for n, c in sorted(wk['attendance'].items(), key=lambda kv: (-kv[1], kv[0])))
            i = s.text(inner.x, inner.y, txt, self.F['small'], P['muted'], wrap=inner.w)
            inner.y = s.cv.bbox(i)[3] + px(2)

    def history_bosses(self, pg):
        """Boss progress: every boss, kills and wipes, best and latest kill, kill time week by week."""
        P, px = self.P, self.px
        bosses = self.model.boss_history()
        if not bosses:
            return self.empty(pg, 'No boss fights yet.')

        def body(inner):
            s = inner.s
            for i, b in enumerate(bosses):
                if i:
                    s.cv.create_line(inner.x, inner.y, inner.x + inner.w, inner.y, fill=P['line_soft'])
                key = 'boss:' + str(b['name'])
                is_open = key in self.open
                t = s.tag(lambda k=key: self.toggle(k))
                y = inner.y + px(10)
                if self.narrow:
                    self.boss_row_narrow(inner, b, t, is_open)
                    continue
                row = s.cv.create_rectangle(inner.x, inner.y + 1, inner.x + inner.w, y + px(40), fill=P['surface'], outline='', tags=(t,))
                s.hover(t, row, P['surface'], P['hover_surface'])
                s.text(inner.x, y, b['name'], self.F['semi'], P['text'], tags=(t,), maxw=px(250))
                last = b['pulls'][-1]['start']
                s.text(inner.x, y + self.line_h['semi'], f"{plural(len(b['kills']), 'kill')} · {plural(b['wipes'], 'wipe')} · last {day(last)}",
                       self.F['small'], P['muted'], tags=(t,))
                x = inner.x + px(290)
                s.text(x, y, 'Fastest', self.F['small'], P['faint'], tags=(t,))
                s.text(x, y + self.line_h['small'], mins(b['best']) if b['best'] else '–', self.F['semi'], P['kill'] if b['best'] else P['faint'], tags=(t,))
                x += px(110)
                s.text(x, y, 'Latest', self.F['small'], P['faint'], tags=(t,))
                s.text(x, y + self.line_h['small'], mins(b['latest']) if b['latest'] else '–', self.F['semi'], P['text'] if b['latest'] else P['faint'], tags=(t,))
                # kill time, week by week (lower is better)
                x += px(110)
                kills = [fight_dur(k) for k in b['kills']]
                if len(kills) >= 2:
                    s.text(x, y, 'Kill times, oldest to newest (up is faster)', self.F['small'], P['faint'], tags=(t,))
                    self.sparkline(s, x, y + self.line_h['small'] + px(2), min(px(220), inner.x + inner.w - x - px(40)), px(20), [-k for k in kills], P['arcane'])
                s.text(inner.x + inner.w, y + px(8), '▾' if is_open else '▸', self.F['small'], P['faint'], anchor='ne', tags=(t,))
                inner.y = y + px(46)
                if is_open:
                    for f in b['pulls'][::-1][:40]:
                        ft = s.tag(lambda i=f['id']: self.go('fight', i))
                        res = 'Kill' if f['success'] else (f"Wipe {round(f['boss_hp'] * 100)}%" if f.get('boss_hp') is not None else 'Wipe')
                        s.text(inner.x + px(14), inner.y, f"{day(f['start'])}, {clock(f['start'])}", self.F['small'], P['muted'], tags=(ft,))
                        s.text(inner.x + px(190), inner.y, res, self.F['smallsemi'], P['kill'] if f['success'] else P['wipe'], tags=(ft,))
                        s.text(inner.x + px(300), inner.y, mins(fight_dur(f)), self.F['small'], P['text'], tags=(ft,))
                        s.text(inner.x + px(390), inner.y, plural(len(f['deaths']), 'death') if f['deaths'] else '', self.F['small'], P['faint'], tags=(ft,))
                        inner.y += self.line_h['small'] + px(5)
                    inner.y += px(8)
        self.panel(pg, None, None, body)

    def boss_row_narrow(self, inner, b, t, is_open):
        """One boss in Boss progress, stacked for a phone: name, record, kill times with the trend, then pulls."""
        s, P, px = inner.s, self.P, self.px
        y0 = inner.y
        row = s.cv.create_rectangle(inner.x, y0 + 1, inner.x + inner.w, y0 + 2, fill=P['surface'], outline='', tags=(t,))
        s.hover(t, row, P['surface'], P['hover_surface'])
        y = y0 + px(10)
        s.text(inner.x, y, b['name'], self.F['semi'], P['text'], tags=(t,), maxw=inner.w - px(20))
        s.text(inner.x + inner.w, y + px(2), '▾' if is_open else '▸', self.F['small'], P['faint'], anchor='ne', tags=(t,))
        y += self.line_h['semi'] + px(1)
        last = b['pulls'][-1]['start']
        s.text(inner.x, y, f"{plural(len(b['kills']), 'kill')} · {plural(b['wipes'], 'wipe')} · last {day(last)}", self.F['small'], P['muted'], tags=(t,), maxw=inner.w)
        y += self.line_h['small'] + px(4)
        x = inner.x
        for label, v, col in (('Fastest', b['best'], P['kill']), ('Latest', b['latest'], P['text'])):
            s.text(x, y, label, self.F['small'], P['faint'], tags=(t,))
            x += self.m(label, 'small') + px(5)
            txt = mins(v) if v else '–'
            s.text(x, y - px(1), txt, self.F['smallsemi'], col if v else P['faint'], tags=(t,))
            x += self.m(txt, 'smallsemi') + px(14)
        kills = [fight_dur(k) for k in b['kills']]
        if len(kills) >= 2 and inner.x + inner.w - x > px(50):
            self.sparkline(s, x, y + px(1), min(px(120), inner.x + inner.w - x - px(6)), px(14), [-k for k in kills], P['arcane'])
        y += self.line_h['small'] + px(8)
        s.cv.coords(row, inner.x, y0 + 1, inner.x + inner.w, y)
        inner.y = y
        if is_open:
            pulls = b['pulls'][::-1][:40]
            res_of = lambda f: 'Kill' if f['success'] else (f"Wipe {round(f['boss_hp'] * 100)}%" if f.get('boss_hp') is not None else 'Wipe')
            c1 = max(self.m(f"{day(f['start'])}, {clock(f['start'])}", 'small') for f in pulls) + px(10)
            c2 = c1 + max(self.m(res_of(f), 'smallsemi') for f in pulls) + px(10)
            c3 = c2 + max(self.m(mins(fight_dur(f)), 'small') for f in pulls) + px(10)
            for f in pulls:
                ft = s.tag(lambda i=f['id']: self.go('fight', i))
                s.text(inner.x, inner.y, f"{day(f['start'])}, {clock(f['start'])}", self.F['small'], P['muted'], tags=(ft,))
                s.text(inner.x + c1, inner.y, res_of(f), self.F['smallsemi'], P['kill'] if f['success'] else P['wipe'], tags=(ft,))
                s.text(inner.x + c2, inner.y, mins(fight_dur(f)), self.F['small'], P['text'], tags=(ft,))
                if f['deaths'] and c3 < inner.w - px(20):
                    s.text(inner.x + c3, inner.y, plural(len(f['deaths']), 'death'), self.F['small'], P['faint'], tags=(ft,), maxw=inner.w - c3)
                inner.y += self.line_h['small'] + px(7)
            inner.y += px(8)

    def history_players(self, pg):
        """Each player's boss DPS (or HPS for healers) across weeks; click one for their history."""
        P, px = self.P, self.px
        ph = self.model.player_history()
        if not ph:
            return self.empty(pg, 'No raid boss kills yet. Player trends come from raid boss kills.')
        players = sorted(ph.values(), key=lambda h: (h['healer'], -(h['hps'] if h['healer'] else h['dps'])))

        def body_narrow(inner):
            s = inner.s
            group = None
            for h in players:
                g = 'Healers' if h['healer'] else 'Damage'
                if g != group:
                    if group:
                        inner.y += px(6)
                    group = g
                    s.text(inner.x, inner.y, g, self.F['smallsemi'], P['faint'])
                    inner.y += self.line_h['smallsemi'] + px(4)
                t = s.tag(lambda n=h['name']: self.go('phist', n))
                y0 = inner.y
                row = s.cv.create_rectangle(inner.x, y0, inner.x + inner.w, y0 + 1, fill=P['surface'], outline='', tags=(t,))
                s.hover(t, row, P['surface'], P['hover_surface'])
                y = y0 + px(6)
                col = self.class_color(h['cls']) if h.get('cls') else self.who_color(h['name'])
                v = h['hps'] if h['healer'] else h['dps']
                val = f"{fmt_int(v)} {'hps' if h['healer'] else 'dps'}"
                s.text(inner.x + inner.w, y, val, self.F['semi'], P['text'], anchor='ne', tags=(t,))
                s.text(inner.x, y, h['name'], self.F['semi'], col, tags=(t,), maxw=inner.w - self.m(val, 'semi') - px(12))
                y += self.line_h['semi'] + px(1)
                trend = [v for _, v in h['trend']]
                spark_w = px(64) if len(trend) >= 2 else 0
                b = h['best']
                bits = [plural(len(h['kills']), 'kill')]
                if trend:
                    bits.append(plural(len(trend), 'week'))
                if b:  # last, so a long boss name is what gets cut short
                    bits.append(f"best {fmt_int(b['hps'] if h['healer'] else b['dps'])} ({b['boss']})")
                s.text(inner.x, y, ' · '.join(bits), self.F['small'], P['muted'], tags=(t,), maxw=inner.w - spark_w - px(10))
                if spark_w:
                    self.sparkline(s, inner.x + inner.w - spark_w, y + px(1), spark_w - px(4), px(14), trend, col)
                y += self.line_h['small'] + px(6)
                s.cv.coords(row, inner.x, y0, inner.x + inner.w, y)
                inner.y = y + px(2)
            inner.y += px(8)
            i = s.text(inner.x, inner.y, 'Average is over all raid boss kills. Healers are anyone who healed more than they damaged. Tap a player for their history.',
                       self.F['small'], P['faint'], wrap=inner.w)
            inner.y = s.cv.bbox(i)[3]

        def body(inner):
            if self.narrow:
                return body_narrow(inner)
            s = inner.s
            cols = [px(0), px(190), px(290), px(400), px(640)]
            heads = ['Player', 'Boss kills', 'Average', 'Best', 'Week by week']
            for cx, hd in zip(cols, heads):
                s.text(inner.x + cx, inner.y, hd, self.F['smallsemi'], P['muted'])
            inner.y += self.line_h['smallsemi'] + px(8)
            s.cv.create_line(inner.x, inner.y, inner.x + inner.w, inner.y, fill=P['line'])
            group = None
            for h in players:
                g = 'Healers' if h['healer'] else 'Damage'
                if g != group:
                    group = g
                    inner.y += px(8)
                    s.text(inner.x, inner.y, g, self.F['smallsemi'], P['faint'])
                    inner.y += self.line_h['smallsemi'] + px(4)
                t = s.tag(lambda n=h['name']: self.go('phist', n))
                rh = px(32)
                row = s.cv.create_rectangle(inner.x, inner.y, inner.x + inner.w, inner.y + rh, fill=P['surface'], outline='', tags=(t,))
                s.hover(t, row, P['surface'], P['hover_surface'])
                cy = inner.y + rh / 2
                col = self.class_color(h['cls']) if h.get('cls') else self.who_color(h['name'])
                s.text(inner.x + cols[0], cy, h['name'], self.F['semi'], col, anchor='w', tags=(t,), maxw=px(180))
                s.text(inner.x + cols[1], cy, str(len(h['kills'])), self.F['base'], P['text'], anchor='w', tags=(t,))
                v = h['hps'] if h['healer'] else h['dps']
                s.text(inner.x + cols[2], cy, f"{fmt_int(v)} {'hps' if h['healer'] else 'dps'}", self.F['base'], P['text'], anchor='w', tags=(t,))
                b = h['best']
                if b:
                    bv = b['hps'] if h['healer'] else b['dps']
                    s.text(inner.x + cols[3], cy, fmt_int(bv), self.F['semi'], P['text'], anchor='w', tags=(t,))
                    s.text(inner.x + cols[3] + self.m(fmt_int(bv), 'semi') + px(6), cy, b['boss'], self.F['small'], P['faint'], anchor='w', tags=(t,),
                           maxw=cols[4] - cols[3] - self.m(fmt_int(bv), 'semi') - px(16))
                trend = [v for _, v in h['trend']]
                if trend:
                    self.sparkline(s, inner.x + cols[4], cy - px(9), min(px(200), inner.w - cols[4] - px(60)), px(18), trend, col)
                    s.text(inner.x + inner.w, cy, plural(len(trend), 'week'), self.F['small'], P['faint'], anchor='e', tags=(t,))
                inner.y += rh + px(2)
            inner.y += px(8)
            i = s.text(inner.x, inner.y, 'Average is over all raid boss kills. Healers are anyone who healed more than they damaged. Click a player for their history.',
                       self.F['small'], P['faint'], wrap=inner.w)
            inner.y = s.cv.bbox(i)[3]
        self.panel(pg, None, None, body)

    def view_player_history(self, pg, name):
        """One player over time: week by week and boss by boss, every kill clickable."""
        P, px = self.P, self.px
        h = self.model.player_history().get(name)
        crumb = ('History', lambda: (setattr(self, 'history_tab', 'players'), self.go('history')))
        if not h:
            self.header(pg, name, None, [], crumb=crumb)
            return self.empty(pg, 'No boss kills for this player yet.')
        key = 'hps' if h['healer'] else 'dps'
        unit = 'HPS' if h['healer'] else 'DPS'
        col = self.class_color(h['cls']) if h.get('cls') else None
        self.header(pg, name, None, [s for s in ((h.get('cls') or '').title(), plural(len(h['kills']), 'boss kill'), plural(h['runs'], 'run')) if s],
                    crumb=crumb, title_color=col)
        b = h['best']
        self.stats(pg, [(fmt_int(h[key]), f'Average {unit} on bosses', None, None),
                        (fmt_int(b[key]) if b else '–', f"Best: {b['boss']}" if b else 'Best', None, None),
                        (fmt(h['dmg'] if not h['healer'] else h['heal']), 'Damage on bosses' if not h['healer'] else 'Healing on bosses', None, None),
                        (str(sum(k['deaths'] for k in h['kills'])), 'Deaths on kills', None, None)])

        def weeks_body(inner):
            s = inner.s
            trend = h['trend']
            if len(trend) >= 2:
                self.sparkline(s, inner.x, inner.y, inner.w, px(60), [v for _, v in trend], col or P['arcane'])
                inner.y += px(72)
            for wk, v in trend[::-1]:
                w = h['weeks'][wk]
                if self.narrow:  # week and kills on the left, the number on the right
                    s.text(inner.x, inner.y, f"Week of {day(wk)}", self.F['base'], P['text'])
                    s.text(inner.x + inner.w, inner.y, f"{fmt_int(v)} {unit.lower()}", self.F['semi'], P['text'], anchor='ne')
                    inner.y += self.line_h['semi']
                    s.text(inner.x, inner.y, plural(w['kills'], 'boss kill'), self.F['small'], P['muted'])
                    inner.y += self.line_h['small'] + px(6)
                    continue
                s.text(inner.x, inner.y, f"Week of {day(wk)}", self.F['base'], P['text'])
                s.text(inner.x + px(200), inner.y, f"{fmt_int(v)} {unit.lower()}", self.F['semi'], P['text'])
                s.text(inner.x + px(320), inner.y, plural(w['kills'], 'boss kill'), self.F['small'], P['muted'])
                inner.y += self.line_h['semi'] + px(5)
        self.panel(pg, 'Week by week', None, weeks_body)

        def bosses_body(inner):
            s = inner.s
            for boss, kills in sorted(h['bosses'].items(), key=lambda kv: -kv[1][-1]['ts']):
                vals = [k[key] for k in kills]
                if self.narrow:
                    s.text(inner.x, inner.y, boss, self.F['semi'], P['text'], maxw=inner.w)
                    inner.y += self.line_h['semi'] + px(1)
                    spark_w = px(64) if len(vals) >= 2 else 0
                    s.text(inner.x, inner.y, f"best {fmt_int(max(vals))} · latest {fmt_int(vals[-1])} · {plural(len(kills), 'kill')}",
                           self.F['small'], P['muted'], maxw=inner.w - spark_w - px(10))
                    if spark_w:
                        self.sparkline(s, inner.x + inner.w - spark_w, inner.y + px(1), spark_w - px(4), px(14), vals, col or P['arcane'])
                    inner.y += self.line_h['small'] + px(5)
                    for k in kills[::-1][:6]:
                        t = s.tag(lambda i=k['fight_id']: self.go('fight', i))
                        v = fmt_int(k[key])
                        s.text(inner.x + inner.w, inner.y, v, self.F['small'], P['text'], anchor='ne', tags=(t,))
                        s.text(inner.x + px(12), inner.y, f"{day(k['ts'])} · {k['run']}", self.F['small'], P['muted'], tags=(t,),
                               maxw=inner.w - px(24) - self.m(v, 'small'))
                        inner.y += self.line_h['small'] + px(6)
                    inner.y += px(10)
                    continue
                s.text(inner.x, inner.y, boss, self.F['semi'], P['text'], maxw=px(230))
                s.text(inner.x + px(240), inner.y, f"best {fmt_int(max(vals))}", self.F['base'], P['text'])
                s.text(inner.x + px(360), inner.y, f"latest {fmt_int(vals[-1])}", self.F['base'], P['muted'])
                s.text(inner.x + px(480), inner.y, plural(len(kills), 'kill'), self.F['small'], P['faint'])
                if len(vals) >= 2:
                    self.sparkline(s, inner.x + px(560), inner.y + px(1), min(px(200), inner.w - px(570)), px(16), vals, col or P['arcane'])
                inner.y += self.line_h['semi'] + px(4)
                for k in kills[::-1][:6]:
                    t = s.tag(lambda i=k['fight_id']: self.go('fight', i))
                    s.text(inner.x + px(14), inner.y, f"{day(k['ts'])} · {k['run']}", self.F['small'], P['muted'], tags=(t,))
                    s.text(inner.x + px(240), inner.y, fmt_int(k[key]), self.F['small'], P['text'], tags=(t,))
                    inner.y += self.line_h['small'] + px(3)
                inner.y += px(8)
        self.panel(pg, 'Boss by boss', None, bosses_body)

    def history_attendance(self, pg):
        """Who came to which raid night: a row of dots per player, newest night on the right."""
        P, px = self.P, self.px
        nights = self.model.raid_nights()
        if not nights:
            return self.empty(pg, 'No raid nights yet.')
        keep = 8 if self.narrow else 16  # a phone fits half as many nights side by side
        all_n = len(nights)
        nights = nights[-keep:]
        counts = {}
        for n in nights:
            for name in n['roster']:
                counts[name] = counts.get(name, 0) + 1
        players = sorted(counts.items(), key=lambda kv: (-kv[1], kv[0].lower()))

        def body(inner):
            s = inner.s
            narrow = self.narrow
            name_w = px(112) if narrow else px(200)
            right_w = self.m('8/8 100%', 'small') + px(8) if narrow else px(130)
            dot_x = inner.x + name_w
            step = min(px(46), (inner.w - name_w - right_w) / max(1, len(nights)))
            label_every = max(1, int(-(-self.m('00/00', 'tiny') // max(1, step - px(4)))))
            for j, n in enumerate(nights):
                if (len(nights) - 1 - j) % label_every:
                    continue  # labels that wouldn't fit side by side: every other one, newest kept
                cx = dot_x + j * step + px(6)
                s.text(cx, inner.y, datetime.fromtimestamp(n['start'] / 1000).strftime('%m/%d'), self.F['tiny'], P['faint'], anchor='n')
            s.text(inner.x + inner.w, inner.y, 'Nights', self.F['smallsemi'], P['muted'], anchor='ne')
            inner.y += self.line_h['tiny'] + px(8)
            for name, c in players:
                cy = inner.y + px(10)
                s.text(inner.x, cy, name, self.F['semi'], self.who_color(name), anchor='w', maxw=name_w - px(10))
                for j, n in enumerate(nights):
                    cx = dot_x + j * step + px(6)
                    here = name in n['roster']
                    r = px(5)
                    s.cv.create_oval(cx - r, cy - r, cx + r, cy + r, fill=P['kill'] if here else P['surface2'], outline='' if here else P['line'])
                pct = round(100 * c / len(nights))
                full = P['kill'] if c == len(nights) else P['text']
                if narrow:
                    s.text(inner.x + inner.w, cy, f"{c}/{len(nights)} {pct}%", self.F['small'], full, anchor='e')
                else:
                    s.text(inner.x + inner.w, cy, f"{c} of {len(nights)} · {pct}%", self.F['base'], full, anchor='e')
                inner.y += px(24 if narrow else 22)
        self.panel(pg, f"{plural(len(nights), 'raid night')}" + (f' (latest {keep})' if all_n > keep else ''), None, body)

    def history_loot(self, pg):
        P, px = self.P, self.px
        per = self.model.loot_by_player()
        if not per:
            return self.empty(pg, 'No raid loot recorded yet. It comes from the chat log, so keep chat logging on.')
        for who, items in per:
            def body(inner, items=items):
                for l in sorted(items, key=lambda l: -l['ts']):
                    if self.narrow:  # item, then raid and day underneath
                        self.item_link(inner.s, inner.x, inner.y, l['name'], l['q'], maxw=inner.w)
                        inner.y += self.line_h['semi']
                        inner.s.text(inner.x, inner.y, f"{l['raid']} · {day(l['ts'])}", self.F['small'], P['muted'], maxw=inner.w)
                        inner.y += self.line_h['small'] + px(8)
                        continue
                    self.item_link(inner.s, inner.x, inner.y, l['name'], l['q'], maxw=inner.w - px(260))
                    inner.s.text(inner.x + inner.w, inner.y, f"{l['raid']} · {day(l['ts'])}", self.F['small'], P['muted'], anchor='ne')
                    inner.y += self.line_h['semi'] + px(5)
            self.panel(pg, f"{who} · {len(items)} item{'s' if len(items) != 1 else ''}", None, body)

    def view_settings(self, pg):
        P, px = self.P, self.px
        self.header(pg, 'Settings')

        def toggle_row(inner, label, sub, on, fn):
            t = inner.s.tag(fn)
            tw, th = px(36), px(20)
            ty = inner.y + px(4)
            inner.s.rr(inner.x, ty, inner.x + tw, ty + th, th / 2, P['arcane'] if on else P['surface2'], '' if on else P['line'], tags=(t,))
            kx = inner.x + tw - th / 2 if on else inner.x + th / 2
            inner.s.cv.create_oval(kx - px(7), ty + th / 2 - px(7), kx + px(7), ty + th / 2 + px(7), fill='#ffffff', outline='' if on else P['line'], tags=(t,))
            inner.s.text(inner.x + tw + px(12), inner.y + px(2), label, self.F['semi'], P['text'], tags=(t,))
            i = inner.s.text(inner.x + tw + px(12), inner.y + px(2) + self.line_h['semi'], sub, self.F['small'], P['muted'], wrap=inner.w - tw - px(12))
            inner.y = inner.s.cv.bbox(i)[3] + px(14)

        def reports(inner):
            toggle_row(inner, 'Save reports automatically', 'After each run and each session, a report, spreadsheet and CSV files are saved to the folder below.',
                       self.auto_save, lambda: self.set('auto_save', not self.auto_save, 'auto_save'))
            inner.s.text(inner.x, inner.y, 'Reports folder', self.F['smallsemi'], P['muted'])
            inner.y += self.line_h['smallsemi'] + px(6)
            inner.s.rr(inner.x, inner.y, inner.x + inner.w, inner.y + px(34), px(8), P['surface2'])
            inner.s.text(inner.x + px(12), inner.y + px(17), self.report_dir, self.F['mono'], P['text'], anchor='w', maxw=inner.w - px(24))
            inner.y += px(46)
            x = inner.x
            if not self.phone:  # a phone has no file manager to open from here
                w, _ = self.button(inner.s, x, inner.y, 'Open folder', lambda: (os.makedirs(self.report_dir, exist_ok=True), open_folder(self.report_dir)), small=True)
                x += w + px(8)
            self.button(inner.s, x, inner.y, 'Change folder…', self.pick_report_dir, small=True)
            inner.y += px(36)
        self.panel(pg, 'Reports', None, reports)

        def logs(inner):
            txt = ('The folder your WoW logs are in. Pick any one log file and Raidscribe reads every log in its folder.' if self.phone else
                   'The folder your WoW logs are in. Choose the World of Warcraft folder, or pick any one log file, and Raidscribe reads every log in that folder.')
            i = inner.s.text(inner.x, inner.y, txt, self.F['base'], P['muted'], wrap=inner.w)
            inner.y = inner.s.cv.bbox(i)[3] + px(8)
            picked = self.cfg.get('logs_dir', None)
            inner.s.rr(inner.x, inner.y, inner.x + inner.w, inner.y + px(34), px(8), P['surface2'])
            inner.s.text(inner.x + px(12), inner.y + px(17), self.logs_dir or 'Not found yet: choose it below', self.F['mono'],
                         P['text'] if self.logs_dir else P['muted'], anchor='w', maxw=inner.w - px(24))
            inner.y += px(46)
            x = self.folder_buttons(inner.s, inner.x, inner.y, small=True)
            if picked:
                self.button(inner.s, x, inner.y, 'Find it by itself', lambda: self.set_logs_dir(None), small=True)
            inner.y += px(36)
        self.panel(pg, 'Logs folder', None, logs)

        def appearance(inner):
            toggle_row(inner, 'Light theme', 'Switch between the dark and light look.', self.theme == 'light', self.toggle_theme)
        self.panel(pg, 'Appearance', None, appearance)

        def about(inner):
            mark = self.mark_image(px(48))
            x = inner.x
            if mark is not None:
                inner.s.cv.create_image(x, inner.y, image=mark, anchor='nw')
                x += mark.width() + px(14)
            inner.s.text(x, inner.y + px(2), 'Raidscribe', self.F['h2'], P['text'])
            inner.s.text(x, inner.y + px(2) + self.line_h['h2'] + px(2), self.version_text(), self.F['base'], P['muted'])
            inner.y += max(mark.height() if mark is not None else 0, self.line_h['h2'] + self.line_h['base'] + px(4)) + px(12)
            i = inner.s.text(inner.x, inner.y, 'A combat and chat log reader for World of Warcraft: Burning Crusade Classic Anniversary.',
                             self.F['base'], P['muted'], wrap=inner.w)
            inner.y = inner.s.cv.bbox(i)[3] + px(14)
            inner.s.text(inner.x, inner.y, 'Raidscribe’s licence', self.F['semi'], P['text'])
            inner.s.text(inner.x + inner.w, inner.y, 'GNU GPL 3.0', self.F['small'], P['faint'], anchor='ne')
            inner.y += self.line_h['semi'] + px(1)
            i = inner.s.text(inner.x, inner.y, 'Free software: you can share it and change it under the GNU General Public License 3.0. © 2026 kcham01.',
                             self.F['small'], P['muted'], wrap=inner.w)
            inner.y = inner.s.cv.bbox(i)[3] + px(8)
            self.button(inner.s, inner.x, inner.y, 'Source code on GitHub', lambda: webbrowser.open('https://github.com/kcham01/Raidscribe'), small=True)
            inner.y += px(28) + px(16)
            inner.s.text(inner.x, inner.y, 'Open-source software and data', self.F['smallsemi'], P['muted'])
            inner.y += self.line_h['smallsemi'] + px(8)
            credits = [('wow-classic-items', 'Item names, qualities and tooltips', 'MIT License'),
                       ('cMaNGOS TBC database', 'Consumable item data: item and spell IDs', 'GNU GPL 3.0'),
                       ('Python', 'Programming language and standard library', 'PSF License Agreement'),
                       ('Tcl/Tk', 'The window and its drawing', 'Tcl/Tk License')]
            if getattr(sys, 'frozen', False):
                credits.append(('PyInstaller', 'Packs Raidscribe into Raidscribe.exe', 'GPL 2.0 with the bootloader exception'))
            for name, what, lic in credits:
                inner.s.text(inner.x, inner.y, name, self.F['semi'], P['text'])
                inner.s.text(inner.x + inner.w, inner.y, lic, self.F['small'], P['faint'], anchor='ne')
                inner.y += self.line_h['semi'] + px(1)
                inner.s.text(inner.x, inner.y, what, self.F['small'], P['muted'])
                inner.y += self.line_h['small'] + px(9)
            notices = self.notices_file()
            if notices:
                inner.y += px(2)
                self.button(inner.s, inner.x, inner.y, 'View licences', lambda: open_folder(notices), small=True)
                inner.y += px(38)
            i = inner.s.text(inner.x, inner.y, 'World of Warcraft® and Blizzard Entertainment® are trademarks or registered trademarks of Blizzard '
                             'Entertainment, Inc. in the U.S. and/or other countries. Raidscribe is an independent project and is not affiliated '
                             'with or endorsed by Blizzard Entertainment.', self.F['small'], P['faint'], wrap=inner.w)
            inner.y = inner.s.cv.bbox(i)[3] + px(4)
        self.panel(pg, 'About', None, about)


    def pick_logs_dir(self):
        """Pick a log file rather than a folder: Tk's folder picker hides files, so a folder holding logs looks empty.
        Phones get Raidscribe's own browser (big rows to tap); a PC gets the normal file dialog."""
        here = self.script_dir()
        if self.phone:
            spots = (self.logs_dir, here, '/storage/emulated/0', os.path.expanduser('~'))
        else:   # where the logs are, else Documents (where WoW often is); never the app's own install folder
            spots = (self.logs_dir, os.path.dirname(os.path.normpath(self.logs_dir)) if self.logs_dir else '',
                     os.path.join(os.path.expanduser('~'), 'Documents'), os.path.expanduser('~'))
        start = next((d for d in spots if d and os.path.isdir(d)), None)
        if self.phone:
            self.browse_dir = start or here
            self.menu_open = False
            self.close_item()
            self.render()
            self.main.cv.yview_moveto(0)
            return
        try:
            from tkinter import filedialog
            f = filedialog.askopenfilename(initialdir=start, title='Pick one of your WoW logs (WoWCombatLog… or WoWChatLog…)',
                                           filetypes=[('WoW logs', 'WoWCombatLog*.txt WoWChatLog*.txt'), ('Text files', '*.txt'), ('All files', '*')])
        except Exception:
            f = None
        if not f:
            return
        name = os.path.basename(f).lower()
        if not (name.startswith(('wowcombatlog', 'wowchatlog')) and name.endswith('.txt')):
            self.show_toast('That isn\u2019t a WoW log. Pick a file named WoWCombatLog-….txt or WoWChatLog.txt.')
            return
        self.set_logs_dir(os.path.dirname(os.path.abspath(f)))

    def version_text(self):
        """'Version 1.0.0-beta (build 21)': the build number tells two test builds of the same version apart."""
        v, b = globals().get('APP_VERSION', 'dev'), globals().get('APP_BUILD', '')
        return f'Version {v}' + (f' (build {b})' if b else '')

    def notices_file(self):
        """THIRD-PARTY-NOTICES.txt (the licences of everything Raidscribe uses), installed next to the app."""
        dirs = [getattr(sys, '_MEIPASS', ''), os.path.dirname(os.path.abspath(sys.executable)) if getattr(sys, 'frozen', False) else '',
                self.script_dir()]
        for d in dirs:
            p = os.path.join(d, 'THIRD-PARTY-NOTICES.txt') if d else ''
            if p and os.path.isfile(p):
                return p
        return None

    def pick_wow_folder(self):
        """Choose the World of Warcraft folder (or _anniversary_, or Logs): Raidscribe works out the Logs folder from it."""
        start = next((d for d in (self.logs_dir and os.path.dirname(os.path.dirname(self.logs_dir)), self.logs_dir,
                                  os.path.join(os.path.expanduser('~'), 'Documents'), os.path.expanduser('~'))
                      if d and os.path.isdir(d)), None)
        try:
            from tkinter import filedialog
            d = filedialog.askdirectory(initialdir=start, mustexist=True, title='Choose your World of Warcraft folder')
        except Exception:
            d = None
        if not d:
            return
        find = globals().get('logs_in_choice')
        logs = find(d) if find else d
        if not logs:
            self.show_toast('No WoW logs there. Choose the World of Warcraft folder, or the _anniversary_\\Logs folder inside it.')
            return
        self.set_logs_dir(os.path.normpath(logs))

    def set_logs_dir(self, d):
        """Remembers the folder and starts reading it straight away."""
        self.cfg.set('logs_dir', d)
        target = d
        if not target:  # back to the default: worked out the same way as at start-up
            find = globals().get('logs_folder')
            target = find(os.path.dirname(self.cfg.path) if hasattr(self.cfg, 'path') else self.data_dir) if find else self.logs_dir
        if target and os.path.normpath(target) != os.path.normpath(self.logs_dir or '.'):
            self.switch_logs(target)
            self.show_toast(f'Reading logs from {target}')
        else:
            self.render(keep_scroll=True)

    def browse(self, d):
        self.browse_dir = d
        self.render()
        self.main.cv.yview_moveto(0)

    def view_browse(self, pg, d):
        """A file browser sized for fingers: folders and WoW logs only. Tap a folder to open it, tap a log to use its folder."""
        s, P, px = pg.s, self.P, self.px
        self.header(pg, 'Pick a log file', None, ['Folders and WoW logs only. Tap a log and Raidscribe reads every log in its folder.'])
        # where you are: the end of the path matters most, so a long one is cut at the start
        path = d
        while len(path) > 3 and self.m(path, 'mono') > pg.w - px(24):
            path = '…' + path[2:]
        s.rr(pg.x, pg.y, pg.x + pg.w, pg.y + px(34), px(8), P['surface2'])
        s.text(pg.x + px(12), pg.y + px(17), path, self.F['mono'], P['text'], anchor='w')
        pg.y += px(46)
        # shortcuts
        here = self.script_dir()
        spots = [('Raidscribe\u2019s folder', here), ('Internal storage', '/storage/emulated/0'), ('Download', '/storage/emulated/0/Download'),
                 ('Documents', '/storage/emulated/0/Documents'), ('Home', os.path.expanduser('~'))]
        spots = [(l, p) for l, p in spots if os.path.isdir(p)]
        seen = set()
        spots = [(l, p) for l, p in spots if not (os.path.realpath(p) in seen or seen.add(os.path.realpath(p)))]
        self.chips(s, pg.x, pg.y, [(p, l) for l, p in spots], d, self.browse, P['bg'], right=pg.x + pg.w)
        pg.y = self.chips_bottom + px(14)
        try:
            names = sorted(os.listdir(d), key=str.lower)
            err = None
        except OSError as ex:
            names, err = [], ex
        dirs = [n for n in names if not n.startswith('.') and os.path.isdir(os.path.join(d, n))]
        logs = [n for n in names if n.lower().startswith(('wowcombatlog', 'wowchatlog')) and n.lower().endswith('.txt')]
        other = len(names) - len(dirs) - len(logs)

        def body(inner):
            rows = []
            parent = os.path.dirname(d.rstrip('/\\')) or d
            if parent != d:
                rows.append(('up', '‹  Up one folder', os.path.basename(parent) or parent, P['muted'], lambda: self.browse(parent)))
            for n in logs:
                p = os.path.join(d, n)
                try:
                    st = os.stat(p)
                    info = f"{fmt_bytes(st.st_size)} · {datetime.fromtimestamp(st.st_mtime).strftime('%b %d, %I:%M %p').replace(' 0', ' ')}"
                except OSError:
                    info = ''
                rows.append(('log', n, info, P['arcane'], lambda p=p: (setattr(self, 'browse_dir', None), self.set_logs_dir(os.path.dirname(p)))))
            for n in dirs:
                rows.append(('dir', n, '', P['text'], lambda p=os.path.join(d, n): self.browse(p)))
            if err is not None:
                i = inner.s.text(inner.x, inner.y, 'Android won\u2019t let Python read this folder. Try Raidscribe\u2019s folder (the one Raidscribe.pyw is in) '
                                 'and copy your logs there.', self.F['base'], P['wipe'], wrap=inner.w)
                inner.y = inner.s.cv.bbox(i)[3] + px(12)
            for i, (icon, title, sub, col, fn) in enumerate(rows):
                if i:
                    inner.s.cv.create_line(inner.x, inner.y, inner.x + inner.w, inner.y, fill=P['line_soft'])
                t = inner.s.tag(fn)
                y0 = inner.y
                rh = px(48) if sub else px(40)
                bg = inner.s.cv.create_rectangle(inner.x, y0 + 1, inner.x + inner.w, y0 + rh, fill=P['surface'], outline='', tags=(t,))
                inner.s.hover(t, bg, P['surface'], P['hover_surface'])
                ty = y0 + (px(6) if sub else (rh - self.line_h['semi']) / 2)
                tx = inner.x + px(4)
                iy = ty + self.line_h['semi'] / 2
                if icon == 'dir':  # a little folder
                    inner.s.rr(tx, iy - px(6), tx + px(8), iy - px(3), px(1), P['muted'], tags=(t,))
                    inner.s.rr(tx, iy - px(4), tx + px(18), iy + px(8), px(2), P['muted'], tags=(t,))
                    tx += px(28)
                elif icon == 'log':  # a little page with lines
                    inner.s.rr(tx + px(2), iy - px(9), tx + px(16), iy + px(9), px(2), '', P['arcane'], width=max(1, px(1.4)), tags=(t,))
                    for k in (-4, 0, 4):
                        inner.s.cv.create_line(tx + px(5), iy + px(k), tx + px(13), iy + px(k), fill=P['arcane'], tags=(t,))
                    tx += px(28)
                inner.s.text(tx, ty, title, self.F['semi'], col, tags=(t,), maxw=inner.x + inner.w - tx - px(4))
                if sub:
                    inner.s.text(tx, ty + self.line_h['semi'], sub, self.F['small'], P['muted'], tags=(t,), maxw=inner.x + inner.w - tx - px(4))
                inner.y = y0 + rh
            if not logs and err is None:
                inner.y += px(10)
                txt = 'No WoW logs in this folder' + (f' ({plural(other, "other file")} hidden)' if other else '') + '.'
                i = inner.s.text(inner.x, inner.y, txt, self.F['small'], P['faint'], wrap=inner.w)
                inner.y = inner.s.cv.bbox(i)[3]
        self.panel(pg, None, None, body)
        self.button(s, pg.x, pg.y, 'Cancel', lambda: (setattr(self, 'browse_dir', None), self.render()), small=False)
        pg.y += px(50)

    def switch_logs(self, folder):
        """Stops reading the old folder and starts on the new one, without restarting the app."""
        old = self.w
        old.running = False
        new = type(old)(folder, old.cache_dir, old.Combat, old.Chat)
        self.w = new
        self.logs_dir = folder
        self.state, self.progress, self.error = 'starting', ('Starting', 0.0), None
        self.view = ('current', None)
        self.menu_open = False
        self.seen_watch = None
        for attr in ('_snap_key', '_watch_key', 'drawn_versions', '_act_key'):
            if hasattr(self, attr):
                delattr(self, attr)
        new.start()
        self.render()

    def pick_report_dir(self):
        try:
            from tkinter import filedialog
            d = filedialog.askdirectory(initialdir=self.report_dir, title='Where should Raidscribe save reports?')
        except Exception:
            d = None
        if d:
            self.set('report_dir', os.path.normpath(d), 'report_dir')


class Inner:
    """Content area inside a panel."""

    def __init__(self, pg, pad):
        self.s = pg.s
        self.x = pg.x + pad
        self.w = pg.w - 2 * pad
        self.y = pg.y

    def gap(self, n):
        self.y += self.s.app.px(n)
# ======================================================================
#  Start-up
# ======================================================================



IS_ANDROID = 'ANDROID_ROOT' in os.environ or 'ANDROID_DATA' in os.environ or hasattr(sys, 'getandroidapilevel')
# where a synced copy of the WoW Logs folder usually lands on a phone (Syncthing, OneDrive, Google Drive sync apps)
PHONE_LOGS = ['/storage/emulated/0/Raidscribe/Logs', '/storage/emulated/0/Documents/Raidscribe/Logs', '/storage/emulated/0/Logs',
              '/storage/emulated/0/Syncthing/Logs', '/storage/emulated/0/Sync/Logs', '/storage/emulated/0/Documents/Logs',
              '/storage/emulated/0/Download/Logs', '/sdcard/Raidscribe/Logs',
              '/storage/emulated/0/Leyline/Logs', '/storage/emulated/0/Documents/Leyline/Logs']  # the app's old name


def data_folder():
    if IS_ANDROID:
        new, old = os.path.join(os.path.expanduser('~'), '.raidscribe'), os.path.join(os.path.expanduser('~'), '.leyline')
    else:
        base = os.environ.get('LOCALAPPDATA') or os.path.join(os.path.expanduser('~'), '.local', 'share')
        new, old = os.path.join(base, 'Raidscribe'), os.path.join(base, 'Leyline')
    if not os.path.exists(new) and os.path.isdir(old):  # the app was called Leyline before: keep its settings and history
        try:
            os.rename(old, new)
        except OSError:
            return old
    return new


def script_folders():
    """The folder Raidscribe.pyw itself is in (on a phone: wherever Pydroid opened it from). Pydroid reports it in
    different ways depending on how the script was started, so every hint is tried."""
    out = []
    if getattr(sys, 'frozen', False):   # the installed Raidscribe.exe: its own folder
        out.append(os.path.dirname(os.path.abspath(sys.executable)))
    for p in (sys.argv[0] if sys.argv and sys.argv[0] else '', globals().get('__file__', '')):
        if p and os.path.isfile(p):
            out.append(os.path.dirname(os.path.abspath(p)))
    try:
        out.append(os.getcwd())
    except OSError:
        pass
    return list(dict.fromkeys(out)) or ['.']


def has_logs(folder):
    try:
        return any(is_combat(n) or is_chat(n) for n in os.listdir(folder))
    except OSError:
        return False


WOW_FLAVOR = '_anniversary_'   # the game's folder for the TBC Anniversary realms, inside World of Warcraft


def wow_roots():
    """Where World of Warcraft might be installed, most likely first: what Battle.net wrote in the registry, then the
    usual folders on every drive and in the user's own folders."""
    out = []
    if sys.platform == 'win32':
        try:
            import winreg
            keys = [(r'SOFTWARE\WOW6432Node\Blizzard Entertainment\World of Warcraft', 'InstallPath'),
                    (r'SOFTWARE\Blizzard Entertainment\World of Warcraft', 'InstallPath'),
                    (r'SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\World of Warcraft', 'InstallLocation'),
                    (r'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\World of Warcraft', 'InstallLocation')]
            for hive in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
                for key, value in keys:
                    try:
                        with winreg.OpenKey(hive, key) as k:
                            p = winreg.QueryValueEx(k, value)[0]
                    except OSError:
                        continue
                    if isinstance(p, str) and p.strip():
                        out.append(p.strip().strip('"'))
        except ImportError:
            pass
        for drive in 'CDEFGHIJKLMN':
            d = drive + ':\\'
            if not os.path.exists(d):
                continue
            for sub in ('Program Files (x86)', 'Program Files', 'Games', 'Blizzard', 'Battle.net', 'Blizzard Games', ''):
                out.append(os.path.join(d, sub, 'World of Warcraft'))
    home = os.path.expanduser('~')
    for base in (home, os.path.join(home, 'Documents'), os.path.join(home, 'OneDrive', 'Documents'), os.path.join(home, 'Games'),
                 os.path.join(home, 'Desktop')):
        out.append(os.path.join(base, 'World of Warcraft'))
    roots = []
    for p in out:
        p = os.path.normpath(p)
        name = os.path.basename(p)
        while name.startswith('_') and name.endswith('_') and len(name) > 2:   # the registry often names _retail_ or _classic_
            p = os.path.dirname(p)
            name = os.path.basename(p)
        if os.path.normcase(p) not in (os.path.normcase(r) for r in roots):
            roots.append(p)
    return roots


def find_wow_logs():
    """The WoW Logs folder for the Anniversary realms on this PC: one with logs in it if there is one, else the folder
    WoW will create on its first log. '' when WoW isn't found at all."""
    waiting = ''
    for root in wow_roots():
        flavor = os.path.join(root, WOW_FLAVOR)
        if not os.path.isdir(flavor):
            continue
        logs = os.path.join(flavor, 'Logs')
        if has_logs(logs):
            return logs
        waiting = waiting or logs
    return waiting


def logs_in_choice(path):
    """The Logs folder meant by a folder someone chose: the Logs folder itself, the game's _anniversary_ folder, the
    World of Warcraft folder, or anywhere holding WoW logs. None if it's none of those."""
    path = os.path.normpath(path)
    if has_logs(path):
        return path
    for cand in (os.path.join(path, WOW_FLAVOR, 'Logs'), os.path.join(path, 'World of Warcraft', WOW_FLAVOR, 'Logs'), os.path.join(path, 'Logs')):
        if has_logs(cand):
            return cand
    name = os.path.basename(path).lower()
    if name == 'logs' and os.path.isdir(path):
        return path
    if name == WOW_FLAVOR:
        return os.path.join(path, 'Logs')
    for flavor in (os.path.join(path, WOW_FLAVOR), os.path.join(path, 'World of Warcraft', WOW_FLAVOR)):
        if os.path.isdir(flavor):
            return os.path.join(flavor, 'Logs')   # WoW makes Logs on its first log
    return None


def logs_folder(data):
    """Where the logs are: a folder picked in Settings; else WoW logs sitting next to the app (or in a Logs folder
    beside it); else World of Warcraft's own Logs folder, found by itself, or the usual synced places on a phone.
    '' on a PC when none of those exist: the app then asks where WoW is."""
    try:
        with open(os.path.join(data, 'settings.json'), encoding='utf-8') as fh:
            picked = json.load(fh).get('logs_dir')
        if picked and os.path.isdir(picked):
            return picked
    except Exception:
        pass
    heres = script_folders()
    for here in heres:
        for d in (here, os.path.join(here, 'Logs')):
            if has_logs(d):
                return d
    if IS_ANDROID:
        return next((p for p in PHONE_LOGS if has_logs(p)), heres[0])
    return find_wow_logs()


def make_icons(root):
    """The window and taskbar icon: the Raidscribe mark at a few sizes, so Windows picks a sharp one."""
    return [tk.PhotoImage(master=root, data=MARK_PNG[s]) for s in (64, 48, 32, 16)]


def main():
    data = data_folder()
    folder = sys.argv[1] if len(sys.argv) > 1 else logs_folder(data)
    try:  # sharp text on high-DPI screens
        import ctypes
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception:
            ctypes.windll.user32.SetProcessDPIAware()
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('Raidscribe.LogReader')
    except Exception:
        pass
    root = tk.Tk()
    if IS_ANDROID:  # the whole screen
        root.geometry(f'{root.winfo_screenwidth()}x{root.winfo_screenheight()}+0+0')
    else:
        root.geometry(f'{int(1340 * root.winfo_fpixels("1i") / 96)}x{int(860 * root.winfo_fpixels("1i") / 96)}')
    try:
        icons = make_icons(root)
        root.iconphoto(True, *icons)
        root._icons = icons
    except Exception:
        pass
    watcher = Watcher(folder, os.path.join(data, 'cache'), CombatParser, ChatParser)
    app = App(root, watcher, folder, data, phone=IS_ANDROID)

    def report(exc, val, tb):
        app.log_error(''.join(traceback.format_exception(exc, val, tb)))
    root.report_callback_exception = report
    watcher.start()
    root.mainloop()
    watcher.running = False


if __name__ == '__main__':
    main()
