"""Tests Raidscribe on a real Windows machine, the way a person would use it (run by ci/windows.sh after the build).

Installs Raidscribe-Setup.exe silently, then starts the installed Raidscribe.exe again and again with a fresh
profile each time:
  - no WoW on the PC: the "Where's World of Warcraft?" screen, then Choose WoW folder... in the real Windows
    folder picker, a log copied in while it's open, Settings and About, View licences, closing and reopening
  - Pick a log file... in the real Windows file picker (and picking something that isn't a WoW log)
  - WoW found by itself: from the registry, from Program Files, and a WoW that hasn't saved a log yet
then uninstalls and checks nothing is left behind. Clicks are real mouse clicks; the app tells the test where
its buttons are and what's on screen through RAIDSCRIBE_STATE_FILE. Screenshots go to test-win/shots.
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import traceback
import winreg

from PIL import ImageGrab
from pywinauto import Application, Desktop, mouse, keyboard

V = sys.argv[1] if len(sys.argv) > 1 else '0.0.0'
ROOT = os.getcwd()
OUT = os.path.join(ROOT, 'test-win')
SHOTS = os.path.join(OUT, 'shots')
LOGS = os.path.join(ROOT, 'test', 'logs')
OLD_LOG, NEW_LOG, CHAT = 'WoWCombatLog-101926_190000.txt', 'WoWCombatLog-102226_193000.txt', 'WoWChatLog.txt'
APP_ID = '{620482ED-1406-4D08-969E-B7BBD7D12839}_is1'
INSTALL = os.path.join(os.environ['LOCALAPPDATA'], 'Programs', 'Raidscribe')
EXE = os.path.join(INSTALL, 'Raidscribe.exe')
TEST = r'C:\rs-test'
os.makedirs(SHOTS, exist_ok=True)

results = []


def check(name, ok, detail=''):
    results.append([name, bool(ok), str(detail)[:500]])
    print(('PASS ' if ok else 'FAIL ') + name + (f'  [{str(detail)[:300]}]' if detail != '' else ''), flush=True)
    return bool(ok)


def shot(name):
    try:
        ImageGrab.grab(all_screens=True).save(os.path.join(SHOTS, name + '.png'))
    except Exception as ex:
        print('screenshot failed:', ex)


def make_wow(root, logs=(OLD_LOG, CHAT), make_logs=True):
    """A pretend World of Warcraft folder: <root>/_anniversary_/Logs with some of the test logs in it."""
    flavor = os.path.join(root, '_anniversary_')
    os.makedirs(flavor, exist_ok=True)
    os.makedirs(os.path.join(root, '_retail_'), exist_ok=True)
    logs_dir = os.path.join(flavor, 'Logs')
    if make_logs:
        os.makedirs(logs_dir, exist_ok=True)
        for n in logs:
            shutil.copy(os.path.join(LOGS, n), logs_dir)
    return logs_dir


def same(a, b):
    return bool(a) and bool(b) and os.path.normcase(os.path.normpath(a)) == os.path.normcase(os.path.normpath(b))


class RunningApp:
    """The installed Raidscribe.exe, started with its own empty profile (settings, history cache)."""

    def __init__(self, label, profile=None):
        self.label = label
        self.profile = profile or tempfile.mkdtemp(prefix='rs-profile-')
        self.state_file = os.path.join(self.profile, 'state.json')
        env = dict(os.environ, LOCALAPPDATA=self.profile, RAIDSCRIBE_STATE_FILE=self.state_file)
        if os.path.exists(self.state_file):
            os.remove(self.state_file)
        self.proc = subprocess.Popen([EXE], env=env, cwd=INSTALL)
        self.win = None
        st = self.wait(lambda s: True, 40, 'window up')
        if st is None:
            return
        try:
            self.app = Application(backend='win32').connect(process=self.proc.pid, timeout=20)
            self.win = self.app.top_window()
            t = time.time()
            self.win.maximize()
            self.focus()
            self.wait(lambda s: s['time'] > t + 0.3, 10, 'redrawn after maximise', quiet=True)
        except Exception as ex:
            check(f'{label}: window found', False, ex)

    def focus(self):
        try:
            self.win.set_focus()
        except Exception:
            pass

    def state(self):
        try:
            with open(self.state_file, encoding='utf-8') as fh:
                return json.load(fh)
        except Exception:
            return None

    def wait(self, pred, timeout, what='', quiet=False):
        end = time.time() + timeout
        last = None
        while time.time() < end:
            if self.proc.poll() is not None:
                check(f'{self.label}: app still running ({what})', False, f'exited with {self.proc.returncode}')
                return None
            s = self.state()
            if s:
                last = s
                try:
                    if pred(s):
                        return s
                except Exception:
                    pass
            time.sleep(0.4)
        if not quiet:
            summary = {k: last.get(k) for k in ('state', 'logs_dir', 'view', 'toast')} if last else None
            check(f'{self.label}: {what}', False, f'timed out; last state {summary}')
        return None

    def button(self, label):
        s = self.state() or {}
        return next((b for b in s.get('buttons', []) if b['label'] == label), None)

    def click_button(self, label):
        self.focus()
        b = self.button(label)
        if not b:
            return check(f'{self.label}: button "{label}" on screen', False, [x['label'] for x in (self.state() or {}).get('buttons', [])])
        mouse.click(coords=(b['x'], b['y']))
        return True

    def click_text(self, where, text):
        self.focus()
        s = self.state() or {}
        t = next((t for t in s.get('targets', []) if t['where'] == where and t['text'] == text and t['visible']), None)
        if not t:
            return check(f'{self.label}: "{text}" on screen', False, '')
        mouse.click(coords=(t['x'], t['y']))
        return True

    def scroll_main(self, steps):
        s = self.state() or {}
        t = next((t for t in s.get('targets', []) if t['where'] == 'main' and t['visible']), None)
        if t:
            mouse.scroll(coords=(t['x'], t['y']), wheel_dist=steps)
            time.sleep(2)   # the app rewrites where everything is once a second

    def errors(self):
        p = os.path.join(self.profile, 'Raidscribe', 'errors.log')
        return open(p, encoding='utf-8', errors='replace').read()[-1500:] if os.path.exists(p) else ''

    def close(self):
        """Closes the window like the X button does and checks the app actually exits."""
        try:
            if self.win is not None:
                self.win.close()
            self.proc.wait(15)
            ok = True
        except Exception as ex:
            ok = False
            self.proc.kill()
        check(f'{self.label}: closes cleanly', ok)
        err = self.errors()
        check(f'{self.label}: no errors logged', not err, err)


def find_hwnd(title_start):
    """A visible window whose title starts with title_start, from the plain Windows window list. A picker opened
    by the app belongs to the app's window, so UI Automation doesn't list it with the top-level windows; this does."""
    import ctypes
    from ctypes import wintypes
    user32 = ctypes.windll.user32
    found = []

    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def each(hwnd, _):
        if user32.IsWindowVisible(hwnd):
            n = user32.GetWindowTextLengthW(hwnd)
            buf = ctypes.create_unicode_buffer(n + 1)
            user32.GetWindowTextW(hwnd, buf, n + 1)
            if buf.value.startswith(title_start):
                found.append(hwnd)
        return True
    user32.EnumWindows(each, 0)
    return found[0] if found else None


def dialog(title_start, timeout=20):
    """The Windows folder/file picker the app opened, as a pywinauto window (win32), or None."""
    end = time.time() + timeout
    while time.time() < end:
        h = find_hwnd(title_start)
        if h:
            time.sleep(0.8)   # let it finish drawing
            return Application(backend='win32').connect(handle=h).window(handle=h).wrapper_object()
        time.sleep(0.4)
    return None


def still_open(dlg):
    try:
        return dlg.is_visible()
    except Exception:
        return False


def dump(dlg, name):
    try:
        lines = []
        for w in dlg.descendants():
            try:
                r = w.rectangle()
                lines.append(f'{w.class_name()!r:28} id={w.control_id():<6} visible={w.is_visible()!s:5} '
                             f'rect=({r.left},{r.top},{r.right},{r.bottom}) text={w.window_text()!r}')
            except Exception as ex:
                lines.append(f'? {ex}')
        with open(os.path.join(OUT, name), 'w', encoding='utf-8') as fh:
            fh.write('\n'.join(lines))
    except Exception as ex:
        print('dump failed', ex)


def name_box(dlg):
    """The Folder: / File name: box: an Edit inside the combo box with id 1148 (file) or 1152 (folder) in every
    Windows picker; failing that, the visible Edit lowest down in the dialog."""
    edits = [w for w in dlg.descendants(class_name='Edit') if w.is_visible()]
    for e in edits:
        try:
            if e.control_id() in (1148, 1152) or e.parent().control_id() in (1148, 1152):
                return e
        except Exception:
            pass
    return max(edits, key=lambda e: e.rectangle().top) if edits else None


def press_ok(dlg):
    """Presses Select Folder / Open (the button with id 1, IDOK) the way Windows' own automation does."""
    for b in dlg.descendants(class_name='Button'):
        try:
            if b.control_id() == 1 and b.is_visible():
                b.click()
                return True
        except Exception:
            pass
    return False


def fill_and_ok(dlg, field, path, label):
    """Puts a path in the picker's Folder:/File name: box and presses Select Folder / Open, like a person would."""
    try:
        box = name_box(dlg)
        if box is None:
            raise RuntimeError('no name box')
        box.set_edit_text(path)
        time.sleep(0.5)
        shot(label)
        if not press_ok(dlg):
            raise RuntimeError('no OK button')
    except Exception as ex:
        dump(dlg, label + '-controls.txt')
        print('filling the picker failed, typing instead:', ex)
        try:
            dlg.set_focus()   # the name box has the cursor when a picker opens
            keyboard.send_keys('^a' + path.replace('{', '{{}').replace('}', '{}}').replace('+', '{+}').replace('%', '{%}')
                               .replace('^', '{^}').replace('~', '{~}').replace('(', '{(}').replace(')', '{)}'), with_spaces=True)
            keyboard.send_keys('{ENTER}')
        except Exception as ex2:
            print('typing failed too:', ex2)
    # a folder picker can open the typed folder instead of choosing it: press Select Folder again (it then
    # chooses the folder it's showing)
    for _ in range(3):
        time.sleep(1.5)
        if not still_open(dlg):
            return True
        press_ok(dlg)
    if still_open(dlg):
        dump(dlg, label + '-controls.txt')
        shot(label + '-stuck')
        for b in dlg.descendants(class_name='Button'):   # Cancel (id 2), so the app isn't left waiting
            try:
                if b.control_id() == 2:
                    b.click()
            except Exception:
                pass
        return False
    return True


def file_version(path, what):
    import win32api
    try:
        return win32api.GetFileVersionInfo(path, '\\StringFileInfo\\040904B0\\' + what)
    except Exception as ex:
        return f'? ({ex})'


def reg_value(hive, key, name):
    try:
        with winreg.OpenKey(hive, key) as k:
            return winreg.QueryValueEx(k, name)[0]
    except OSError:
        return None


def main():
    shutil.rmtree(TEST, ignore_errors=True)
    os.makedirs(TEST)

    # ---------------------------------------------------------------- what was built
    built = os.path.join(ROOT, 'build', 'dist', 'Raidscribe', 'Raidscribe.exe')
    check('Raidscribe.exe built', os.path.isfile(built))
    check('exe says it is Raidscribe ' + V, file_version(built, 'ProductName') == 'Raidscribe' and file_version(built, 'ProductVersion') == V,
          (file_version(built, 'ProductName'), file_version(built, 'ProductVersion')))
    import ctypes
    icons = ctypes.windll.shell32.ExtractIconExW(built, -1, None, None, 0)
    check('exe has the Raidscribe icon', icons >= 1, icons)
    notices = os.path.join(ROOT, 'build', 'dist', 'Raidscribe', 'THIRD-PARTY-NOTICES.txt')
    text = open(notices, encoding='utf-8').read() if os.path.exists(notices) else ''
    check('licence notices complete', all(k in text for k in ('wow-classic-items', 'cMaNGOS', 'Python', 'Tcl', 'Tk', 'PyInstaller')),
          [k for k in ('wow-classic-items', 'cMaNGOS', 'Python', 'Tcl', 'Tk', 'PyInstaller') if k not in text])
    setup = next((os.path.join(ROOT, 'out', n) for n in os.listdir(os.path.join(ROOT, 'out')) if n.startswith('Raidscribe-Setup-')), None)
    check('installer built', setup and os.path.getsize(setup) > 3_000_000, setup and os.path.getsize(setup))
    check('installer is named for this version', setup and setup.endswith(f'Raidscribe-Setup-{V}.exe'), setup)
    check('portable zip built', os.path.isfile(os.path.join(ROOT, 'out', f'Raidscribe-{V}-portable.zip')))
    if not setup:
        return

    # ---------------------------------------------------------------- install
    r = subprocess.run([setup, '/VERYSILENT', '/SUPPRESSMSGBOXES', '/NORESTART', '/CURRENTUSER', '/TASKS=desktopicon',
                        '/LOG=' + os.path.join(OUT, 'install.log')], timeout=300)
    check('installs without asking for admin', r.returncode == 0, r.returncode)
    check('installed in AppData\\Local\\Programs\\Raidscribe', os.path.isfile(EXE), EXE)
    import win32com.client
    shell = win32com.client.Dispatch('WScript.Shell')
    start_lnk = os.path.join(shell.SpecialFolders('Programs'), 'Raidscribe.lnk')
    desk_lnk = os.path.join(shell.SpecialFolders('Desktop'), 'Raidscribe.lnk')
    check('Start menu shortcut', os.path.isfile(start_lnk) and same(shell.CreateShortCut(start_lnk).Targetpath, EXE), start_lnk)
    check('desktop shortcut (ticked)', os.path.isfile(desk_lnk), desk_lnk)
    ukey = r'Software\Microsoft\Windows\CurrentVersion\Uninstall' + '\\' + APP_ID
    entry = {n: reg_value(winreg.HKEY_CURRENT_USER, ukey, n) for n in ('DisplayName', 'DisplayVersion', 'Publisher', 'DisplayIcon')}
    check('listed in Settings > Apps with name, version, icon',
          entry['DisplayName'] == 'Raidscribe' and entry['DisplayVersion'] == V and entry['Publisher'] == 'Raidscribe'
          and (entry['DisplayIcon'] or '').lower().startswith(EXE.lower()), entry)

    # ---------------------------------------------------------------- first start, no WoW on this PC
    wow_a = os.path.join(TEST, 'My Games', 'World of Warcraft')
    logs_a = make_wow(wow_a)
    a = RunningApp('first start')
    s = a.wait(lambda s: s['state'] == 'missing', 30, 'shows the no-WoW screen')
    if s:
        check('first start: asks where WoW is', not s['logs_dir'] and 'Where’s World of Warcraft?' in s['main'], s['main'][:3])
        check('first start: both buttons', {'Choose WoW folder…', 'Pick a log file…'} <= {b['label'] for b in s['buttons']},
              [b['label'] for b in s['buttons']])
        check('window title is Raidscribe', s['title'] == 'Raidscribe', s['title'])
        s = a.wait(lambda s: s['items'] > 20000, 30, 'item details loaded')
        if s:
            check('item details loaded', True, s['items'])
    shot('01-first-start-no-wow')
    a.click_button('Choose WoW folder…')
    dlg = dialog('Choose your World of Warcraft folder')
    check('Choose WoW folder… opens the Windows folder picker', dlg is not None)
    if dlg:
        shot('02-folder-picker')
        check('folder picker: chose World of Warcraft', fill_and_ok(dlg, 'Folder:', wow_a, '02b-folder-typed'))
    s = a.wait(lambda s: s['state'] == 'ready' and 'Karazhan' in ' '.join(s['nav']), 90, 'reads the chosen folder')
    if s:
        check('chosen WoW folder becomes its _anniversary_\\Logs', same(s['logs_dir'], logs_a), s['logs_dir'])
    shot('03-after-choosing-folder')
    cfg = os.path.join(a.profile, 'Raidscribe', 'settings.json')
    saved = json.load(open(cfg, encoding='utf-8')).get('logs_dir') if os.path.exists(cfg) else None
    check('choice remembered in settings', same(saved, logs_a), saved)
    shutil.copy(os.path.join(LOGS, NEW_LOG), logs_a)
    s = a.wait(lambda s: "Gruul's Lair" in s['nav'], 90, 'a log copied in while open is read')
    if s:
        check('log copied in while open is read', True)
        a.click_text('nav', "Gruul's Lair")
        s = a.wait(lambda s: s['view'][0] == 'run' and "Gruul's Lair" in s['main'], 20, 'opens the Gruul run')
        if s:
            check('run page shows damage and bosses', 'Damage' in s['main'] and 'High King Maulgar' in ' '.join(s['main']), s['main'][:12])
        shot('04-gruul-run')
    a.click_text('nav', 'Settings')
    s = a.wait(lambda s: s['view'][0] == 'settings', 20, 'opens Settings')
    if s:
        check('Settings shows the logs folder and both pickers', same(s['logs_dir'], logs_a) and
              {'Pick a log file…', 'Choose WoW folder…', 'Find it by itself'} <= {b['label'] for b in s['buttons']},
              [b['label'] for b in s['buttons']])
        check('About shows the version', f'Version {V}' in s['main'], [t for t in s['main'] if t.startswith('Version')])
        check('About credits PyInstaller and Tcl/Tk', 'PyInstaller' in s['main'] and 'Tcl/Tk' in s['main'])
        check('licence file found by the app', bool(s['notices']), s['notices'])
        shot('05-settings')
        a.scroll_main(-30)
        shot('06-settings-about')
        if a.click_button('View licences'):
            end, found = time.time() + 20, None
            while time.time() < end and not found:
                found = next((w for w in Desktop(backend='win32').windows() if 'THIRD-PARTY-NOTICES' in (w.window_text() or '')), None)
                time.sleep(0.5)
            check('View licences opens the licence file', found is not None)
            shot('07-licences-open')
            subprocess.run(['taskkill', '/F', '/IM', 'notepad.exe'], capture_output=True)
    a.close()
    b = RunningApp('reopened', profile=a.profile)
    s = b.wait(lambda s: s['state'] == 'ready', 60, 'opens straight to the chosen folder')
    if s:
        check('reopened: same folder, no question asked', same(s['logs_dir'], logs_a), s['logs_dir'])
    shot('08-reopened')
    b.close()

    # ---------------------------------------------------------------- Pick a log file…
    elsewhere = os.path.join(TEST, 'Copied logs')
    os.makedirs(elsewhere)
    shutil.copy(os.path.join(LOGS, NEW_LOG), elsewhere)
    open(os.path.join(TEST, 'notes.txt'), 'w').write('not a log')
    c = RunningApp('pick a file')
    c.wait(lambda s: s['state'] == 'missing', 30, 'shows the no-WoW screen')
    c.click_button('Pick a log file…')
    dlg = dialog('Pick one of your WoW logs')
    check('Pick a log file… opens the Windows file picker', dlg is not None)
    if dlg:
        fill_and_ok(dlg, 'File name:', os.path.join(TEST, 'notes.txt'), '09-picked-wrong-file')
        s = c.wait(lambda s: (s.get('toast') or '').startswith('That isn’t a WoW log'), 15, 'explains a file that isn’t a WoW log')
        if s:
            check('a file that isn’t a log is refused with a reason', True)
        shot('10-not-a-log')
        c.click_button('Pick a log file…')
        dlg = dialog('Pick one of your WoW logs')
        if dlg:
            shot('11-file-picker')
            fill_and_ok(dlg, 'File name:', os.path.join(elsewhere, NEW_LOG), '11b-file-typed')
    s = c.wait(lambda s: s['state'] == 'ready' and "Gruul's Lair" in s['nav'], 90, 'reads the picked file’s folder')
    if s:
        check('picked file: its folder is read', same(s['logs_dir'], elsewhere), s['logs_dir'])
    shot('12-after-picking-file')
    c.close()

    # ---------------------------------------------------------------- WoW found by itself
    reg_root = os.path.join(TEST, 'Registry Install', 'World of Warcraft')
    logs_r = make_wow(reg_root, logs=(NEW_LOG, CHAT))
    key = r'Software\Blizzard Entertainment\World of Warcraft'
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, key) as k:
        winreg.SetValueEx(k, 'InstallPath', 0, winreg.REG_SZ, os.path.join(reg_root, '_retail_') + '\\')
    d = RunningApp('found from the registry')
    s = d.wait(lambda s: s['state'] == 'ready', 60, 'finds WoW from the registry')
    if s:
        check('registry: finds _anniversary_\\Logs by itself', same(s['logs_dir'], logs_r), s['logs_dir'])
    shot('13-found-from-registry')
    d.close()
    winreg.DeleteKey(winreg.HKEY_CURRENT_USER, key)

    pf = os.path.join(os.environ.get('ProgramFiles(x86)', r'C:\Program Files (x86)'), 'World of Warcraft')
    made_pf = not os.path.exists(pf)
    try:
        # WoW installed, but logging never turned on: no Logs folder yet
        logs_pf = make_wow(pf, make_logs=False)
        e = RunningApp('WoW without logs yet')
        s = e.wait(lambda s: s['state'] == 'missing' and s['logs_dir'], 30, 'waits for WoW’s first log')
        if s:
            check('no logs yet: points at where they will be', same(s['logs_dir'], logs_pf), s['logs_dir'])
            check('no logs yet: says how to turn logging on', any('/combatlog' in t for t in s['main']), s['main'][:4])
            check('no logs yet: says it is waiting, not that something is wrong', 'Waiting for WoW’s first log' in s['main'], s['main'][:2])
        shot('14-wow-without-logs')
        os.makedirs(logs_pf, exist_ok=True)
        for n in (OLD_LOG, CHAT):
            shutil.copy(os.path.join(LOGS, n), logs_pf)
        s = e.wait(lambda s: s['state'] == 'ready' and 'Karazhan' in ' '.join(s['nav']), 60, 'picks up the first log by itself')
        if s:
            check('first log appears: read without restarting', True)
        shot('15-first-log-appeared')
        e.close()
        f = RunningApp('found in Program Files')
        s = f.wait(lambda s: s['state'] == 'ready', 60, 'finds WoW in Program Files')
        if s:
            check('Program Files: found by itself', same(s['logs_dir'], logs_pf), s['logs_dir'])
        shot('16-found-in-program-files')
        f.close()
    finally:
        if made_pf:
            shutil.rmtree(pf, ignore_errors=True)

    # ---------------------------------------------------------------- uninstall
    unins = os.path.join(INSTALL, 'unins000.exe')
    check('uninstaller installed', os.path.isfile(unins))
    if os.path.isfile(unins):
        subprocess.run([unins, '/VERYSILENT', '/SUPPRESSMSGBOXES', '/NORESTART'], timeout=120)
        end = time.time() + 90
        while time.time() < end and (os.path.exists(EXE) or reg_value(winreg.HKEY_CURRENT_USER, ukey, 'DisplayName')):
            time.sleep(1)
        check('uninstall removes the app', not os.path.exists(EXE))
        check('uninstall removes the shortcuts', not os.path.exists(start_lnk) and not os.path.exists(desk_lnk))
        check('uninstall removes it from Settings > Apps', reg_value(winreg.HKEY_CURRENT_USER, ukey, 'DisplayName') is None)


if __name__ == '__main__':
    try:
        main()
    except Exception:
        check('test ran to the end', False, traceback.format_exc())
        shot('99-crash')
    passed = sum(1 for r in results if r[1])
    print(f'{passed}/{len(results)} checks passed')
    with open(os.path.join(OUT, 'results.json'), 'w', encoding='utf-8') as fh:
        json.dump({'version': V, 'passed': passed, 'total': len(results), 'checks': results}, fh, indent=1)
    sys.exit(0 if results and passed == len(results) else 1)
