"""Gets everything ready for PyInstaller (run by ci/windows.sh on the Windows build machine):
build/Raidscribe.pyw with the version stamped in, build/version_info.txt (the version details Windows shows in
the .exe's Properties), and build/THIRD-PARTY-NOTICES.txt (the licence of everything the app includes)."""
import glob
import os
import sys
from importlib import metadata

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
BUILD = os.path.join(ROOT, 'build')
version = os.environ.get('VERSION_NAME', '0.0.0')            # what people see, e.g. 1.0.0-beta
build = os.environ.get('BUILD_NUMBER', '0')                  # GitHub's build number, e.g. 21
os.makedirs(BUILD, exist_ok=True)

# the app, with its version
src = open(os.path.join(HERE, 'Raidscribe.pyw'), encoding='utf-8').read()
assert 'APP_VERSION = "dev"' in src, 'APP_VERSION line not found'
src = src.replace('APP_VERSION = "dev"', f'APP_VERSION = "{version}"', 1).replace('APP_BUILD = ""', f'APP_BUILD = "{build}"', 1)
open(os.path.join(BUILD, 'Raidscribe.pyw'), 'w', encoding='utf-8').write(src)

# version details for Raidscribe.exe > Properties > Details
import re
nums = tuple(int(n) for n in (re.findall(r'\d+', version.split('-')[0])[:3] + ['0', '0', '0'])[:3]) + (int(build or 0),)
info = f'''VSVersionInfo(
  ffi=FixedFileInfo(filevers={nums}, prodvers={nums}, mask=0x3f, flags=0x0, OS=0x40004, fileType=0x1, subtype=0x0, date=(0, 0)),
  kids=[
    StringFileInfo([StringTable('040904B0', [
      StringStruct('CompanyName', 'Raidscribe'),
      StringStruct('FileDescription', 'Raidscribe'),
      StringStruct('FileVersion', '{version} (build {build})'),
      StringStruct('InternalName', 'Raidscribe'),
      StringStruct('LegalCopyright', 'Raidscribe. World of Warcraft is a trademark of Blizzard Entertainment, Inc.'),
      StringStruct('OriginalFilename', 'Raidscribe.exe'),
      StringStruct('ProductName', 'Raidscribe'),
      StringStruct('ProductVersion', '{version}')])]),
    VarFileInfo([VarStruct('Translation', [1033, 1200])])
  ]
)
'''
open(os.path.join(BUILD, 'version_info.txt'), 'w', encoding='utf-8').write(info)


# licences: what Raidscribe.exe has inside it
def read(path):
    with open(path, encoding='utf-8', errors='replace') as fh:
        return fh.read().strip()


def first(patterns):
    for pat in patterns:
        for p in sorted(glob.glob(pat)):
            if os.path.isfile(p):
                return p
    return None


base = sys.base_prefix
tcl = first([os.path.join(base, 'tcl', 'tcl8*', 'license.terms'), os.path.join(base, 'tcl', '*', 'license.terms')])
tk = first([os.path.join(base, 'tcl', 'tk8*', 'license.terms')])
pyinst = None
try:
    files = metadata.files('pyinstaller') or []
    for f in files:
        if os.path.basename(str(f)).upper().startswith('COPYING'):
            pyinst = str(f.locate())
            break
except metadata.PackageNotFoundError:
    pass

parts = [
    ('Raidscribe', 'A combat and chat log reader for World of Warcraft: Burning Crusade Classic Anniversary.\n\n'
     'Copyright (C) 2026 kcham01. Raidscribe is free software: you can redistribute it and/or modify it under the terms of '
     'the GNU General Public License as published by the Free Software Foundation, version 3. It is distributed in the hope '
     'that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A '
     'PARTICULAR PURPOSE. See the licence below for details. Source code: https://github.com/kcham01/Raidscribe\n\n'
     'World of Warcraft and Blizzard Entertainment are trademarks or registered trademarks of Blizzard Entertainment, Inc. '
     'in the U.S. and/or other countries. Raidscribe is an independent project and is not affiliated with or endorsed by '
     'Blizzard Entertainment.\n\nRaidscribe includes the following open-source software and data. Their licences follow, '
     'after Raidscribe\'s own.'),
    ('Raidscribe: GNU General Public License 3.0', read(os.path.join(HERE, 'licenses', 'GPL-3.0.txt'))),
    ('wow-classic-items (item names, qualities and tooltips): MIT License', read(os.path.join(HERE, 'licenses', 'wow-classic-items.txt'))),
    ('cMaNGOS TBC database (consumable item data: item and spell IDs): GNU General Public License 3.0\n'
     'Source: https://github.com/cmangos/tbc-db', read(os.path.join(HERE, 'licenses', 'GPL-3.0.txt'))),
    (f'Python {sys.version.split()[0]}: PSF License Agreement',
     read(pylic) if (pylic := first([os.path.join(base, 'LICENSE.txt'), os.path.join(base, 'LICENSE')])) else 'https://docs.python.org/3/license.html'),
]
if tcl:
    parts.append(('Tcl (the window toolkit Tk runs on): Tcl/Tk License', read(tcl)))
if tk:
    parts.append(('Tk (the window and its drawing): Tcl/Tk License', read(tk)))
parts.append(('PyInstaller (packs Raidscribe into Raidscribe.exe): GPL 2.0 with the bootloader exception, which allows '
              'programs built with it to use any licence', read(pyinst) if pyinst else 'https://github.com/pyinstaller/pyinstaller/blob/develop/COPYING.txt'))
line = '=' * 78
out = '\n\n'.join(f'{line}\n{title}\n{line}\n\n{text}' for title, text in parts) + '\n'
open(os.path.join(BUILD, 'THIRD-PARTY-NOTICES.txt'), 'w', encoding='utf-8').write(out)
print(f'prepared version {version}: tcl={bool(tcl)} tk={bool(tk)} pyinstaller-licence={bool(pyinst)}')
