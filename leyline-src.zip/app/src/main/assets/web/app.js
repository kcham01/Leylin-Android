'use strict';
/* Leyline for Android: the screens. Data comes from the Python side (api.py) through call(); nothing here does
   number-crunching, it only lays things out for a phone. */

// ---------------------------------------------------------------- bridge
const N = window.LeylineAndroid || null;          // the app's Kotlin side, when running inside the APK
const pending = {};
let seq = 0;
window.__nativeLog = [];                         // what would have gone to Android (tests read this in a browser)
function call(name, args = {}) {
  return new Promise((resolve, reject) => {
    if (N) {
      const id = ++seq;
      pending[id] = { resolve, reject };
      N.call(id, name, JSON.stringify(args));
    } else {
      fetch('/call/' + name, { method: 'POST', body: JSON.stringify(args) })
        .then(r => r.json()).then(j => j.error ? reject(j.error) : resolve(j.ok)).catch(reject);
    }
  });
}
const native = {
  copy(text) { window.__nativeLog.push(['copy', text]); if (N) return N.copyText(text); try { navigator.clipboard.writeText(text).catch(() => {}); } catch (e) {} return true; },
  shareImage(dataUrl, title) { window.__nativeLog.push(['shareImage', title, dataUrl.length]); if (N) N.shareImage(dataUrl.split(',')[1], title); },
  openUrl(url) { window.__nativeLog.push(['openUrl', url]); if (N) N.openUrl(url); },
  alert(sound) { window.__nativeLog.push(['alert', sound]); if (N) N.alert(!!sound); },
  hasStorage() { return N ? N.hasStorage() : true; },
  askStorage() { window.__nativeLog.push(['askStorage']); if (N) N.askStorage(); },
  version() { return N ? N.version() : 'dev'; },
  setTheme(t) { if (N && N.setTheme) N.setTheme(t); },
};

// ---------------------------------------------------------------- helpers
const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const enc = encodeURIComponent, dec = decodeURIComponent;
const CLASS = { WARRIOR: '#C69B6D', PALADIN: '#F48CBA', HUNTER: '#AAD372', ROGUE: '#FFF468', PRIEST: '#F2F2F2', SHAMAN: '#0070DD',
  MAGE: '#3FC7EB', WARLOCK: '#8788EE', DRUID: '#FF7C0A', DEATHKNIGHT: '#C41E3A' };
const QUAL = { dark: ['#9d9d9d', null, '#1eff00', '#2f8fff', '#b048f8', '#ff8000', '#e6cc80'], light: ['#8a8a8a', null, '#12a000', '#0a6fd6', '#8a2be2', '#d96a00', '#a8894a'] };
const CHANNEL = {
  dark: { raid: '#ff7f00', raidwarning: '#ff4709', party: '#a8a8ff', guild: '#40ff40', officer: '#40c040', whisper: '#ff80ff', yell: '#ff4040', instance: '#ff7f00', channel: '#ffc0c0', say: '#e9e7f5', system: '#e9d36a' },
  light: { raid: '#c25e00', raidwarning: '#d43a00', party: '#5050d0', guild: '#1f8a1f', officer: '#1f7a1f', whisper: '#b03fb0', yell: '#d02020', instance: '#c25e00', channel: '#b3566a', say: '#1d1b2f', system: '#8a6d00' } };
function css(v) { return getComputedStyle(document.documentElement).getPropertyValue('--' + v).trim(); }
function cc(cls) {
  if (cls === 'PRIEST' && S.theme === 'light') return '#8d8aa6';
  if (cls === 'ROGUE' && S.theme === 'light') return '#c9b800';
  if (!CLASS[cls]) return null;
  return S.theme === 'light' ? mix(CLASS[cls], '#000000', .72) : CLASS[cls];   // class colours are made for dark backgrounds
}
function nameColor(cls, fallback) { return cc(cls) || fallback || 'var(--text)'; }
function who(name, cls, extra = '') { return `<span class="semi" style="color:${nameColor(cls)}" ${extra}>${esc(name)}</span>`; }
function qcol(q) { return q == null ? css('text') : (QUAL[S.theme][q] || css('text')); }
function item(it, extraCls = '') {
  const q = it.q == null ? 1 : it.q;
  return `<span class="item q${q} ${extraCls}" data-item="${esc(it.name)}">[${esc(it.name)}]</span>` + (it.count ? ` <span class="muted">×${it.count}</span>` : '');
}
function mix(a, b, t) {   // a over b, t = share of a
  const p = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16));
  const [x, y] = [p(a), p(b)];
  return '#' + x.map((v, i) => Math.round(v * t + y[i] * (1 - t)).toString(16).padStart(2, '0')).join('');
}
function spark(values, w, h, color, dot = true) {
  const vals = values.filter(v => v != null);
  if (vals.length < 2) return '';
  const lo = Math.min(...vals), hi = Math.max(...vals), rng = (hi - lo) || 1, n = values.length;
  const pts = values.map((v, i) => [2 + (w - 4) * i / (n - 1), 2 + (h - 4) - (h - 4) * (v - lo) / rng]);
  const last = pts[pts.length - 1];
  return `<svg class="spark" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}"><polyline points="${pts.map(p => p.join(',')).join(' ')}" fill="none" stroke="${color}" stroke-width="1.6"/>` +
    (dot ? `<circle cx="${last[0]}" cy="${last[1]}" r="3" fill="${color}"/>` : '') + '</svg>';
}
function plural(n, w) { return `${n} ${w}${n === 1 ? '' : 's'}`; }

// ---------------------------------------------------------------- state
const S = {
  theme: 'dark', status: null, versions: null, filter: 'all', menu: false, open: new Set(), meterTab: 'damage', scope: null,
  loot: { q: 2, who: 'all', text: '' }, msgs: { q: '', ch: 'all', limit: 300 }, browse: { mode: 'logs', dir: null },
  lastCombat: '#/', lastChat: '#/chat/loot', nav: null, rendering: 0, lastChatRender: 0, permission: true,
};
try { S.theme = localStorage.getItem('theme') || 'dark'; } catch (e) {}

function route() {
  const h = location.hash.replace(/^#\/?/, '');
  const parts = h.split('/').map(dec);
  return { name: parts[0] || 'home', a: parts[1], b: parts[2] };
}
function go(hash) { if (location.hash === hash) render(); else location.hash = hash; }
const isChat = r => r.name === 'chat';

// ---------------------------------------------------------------- top bar and menu
function drawTop() {
  const r = route();
  const st = S.status || {};
  $('#top').innerHTML = `
    <button class="iconbtn ${S.menu ? 'on' : ''}" data-act="menu" aria-label="Menu"><svg viewBox="0 0 24 24"><path d="M4 7h16M4 12h16M4 17h16"/></svg></button>
    <div class="seg big"><button class="${isChat(r) ? '' : 'on'}" data-act="tab" data-tab="combat">Combat</button><button class="${isChat(r) ? 'on' : ''}" data-act="tab" data-tab="chat">Chat</button></div>
    <div class="spacer"></div>
    <span class="dot ${st.dot === 'live' ? 'live' : ''}" title="${esc(st.status || '')}"></span>
    <button class="iconbtn" data-act="theme" aria-label="Theme">${S.theme === 'dark'
      ? '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="4"/><path d="M12 2.5v2M12 19.5v2M2.5 12h2M19.5 12h2M5.3 5.3l1.4 1.4M17.3 17.3l1.4 1.4M5.3 18.7l1.4-1.4M17.3 6.7l1.4-1.4"/></svg>'
      : '<svg viewBox="0 0 24 24"><path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/></svg>'}</button>`;
}
async function drawMenu() {
  const m = $('#menu');
  m.classList.toggle('open', S.menu);
  if (!S.menu) return;
  const r = route();
  const nav = await call('nav', { filter: S.filter });
  S.nav = nav;
  let h = '';
  if (isChat(r)) {
    const c = nav.chat || {};
    const items = [['loot', 'Loot', plural(c.loot || 0, 'item')], ['rolls', 'Rolls', plural(c.rolls || 0, 'roll-off')], ['activity', 'Activity', plural(c.activity || 0, 'event')],
                   ['watch', 'Watch list', plural(c.watch || 0, 'match').replace('matchs', 'matches')], ['messages', 'All messages', `${(c.messages || 0).toLocaleString()} lines`]];
    h += `<div class="navhead">Chat log</div>` + items.map(([k, t, s]) => `<div class="navitem ${r.a === k ? 'on' : ''}" data-go="#/chat/${k}"><div><div class="t">${t}</div><div class="s">${s}</div></div></div>`).join('');
  } else {
    h += `<div class="navhead">Sessions</div><div class="chips" style="margin:0 8px 8px">${[['all', 'All'], ['raid', 'Raids'], ['dungeon', 'Dungeons'], ['pvp', 'PvP']]
      .map(([k, l]) => `<button class="chip ${S.filter === k ? 'on' : ''}" data-act="filter" data-k="${k}">${l}</button>`).join('')}</div>`;
    if (!nav.runs.length) h += `<div class="navitem"><div class="s">Nothing here yet.</div></div>`;
    h += nav.runs.map(x => `<div class="navitem ${r.name === 'run' && r.a === x.id ? 'on' : ''}" data-go="#/run/${enc(x.id)}"><span class="mk ${x.mark}"></span><div><div class="t ellip">${esc(x.name)}</div><div class="s">${esc(x.line)}</div></div></div>`).join('');
    h += `<div class="navhead">More</div>
      <div class="navitem ${r.name === 'history' ? 'on' : ''}" data-go="#/history/weeks"><div><div class="t">History</div><div class="s">Weeks, bosses, players, attendance, loot</div></div></div>
      <div class="navitem ${r.name === 'settings' ? 'on' : ''}" data-go="#/settings"><div><div class="t">Settings</div><div class="s">Logs folder, reports, theme</div></div></div>`;
  }
  m.querySelector('.sheet').innerHTML = h;
}

// ---------------------------------------------------------------- page pieces
function header({ crumb, title, color, badge, subs = [] }) {
  return `<div class="header">${crumb ? `<div class="crumb" data-go="${crumb.go}">‹ ${esc(crumb.label)}</div><br>` : ''}
    <div class="titlerow"><h1 style="${color ? 'color:' + color : ''}">${esc(title)}</h1>${badge ? `<span class="badge ${badge.kind}">${esc(badge.label)}</span>` : ''}</div>
    ${subs.length ? `<div class="subs">${subs.map(s => `<span>${esc(s)}</span>`).join('')}</div>` : ''}</div>`;
}
function statsGrid(list) {
  return `<div class="stats">${list.map(s => `<div class="stat"><div class="v" style="${s.c ? 'color:var(--' + s.c + ')' : s.q ? 'color:' + qcol(s.q) : ''}">${esc(s.v)}${s.suffix ? `<small>${esc(s.suffix)}</small>` : ''}</div><div class="l">${esc(s.l)}</div></div>`).join('')}</div>`;
}
function panel(title, right, body) {
  return `<div class="panel">${title || right ? `<div class="ph">${title ? `<h2>${esc(title)}</h2>` : ''}${right || ''}</div>` : ''}${body}</div>`;
}
function seg(opts, cur, act, extra = '') {
  return `<div class="seg" ${extra}>${opts.map(([k, l]) => `<button class="${String(k) === String(cur) ? 'on' : ''}" data-act="${act}" data-k="${esc(k)}">${esc(l)}</button>`).join('')}</div>`;
}
function chips(opts, cur, act) {
  return `<div class="chips">${opts.map(([k, l]) => `<button class="chip ${String(k) === String(cur) ? 'on' : ''}" data-act="${act}" data-k="${esc(k)}">${esc(l)}</button>`).join('')}</div>`;
}
function emptyBox(title, text) { return `<div class="empty">${title ? `<h2>${esc(title)}</h2>` : ''}${esc(text)}</div>`; }
function actionBar(kind, ident) {
  return `<div class="actions"><button class="btn primary" data-act="copy" data-kind="${kind}" data-id="${esc(ident)}">Copy summary</button>
    <button class="btn" data-act="card" data-kind="${kind}" data-id="${esc(ident)}">Share image</button>
    <button class="btn" data-act="save" data-kind="${kind}" data-id="${esc(ident)}">Save report</button></div>`;
}
function bar(color, w) { return `<span class="bar" style="width:${Math.max(2, w * 100)}%;background:${mix(color, css('surface'), parseFloat(css('bar')) || .17)}"></span>`; }
function meterRow(i, r, top, go, opts = {}) {
  const col = cc(r.cls) || (S.theme === 'light' ? '#a19eb8' : '#77748f');
  const died = opts.died ? `<span class="died" title="Died">✕${opts.died > 1 ? opts.died : ''}</span>` : '';
  const caret = opts.caret != null ? `<span class="caret">${opts.caret ? '▾' : '▸'}</span>` : '';
  return `<div class="mrow ${opts.open ? 'open' : ''}" ${go}><span class="rank">${i + 1}</span><span class="track">${bar(col, r.raw / top)}<span class="edge" style="background:${col}"></span>
    <span class="nm" style="color:${nameColor(r.cls)}">${esc(r.name)}${died}${caret}</span><span class="vals"><span class="v">${esc(r.v)}</span><span class="r">${esc(r.rate)}</span><span class="p">${esc(typeof r.pct === 'number' ? r.pct + '%' : r.pct)}</span></span></span></div>`;
}
// One player's drop-down: deaths (tap one for what hit them), consumables, cooldowns and utility, interrupts, damage taken.
function deathBlock(x, key, fightLink) {
  const open = S.open.has(key);
  let h = `<div class="pdeath tap" data-act="openkey" data-k="${esc(key)}"><div class="flexrow"><span><span class="semi">${esc(x.fight)}</span> <span class="faint small">${esc(x.at)} in · ${esc(x.clock)}</span></span>
    <span class="w semi">${esc(x.amount || '')}</span></div><div class="small">${esc(x.spell)}${x.killer ? ` <span class="muted">from ${esc(x.killer)}</span>` : ''} <span class="faint">${open ? '▾' : '▸'}</span></div></div>`;
  if (open) {
    h += `<div class="recap">${x.recap.map(e => `<span class="faint">${esc(e.ago)}</span><span class="semi" style="color:var(--${e.dmg ? 'wipe' : 'kill'})">${e.dmg ? '−' : '+'}${esc(e.amount)}</span><span>${esc(e.spell)}</span>
      ${[e.src, e.crit ? 'crit' : '', e.overkill ? e.overkill + ' overkill' : ''].filter(Boolean).length ? `<span class="x">${esc([e.src, e.crit ? 'crit' : '', e.overkill ? e.overkill + ' overkill' : ''].filter(Boolean).join(' · '))}</span>` : ''}`).join('')}</div>`;
    if (fightLink) h += `<span class="more small" data-act="fightdeaths" data-id="${esc(x.fight_id)}" style="margin:0 0 8px 52px">Open this fight ›</span>`;
  }
  return h;
}
function playerDrop(x, deaths, keyBase, fullLink) {
  const sec = (title, body) => `<div class="psec"><div class="pst">${title}</div>${body}</div>`;
  let h = '';
  if (deaths && deaths.length) h += sec(deaths.length > 1 ? `Deaths (${deaths.length})` : 'Death', deaths.map((d, i) => deathBlock(d, `${keyBase}:d:${i}`, !!fullLink)).join(''));
  if (x.cons.length) h += sec('Consumables', `<div class="plist">${x.cons.map(c => `<span>${item(c)} <span class="muted">×${c.n}</span></span>`).join('')}</div>`);
  if (x.cds.length) {
    const groups = [['defensive', 'Defensive'], ['cooldown', 'Cooldowns'], ['utility', 'Utility']];
    h += sec('Cooldowns and utility', groups.map(([k, l]) => {
      const list = x.cds.filter(c => c[2] === k);
      return list.length ? `<div class="pline"><span class="kv">${l}</span> ${list.map(c => `<span class="nowrap">${esc(c[0])} <span class="muted">×${c[1]}</span></span>`).join(' · ')}</div>` : '';
    }).join(''));
  }
  if (x.ints || x.dispels) {
    let b = '';
    if (x.ints) b += `<div class="pline"><b>${x.ints}</b> <span class="kv">with</span> ${x.int_by.map(k => `${esc(k[0])} <span class="muted">×${k[1]}</span>`).join(', ')}</div>` +
      (x.kicked.length ? `<div class="pline small"><span class="kv">Stopped</span> ${x.kicked.map(k => `${esc(k[0])} <span class="muted">×${k[1]}</span>`).join(', ')}</div>` : '');
    if (x.dispels) b += `<div class="pline"><span class="kv">Dispels</span> <b>${x.dispels}</b></div>`;
    h += sec(x.ints ? 'Interrupts' : 'Dispels', b);
  }
  if (x.taken) h += sec(`Damage taken <span class="muted" style="font-weight:400">${esc(x.taken)}</span>`, x.taken_by.map(t => `<div class="brow"><span class="muted ellip">${esc(t[0])}</span><span>${esc(t[1])}</span><span class="faint" style="text-align:right">${t[2]}%</span>
      <span class="bb" style="width:${Math.max(2, t[2])}%;background:${mix(css('wipe'), css('surface'), .55)}"></span></div>`).join('') +
      (x.avoid ? `<div class="pline small"><span class="kv">Avoidable</span> <b class="w">${esc(x.avoid)}</b></div>` : ''));
  if (!h && !fullLink) return '';   // on a fight's page the abilities above are enough
  if (!h) h = '<div class="muted small" style="padding:4px 0">Nothing else to show for this player.</div>';
  if (fullLink) h = '<div class="faint tiny" style="padding:2px 0 0">Whole run, trash included</div>' + h + `<span class="more" data-go="${fullLink}">Full summary ›</span>`;
  return `<div class="pdrop">${h}</div>`;
}
function resLabel(res) { return `<span class="${res.kind === 'kill' ? 'k' : res.kind === 'wipe' ? 'w' : 'faint'} semi">${esc(res.label)}</span>`; }
function msgRow(m, hl) {
  const ch = CHANNEL[S.theme][m.ch] || css('muted');
  const tint = ['whisper', 'party', 'raid', 'raidwarning', 'guild', 'officer', 'instance', 'yell'].includes(m.ch);
  const tcol = tint ? mix(ch, css('text'), .55) : (m.ch === 'system' ? css('muted') : css('text'));
  const mark = s => {
    let out = esc(s);
    for (const w of hl || []) if (w) out = out.replace(new RegExp('(' + w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/&/g, '&amp;') + ')', 'ig'), '<mark>$1</mark>');
    return out;
  };
  const text = m.parts ? m.parts.map(p => p.i ? item({ name: p.i, q: p.q }) : mark(p.t)).join('') : mark(m.text);
  return `<div class="msg"><div class="h"><span class="t">${esc(m.t)}</span><span class="pill" style="color:${ch};background:${mix(ch, css('surface'), .14)}">${esc(m.label)}</span>
    ${m.who ? `<span class="who" style="color:${nameColor(m.cls)}" data-act="filtername" data-k="${esc(m.who)}">${esc(m.who)}</span>` : ''}</div>
    <div class="tx" style="color:${tcol}">${text}</div></div>`;
}

// ---------------------------------------------------------------- pages
async function pageRun(id) {
  let d = id ? await call('run', { id }) : null;
  if (!d) {
    const nav = S.nav || await call('nav', { filter: 'all' });
    if (!nav.runs.length) return noRuns();
    d = await call('run', { id: nav.runs[0].id });
  }
  S.lastCombat = '#/run/' + enc(d.id);
  let h = header({ title: d.name, badge: d.badge, subs: d.subs }) + actionBar('run', d.id).replace('<div class="actions">', '<div class="actions" style="margin:-4px 0 18px">');
  h += statsGrid(d.stats);
  // damage and healing
  const scopeSeg = d.scope_choice ? `<div class="right">${seg([['boss', 'Boss fights'], ['all', 'Everything']], d.scope, 'scope')}</div>` : '';
  let m = '';
  for (const [title, block] of [['Damage', d.damage], ['Healing', d.healing]]) {
    m += `<div class="mhead"><b>${title}</b><span class="muted small">${esc(block.total)} total</span></div>`;
    if (!block.rows.length) m += `<div class="faint" style="margin-bottom:12px">None.</div>`;
    const top = block.rows.length ? block.rows[0].raw : 1;
    m += block.rows.map((r, i) => {
      const key = `pd:${title}:${r.guid}`, open = S.open.has(key), x = d.details[r.guid];
      const deaths = (x && x.deaths) || [];
      let row = meterRow(i, r, top, `data-act="openkey" data-k="${esc(key)}" data-died="${deaths.length ? 1 : 0}"`, { died: deaths.length, caret: open, open });
      if (open && x) row += playerDrop(x, deaths, key, `#/player/${enc(d.id)}/${enc(r.guid)}`);
      return row;
    }).join('');
    m += '<div style="height:14px"></div>';
  }
  m += `<div class="note">${esc(d.scope_note)} Tap a player for their deaths, consumables, cooldowns and damage taken.</div>`;
  h += panel('Damage and healing', scopeSeg, m);
  // boss by boss
  if (d.bosses.length) {
    const b = d.bosses.map(x => {
      const pulls = x.pending ? '<span class="pull pending"></span>' : x.attempts.map(a => a.success
        ? `<span class="pull k" data-go="#/fight/${enc(a.id)}"><span>✓</span></span>`
        : `<span class="pull x" data-go="#/fight/${enc(a.id)}">${a.hp ? `<span class="hp" style="width:${Math.max(8, a.hp * 100)}%"></span>` : ''}<span>${a.hp != null ? Math.round(a.hp * 100) + '%' : '✕'}</span></span>`).join('');
      const tops = x.tops.map(t => `<span class="faint">${t.label}</span><span class="who">${t.who.map(p => `<span>${who(p.name, p.cls)} <span class="muted">${esc(p.v)}</span></span>`).join('')}</span>`).join('');
      return `<div class="boss"><div class="top"><span class="${x.pending ? 'faint' : 'semi'}">${esc(x.name)}</span><span class="muted small">${esc(x.right)}</span></div>
        <div class="pulls">${pulls}</div>${tops ? `<div class="tops">${tops}</div>` : ''}</div>`;
    }).join('');
    h += panel('Boss by boss', `<div class="right" style="flex-basis:100%">Tap a box for that pull. Red: boss health left.</div>`, b);
  }
  // fight by fight
  if (d.pulls.length) {
    const all = S.open.has('pulls:all');
    const rows = d.pulls.slice(0, all ? 1e9 : 30).map(p => `<div class="row tap" data-go="#/fight/${enc(p.id)}"><div class="${p.boss ? 'semi' : ''}">${esc(p.name)}</div>
      <div class="line2"><span><span class="kv">Time</span> <b>${esc(p.clock)}</b></span><span><span class="kv">Result</span> ${resLabel(p.res)}</span><span><span class="kv">Length</span> <b>${esc(p.len)}</b></span>
      <span><span class="kv">Group DPS</span> <b>${esc(p.dps)}</b></span>${p.deaths ? `<span><span class="kv">Deaths</span> <b class="w">${p.deaths}</b></span>` : ''}</div></div>`).join('');
    h += panel('Fight by fight', `<span class="right">${plural(d.pulls.length, 'pull')}</span>`, rows + (d.pulls.length > 30 && !all ? `<span class="more" data-act="openkey" data-k="pulls:all">Show all ${d.pulls.length}</span>` : ''));
  }
  if (d.loot.length) h += panel('Loot', `<span class="right">${plural(d.loot.length, 'item')}</span>`, lootRows(d.loot));
  if (d.records.length) h += panel('Records set', '', d.records.map(r => `<div class="row">🏆 ${esc(r)}</div>`).join(''));
  return h;
}
function lootRows(list) {
  return list.map(l => `<div class="row">${item(l)}<div class="line2"><span class="faint">${esc(l.t)}</span>${who(l.who, l.cls)}${l.src ? `<span>${esc(l.src)}</span>` : ''}${l.side ? `<span>${esc(l.side)}</span>` : ''}</div></div>`).join('');
}
async function noRuns() {
  const st = S.status || {};
  return header({ title: 'No runs yet' }) + emptyBox('', 'Raids, dungeons and PvP show up here once your logs have one in them: a summary of the whole run, everyone’s damage and healing, every boss and every pull.') +
    panel('Logs folder', '', `<div class="pathbox mono">${esc(st.logs_dir || '')}</div><div class="actions"><button class="btn primary" data-act="browse" data-k="logs">Choose folder…</button></div>`);
}

async function pageFight(id) {
  const d = await call('fight', { id });
  if (!d) return emptyBox('Not found', 'That fight isn’t in the logs any more.');
  let h = header({ crumb: d.crumb && { go: '#/run/' + enc(d.crumb.id), label: d.crumb.label }, title: d.name, badge: d.badge, subs: d.subs });
  h += statsGrid(d.stats);
  const nd = d.deaths.length;
  const tabs = [['damage', 'Damage'], ['healing', 'Healing'], ['taken', 'Damage taken'], ['deaths', nd ? `Deaths (${nd})` : 'Deaths'], ['utility', 'Utility']];
  let body = seg(tabs, S.meterTab, 'meter', 'style="margin-bottom:14px"');
  if (S.meterTab === 'deaths') {
    body += nd ? d.deaths.map((x, i) => {
      const key = `${d.id}:death:${i}`, open = S.open.has(key);
      return `<div class="death tap ${i ? 'sep' : ''}" data-act="openkey" data-k="${esc(key)}"><span class="at">${esc(x.at)}</span><div>${who(x.name, x.cls)} <span class="faint small">${open ? '▾' : '▸'}</span>
        <div class="small muted">${esc(x.spell)}${x.killer ? ' from ' + esc(x.killer) : ''}</div></div><span class="w">${esc(x.amount || '')}</span></div>` +
        (open ? `<div class="recap">${x.recap.map(e => `<span class="faint">${esc(e.ago)}</span><span class="semi" style="color:var(--${e.dmg ? 'wipe' : 'kill'})">${e.dmg ? '−' : '+'}${esc(e.amount)}</span><span>${esc(e.spell)}</span>
          ${[e.src, e.crit ? 'crit' : '', e.overkill ? e.overkill + ' overkill' : ''].filter(Boolean).length ? `<span class="x">${esc([e.src, e.crit ? 'crit' : '', e.overkill ? e.overkill + ' overkill' : ''].filter(Boolean).join(' · '))}</span>` : ''}`).join('')}</div>` : '');
    }).join('') : '<div class="muted">Nobody died.</div>';
  } else if (S.meterTab === 'utility') {
    body += d.utility.length ? d.utility.map(u => {
      const bits = [`<span><span class="kv">Interrupts</span> <b>${u.interrupts || '–'}</b></span>`, `<span><span class="kv">Dispels</span> <b>${u.dispels || '–'}</b></span>`];
      if (u.cons) bits.push(`<span><span class="kv">Consumables</span> <b>${esc(u.cons)}</b></span>`);
      if (u.avoid) bits.push(`<span><span class="kv">Avoidable</span> <b class="w">${esc(u.avoid)}</b></span>`);
      return `<div class="row">${who(u.name, u.cls)}<div class="line2">${bits.join('')}</div></div>`;
    }).join('') : '<div class="muted">Nothing here yet.</div>';
  } else {
    const rows = d.meters[S.meterTab];
    if (!rows.length) body += `<div class="muted">${{ healing: 'No healing in this fight.', taken: 'Nobody took damage.' }[S.meterTab] || 'No damage yet.'}</div>`;
    const top = rows.length ? rows[0].raw : 1;
    body += rows.map((r, i) => {
      const key = `${d.id}:${S.meterTab}:${r.guid}`, open = S.open.has(key);
      let x = meterRow(i, r, top, `data-act="openkey" data-k="${esc(key)}"`, { died: r.died.length, caret: open, open });
      if (open) {
        const col = cc(r.cls) || css('muted'), bt = r.by.length ? r.by[0].raw : 1;
        x += `<div class="breakdown">${r.by.map(b => `<div class="brow"><span class="muted ellip">${esc(b.n)}</span><span>${esc(b.v)}</span><span class="faint" style="text-align:right">${b.pct}%</span>
          <span class="bb" style="width:${Math.max(2, 100 * b.raw / bt)}%;background:${mix(col, css('surface'), .7)}"></span></div>`).join('')}
          ${r.extra.map(([k, v]) => `<div class="brow"><span class="muted">${esc(k)}</span><span>${esc(v)}</span><span></span></div>`).join('')}</div>`;
        x += playerDrop(r.more, r.died, key, null);
      }
      return x;
    }).join('');
    if (rows.length) body += '<div class="note">Tap a player for their abilities, consumables, cooldowns and damage taken.</div>';
  }
  h += panel('', '', body);
  if (d.loot.length) h += panel('Loot', '', lootRows(d.loot));
  if (d.chat.length) h += panel('Chat during the fight', '', d.chat.map(m => msgRow(m)).join(''));
  return h;
}

async function pagePlayer(run, guid) {
  const d = await call('player', { run, guid });
  if (!d) return emptyBox('Not found', 'That run isn’t in the logs any more.');
  const crumb = { go: '#/run/' + enc(d.crumb.id), label: d.crumb.label };
  if (d.empty) return header({ crumb, title: d.name, subs: d.subs }) + emptyBox('', 'This player has no numbers in the fights counted here. Try “Everything” on the run page.');
  let h = header({ crumb, title: d.name, color: cc(d.cls), subs: d.subs }) + actionBar('player', run + '|' + guid).replace('<div class="actions">', '<div class="actions" style="margin:-4px 0 18px">');
  h += statsGrid(d.stats);
  h += panel('Fight by fight', '', d.fights.length ? d.fights.map(f => {
    const bits = [`<span><span class="kv">Result</span> ${resLabel(f.res)}</span>`, `<span><span class="kv">Time</span> <b>${esc(f.time)}</b></span>`];
    if (f.dps) bits.push(`<span><span class="kv">DPS</span> <b>${esc(f.dps)}</b></span>`, `<span><span class="kv">Damage</span> <b>${esc(f.dmg)}</b></span>`);
    if (f.hps) bits.push(`<span><span class="kv">HPS</span> <b>${esc(f.hps)}</b></span>`, `<span><span class="kv">Healing</span> <b>${esc(f.heal)}</b></span>`);
    if (f.died) bits.push('<span class="w">Died</span>');
    return `<div class="row tap" data-go="#/fight/${enc(f.id)}"><div class="${f.boss ? 'semi' : ''}">${esc(f.name)}</div><div class="line2">${bits.join('')}</div></div>`;
  }).join('') : '<div class="muted">No fights.</div>');
  const bars = (list, col) => list.map(b => `<div class="brow" style="font-size:15px"><span class="ellip">${esc(b.n)}</span><span>${esc(b.v)}</span><span class="muted" style="text-align:right">${b.pct}%</span>
    <span class="bb" style="width:${Math.max(2, b.w * 100)}%;background:${mix(col, css('surface'), .75)}"></span></div>`).join('');
  if (d.dmg_by.length) h += panel('Damage by ability', '', bars(d.dmg_by, css('wipe')));
  if (d.heal_by.length) h += panel('Healing by ability', '', bars(d.heal_by, css('kill')));
  if (d.deaths.length) h += panel('Deaths', '', d.deaths.map(x => `<div class="row tap" data-act="fightdeaths" data-id="${esc(x.fight_id)}"><div class="flexrow"><span class="semi ellip">${esc(x.fight)}</span><span class="muted small">${esc(x.when)}</span></div><div class="small w">${esc(x.what)}</div></div>`).join(''));
  if (d.cons.length || d.loot.length) {
    let b = '';
    if (d.cons.length) b += `<div class="grouphead">Consumables</div>` + d.cons.map(c => `<div class="flexrow" style="padding:3px 0">${item(c)}<span class="muted">×${c.n}</span></div>`).join('');
    if (d.loot.length) b += `<div class="grouphead" style="margin-top:14px">Loot</div>` + d.loot.map(l => `<div class="flexrow" style="padding:3px 0">${item(l)}<span class="muted">${esc(l.t)}</span></div>`).join('');
    h += panel('Consumables and loot', '', b);
  }
  return h;
}

async function pageHistory(tab) {
  tab = tab || 'weeks';
  const tabs = [['weeks', 'Weeks'], ['bosses', 'Bosses'], ['players', 'Players'], ['attendance', 'Attendance'], ['loot', 'Loot']];
  let h = header({ title: 'History', subs: ['Everything Leyline has read, week by week. Weeks start on Tuesday, when raids reset.'] }).replace('</div></div>', '</div></div>');
  h += chips(tabs, tab, 'htab');
  const d = await call('history', { tab });
  if (!d) return h;
  if (tab === 'weeks') {
    if (!d.weeks.length) return h + emptyBox('', 'Nothing yet. Each week you raid or run dungeons gets a recap here.');
    for (const wk of d.weeks) {
      let b = `<div class="muted" style="margin-bottom:10px">${esc(wk.bits)}</div>`;
      b += wk.runs.map(r => `<div class="row tap" data-go="#/run/${enc(r.id)}"><div class="flexrow"><span class="semi">${esc(r.title)}</span><span class="faint">›</span></div><div class="small muted">${esc(r.line)}</div></div>`).join('');
      for (const t of wk.tops) b += `<div class="small faint" style="margin-top:12px">${esc(t.label)}</div><div class="small">${t.who.map(p => `<span style="margin-right:12px;white-space:nowrap">${who(p.name, p.cls)} <span class="muted">${esc(p.v)}</span></span>`).join('')}</div>`;
      if (wk.raiders) b += `<div class="small muted" style="margin-top:12px">Raiders: ${esc(wk.raiders)}</div>`;
      const right = `<div class="actions" style="margin:0;flex-basis:100%"><button class="btn primary" data-act="copy" data-kind="week" data-id="${wk.start}">Copy summary</button><button class="btn" data-act="card" data-kind="week" data-id="${wk.start}">Share image</button></div>`;
      h += panel(wk.title, right, b);
    }
  } else if (tab === 'bosses') {
    if (!d.bosses.length) return h + emptyBox('', 'No boss fights yet.');
    h += panel('', '', d.bosses.map(b => {
      const key = 'boss:' + b.name, open = S.open.has(key);
      let x = `<div class="row tap" data-act="openkey" data-k="${esc(key)}"><div class="flexrow"><span class="semi">${esc(b.name)}</span><span class="faint small">${open ? '▾' : '▸'}</span></div>
        <div class="small muted">${esc(b.line)}</div><div class="flexrow" style="margin-top:3px"><span class="small"><span class="faint">Fastest</span> <span class="semi" style="color:var(--${b.best ? 'kill' : 'faint'})">${esc(b.best || '–')}</span>
        &nbsp; <span class="faint">Latest</span> <span class="semi">${esc(b.latest || '–')}</span></span>${spark(b.trend, 110, 16, css('arcane'))}</div></div>`;
      if (open) x += `<div style="margin:0 0 10px">${b.pulls.map(p => `<div class="tap small" data-go="#/fight/${enc(p.id)}" style="display:grid;grid-template-columns:1fr auto auto auto;gap:10px;padding:5px 0">
        <span class="muted">${esc(p.when)}</span>${resLabel(p.res)}<span>${esc(p.len)}</span><span class="faint">${esc(p.deaths)}</span></div>`).join('')}</div>`;
      return x;
    }).join(''));
  } else if (tab === 'players') {
    if (!d.players.length) return h + emptyBox('', 'No raid boss kills yet. Player trends come from raid boss kills.');
    let group = null, b = '';
    for (const p of d.players) {
      const g = p.healer ? 'Healers' : 'Damage';
      if (g !== group) { b += `<div class="grouphead" style="margin-top:${group ? 14 : 0}px">${g}</div>`; group = g; }
      const bits = [plural(p.kills, 'kill')];
      if (p.trend.length) bits.push(plural(p.weeks, 'week'));
      if (p.best) bits.push('best ' + p.best);
      b += `<div class="row tap" data-go="#/phist/${enc(p.name)}"><div class="flexrow"><span class="semi ellip" style="color:${nameColor(p.cls)}">${esc(p.name)}</span><span class="semi">${esc(p.val)}</span></div>
        <div class="flexrow"><span class="small muted ellip">${esc(bits.join(' · '))}</span>${spark(p.trend, 64, 14, cc(p.cls) || css('arcane'))}</div></div>`;
    }
    h += panel('', '', b + '<div class="note">Average is over all raid boss kills. Healers are anyone who healed more than they damaged. Tap a player for their history.</div>');
  } else if (tab === 'attendance') {
    if (!d.nights.length) return h + emptyBox('', 'No raid nights yet.');
    const avail = Math.min(760, window.innerWidth) - 28 - 28 - 112 - 72;
    const keep = Math.min(d.nights.length, Math.max(4, Math.floor(avail / 24)));
    const nights = d.nights.slice(-keep), off = d.nights.length - keep;
    const labelEvery = 1 + (keep * 24 < avail * 0.9 ? 0 : 1);
    let g = `<div class="att" style="grid-template-columns:112px repeat(${keep}, 1fr) 72px"><span></span>` +
      nights.map((n, j) => `<span class="lab">${(keep - 1 - j) % labelEvery ? '' : esc(n.label)}</span>`).join('') + '<span class="lab" style="justify-self:end">Nights</span>';
    for (const p of d.players) {
      const here = p.here.slice(off), c = here.filter(Boolean).length;
      g += `<span class="nm" style="color:${nameColor(p.cls)}">${esc(p.name)}</span>` + here.map(x => `<span class="d ${x ? 'on' : ''}"></span>`).join('') +
        `<span class="cnt ${c === keep ? 'k' : ''}">${c}/${keep} ${Math.round(100 * c / keep)}%</span>`;
    }
    h += panel(plural(keep, 'raid night') + (d.total > keep ? ` (latest ${keep})` : ''), '', g + '</div>');
  } else if (tab === 'loot') {
    if (!d.people.length) return h + emptyBox('', 'No raid loot recorded yet. It comes from the chat log, so keep chat logging on.');
    for (const p of d.people) h += panel(`${p.who} · ${plural(p.items.length, 'item')}`, '', p.items.map(l => `<div style="padding:4px 0">${item(l)}<div class="small muted">${esc(l.where)}</div></div>`).join(''));
  }
  return h;
}

async function pagePhist(name) {
  const d = await call('phist', { name });
  const crumb = { go: '#/history/players', label: 'History' };
  if (!d || d.empty) return header({ crumb, title: name }) + emptyBox('', 'No boss kills for this player yet.');
  const col = cc(d.cls);
  let h = header({ crumb, title: d.name, color: col, subs: d.subs }) + statsGrid(d.stats);
  let wb = d.trend.length >= 2 ? `<div style="margin-bottom:12px">${spark(d.trend, Math.min(700, window.innerWidth - 60), 60, col || css('arcane'))}</div>` : '';
  wb += d.weeks.map(w => `<div class="row"><div class="flexrow"><span>${esc(w.title)}</span><span class="semi">${esc(w.v)}</span></div><div class="small muted">${esc(w.kills)}</div></div>`).join('');
  h += panel('Week by week', '', wb);
  h += panel('Boss by boss', '', d.bosses.map(b => `<div class="row"><div class="semi">${esc(b.name)}</div><div class="flexrow"><span class="small muted">${esc(b.line)}</span>${spark(b.trend, 64, 14, col || css('arcane'))}</div>
    ${b.kills.map(k => `<div class="flexrow tap small" data-go="#/fight/${enc(k.id)}" style="padding:4px 0 4px 12px"><span class="muted ellip">${esc(k.where)}</span><span>${esc(k.v)}</span></div>`).join('')}</div>`).join(''));
  return h;
}

// ---- chat pages
async function pageChat(view) {
  view = view || 'loot';
  S.lastChat = '#/chat/' + view;
  const st = S.status || {};
  if (view === 'loot') {
    let h = header({ title: 'Loot', subs: ['Everything you and your group looted, newest first. Tap an item for its tooltip.'] });
    h += chips([[4, 'Epic'], [3, 'Rare+'], [2, 'Uncommon+'], [0, 'All']], S.loot.q, 'lootq');
    h += `<div id="lootstats"></div><div class="label">Search items or players</div><div class="searchrow"><input class="field" id="lootsearch" value="${esc(S.loot.text)}" placeholder="Item or player" autocomplete="off"></div>`;
    h += chips([['all', 'Everyone'], ['me', 'Just me'], ['won', 'Rolled for']], S.loot.who, 'lootwho');
    h += '<div id="results"></div>';
    return h;
  }
  if (view === 'rolls') {
    const d = await call('chat_rolls');
    let h = header({ title: 'Rolls', subs: ['Need/Greed rolls and /roll roll-offs, with the winner worked out. Re-rolls don’t count.'] });
    if (!d) return h + noChat();
    if (!d.rolls.length) return h + emptyBox('', 'No rolls in the chat log yet. They show up when someone types /roll.');
    return h + panel('', '', d.rolls.map(r => `<div class="row">${r.item ? item(r.item) : `<span class="semi">Roll 1–${esc(r.hi)}</span>`}
      <div class="flexrow small" style="margin:3px 0 7px"><span>${r.winner ? who(r.winner.name, r.winner.cls) + ` <span class="${r.tie ? 'w' : 'muted'}">wins${r.tie ? ' · tie' : ''}</span>` : ''}</span><span class="faint">${esc(r.when)}</span></div>
      <div>${r.rolls.map(x => `<span class="roll ${x.win ? 'win' : ''} ${x.again ? 'again' : ''}" style="${!x.win && !x.again ? 'color:' + mix(cc(x.cls) || css('muted'), css('surface2'), .8) : ''}">${esc(x.label)}</span>`).join('')}</div></div>`).join(''));
  }
  if (view === 'activity') {
    const d = await call('chat_activity');
    let h = header({ title: 'Activity', subs: ['Honor, reputation, experience, quests and resets, from your chat log.'] });
    if (!d) return h + noChat();
    h += statsGrid(d.stats);
    if (!d.groups.length) return h + emptyBox('', 'Nothing yet.');
    for (const g of d.groups) h += panel(g.day, '', g.rows.map(r => `<div class="row"><div class="small"><span class="faint">${esc(r.t)}</span> &nbsp; <span class="muted">${esc(r.kind)}</span></div>
      <div style="${r.c ? 'color:var(--' + r.c + ')' : ''}">${esc(r.text)}</div></div>`).join(''));
    return h;
  }
  if (view === 'watch') {
    const d = await call('chat_watch');
    let h = header({ title: 'Watch list', subs: ['Messages that mention any of your words. New ones pop up while the app is open.'] });
    h += `<div class="label">Words to watch for, separated by commas</div><input class="field" id="watchwords" value="${esc(d.words)}" autocomplete="off">
      <div class="toggle" data-act="sound" style="margin-top:12px"><span class="sw ${d.sound ? 'on' : ''}"></span><span>Sound and vibrate</span></div><div id="results"></div>`;
    return h;
  }
  // all messages
  let h = header({ title: 'All messages' });
  h += `<div class="label">Search names or words</div><div class="searchrow"><input class="field" id="msgsearch" value="${esc(S.msgs.q)}" placeholder="Name or word" autocomplete="off">
    ${S.msgs.q ? '<span class="more" data-act="clearsearch" style="margin:0;white-space:nowrap">Clear search</span>' : ''}</div>`;
  h += chips([['all', 'All'], ['social', 'No Trade/LFG'], ['raid', 'Raid'], ['party', 'Party'], ['guild', 'Guild'], ['whisper', 'Whispers'], ['channel', 'Trade & LFG'], ['say', 'Say & yell'], ['system', 'System']], S.msgs.ch, 'msgch');
  h += '<div id="results"></div>';
  return h;
}
function noChat() { return emptyBox('No chat log yet', 'Copy WoWChatLog.txt from your PC’s Logs folder next to your combat logs. WoW only writes it when you log out.'); }
async function fillResults() {
  const r = route(), box = $('#results');
  if (!box) return;
  const view = r.a || 'loot';
  if (view === 'loot') {
    const d = await call('chat_loot', S.loot);
    if (!d) { box.innerHTML = noChat(); return; }
    $('#lootstats').innerHTML = statsGrid(d.stats);
    box.innerHTML = d.groups.length ? d.groups.map(g => panel(g.day, '', lootRows(g.rows))).join('')
      : emptyBox('', S.loot.text || S.loot.who !== 'all' ? 'Nothing matches.' : 'No loot at this quality yet.');
  } else if (view === 'watch') {
    const d = await call('chat_watch');
    box.innerHTML = !d.words ? emptyBox('', 'Add a word or two above to start watching.') : !d.rows.length ? emptyBox('', 'Nothing yet for those words.')
      : panel('', '', d.rows.map(m => msgRow(m, d.hl)).join(''));
  } else if (view === 'messages') {
    const d = await call('chat_messages', S.msgs);
    if (!d) { box.innerHTML = noChat(); return; }
    if (!d.rows.length) { box.innerHTML = emptyBox('', 'No messages match.'); return; }
    let out = '', dk = null;
    for (const m of d.rows) {
      if (m.dk !== dk) { out += `<div class="grouphead" style="margin-top:${dk ? 14 : 0}px">${esc(m.day)}</div>`; dk = m.dk; }
      out += msgRow(m, S.msgs.q ? [S.msgs.q] : null);
    }
    if (d.more) out += '<button class="btn" data-act="moremsgs" style="margin-top:12px">Show more</button>';
    box.innerHTML = panel('', '', out);
  }
}

// ---- settings and folders
async function pageSettings() {
  const d = await call('settings');
  let h = header({ title: 'Settings' });
  const what = d.combat_logs ? `Reading ${plural(d.combat_logs, 'combat log')}${d.chat_log ? ' and the chat log' : ''} from this folder${d.reading ? ' (still reading)' : ''}.`
    : 'No WoW logs in this folder yet.';
  h += panel('Logs folder', '', `<div class="pathbox mono">${esc(d.logs_dir || '')}</div><div class="muted" style="margin:-4px 0 12px">${esc(what)}</div>
    <div class="actions" style="margin:0"><button class="btn primary" data-act="browse" data-k="logs">Choose folder…</button><button class="btn" data-act="reread">Read the folder again</button></div>
    <div class="note">Copy the WoWCombatLog-….txt files and WoWChatLog.txt from your PC’s World of Warcraft\\_anniversary_\\Logs folder into this folder. Every log in it is read, including ones you copy in while the app is open.</div>`);
  h += panel('Reports', '', `<div class="muted" style="margin-bottom:10px">Save report and Share image › Save with report put files here.</div>
    <div class="pathbox mono">${esc(d.report_dir)}</div><button class="btn" data-act="browse" data-k="reports">Change folder…</button>`);
  h += panel('Appearance', '', `<div class="toggle" data-act="theme"><span class="sw ${S.theme === 'light' ? 'on' : ''}"></span><div><div class="semi">Light theme</div><div class="small muted">Switch between the dark and light look.</div></div></div>`);
  const lic = (name, what, who, license, key) => `<div class="lic"><div class="flexrow"><span class="semi">${name}</span><span class="more" data-act="license" data-k="${key}" style="margin:0">View licence</span></div>
    <div class="small muted">${what}</div><div class="small faint">${who} · ${license}</div></div>`;
  h += panel('About', '', `<div class="about-head"><div class="about-name">Leyline</div><div class="muted">Version ${esc(native.version())}</div>
      <div class="small muted" style="margin-top:6px">A combat and chat log reader for World of Warcraft: Burning Crusade Classic Anniversary. Everything is read and worked out on this phone; nothing is sent anywhere.</div></div>
    <div class="pst" style="margin:14px 0 6px">Open-source software and data</div>
    ${lic('Inter', 'Typeface', '© 2016 The Inter Project Authors', 'SIL Open Font License 1.1', 'inter')}
    ${lic('wow-classic-items', `Item names, qualities and tooltips (${esc(d.items)})`, '© 2019 Nakroma and contributors', 'MIT License', 'items')}
    ${lic('Chaquopy', 'Runs the Python log reader on Android', '© 2017–2025 Chaquo Ltd and contributors', 'MIT License', 'chaquopy')}
    ${lic('Python 3.12', 'Programming language and standard library', '© 2001–2024 Python Software Foundation', 'PSF License Agreement', 'python')}
    ${lic('AndroidX Core', 'Sharing files with other apps', '© The Android Open Source Project', 'Apache License 2.0', 'androidx')}
    ${lic('cMaNGOS TBC database', 'Which item each consumable spell belongs to (facts only)', '© cMaNGOS contributors', 'GNU GPL 3.0', 'cmangos')}
    <div class="small faint" style="margin-top:14px">Boss and encounter IDs are facts about the game. World of Warcraft® and Blizzard Entertainment® are trademarks or registered trademarks of Blizzard Entertainment, Inc. in the U.S. and/or other countries. Leyline is an independent project and is not affiliated with or endorsed by Blizzard Entertainment.</div>`);
  return h;
}
async function pageBrowse() {
  const b = S.browse;
  const d = await call('browse', { dir: b.dir });
  b.dir = d.dir;
  const logsMode = b.mode === 'logs';
  let h = header({ title: logsMode ? 'Choose your logs folder' : 'Choose a folder', subs: [logsMode ? 'Open the folder with your WoW logs and tap Use this folder. Every log in it is read.' : 'Open the folder reports should go in, then tap Use this folder.'] });
  h += `<div class="pathbox mono">${esc(d.dir)}</div>`;
  if (logsMode && (d.combat_count || d.logs.length)) h += `<div class="actions" style="margin:-2px 0 14px"><button class="btn primary big" data-act="picklog" data-k="${esc(d.dir)}">Use this folder · ${plural(d.combat_count, 'combat log')}</button></div>`;
  if (d.spots.length) h += chips(d.spots.map(s => [s.dir, s.label]), d.dir, 'bdir');
  const icon = kind => kind === 'dir'
    ? `<svg class="fileicon" viewBox="0 0 22 18"><path d="M1 3a2 2 0 0 1 2-2h5l2 2h9a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2z" fill="${css('muted')}"/></svg>`
    : `<svg class="fileicon" viewBox="0 0 22 22"><rect x="4" y="1.5" width="14" height="19" rx="2" fill="none" stroke="${css('arcane')}" stroke-width="1.6"/><path d="M7.5 7h7M7.5 11h7M7.5 15h5" stroke="${css('arcane')}" stroke-width="1.4"/></svg>`;
  let rows = '';
  if (d.parent) rows += `<div class="brow-file" data-act="bdir" data-k="${esc(d.parent)}"><span class="fileicon" style="text-align:center">‹</span><div><div class="semi muted">Up one folder</div></div></div>`;
  if (d.error) rows += `<div class="w" style="padding:10px 0">Android won’t let Leyline read this folder. Try Internal storage, then Leyline or Download.</div>`;
  if (logsMode) rows += d.logs.map(l => `<div class="brow-file" data-act="picklog" data-k="${esc(d.dir)}">${icon('log')}<div style="min-width:0"><div class="semi ellip" style="color:var(--arcane)">${esc(l.name)}</div><div class="small muted">${esc(l.info)}</div></div></div>`).join('');
  rows += d.dirs.map(n => `<div class="brow-file" data-act="bdir" data-k="${esc(d.dir.replace(/\/$/, '') + '/' + n)}">${icon('dir')}<div class="semi ellip">${esc(n)}</div></div>`).join('');
  if (logsMode && !d.logs.length && !d.error) rows += `<div class="small faint" style="padding:10px 0">No WoW logs in this folder${d.hidden ? ` (${plural(d.hidden, 'other file')} hidden)` : ''}. Open the folder you copied them into.</div>`;
  h += panel('', '', rows);
  h += `<div class="actions">${logsMode ? '' : '<button class="btn primary" data-act="pickreports">Use this folder</button>'}<button class="btn" data-act="cancelbrowse">Cancel</button></div>`;
  return h;
}
function pagePermission() {
  return header({ title: 'Let Leyline read your logs' }) +
    emptyBox('', 'Leyline reads the WoW log files you copy onto this phone. Android asks you to allow that once: tap the button, switch on “Allow access to manage all files” for Leyline, then come back.') +
    `<div class="actions"><button class="btn primary big" data-act="askstorage">Allow access</button></div>
     <div class="note" style="margin-top:18px">Leyline only reads WoW logs and writes reports to Documents/Leyline Reports. It doesn’t send anything anywhere.</div>`;
}
function pageLoading(st) {
  const [label, p] = st.progress || ['Starting', 0];
  return `<div style="padding-top:60px"><h1>Reading your logs</h1><div class="progress"><div style="width:${Math.max(2, (p || 0) * 100)}%"></div></div>
    <div class="muted">${esc(label)}</div><div class="small faint" style="margin-top:24px">Older logs are saved after the first read, so this is quicker next time.</div></div>`;
}
function pageMissing(st) {
  return header({ title: 'No logs yet' }) + emptyBox('', 'WoW writes its logs on your PC, in World of Warcraft\\_anniversary_\\Logs. Copy the WoWCombatLog-….txt and WoWChatLog.txt files from there to this phone, then choose that folder here.') +
    `<div class="label">Leyline is looking in</div><div class="pathbox mono">${esc(st.logs_dir)}</div>
     <div class="actions"><button class="btn primary big" data-act="browse" data-k="logs">Choose folder…</button></div>
     <div class="note">Easiest: put them in Internal storage › Leyline › Logs. <span class="more" data-act="makefolder" style="margin:0">Make that folder now</span></div>`;
}
function pageError(st) {
  return header({ title: 'Couldn’t read the logs' }) + emptyBox('', 'Something in the logs tripped Leyline up. The details are below; send them to whoever is helping you.') + `<div class="pathbox mono small">${esc((st.error || '').slice(-2000))}</div>`;
}

// ---------------------------------------------------------------- render
async function render(keepScroll = false) {
  const myTurn = ++S.rendering;
  const r = route();
  drawTop();
  if (S.menu) drawMenu();
  const st = S.status || { state: 'starting' };
  let html;
  try {
    if (!S.permission) html = pagePermission();
    else if (r.name === 'browse') html = await pageBrowse();
    else if (r.name === 'settings') html = await pageSettings();
    else if (st.state === 'missing') html = pageMissing(st);
    else if (st.state === 'error') html = pageError(st);
    else if (st.state !== 'ready') html = pageLoading(st);
    else if (r.name === 'run') html = await pageRun(r.a);
    else if (r.name === 'fight') html = await pageFight(r.a);
    else if (r.name === 'player') html = await pagePlayer(r.a, r.b);
    else if (r.name === 'history') html = await pageHistory(r.a);
    else if (r.name === 'phist') html = await pagePhist(r.a);
    else if (r.name === 'chat') html = await pageChat(r.a);
    else html = await pageRun(null);
  } catch (e) {
    html = header({ title: 'Something went wrong' }) + `<div class="pathbox mono small">${esc(String(e).slice(-1500))}</div>`;
  }
  if (myTurn !== S.rendering) return;   // a newer render started meanwhile
  const y = window.scrollY;
  $('#main').innerHTML = html;
  if (r.name === 'chat' && ['loot', 'watch', 'messages', undefined].includes(r.a) && st.state === 'ready') await fillResults();
  window.scrollTo(0, keepScroll ? y : 0);
}

// ---------------------------------------------------------------- overlays
function closeOverlay() { const o = $('.overlay'); if (o) { o.remove(); return true; } return false; }
async function showItem(name) {
  const d = await call('item', { name });
  const q = d.q == null ? 1 : d.q;
  const tipQ = ['#9d9d9d', '#ffffff', '#1eff00', '#0070dd', '#a335ee', '#ff8000', '#e6cc80'];
  const rows = [];
  for (const [text, style] of d.tooltip) {
    if (style === 'r' && rows.length) { rows[rows.length - 1].right = text; continue; }
    rows.push({ text, style });
  }
  const o = document.createElement('div');
  o.className = 'overlay';
  o.innerHTML = `<div class="tip"><div class="tn" style="color:${tipQ[q] || '#fff'}">${esc(name)}</div>
    ${rows.map(r => `<div class="ln ${r.style || ''}"><span>${esc(r.text)}</span>${r.right ? `<span>${esc(r.right)}</span>` : ''}</div>`).join('')}
    ${d.note ? `<div class="ln f" style="margin-top:6px">${esc(d.note)}</div>` : ''}${d.known ? '' : '<div class="ln f">Leyline has no details for this item. Wowhead will.</div>'}
    <div class="btns"><button class="p" data-act="wowhead" data-k="${esc(d.url)}">Wowhead ↗</button><button data-act="copyname" data-k="${esc(name)}">Copy name</button><button data-act="close">Close</button></div></div>`;
  document.body.appendChild(o);
}
function toast(text) {
  const t = $('#toast');
  t.textContent = text;
  t.style.display = 'block';
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => { t.style.display = 'none'; }, 5000);
}

// ---- the share picture, drawn the same way as the PC app's card
async function drawCard(card) {
  await document.fonts.ready;
  const W = 720, K = 2;
  const P = { bg: css('bg'), text: css('text'), muted: css('muted'), faint: css('faint'), kill: css('kill'), wipe: css('wipe'), arcane: css('arcane'), line: css('line-soft') };
  const cv = document.createElement('canvas');
  const ctx = cv.getContext('2d');
  const F = { h1: '700 27px Inter', base: '400 15px Inter', semi: '600 15px Inter', small: '400 13px Inter', smallsemi: '600 13px Inter', stat: '600 23px Inter', tiny: '600 11px Inter' };
  const LH = { h1: 34, base: 20, semi: 20, small: 17, smallsemi: 17, stat: 30 };
  const ops = [];
  const text = (x, y, s, f, col, align = 'left', maxw = null) => ops.push(['t', x, y, String(s), f, col, align, maxw]);
  const rect = (x, y, w, h, r, col, stroke) => ops.push(['r', x, y, w, h, r, col, stroke]);
  const x = 28, w = W - 56;
  let y = 26;
  const qc = q => (q == null ? P.text : (QUAL[S.theme][q] || P.text));
  text(x, y, card.title, 'h1', card.cls ? (cc(card.cls) || P.text) : P.text, 'left', w);
  y += LH.h1 + 2;
  text(x, y, card.bits.join(' · '), 'base', P.muted, 'left', w);
  y += LH.base + 18;
  if (card.kind === 'run') {
    for (const b of card.bosses) {
      text(x, y + 4, b.name, 'semi', P.text, 'left', 250);
      let bx = x + 260;
      for (const a of b.attempts) {
        if (a.success) { rect(bx, y + 2, 40, 24, 6, P.kill); text(bx + 20, y + 5, '✓', 'semi', '#ffffff', 'center'); }
        else { rect(bx, y + 2, 40, 24, 6, mix(P.wipe, P.bg, .18)); text(bx + 20, y + 7, a.hp != null ? Math.round(a.hp * 100) + '%' : '✕', 'tiny', P.wipe, 'center'); }
        bx += 46;
      }
      if (b.kill) text(x + w, y + 6, b.kill, 'small', P.muted, 'right');
      y += 32;
    }
    if (card.bosses.length) y += 12;
    // the group
    const cols = [['DPS', 'dps'], ['Damage', 'dmg']].concat(card.heals ? [['HPS', 'hps'], ['Healing', 'heal']] : []).concat([['Died', 'deaths']]);
    const cw = 78, xs = cols.map((_, i) => x + w - (cols.length - 1 - i) * cw);
    text(x, y, card.group_title, 'smallsemi', P.muted);
    cols.forEach((c, i) => text(xs[i], y, c[0], 'smallsemi', P.muted, 'right'));
    y += LH.smallsemi + 6;
    for (const p of card.players) {
      const rh = LH.semi + 6, col = cc(p.cls) || P.muted;
      if (p.w) rect(x, y + 1, Math.max(3, (xs[0] - cw - x - 10) * p.w), rh - 3, 4, mix(col, P.bg, .14));
      text(x + 8, y + 3, p.name, 'semi', cc(p.cls) || P.text, 'left', xs[0] - cw - x - 20);
      cols.forEach((c, i) => { const v = p[c[1]]; text(xs[i], y + 3, v, 'base', v === '–' ? P.faint : c[1] === 'deaths' ? P.wipe : P.text, 'right'); });
      y += rh;
    }
    y += 14;
    if (card.loot.length) {
      text(x, y, 'Loot', 'smallsemi', P.muted); y += LH.smallsemi + 6;
      for (const l of card.loot) { text(x, y, `[${l.name}]`, 'semi', qc(l.q), 'left', w - 160); text(x + w, y, l.who, 'base', cc(l.cls) || P.muted, 'right'); y += LH.semi + 4; }
      if (card.more_loot) { text(x, y, `and ${card.more_loot} more`, 'small', P.faint); y += LH.small + 4; }
      y += 8;
    }
  } else if (card.kind === 'player') {
    const bw = w / card.boxes.length;
    card.boxes.forEach(([v, l], i) => { text(x + i * bw, y, v, 'stat', l === 'Deaths' && card.died ? P.wipe : P.text); text(x + i * bw, y + LH.stat, l, 'small', P.muted); });
    y += LH.stat + LH.small + 16;
    if (card.fights.length) {
      text(x, y, 'Boss fights', 'smallsemi', P.muted); y += LH.smallsemi + 6;
      for (const f of card.fights) {
        rect(x, y + 3, 12, 12, 3, f.ok ? P.kill : P.wipe);
        text(x + 20, y, f.name, 'semi', P.text, 'left', 300); text(x + w - 70, y, f.val, 'base', P.text, 'right'); text(x + w, y, f.time, 'small', P.muted, 'right');
        y += LH.semi + 5;
      }
      y += 10;
    }
    for (const a of card.abilities) {
      text(x, y, a.head, 'smallsemi', P.muted); y += LH.smallsemi + 6;
      for (const [k, v] of a.rows) { text(x, y, k, 'base', P.text, 'left', w - 140); text(x + w, y, v, 'base', P.muted, 'right'); y += LH.base + 4; }
      y += 10;
    }
    if (card.loot.length) {
      text(x, y, 'Loot', 'smallsemi', P.muted); y += LH.smallsemi + 6;
      for (const l of card.loot) { text(x, y, `[${l.name}]`, 'semi', qc(l.q), 'left', w); y += LH.semi + 4; }
      y += 8;
    }
  } else if (card.kind === 'week') {
    for (const r of card.runs) { text(x, y, r.day, 'small', P.faint); text(x + 100, y, r.title, 'semi', P.text, 'left', 260); text(x + w, y, r.bits, 'base', P.muted, 'right', w - 380); y += LH.semi + 6; }
    const cw = (w - 24) / 2;
    let bottom = y + 12;
    card.tops.forEach((t, i) => {
      const cx = x + i * (cw + 24);
      let cy = y + 12;
      text(cx, cy, t.head, 'smallsemi', P.muted); cy += LH.smallsemi + 6;
      for (const r of t.rows) { text(cx, cy, r.name, 'semi', cc(r.cls) || P.text, 'left', cw - 80); text(cx + cw, cy, r.v, 'base', P.text, 'right'); cy += LH.semi + 4; }
      bottom = Math.max(bottom, cy);
    });
    y = bottom + 10;
    if (card.raiders) {
      // wrap the raider list
      ctx.font = F.small;
      const words = ('Raiders: ' + card.raiders).split(' ');
      let line = '';
      for (const wd of words) {
        if (ctx.measureText(line + wd).width > w && line) { text(x, y, line.trim(), 'small', P.muted); y += LH.small + 2; line = ''; }
        line += wd + ' ';
      }
      if (line.trim()) { text(x, y, line.trim(), 'small', P.muted); y += LH.small + 8; }
    }
  }
  y += 10;
  ops.push(['l', x, y, x + w, y]);
  y += 10;
  text(x, y, 'Leyline', 'smallsemi', P.arcane);
  y += LH.smallsemi + 18;
  cv.width = W * K; cv.height = y * K;
  ctx.scale(K, K);
  ctx.fillStyle = P.bg; ctx.fillRect(0, 0, W, y);
  ctx.textBaseline = 'top';
  const clip = (s, f, maxw) => {
    ctx.font = F[f];
    if (!maxw || ctx.measureText(s).width <= maxw) return s;
    while (s.length > 1 && ctx.measureText(s + '…').width > maxw) s = s.slice(0, -1);
    return s + '…';
  };
  for (const op of ops) {
    if (op[0] === 'r') {
      const [, rx, ry, rw, rh, rr, col] = op;
      ctx.fillStyle = col; ctx.beginPath(); ctx.roundRect ? ctx.roundRect(rx, ry, rw, rh, rr) : ctx.rect(rx, ry, rw, rh); ctx.fill();
    } else if (op[0] === 'l') {
      ctx.strokeStyle = P.line; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(op[1], op[2] + .5); ctx.lineTo(op[3], op[4] + .5); ctx.stroke();
    } else {
      const [, tx, ty, s, f, col, align, maxw] = op;
      const str = clip(s, f, maxw);
      ctx.font = F[f]; ctx.fillStyle = col; ctx.textAlign = align;
      ctx.fillText(str, tx, ty);
    }
  }
  ctx.strokeStyle = P.line; ctx.lineWidth = 1.5;
  ctx.beginPath(); ctx.roundRect ? ctx.roundRect(6, 6, W - 12, y - 10, 14) : ctx.rect(6, 6, W - 12, y - 10); ctx.stroke();
  return cv.toDataURL('image/png');
}
async function showCard(kind, id) {
  const card = await call('card', { kind, ident: id });
  if (!card) return toast('Nothing to show for this player in the fights counted.');
  const url = await drawCard(card);
  const o = document.createElement('div');
  o.className = 'overlay';
  o.innerHTML = `<div class="sheetcard"><img src="${url}" alt="Summary picture"><div class="actions">
    <button class="btn primary" data-act="sharecard">Share…</button><button class="btn" data-act="savecard">Save with report</button><button class="btn" data-act="close">Close</button></div></div>`;
  o.dataset.kind = kind; o.dataset.id = id; o.dataset.url = url; o.dataset.title = card.title;
  document.body.appendChild(o);
}

// ---------------------------------------------------------------- actions
const actions = {
  menu() { S.menu = !S.menu; drawTop(); drawMenu(); },
  tab(el) { S.menu = false; drawMenu(); go(el.dataset.tab === 'chat' ? S.lastChat : S.lastCombat); },
  theme() { setTheme(S.theme === 'dark' ? 'light' : 'dark'); },
  filter(el) { S.filter = el.dataset.k; drawMenu(); },
  scope(el) { call('set', { key: 'run_scope', value: el.dataset.k }).then(() => render(true)); },
  meter(el) { S.meterTab = el.dataset.k; render(true); },
  openkey(el) { const k = el.dataset.k; S.open.has(k) ? S.open.delete(k) : S.open.add(k); render(true); },
  fightdeaths(el) { S.meterTab = 'deaths'; go('#/fight/' + enc(el.dataset.id)); },
  htab(el) { go('#/history/' + el.dataset.k); },
  async copy(el) {
    const text = await call('share_text', { kind: el.dataset.kind, ident: el.dataset.id });
    if (!text) return toast('Nothing to copy for this player in the fights counted.');
    toast(native.copy(text) ? 'Summary copied. Paste it into Discord.' : 'Couldn’t reach the clipboard. Try again.');
  },
  card(el) { showCard(el.dataset.kind, el.dataset.id); },
  async save(el) {
    const folder = await call('save_report', { kind: el.dataset.kind, ident: el.dataset.id });
    toast(folder ? `Report saved to ${folder}` : 'Couldn’t save the report.');
  },
  sharecard() { const o = $('.overlay'); native.shareImage(o.dataset.url, o.dataset.title); },
  async savecard() {
    const o = $('.overlay');
    const folder = await call('save_report', { kind: o.dataset.kind, ident: o.dataset.id, png: o.dataset.url });
    toast(folder ? `Saved with the report in ${folder}` : 'Couldn’t save.');
  },
  close() { closeOverlay(); },
  wowhead(el) { native.openUrl(el.dataset.k); closeOverlay(); },
  copyname(el) { native.copy(el.dataset.k); closeOverlay(); toast('Item name copied.'); },
  lootq(el) { S.loot.q = +el.dataset.k; render(true); },
  lootwho(el) { S.loot.who = el.dataset.k; render(true); },
  msgch(el) { S.msgs.ch = el.dataset.k; S.msgs.limit = 300; render(true); },
  moremsgs() { S.msgs.limit += 300; fillResults(); },
  filtername(el) { S.msgs.q = el.dataset.k; S.msgs.limit = 300; go('#/chat/messages'); },
  clearsearch() { S.msgs.q = ''; render(true); },
  async sound() { const d = await call('chat_watch'); await call('chat_watch', { sound: !d.sound }); render(true); },
  async reread() {
    const d = await call('settings');
    await call('set_logs_dir', { dir: d.logs_dir });
    S.status = null; S.versions = null;
    toast('Reading the logs folder again.');
    poll(true);
    setTimeout(() => render(true), 1500);
  },
  license(el) {
    const names = { inter: 'Inter — SIL Open Font License 1.1', items: 'wow-classic-items — MIT License', chaquopy: 'Chaquopy — MIT License',
      python: 'Python — PSF License Agreement', androidx: 'AndroidX Core — Apache License 2.0', cmangos: 'cMaNGOS TBC database — GNU GPL 3.0' };
    const o = document.createElement('div');
    o.className = 'overlay';
    o.innerHTML = `<div class="sheetcard licbox"><div class="semi" style="margin-bottom:8px">${esc(names[el.dataset.k] || '')}</div><pre>${esc((window.LICENSES || {})[el.dataset.k] || '')}</pre>
      <div class="actions"><button class="btn" data-act="close">Close</button></div></div>`;
    document.body.appendChild(o);
  },
  browse(el) { S.browse = { mode: el.dataset.k, dir: null, back: location.hash }; go('#/browse'); },
  bdir(el) { S.browse.dir = el.dataset.k; render(); },
  async picklog(el) {
    await call('set_logs_dir', { dir: el.dataset.k });
    S.status = null; S.versions = null;
    toast('Reading logs from ' + el.dataset.k);
    location.hash = '#/';
    poll(true);
  },
  async pickreports() { await call('set', { key: 'report_dir', value: S.browse.dir }); toast('Reports will be saved in ' + S.browse.dir); history.back(); },
  cancelbrowse() { history.back(); },
  askstorage() { native.askStorage(); },
  async makefolder() { const d = await call('make_logs_folder'); toast('Made ' + d + '. Copy your logs into it.'); },
};
document.addEventListener('click', e => {
  const t = e.target;
  if (t.classList && t.classList.contains('overlay')) { closeOverlay(); return; }
  if (t.classList && t.classList.contains('shade')) { S.menu = false; drawTop(); drawMenu(); return; }
  const it = t.closest('[data-item]');
  if (it) { showItem(it.dataset.item); return; }
  const a = t.closest('[data-act]');
  if (a && actions[a.dataset.act]) { actions[a.dataset.act](a); return; }
  const g = t.closest('[data-go]');
  if (g) {
    if (S.menu) { S.menu = false; $('#menu').classList.remove('open'); }
    go(g.dataset.go);
  }
});
let typing;
document.addEventListener('input', e => {
  const id = e.target.id;
  clearTimeout(typing);
  typing = setTimeout(async () => {
    if (id === 'lootsearch') { S.loot.text = e.target.value; fillResults(); }
    if (id === 'msgsearch') { S.msgs.q = e.target.value; S.msgs.limit = 300; fillResults(); }
    if (id === 'watchwords') { await call('chat_watch', { words: e.target.value }); fillResults(); }
  }, 250);
});
window.addEventListener('hashchange', () => { closeOverlay(); S.menu = false; $('#menu').classList.remove('open'); const r = route(); if (r.name === 'chat') S.lastChat = location.hash; render(); });

function setTheme(t) {
  S.theme = t;
  document.documentElement.dataset.theme = t;
  native.setTheme(t);
  try { localStorage.setItem('theme', t); } catch (e) {}
  call('set', { key: 'theme', value: t }).catch(() => {});
  render(true);
}

// ---------------------------------------------------------------- live updates
async function poll(now) {
  clearTimeout(poll.timer);
  try {
    const st = await call('status');
    const prev = S.status;
    S.status = st;
    for (const t of st.toasts) toast(t);
    for (const a of st.alerts) { toast(a.text); native.alert(a.sound); }
    const v = st.versions, old = S.versions;
    S.versions = v;
    const r = route();
    const big = !old || v.state !== old.state || v.fights !== old.fights || v.addon !== old.addon || v.items !== old.items;
    const chatChanged = old && v.chat !== old.chat;
    const typingNow = document.activeElement && document.activeElement.tagName === 'INPUT';
    if (!$('.overlay') && r.name !== 'browse') {
      if (big && !typingNow) render(!!old && old.state === v.state);
      else if (chatChanged && Date.now() - S.lastChatRender > 3000) {
        S.lastChatRender = Date.now();
        if (r.name === 'chat') fillResults(); else if (['run', 'fight', 'player', 'history', 'home'].includes(r.name) && !typingNow) render(true);
      } else if (prev && prev.dot !== st.dot) drawTop();
    } else if (!prev || prev.dot !== st.dot) drawTop();
  } catch (e) { /* the Python side is still starting */ }
  poll.timer = setTimeout(poll, S.status && S.status.state === 'ready' ? 1500 : 500);
}

window.Leyline = {
  resolve(id, json) {
    const p = pending[id];
    if (!p) return;
    delete pending[id];
    const j = JSON.parse(json);
    j.error ? p.reject(j.error) : p.resolve(j.ok);
  },
  back() {   // Android's back button: close what's open first; returns true when handled here
    if (closeOverlay()) return true;
    if (S.menu) { S.menu = false; drawTop(); drawMenu(); return true; }
    return false;
  },
  onResume() {
    const had = S.permission;
    S.permission = native.hasStorage();
    if (S.permission && !had) { poll(true); render(); }
  },
};

// ---------------------------------------------------------------- start
document.documentElement.dataset.theme = S.theme;
native.setTheme(S.theme);
S.permission = native.hasStorage();
drawTop();
render();
if (S.permission) poll(true);
