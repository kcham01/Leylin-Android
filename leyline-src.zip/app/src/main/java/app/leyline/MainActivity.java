package app.leyline;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.WindowInsetsController;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** One screen: the HTML app in a WebView, talking to the Python side (api.py) through the bridge below. */
public class MainActivity extends Activity {
    private static final String TAG = "Leyline";
    private WebView web;
    private PyObject api;
    private final ExecutorService python = Executors.newSingleThreadExecutor();  // Python calls, one at a time, off the UI thread
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        boolean debuggable = (getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0;
        if (debuggable || getIntent().getBooleanExtra("devtools", false)) {
            WebView.setWebContentsDebuggingEnabled(true);   // lets the automated test drive the screens
        }
        setBars("dark");
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#12111c"));
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setTextZoom(100);
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onConsoleMessage(ConsoleMessage m) {
                Log.d(TAG, "js: " + m.message() + " (" + m.sourceId() + ":" + m.lineNumber() + ")");
                return true;
            }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String url = r.getUrl().toString();
                if (url.startsWith("file:")) return false;
                openUrl(url);
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "LeylineAndroid");

        // Python starts on the worker thread; calls queue up behind it, so the screen never waits on the UI thread.
        python.execute(() -> {
            try {
                if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
                String items = copyAsset("Leyline_items.dat");
                api = Python.getInstance().getModule("leyline_android")
                        .callAttr("make_api", new File(getFilesDir(), "leyline").getAbsolutePath(), items);
            } catch (Throwable t) {
                Log.e(TAG, "python start failed", t);
            }
        });
        web.loadUrl("file:///android_asset/web/index.html");
    }

    /** Assets live inside the APK; Python needs a real file. Copied again when the app is updated. */
    private String copyAsset(String name) throws Exception {
        File out = new File(getFilesDir(), name);
        long stamp = getPackageManager().getPackageInfo(getPackageName(), 0).lastUpdateTime;
        File mark = new File(getFilesDir(), name + ".stamp");
        if (out.exists() && mark.exists() && mark.lastModified() == stamp) return out.getAbsolutePath();
        try (InputStream in = getAssets().open(name); OutputStream o = new FileOutputStream(out)) {
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
        }
        mark.createNewFile();
        mark.setLastModified(stamp);
        return out.getAbsolutePath();
    }

    private void js(String code) { ui.post(() -> web.evaluateJavascript(code, null)); }

    private boolean hasStorage() {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
        return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void askStorage() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + getPackageName())));
            } catch (ActivityNotFoundException e) {
                startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
            }
        } else {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        }
    }

    private void openUrl(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (ActivityNotFoundException e) {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("link", url));
            Toast.makeText(this, "No browser found; link copied", Toast.LENGTH_LONG).show();
        }
    }

    @SuppressWarnings("deprecation")
    private void setBars(String theme) {
        boolean light = "light".equals(theme);
        int bg = Color.parseColor(light ? "#f5f4fa" : "#12111c");
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        if (Build.VERSION.SDK_INT >= 30 && getWindow().getInsetsController() != null) {
            int flags = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
            getWindow().getInsetsController().setSystemBarsAppearance(light ? flags : 0, flags);
        } else {
            View d = getWindow().getDecorView();
            int f = d.getSystemUiVisibility();
            f = light ? (f | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR) : (f & ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
            d.setSystemUiVisibility(f);
        }
    }

    /** What the HTML side can ask for. */
    private class Bridge {
        @JavascriptInterface
        public void call(int id, String name, String args) {
            python.execute(() -> {
                String out;
                try {
                    if (api == null) throw new IllegalStateException("Python didn't start");
                    out = api.callAttr("call", name, args).toString();
                } catch (Throwable t) {
                    Log.e(TAG, "call " + name, t);
                    out = "{\"error\": " + JSONObject.quote(String.valueOf(t)) + "}";
                }
                js("window.Leyline.resolve(" + id + "," + JSONObject.quote(out) + ")");
            });
        }

        @JavascriptInterface
        public boolean copyText(String text) {
            ui.post(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("Leyline", text));
            });
            return true;
        }

        @JavascriptInterface
        public void shareImage(String base64png, String title) {
            ui.post(() -> {
                try {
                    File dir = new File(getCacheDir(), "share");
                    dir.mkdirs();
                    String safe = (title == null ? "Leyline" : title).replaceAll("[^A-Za-z0-9 _-]", "").trim();
                    File f = new File(dir, (safe.isEmpty() ? "Leyline" : safe) + ".png");
                    try (OutputStream o = new FileOutputStream(f)) { o.write(Base64.decode(base64png, Base64.DEFAULT)); }
                    Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".files", f);
                    Intent send = new Intent(Intent.ACTION_SEND).setType("image/png").putExtra(Intent.EXTRA_STREAM, uri)
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    send.setClipData(ClipData.newRawUri("", uri));
                    startActivity(Intent.createChooser(send, "Share picture"));
                } catch (Exception e) {
                    Log.e(TAG, "share", e);
                    Toast.makeText(MainActivity.this, "Couldn't share the picture", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void openUrl(String url) { ui.post(() -> MainActivity.this.openUrl(url)); }

        @JavascriptInterface
        public void alert(boolean sound) {
            ui.post(() -> {
                try {
                    Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    if (v != null) v.vibrate(VibrationEffect.createOneShot(180, VibrationEffect.DEFAULT_AMPLITUDE));
                    if (sound) {
                        Ringtone r = RingtoneManager.getRingtone(MainActivity.this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION));
                        if (r != null) r.play();
                    }
                } catch (Exception e) {
                    Log.e(TAG, "alert", e);
                }
            });
        }

        @JavascriptInterface public boolean hasStorage() { return MainActivity.this.hasStorage(); }
        @JavascriptInterface public void askStorage() { ui.post(MainActivity.this::askStorage); }
        @JavascriptInterface public void setTheme(String theme) { ui.post(() -> setBars(theme)); }

        @JavascriptInterface
        public String version() {
            try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Exception e) { return "?"; }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.evaluateJavascript("window.Leyline && window.Leyline.onResume()", null);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        web.evaluateJavascript("window.Leyline && window.Leyline.onResume()", null);
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.Leyline ? window.Leyline.back() : false", handled -> {
            if ("true".equals(handled)) return;
            if (web.canGoBack()) web.goBack();
            else MainActivity.super.onBackPressed();
        });
    }
}
