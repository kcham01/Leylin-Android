"""Item lookups by name: quality, item id (for Wowhead links) and the game-style tooltip.

The chat log only has item names, so names are all there is to go on. Leyline_items.dat (next to the app)
holds about 30,000 TBC items. The AutoLog addon's loot records add exact ids and qualities on top.
Random-enchant items ("Darkcrest Sabatons of the Champion") are found through their base name.
"""
import json
import os
import threading
import urllib.parse
import zlib

ITEMS_FILE = 'Leyline_items.dat'


def wowhead_url(info, name):
    if info and info.get('id'):
        return f"https://www.wowhead.com/tbc/item={info['id']}"
    return 'https://www.wowhead.com/tbc/search?q=' + urllib.parse.quote(name)


class ItemDB:
    def __init__(self):
        self.by_name = {}     # name -> [id, name, q, ilvl, tooltip]
        self.learned = {}     # name -> {'id', 'q'} from the addon (exact, beats the file)
        self.ready = False
        self.error = None
        self.count = 0
        self._cache = {}

    def find_file(self, *dirs):
        for d in dirs:
            if d:
                p = os.path.join(d, ITEMS_FILE)
                if os.path.isfile(p):
                    return p
        return None

    def load(self, path):
        try:
            data = json.loads(zlib.decompress(open(path, 'rb').read()).decode('utf-8'))
            self.by_name = {row[1]: row for row in data['items']}
            self.count = len(self.by_name)
            self._cache = {}
            self.ready = True
        except Exception as ex:
            self.error = f'{path}: {ex}'

    def load_async(self, path, done=None):
        def run():
            self.load(path)
            if done:
                done()
        threading.Thread(target=run, daemon=True).start()

    def learn(self, events):
        """Exact ids and qualities from the addon's loot records."""
        n = 0
        for e in events or ():
            if e.get('e') == 'loot' and e.get('name') and (e.get('item') or e.get('q') is not None):
                old = self.learned.get(e['name'])
                new = {'id': e.get('item'), 'q': e.get('q')}
                if old != new:
                    self.learned[e['name']] = new
                    n += 1
        if n:
            self._cache = {}

    def info(self, name):
        """{'id', 'q', 'name', 'base', 'ilvl', 'tooltip'} or None when the item isn't known."""
        if not name:
            return None
        if name in self._cache:
            return self._cache[name]
        out = None
        row = self.by_name.get(name)
        base = name
        if row is None:
            # random enchants add " of the Owl" / " of Stamina" to a base item; try shorter and shorter names
            cut = name
            while ' of ' in cut:
                cut = cut[:cut.rfind(' of ')]
                row = self.by_name.get(cut)
                if row:
                    base = cut
                    break
        if row:
            out = {'id': row[0], 'q': row[2], 'name': name, 'base': base, 'ilvl': row[3], 'tooltip': row[4]}
        got = self.learned.get(name)
        if got:
            out = dict(out or {'name': name, 'base': name, 'ilvl': None, 'tooltip': None})
            if got.get('id'):
                out['id'] = got['id']
            if got.get('q') is not None:
                out['q'] = got['q']
        if len(self._cache) > 20000:
            self._cache = {}
        self._cache[name] = out
        return out

    def quality(self, name, q=None):
        if q is not None:
            return q
        i = self.info(name)
        return i.get('q') if i else None


ITEMS = ItemDB()
