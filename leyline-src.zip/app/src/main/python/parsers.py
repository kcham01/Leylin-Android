# ======================================================================
#  Log parsers (combat + chat). Pure Python, no UI.
# ======================================================================

import csv
import re
import time
from datetime import datetime

from bosses import BOSS_TABLE, BOSS_NPC, CLASSIC_INSTANCES, ENC_NPCS, HOLIDAY_ENCS  # dev

F_MINE, F_PARTY, F_RAID, F_GROUP = 0x1, 0x2, 0x4, 0x7
F_FRIENDLY = 0x10
F_PLAYER, F_PET, F_GUARDIAN, F_OBJECT = 0x400, 0x1000, 0x2000, 0x4000
NO_GUID = '0000000000000000'
LIVE_IDLE = 30000       # live: a fight with nothing new in the log for this long has ended
OPEN_WORLD_GAP = 20000  # out in the world, a fight with a mob still alive survives this long a pause
NPC_BOSS_GAP = 20000    # ms of quiet that ends a boss fight found by its NPC (no ENCOUNTER_END to say so)
TRASH_GAP = 5000        # ms without combat that ends a trash fight
ACTIVE_GAP = 3500       # gaps longer than this don't count as active time
RUN_GAP = 3 * 3600_000  # re-entering the same instance after this long is a new run
WORLD_INSTANCES = {0, 1, 530, 571}
PVP_INSTANCES = {489, 529, 30, 566, 559, 562, 572, 617, 618}  # battlegrounds and arenas
SELF_REZ = {'Soulstone Resurrection', 'Reincarnation', 'Ankh', 'Resurrection'}

CLASS_SPELLS = {
    'WARRIOR': ['Heroic Strike', 'Sunder Armor', 'Bloodthirst', 'Mortal Strike', 'Whirlwind', 'Shield Slam', 'Revenge', 'Battle Shout', 'Commanding Shout', 'Execute', 'Slam', 'Cleave', 'Devastate', 'Thunder Clap', 'Demoralizing Shout', 'Rampage', 'Overpower', 'Hamstring', 'Intercept', 'Shield Block', 'Bloodrage', 'Berserker Rage', 'Deep Wound', 'Deep Wounds', 'Taunt'],
    'ROGUE': ['Sinister Strike', 'Eviscerate', 'Slice and Dice', 'Mutilate', 'Backstab', 'Rupture', 'Hemorrhage', 'Instant Poison', 'Deadly Poison', 'Wound Poison', 'Kick', 'Expose Armor', 'Envenom', 'Ambush', 'Garrote', 'Blade Flurry', 'Adrenaline Rush', 'Kidney Shot', 'Cheap Shot', 'Gouge', 'Feint', 'Vanish', 'Shiv'],
    'HUNTER': ['Steady Shot', 'Auto Shot', 'Arcane Shot', 'Multi-Shot', 'Serpent Sting', "Hunter's Mark", 'Aimed Shot', 'Kill Command', 'Bestial Wrath', 'Rapid Fire', 'Raptor Strike', 'Mongoose Bite', 'Wing Clip', 'Feign Death', 'Misdirection', 'Explosive Trap', 'Immolation Trap', 'Freezing Trap', 'Scatter Shot', 'Silencing Shot', 'Concussive Shot', 'Viper Sting', 'Volley', 'Mend Pet', 'Tranquilizing Shot'],
    'MAGE': ['Frostbolt', 'Fireball', 'Arcane Missiles', 'Arcane Blast', 'Scorch', 'Fire Blast', 'Ice Lance', 'Arcane Explosion', 'Pyroblast', 'Frost Nova', 'Counterspell', 'Polymorph', 'Evocation', 'Arcane Power', 'Icy Veins', 'Combustion', 'Ice Block', 'Mana Shield', 'Ice Barrier', 'Blink', 'Cone of Cold', 'Flamestrike', "Dragon's Breath", 'Blast Wave', 'Molten Armor', 'Mage Armor', 'Arcane Intellect', 'Arcane Brilliance', 'Ignite', 'Presence of Mind', 'Cold Snap', 'Remove Lesser Curse', 'Summon Water Elemental', 'Invisibility'],
    'WARLOCK': ['Shadow Bolt', 'Corruption', 'Curse of Agony', 'Curse of the Elements', 'Curse of Recklessness', 'Curse of Doom', 'Curse of Tongues', 'Immolate', 'Incinerate', 'Life Tap', 'Unstable Affliction', 'Siphon Life', 'Seed of Corruption', 'Drain Life', 'Drain Soul', 'Searing Pain', 'Soul Fire', 'Shadowburn', 'Conflagrate', 'Fear', 'Howl of Terror', 'Death Coil', 'Banish', 'Hellfire', 'Rain of Fire', 'Dark Pact', 'Fel Armor', 'Demon Armor', 'Soulshatter', 'Shadowfury', 'Summon Imp', 'Summon Felhunter', 'Summon Voidwalker', 'Summon Succubus', 'Summon Felguard', 'Create Healthstone', 'Ritual of Souls'],
    'PRIEST': ['Flash Heal', 'Greater Heal', 'Renew', 'Prayer of Healing', 'Prayer of Mending', 'Power Word: Shield', 'Circle of Healing', 'Binding Heal', 'Mind Blast', 'Shadow Word: Pain', 'Shadow Word: Death', 'Mind Flay', 'Vampiric Touch', 'Vampiric Embrace', 'Devouring Plague', 'Shadowfiend', 'Smite', 'Holy Fire', 'Power Word: Fortitude', 'Prayer of Fortitude', 'Inner Fire', 'Psychic Scream', 'Fade', 'Dispel Magic', 'Mass Dispel', 'Abolish Disease', 'Pain Suppression', 'Power Infusion', 'Shadowform', 'Lightwell', 'Desperate Prayer', 'Mana Burn', 'Divine Spirit', 'Prayer of Spirit', 'Shadow Protection', 'Prayer of Shadow Protection', 'Inner Focus', 'Fear Ward', 'Silence'],
    'DRUID': ['Rejuvenation', 'Lifebloom', 'Regrowth', 'Healing Touch', 'Swiftmend', 'Tranquility', 'Wrath', 'Starfire', 'Moonfire', 'Insect Swarm', 'Hurricane', 'Mangle (Cat)', 'Mangle (Bear)', 'Shred', 'Rip', 'Ferocious Bite', 'Rake', 'Maul', 'Swipe', 'Lacerate', 'Faerie Fire', 'Faerie Fire (Feral)', 'Innervate', 'Rebirth', 'Barkskin', 'Cat Form', 'Bear Form', 'Dire Bear Form', 'Moonkin Form', 'Tree of Life', 'Mark of the Wild', 'Gift of the Wild', 'Thorns', 'Entangling Roots', 'Cyclone', 'Abolish Poison', 'Remove Curse', "Nature's Swiftness", 'Growl', 'Demoralizing Roar', "Tiger's Fury", 'Prowl', 'Dash'],
    'SHAMAN': ['Lightning Bolt', 'Chain Lightning', 'Chain Heal', 'Lesser Healing Wave', 'Healing Wave', 'Earth Shock', 'Flame Shock', 'Frost Shock', 'Stormstrike', 'Windfury Attack', 'Windfury Totem', 'Grace of Air Totem', 'Strength of Earth Totem', 'Mana Spring Totem', 'Mana Tide Totem', 'Searing Totem', 'Fire Nova Totem', 'Magma Totem', 'Totem of Wrath', 'Wrath of Air Totem', 'Tremor Totem', 'Grounding Totem', 'Earth Shield', 'Water Shield', 'Lightning Shield', 'Bloodlust', 'Heroism', 'Purge', 'Cure Poison', 'Cure Disease', 'Shamanistic Rage', 'Elemental Mastery', 'Flametongue Attack', 'Rockbiter Weapon', 'Earthbind Totem', 'Tranquil Air Totem', 'Healing Stream Totem', 'Ancestral Spirit'],
    'PALADIN': ['Holy Light', 'Flash of Light', 'Holy Shock', 'Judgement', 'Judgement of Light', 'Judgement of Wisdom', 'Judgement of the Crusader', 'Judgement of Righteousness', 'Judgement of Command', 'Judgement of Blood', 'Judgement of Vengeance', 'Seal of Light', 'Seal of Wisdom', 'Seal of Righteousness', 'Seal of Command', 'Seal of the Crusader', 'Seal of Blood', 'Seal of Vengeance', 'Crusader Strike', 'Consecration', 'Holy Shield', "Avenger's Shield", 'Exorcism', 'Hammer of Wrath', 'Hammer of Justice', 'Divine Shield', 'Divine Protection', 'Blessing of Protection', 'Blessing of Freedom', 'Blessing of Sacrifice', 'Blessing of Might', 'Blessing of Wisdom', 'Blessing of Kings', 'Blessing of Salvation', 'Greater Blessing of Might', 'Greater Blessing of Wisdom', 'Greater Blessing of Kings', 'Greater Blessing of Salvation', 'Cleanse', 'Purify', 'Lay on Hands', 'Divine Favor', 'Divine Illumination', 'Righteous Defense', 'Righteous Fury', 'Avenging Wrath', 'Devotion Aura', 'Retribution Aura', 'Concentration Aura', 'Sanctity Aura', 'Vengeance', 'Redemption', 'Seal of Justice'],
}
for _c, _names in {'WARRIOR': ['Battle Stance', 'Defensive Stance', 'Berserker Stance', 'Charge', 'Victory Rush', 'Recklessness', 'Shield Wall', 'Last Stand', 'Intimidating Shout', 'Pummel', 'Shield Bash', 'Disarm', 'Sweeping Strikes', 'Death Wish', 'Spell Reflection', 'Intervene'], 'ROGUE': ['Stealth', 'Sprint', 'Evasion', 'Cloak of Shadows', 'Blind', 'Sap', 'Distract', 'Cold Blood', 'Preparation', 'Shadowstep', 'Pick Pocket', 'Mind-numbing Poison', 'Crippling Poison', 'Deadly Throw', 'Riposte'], 'HUNTER': ['Aspect of the Hawk', 'Aspect of the Monkey', 'Aspect of the Cheetah', 'Aspect of the Pack', 'Aspect of the Viper', 'Aspect of the Wild', 'Aspect of the Beast', 'Trueshot Aura', 'Call Pet', 'Revive Pet', 'Feed Pet', 'Track Humanoids', 'Track Beasts', 'Flare', 'Deterrence', 'Disengage', 'Intimidation', 'Readiness', 'Wyvern Sting', 'Scorpid Sting', 'Arcane Shot'], 'MAGE': ['Frost Armor', 'Ice Armor', 'Dampen Magic', 'Amplify Magic', 'Conjure Water', 'Conjure Food', 'Conjure Mana Emerald', 'Slow Fall', 'Fire Ward', 'Frost Ward', 'Spellsteal', 'Slow', 'Ritual of Refreshment', 'Teleport: Shattrath', 'Portal: Shattrath'], 'WARLOCK': ['Demon Skin', 'Shadow Ward', 'Unending Breath', 'Detect Invisibility', 'Create Soulstone', 'Create Firestone', 'Create Spellstone', 'Ritual of Summoning', 'Health Funnel', 'Enslave Demon', 'Eye of Kilrogg', 'Soul Link', 'Amplify Curse', 'Curse of Weakness', 'Curse of Exhaustion', 'Fel Domination', 'Demonic Sacrifice'], 'PRIEST': ['Touch of Weakness', 'Shadowguard', 'Feedback', "Elune's Grace", 'Starshards', 'Chastise', 'Holy Nova', 'Levitate', 'Mind Control', 'Mind Soothe', 'Mind Vision', 'Resurrection', 'Shackle Undead', 'Spirit of Redemption'], 'DRUID': ['Travel Form', 'Aquatic Form', 'Flight Form', 'Swift Flight Form', 'Omen of Clarity', 'Leader of the Pack', 'Moonkin Aura', 'Hibernate', 'Soothe Animal', 'Track Humanoids (Cat)', 'Frenzied Regeneration', 'Enrage', 'Feral Charge', 'Bash', 'Pounce', 'Ravage', 'Claw', 'Revive'], 'SHAMAN': ['Ghost Wolf', 'Flametongue Weapon', 'Windfury Weapon', 'Frostbrand Weapon', 'Rockbiter Weapon', 'Water Walking', 'Water Breathing', 'Far Sight', 'Astral Recall', 'Reincarnation', 'Stoneskin Totem', 'Stoneclaw Totem', 'Windwall Totem', 'Nature Resistance Totem', 'Fire Resistance Totem', 'Frost Resistance Totem', 'Poison Cleansing Totem', 'Disease Cleansing Totem', 'Sentry Totem', 'Fire Elemental Totem', 'Earth Elemental Totem', 'Unleashed Rage', 'Totemic Call'], 'PALADIN': ['Crusader Aura', 'Shadow Resistance Aura', 'Frost Resistance Aura', 'Fire Resistance Aura', 'Sense Undead', 'Summon Warhorse', 'Summon Charger', 'Turn Undead', 'Repentance', 'Blessing of Light', 'Greater Blessing of Light', 'Blessing of Sanctuary', 'Greater Blessing of Sanctuary', 'Divine Intervention', 'Spiritual Attunement']}.items():
    CLASS_SPELLS[_c] = CLASS_SPELLS[_c] + [n for n in _names if n not in CLASS_SPELLS[_c]]
# names that more than one class (or pets and procs) can show up with tell nothing
# and effects the log credits to whoever carries them (a Lifebloom bloom, Earth Shield and Prayer of Mending heals,
# Thorns damage, Windfury procs, party auras and totem buffs)
_AMBIGUOUS = {"Nature's Swiftness", 'Enrage', 'Track Humanoids', 'Revive', 'Claw', 'Bash', 'Shoot', 'Resurrection',
              'Lifebloom', 'Earth Shield', 'Prayer of Mending', 'Thorns', 'Windfury Attack', 'Heroism', 'Bloodlust',
              'Leader of the Pack', 'Moonkin Aura', 'Trueshot Aura', 'Unleashed Rage', 'Tree of Life', 'Totem of Wrath',
              'Wrath of Air Totem', 'Grace of Air Totem', 'Strength of Earth Totem', 'Mana Spring Totem', 'Windfury Totem',
              'Tranquil Air Totem', 'Stoneskin Totem', 'Nature Resistance Totem', 'Fire Resistance Totem', 'Frost Resistance Totem',
              'Devotion Aura', 'Retribution Aura', 'Concentration Aura', 'Sanctity Aura', 'Crusader Aura',
              'Shadow Resistance Aura', 'Frost Resistance Aura', 'Fire Resistance Aura', 'Vampiric Embrace', 'Mana Tide Totem',
              'Healing Stream Totem', 'Fire Nova Totem', 'Magma Totem', 'Searing Totem'}
_seen_in = {}
for _c, _names in CLASS_SPELLS.items():
    for _n in _names:
        _seen_in.setdefault(_n, set()).add(_c)
SPELL_CLASS = {n: c for c, names in CLASS_SPELLS.items() for n in names if len(_seen_in[n]) == 1 and n not in _AMBIGUOUS}

CONSUMABLE_NAMES = {'Healing Potion', 'Restore Mana', 'Master Healthstone', 'Major Healthstone', 'Greater Healthstone', 'Healthstone', 'Dark Rune', 'Demonic Rune', 'Haste', 'Destruction', 'Ironshield', 'Heroic', 'Insane Strength', 'Free Action', 'Living Action', 'Restore Energy', 'Nightmare Seed', 'Fel Mana', 'Shrouding Potion', 'Rage'}
CONSUMABLE_IDS = {28495, 28499, 27869, 16666, 28507, 28508, 28515, 28506, 28494, 38929, 27235, 27236, 27237, 17534, 17531, 22729, 28492, 28550}
CONSUMABLE_LABEL = {'Healing Potion': 'Healing potion', 'Restore Mana': 'Mana potion', 'Dark Rune': 'Dark rune', 'Demonic Rune': 'Demonic rune', 'Haste': 'Haste potion', 'Destruction': 'Destruction potion', 'Ironshield': 'Ironshield potion', 'Heroic': 'Heroic potion', 'Insane Strength': 'Insane strength potion', 'Fel Mana': 'Fel mana potion'}

# Damage players could have avoided. A source name limits it to one caster when the spell name is shared.
AVOIDABLE = {
    'Flame Wreath': None,
    'Arcane Explosion': {'Shade of Aran'},
    'Blizzard': {'Shade of Aran'},
    'Hellfire': {'Netherspite Infernal'},
    'Consumption': None,
    'Charred Earth': None,
    'Shadow Nova': {'Prince Malchezaar'},
    'Distracting Ash': None,
}

# Known raid boss lists (encounter IDs from the game data), used to show progress like 8/11.
INSTANCE_BOSSES = {
    532: ('Karazhan', [(652, 'Attumen the Huntsman'), (653, 'Moroes'), (654, 'Maiden of Virtue'), (655, 'Opera Hall'), (656, 'The Curator'), (657, 'Terestian Illhoof'), (658, 'Shade of Aran'), (659, 'Netherspite'), (660, 'Chess Event'), (661, 'Prince Malchezaar'), (662, 'Nightbane')]),
    565: ("Gruul's Lair", [(649, 'High King Maulgar'), (650, 'Gruul the Dragonkiller')]),
    544: ("Magtheridon's Lair", [(651, 'Magtheridon')]),
    568: ("Zul'Aman", [(1189, "Akil'zon"), (1190, 'Nalorakk'), (1191, "Jan'alai"), (1192, 'Halazzi'), (1193, 'Hex Lord Malacrass'), (1194, "Zul'jin")]),
}

# every other dungeon and raid: boss lists from the NPC table (bosses.py), in encounter order
for _inst, _lst in BOSS_TABLE.items():
    if _inst not in INSTANCE_BOSSES:
        _seen = []
        for _e, _n, _ in _lst:
            if _e not in [x[0] for x in _seen]:
                _seen.append((_e, 'Opera Event' if _e == 655 else _n))
        INSTANCE_BOSSES[_inst] = (CLASSIC_INSTANCES.get(_inst, ('',))[0], _seen)

HANDLED = {
    'COMBAT_LOG_VERSION', 'ZONE_CHANGE', 'ENCOUNTER_START', 'ENCOUNTER_END', 'SPELL_SUMMON', 'UNIT_DIED', 'PARTY_KILL', 'SPELL_RESURRECT',
    'SWING_DAMAGE', 'RANGE_DAMAGE', 'SPELL_DAMAGE', 'SPELL_PERIODIC_DAMAGE', 'SPELL_BUILDING_DAMAGE', 'DAMAGE_SHIELD', 'DAMAGE_SPLIT', 'ENVIRONMENTAL_DAMAGE',
    'SPELL_HEAL', 'SPELL_PERIODIC_HEAL', 'SPELL_ABSORBED', 'SPELL_INTERRUPT', 'SPELL_DISPEL', 'SPELL_STOLEN', 'SPELL_CAST_SUCCESS',
}
DAMAGE_EVENTS = {'SWING_DAMAGE', 'RANGE_DAMAGE', 'SPELL_DAMAGE', 'SPELL_PERIODIC_DAMAGE', 'SPELL_BUILDING_DAMAGE', 'DAMAGE_SHIELD', 'DAMAGE_SPLIT', 'ENVIRONMENTAL_DAMAGE'}
HEAL_EVENTS = {'SPELL_HEAL', 'SPELL_PERIODIC_HEAL'}
GUID_PREFIXES = ('Player-', 'Creature-', 'Pet-', 'Vehicle-', 'GameObject-', 'Vignette-', 'Item-')


def npc_of(guid):
    """Creature-0-6263-530-15-18476-000056BBC3 -> 18476"""
    p = guid.split('-')
    return int(p[5]) if len(p) > 6 and p[5].isdigit() else None


def is_guid(s):
    return s == NO_GUID or s.startswith(GUID_PREFIXES)


def is_float(s):
    if '.' not in s:
        return False
    s = s[1:] if s[:1] == '-' else s
    a, _, b = s.partition('.')
    return a.isdigit() and b.isdigit()


def is_int(s):
    s = s[1:] if s[:1] == '-' else s
    return s.isdigit()


def to_int(s):
    try:
        return int(s)
    except (TypeError, ValueError):
        return 0


def flags_of(s):
    try:
        return int(s, 16)
    except (TypeError, ValueError):
        return 0


def short_name(n):
    """'Name-Realm' or 'Name-Realm-US' -> 'Name'. Player names can't contain a dash, realm names can."""
    if not n:
        return n
    i = n.find('-')
    return n[:i] if i > 0 else n


class Stamper:
    """Turns 'M/D[/Y] HH:MM:SS.mmm' into epoch milliseconds, caching each second."""

    def __init__(self, year):
        self.year = year
        self.cache = {}
        self.last_month = None

    def __call__(self, stamp):
        sp = stamp.find(' ')
        if sp < 0:
            return None
        date, clock = stamp[:sp], stamp[sp + 1:]
        hms, _, frac = clock.partition('.')
        key = date + ' ' + hms
        base = self.cache.get(key)
        if base is None:
            try:
                d = date.split('/')
                month = int(d[0])
                if len(d) > 2:
                    y = int(d[2])
                else:
                    # no year in the stamp: a log running past New Year's Eve goes from month 12 to month 1
                    if self.last_month and self.last_month - month >= 6:
                        self.year += 1
                    y = self.year
                    self.last_month = month
                if y < 100:
                    y += 2000
                h, m, s = hms.split(':')
                base = int(datetime(y, int(d[0]), int(d[1]), int(h), int(m), int(s)).timestamp() * 1000)
            except (ValueError, IndexError):
                return None
            if len(self.cache) > 200_000:
                self.cache.clear()
            self.cache[key] = base
        return base + int((frac + '000')[:3]) if frac[:3].isdigit() else base


def split_line(line):
    """Returns (stamp, rest) where rest is everything after the two spaces, or (None, None)."""
    i = line.find('  ')
    if i < 0:
        return None, None
    return line[:i], line[i + 2:].rstrip('\r\n')


def new_stats(name):
    return {'name': name, 'dmg': 0, 'heal': 0, 'overheal': 0, 'absorb': 0, 'taken': 0, 'interrupts': 0, 'dispels': 0, 'deaths': 0,
            'cons': {}, 'avoid': 0, 'avoid_hits': 0, 'active': 0, 'last': 0, 'dmg_by': {}, 'heal_by': {}, 'taken_by': {}, 'kicked': {}}


class CombatParser:
    def __init__(self, year=None, source=''):
        self.stamp = Stamper(year or datetime.now().year)
        self.source = source
        self.advanced = None
        self.adv_len = 0
        self.players = {}       # guid -> {name, cls, mine}
        self.classes = {}       # any player's name -> class, from class spells they cast (colours names in chat)
        self.class_votes = {}   # name -> {class: spells seen}; the class with the most wins, so one odd spell can't flip it
        self.owners = {}        # pet guid -> owner guid
        self.recent = {}        # player guid -> last events (death recap)
        self.fights = []
        self.runs = []
        self.cur = None
        self.run = None
        self.zone = None
        self.saw_zone = False
        self.last_ts = 0
        self.seq = 0
        self.handled = 0  # lines that could change what's shown
        self.clock_shift = 0
        self.after_enc = None   # the boss fight that just ended, while its leftover adds/council may still be fought
        self.recent_dead = {}   # creature guid -> (ts, fight it died in): hits landing just after a death belong there
        self.raw_layout = None  # damage lines carry the unmitigated amount (amount, raw, overkill...) - learnt from the log
        self.enc_mode = False   # the log writes ENCOUNTER_START/END (retail-style clients); otherwise bosses are found by NPC id

    # ---- groups ----
    def group_of(self, guid, flags, name):
        if not (flags & F_GROUP) or guid == NO_GUID:
            return None
        if flags & F_PLAYER:
            if guid not in self.players:
                self.players[guid] = {'name': short_name(name), 'cls': None, 'mine': bool(flags & F_MINE)}
            return guid
        if flags & (F_PET | F_GUARDIAN | F_OBJECT):
            owner = self.owners.get(guid)
            if owner and owner in self.players:
                return owner
        return None

    def stats(self, fight, guid):
        s = fight['players'].get(guid)
        if s is None:
            s = fight['players'][guid] = new_stats(self.players[guid]['name'])
        return s

    @staticmethod
    def mark_active(s, ts):
        if s.get('last') and ts - s['last'] <= ACTIVE_GAP:
            s['active'] += ts - s['last']
        s['last'] = ts

    # ---- runs ----
    def run_for(self, f):
        in_instance = self.zone['is_instance'] if self.zone else False
        inst_id = self.zone['id'] if self.zone else None
        if not self.saw_zone and f.get('instance_id'):
            in_instance, inst_id = True, f['instance_id']
        if not in_instance:
            if f['kind'] == 'trash' and self.run and not self.saw_zone and f['start'] - self.run['end'] < 1_800_000:
                return self.run
            return None
        r = self.run
        boss_again = f['kind'] == 'boss' and r is not None and f.get('encounter_id') in r['killed'] and f.get('encounter_id') not in HOLIDAY_ENCS
        entry = self.zone.get('entry') if self.zone else None
        new_match = inst_id in PVP_INSTANCES and r is not None and r.get('entry') != entry  # every battleground/arena entry is its own match
        if r is None or r['instance_id'] != inst_id or f['start'] - r['end'] > RUN_GAP or boss_again or new_match:
            info = INSTANCE_BOSSES.get(inst_id)
            name = (self.zone and self.zone['is_instance'] and self.zone['name']) or (info and info[0]) or f.get('zone_name') or 'Instance'
            self.run = {'id': f"r{self.source}-{f['start']}", 'instance_id': inst_id, 'name': name, 'start': f['start'], 'end': f['start'],
                        'fights': [], 'killed': [], 'wipes': 0, 'source': self.source, 'entry': entry,
                        'difficulty': self.zone.get('diff') if self.zone else f.get('difficulty')}
            self.runs.append(self.run)
            if boss_again and r is not None and r['instance_id'] == inst_id and entry is not None:
                # a reset and a fresh run: what happened since you last zoned in belongs to the new run
                moved = [x for x in self.fights if x.get('run_id') == r['id'] and x.get('entry') == entry]
                if moved:
                    ids = {x['id'] for x in moved}
                    r['fights'] = [i for i in r['fights'] if i not in ids]
                    r['wipes'] -= sum(1 for x in moved if x['kind'] == 'boss' and not x['success'])
                    r['killed'] = [k for k in r['killed'] if not any(x['kind'] == 'boss' and x['success'] and x.get('encounter_id') == k for x in moved)] + \
                                  [k for k in r['killed'] if False]
                    rest = [x for x in self.fights if x['id'] in set(r['fights'])]
                    r['end'] = max((x['end'] for x in rest), default=r['start'])
                    for x in moved:
                        x['run_id'] = self.run['id']
                    self.run['fights'] = [x['id'] for x in moved]
                    self.run['start'] = min(x['start'] for x in moved)
                    self.run['wipes'] = sum(1 for x in moved if x['kind'] == 'boss' and not x['success'])
        return self.run

    # ---- fights ----
    def open_fight(self, kind, ts, **extra):
        self.seq += 1
        f = {'id': f'{self.source}#{self.seq}', 'kind': kind, 'name': '', 'start': ts, 'end': ts, 'players': {}, 'hostiles': {}, 'deaths': [],
             'boss': None, 'success': None, 'live': True, 'zone_name': self.zone['name'] if self.zone else '', 'attempt': None,
             'run_id': None, 'boss_hp': None, 'targets': 0, 'entry': self.zone.get('entry') if self.zone else None}
        f.update(extra)
        self.cur = f
        return f

    def close_fight(self, ts=None):
        f = self.cur
        if not f:
            return
        self.cur = None
        f['live'] = False
        f['kills'] = len(f.get('dead') or ())
        for k in ('boss_npcs', 'npc_last', 'npcs_dead', 'last_kill', 'forced', 'gap', 'alive', 'dead', 'cleared'):
            f.pop(k, None)
        if f['kind'] == 'boss' and ts:
            f['end'] = ts
        for s in f['players'].values():
            s.pop('last', None)
        f['deaths'] = [d for d in f['deaths'] if not d.get('fake')]
        if f['kind'] == 'trash':
            dmg = sum(s['dmg'] for s in f['players'].values())
            killed = bool(f.get('dead'))
            if dmg == 0 and not f['deaths']:
                return
            if f['end'] - f['start'] < 1500 and dmg < 2000 and not killed:
                return
            if f['hostiles']:
                name, h = max(f['hostiles'].items(), key=lambda kv: kv[1]['dmg'])
                n = len(h['units'])
                f['name'] = name + (f' ×{n}' if n > 1 else '')
                f['targets'] = len(f['hostiles'])
            else:
                f['name'] = 'Trash'
        for h in f['hostiles'].values():
            h['units'] = len(h['units'])
        b = f.pop('boss', None)
        if b and b['max']:
            f['boss_hp'] = max(0.0, min(1.0, b['hp'] / b['max']))
        run = self.run_for(f)
        if run:
            f['run_id'] = run['id']
            run['fights'].append(f['id'])
            run['end'] = max(run['end'], f['end'])
            if f['kind'] == 'boss':
                f['attempt'] = 1 + sum(1 for x in self.fights if x.get('run_id') == run['id'] and x['kind'] == 'boss' and x.get('encounter_id') == f.get('encounter_id'))
                if f['success']:
                    run['killed'].append(f.get('encounter_id'))
                else:
                    run['wipes'] += 1
        self.fights.append(f)

    def boss_hit(self, fight, guid, ts):
        """A boss NPC is in the fight. Without ENCOUNTER lines (old dungeons on the Anniversary client) the pull
        becomes a boss attempt; with them, it notes which parts of a council are still fighting."""
        npc = npc_of(guid)
        info = BOSS_NPC.get(npc)
        if not info:
            return fight
        enc, name, inst = info
        if fight['kind'] == 'trash' and not self.enc_mode:
            fight.update({'kind': 'boss', 'encounter_id': enc, 'name': name, 'instance_id': inst, 'boss': {'max': 0, 'hp': 0}, 'by_npc': True})
        if fight['kind'] == 'boss' and fight.get('encounter_id') == enc:
            if 'boss_npcs' not in fight:
                fight['boss_npcs'] = ENC_NPCS.get(enc, set())
                fight['npc_last'], fight['npcs_dead'], fight['last_kill'] = {}, set(), None
            fight['npc_last'][npc] = ts
        return fight

    def end_npc_boss(self):
        """Kill if the boss died (a council: all of it that fought); otherwise it was a wipe or a reset."""
        f = self.cur
        if not f or not f.get('by_npc'):
            return
        b = f.get('boss')
        hp_left = b['hp'] / b['max'] if b and b.get('max') else None
        # the game doesn't log every death (units far from you can be missing), so a boss last seen
        # nearly dead also counts as killed
        killed = bool(f.get('forced') or f.get('npcs_dead') or (hp_left is not None and hp_left <= 0.03))
        f['success'] = killed
        end = f['end'] if f.get('forced') or not f.get('last_kill') else f['last_kill']
        if killed and f.get('boss'):
            f['boss']['hp'] = 0
        self.close_fight(end)

    def tail_fight(self, guid, ts, name=None):
        """Fighting what's left of a boss encounter just after it ended goes into that boss fight."""
        t = self.after_enc
        if not t or not guid.startswith('Creature-'):
            return None
        f = t['f']
        if ts - f['end'] > 15000:
            self.after_enc = None
            return None
        if npc_of(guid) not in t['npcs'] and name not in f['hostiles'] and ts - t['end0'] > 2000:
            return None  # the council itself, or anything that was already part of the fight (its summons)
        cur = self.cur
        if cur and (cur['kind'] == 'boss' or cur['players']):
            return None  # something else has started
        if cur:
            self.cur = None  # an empty trash fight opened a moment ago: drop it
        f['end'] = ts
        run = next((r for r in reversed(self.runs) if r['id'] == f.get('run_id')), None)
        if run:
            run['end'] = max(run['end'], ts)
        return f

    def trash_over(self, f, ts, guid=None):
        """Is this trash fight finished? Everything it was fighting died (and this is a new target or a moment
        later), or nothing happened for a while. Out in the world a mob that's still alive keeps the fight
        going through pauses (a Gouge, a kite, a sheep), because deaths there are always logged."""
        cl = f.get('cleared')
        if cl is not None and (ts - cl > 1500 or (guid is not None and guid not in f['alive'] and guid not in f['dead'])):
            return True
        quiet = ts - f['end']
        if quiet <= TRASH_GAP:
            return False
        open_world = not (self.zone and self.zone['is_instance'])
        return not (open_world and f.get('alive') and quiet <= OPEN_WORLD_GAP)

    def touch_trash(self, ts, guid=None):
        cur = self.cur
        if cur and cur['kind'] == 'boss':
            if cur.get('by_npc'):
                cur['end'] = ts
            return cur
        if cur and self.trash_over(cur, ts, guid):
            self.close_fight()
        if not self.cur:
            self.open_fight('trash', ts, alive=set(), dead=set(), cleared=None)
        cur = self.cur
        cur['end'] = ts
        if guid is not None and guid not in cur['dead']:
            cur['alive'].add(guid)
            cur['cleared'] = None
        return cur

    def active_fight(self, ts):
        f = self.cur
        if not f:
            return None
        if f['kind'] == 'boss':
            return f
        return None if self.trash_over(f, ts) else f

    def remember(self, guid, ev):
        q = self.recent.get(guid)
        if q is None:
            q = self.recent[guid] = []
        q.append(ev)
        if len(q) > 14:
            del q[0]

    def note_class(self, f):
        if len(f) > 10:
            c = SPELL_CLASS.get(f[10].strip('"'))
            if c:
                self.vote_class(short_name(f[2].strip('"')), c)

    def vote_class(self, name, c):
        if not name:
            return None
        v = self.class_votes.get(name)
        if v is None:
            v = self.class_votes[name] = {}
        v[c] = v.get(c, 0) + 1
        best = max(v, key=v.get)
        self.classes[name] = best
        return best

    def infer_class(self, guid, src_guid, spell):
        p = self.players.get(guid)
        if not p or guid != src_guid:
            return
        c = SPELL_CLASS.get(spell)
        if c:
            p['cls'] = self.vote_class(p['name'], c)

    # ---- one line ----
    def feed(self, line):
        stamp, rest = split_line(line)
        if rest is None:
            return
        c = rest.find(',')
        ev = rest[:c] if c > 0 else rest
        if ev not in HANDLED or len(rest) > 20000:
            if ev == 'SPELL_AURA_APPLIED' and rest.startswith('Player-', c + 1):
                self.note_class(rest.split(',', 11))
            return
        ts = self.stamp(stamp)
        if ts is None:
            return
        ts += self.clock_shift
        if self.last_ts and ts < self.last_ts - 300_000:
            back = self.last_ts - ts
            if 3_300_000 <= back <= 3_900_000:
                # clocks went back an hour (end of daylight saving): keep time moving forward
                self.clock_shift += 3_600_000
                ts += 3_600_000
            else:
                return  # out-of-order line: WoW writes in time order, so this isn't a real event
        self.last_ts = max(ts, self.last_ts)
        self.handled += 1
        cur = self.cur
        if cur:
            if cur['kind'] == 'boss':
                if not cur.get('by_npc'):
                    cur['end'] = ts
                elif ts - cur['end'] > cur.get('gap', NPC_BOSS_GAP):
                    self.end_npc_boss()
            elif self.trash_over(cur, ts):
                self.close_fight()
        f = next(csv.reader((rest,)))

        if ev == 'COMBAT_LOG_VERSION':
            if 'ADVANCED_LOG_ENABLED' in f:
                i = f.index('ADVANCED_LOG_ENABLED')
                self.advanced = len(f) > i + 1 and f[i + 1] == '1'
            return
        if ev == 'ZONE_CHANGE':
            if len(f) < 3 or not is_int(f[1]):
                return
            if self.cur and self.cur.get('by_npc'):
                self.end_npc_boss()
            if self.cur and self.cur['kind'] == 'trash':
                self.close_fight()
            zid = to_int(f[1]) if len(f) > 1 else 0
            diff = to_int(f[3]) if len(f) > 3 else None
            self.saw_zone = True
            # every map that isn't one of the open-world continents is an instance; battlegrounds and arenas
            # report difficulty 0, so difficulty can't be used to tell
            is_inst = zid not in WORLD_INSTANCES
            prev = self.zone
            entry = (prev or {}).get('entry', 0) + (1 if is_inst and (not prev or prev['id'] != zid) else 0)
            self.zone = {'id': zid, 'name': f[2] if len(f) > 2 else '', 'is_instance': is_inst, 'diff': diff, 'entry': entry}
            return
        if ev == 'ENCOUNTER_START':
            if len(f) < 3 or not is_int(f[1]):
                return
            self.enc_mode = True
            self.after_enc = None
            c = self.cur
            if c and c.get('by_npc'):
                if c.get('encounter_id') == to_int(f[1]) and ts - c['start'] < 15000 and not c.get('forced'):
                    c['by_npc'] = False  # the pull was spotted by its NPC a moment before the game announced it
                    return
                self.end_npc_boss()
            if self.cur:
                self.close_fight()
            self.open_fight('boss', ts, encounter_id=to_int(f[1]), name=f[2], difficulty=to_int(f[3]) if len(f) > 3 else 0,
                            size=to_int(f[4]) if len(f) > 4 else 0, instance_id=to_int(f[5]) if len(f) > 5 else None, boss={'max': 0, 'hp': 0})
            return
        if ev == 'ENCOUNTER_END':
            if len(f) < 6 or to_int(f[1]) != (self.cur or {}).get('encounter_id'):
                return  # incomplete, or the end of a different encounter
            c = self.cur
            if c and c['kind'] == 'boss':
                ok = len(f) > 5 and f[5] == '1'
                dead = c.get('npcs_dead') or set()
                c['success'] = ok
                self.close_fight(ts)
                if ok:
                    # the game can call it while part of a council still fights (High King Maulgar dies first):
                    # fighting those NPCs straight afterwards still belongs to this boss fight
                    self.after_enc = {'f': c, 'npcs': ENC_NPCS.get(c.get('encounter_id'), set()) - dead, 'end0': ts}
            return
        if len(f) < 9:
            return
        s_guid, s_name, s_flags = f[1], f[2], flags_of(f[3])
        d_guid, d_name, d_flags = f[5], f[6], flags_of(f[7])
        if ev == 'SPELL_CAST_SUCCESS' and s_guid.startswith('Player-'):
            self.note_class(f)

        if ev == 'SPELL_SUMMON':
            owner = self.group_of(s_guid, s_flags, s_name)
            if owner and d_guid != NO_GUID:
                self.owners[d_guid] = owner
            return
        if ev in ('UNIT_DIED', 'PARTY_KILL'):
            cur = self.cur
            if d_guid.startswith(('Creature-', 'Vehicle-')) and d_guid not in self.recent_dead:
                if len(self.recent_dead) > 300:
                    self.recent_dead = {g: v for g, v in self.recent_dead.items() if ts - v[0] < 10000}
                self.recent_dead[d_guid] = (ts, cur or (self.fights[-1] if self.fights else None))
            if cur and cur['kind'] == 'trash' and d_guid in cur.get('alive', ()):
                cur['alive'].discard(d_guid)
                cur['dead'].add(d_guid)
                if not cur['alive']:
                    cur['cleared'] = ts
            if d_guid.startswith('Creature-'):
                if cur and cur['kind'] == 'boss' and 'boss_npcs' in cur:
                    npc = npc_of(d_guid)
                    if npc in cur['boss_npcs']:
                        cur['npcs_dead'].add(npc)
                        cur['last_kill'] = ts
                        if cur.get('by_npc') and set(cur['npc_last']) <= cur['npcs_dead']:
                            cur['end'] = ts
                            self.end_npc_boss()
                return
            if (d_flags & F_PLAYER) and (d_flags & F_GROUP) and d_guid in self.players:
                t = self.after_enc
                fight = (t['f'] if t and ts - t['f']['end'] < 3000 else None) or self.active_fight(ts) or self.cur
                if not fight:
                    return
                q = [e for e in self.recent.get(d_guid, []) if ts - e['ts'] <= 10000]
                last = next((e for e in reversed(q) if e['t'] == 'd'), None)
                fight['deaths'].append({'guid': d_guid, 'name': self.players[d_guid]['name'], 'ts': ts, 'killer': last['src'] if last else None,
                                        'spell': last['spell'] if last else None, 'amount': last['amount'] if last else 0, 'recap': q})
                self.stats(fight, d_guid)['deaths'] += 1
                self.recent.pop(d_guid, None)
            return
        if ev == 'SPELL_RESURRECT':
            if self.cur:
                for d in self.cur['deaths']:
                    if d['guid'] == d_guid:
                        d['rezzed'] = True
            return

        # prefix
        p, spell, spell_id = 9, None, 0
        if ev == 'SWING_DAMAGE':
            spell = 'Melee'
        elif ev == 'ENVIRONMENTAL_DAMAGE':
            spell, p = (f[9] if len(f) > 9 else 'Environment'), 10
        elif len(f) > 11:
            spell_id, spell, p = to_int(f[9]), f[10], 12
        else:
            return

        is_damage = ev in DAMAGE_EVENTS
        is_heal = ev in HEAL_EVENTS

        # advanced block: infoGUID, ownerGUID, curHP, maxHP, ... posX, posY, mapID, facing, level
        d = p
        if (is_damage or is_heal or ev == 'SPELL_CAST_SUCCESS') and self.advanced is not False and len(f) > p and is_guid(f[p]):
            end = -1
            if self.adv_len:
                e = p + self.adv_len
                if e <= len(f) and is_float(f[e - 5]) and is_float(f[e - 4]) and is_int(f[e - 3]):
                    end = e
            if end < 0:
                i = p + 6
                while i + 4 < len(f) and i < p + 26:
                    if is_float(f[i]) and is_float(f[i + 1]) and is_int(f[i + 2]) and is_float(f[i + 3]) and is_int(f[i + 4]):
                        end = i + 5
                        break
                    i += 1
                if end > 0:
                    self.adv_len = end - p
            if end > 0:
                d = end
                info, owner = f[p], f[p + 1]
                if owner != NO_GUID and info != NO_GUID and owner in self.players:
                    self.owners[info] = owner
                fight = self.cur
                if fight and fight.get('boss') is not None and info != NO_GUID and not info.startswith('Player-'):
                    info_flags = d_flags if info == d_guid else s_flags if info == s_guid else 0
                    if not (info_flags & F_FRIENDLY):
                        mx, hp = to_int(f[p + 3]), to_int(f[p + 2])
                        if mx >= fight['boss']['max']:
                            fight['boss']['max'], fight['boss']['hp'] = mx, hp

        if is_damage:
            n = len(f) - d
            amount = to_int(f[d]) if n > 0 else 0
            if not amount:
                return
            src = self.group_of(s_guid, s_flags, s_name)
            dst = self.group_of(d_guid, d_flags, d_name) if d_flags & F_PLAYER else None
            # most clients put the unmitigated amount right after the amount (amount, raw, overkill, ...), older ones
            # don't (amount, overkill, school, ...). Overkill is -1 on every hit that doesn't kill, so the first such
            # hit shows which layout this log uses (a crit's raw amount is below the amount, so values can't tell)
            raw = self.raw_layout
            if raw is None:
                if n > 2 and f[d + 2] == '-1':
                    raw = self.raw_layout = True
                elif n > 1 and f[d + 1] == '-1':
                    raw = self.raw_layout = False
                else:
                    raw = n >= 11 or (n >= 10 and is_int(f[d + 1]) and to_int(f[d + 1]) >= amount)
            ok_i = d + (2 if raw else 1)
            overkill = max(0, to_int(f[ok_i])) if ok_i < len(f) and is_int(f[ok_i]) else 0
            if src and not (d_flags & F_FRIENDLY):
                # damage done counts what the target actually lost, like the game's combat text (no overkill)
                amount = max(0, amount - overkill) if overkill < amount else amount
                rd = self.recent_dead.get(d_guid)
                if rd and rd[1] is not None and ts - rd[0] < 3000:
                    fight = rd[1]  # the killing blow's overkill, a last DoT tick: part of the fight that killed it
                else:
                    fight = self.tail_fight(d_guid, ts, d_name) or self.touch_trash(ts, d_guid)
                    if d_guid.startswith('Creature-'):
                        fight = self.boss_hit(fight, d_guid, ts)
                s = self.stats(fight, src)
                label = spell if s_guid == src else f'{short_name(s_name)}: {spell}'
                s['dmg'] += amount
                s['dmg_by'][label] = s['dmg_by'].get(label, 0) + amount
                self.mark_active(s, ts)
                h = fight['hostiles'].get(d_name)
                if h is None:
                    h = fight['hostiles'][d_name] = {'dmg': 0, 'units': set()}
                h['dmg'] += amount
                if isinstance(h['units'], set):  # a closed fight (a boss fight's tail) keeps only the count
                    h['units'].add(d_guid)
                self.infer_class(src, s_guid, spell)
            elif dst and not (s_flags & F_GROUP):
                fight = self.active_fight(ts) if s_flags & F_FRIENDLY else (self.tail_fight(s_guid, ts, s_name) or self.touch_trash(ts, s_guid))
                if fight and s_guid.startswith('Creature-'):
                    fight = self.boss_hit(fight, s_guid, ts)
                crit_i = d + (7 if raw else 6)
                self.remember(dst, {'t': 'd', 'ts': ts, 'amount': amount, 'src': s_name or 'Environment', 'spell': spell,
                                    'crit': crit_i < len(f) and f[crit_i] == '1', 'overkill': max(0, overkill)})
                if not fight:
                    return
                s = self.stats(fight, dst)
                s['taken'] += amount
                s['taken_by'][spell] = s['taken_by'].get(spell, 0) + amount
                if spell in AVOIDABLE:
                    srcs = AVOIDABLE[spell]
                    if srcs is None or s_name in srcs:
                        s['avoid'] += amount
                        s['avoid_hits'] += 1
            return

        if is_heal:
            src = self.group_of(s_guid, s_flags, s_name)
            n = len(f) - d
            amount = to_int(f[d]) if n > 0 else 0
            oi = d + (2 if n >= 5 else 1)
            over = to_int(f[oi]) if oi < len(f) else 0
            eff = max(0, amount - over)
            dst = self.group_of(d_guid, d_flags, d_name) if d_flags & F_PLAYER else None
            if dst and eff > 0:
                self.remember(dst, {'t': 'h', 'ts': ts, 'amount': eff, 'src': s_name, 'spell': spell})
            if not src:
                return
            self.infer_class(src, s_guid, spell)
            fight = self.active_fight(ts)
            if not fight:
                return
            s = self.stats(fight, src)
            s['heal'] += eff
            s['overheal'] += min(over, amount)
            label = spell if s_guid == src else f'{short_name(s_name)}: {spell}'
            if eff:
                s['heal_by'][label] = s['heal_by'].get(label, 0) + eff
            self.mark_active(s, ts)
            return

        if ev == 'SPELL_ABSORBED':
            c = 9 if (is_guid(f[9]) and len(f) - 9 <= 9) else 12
            if len(f) <= c + 7:
                return
            caster = self.group_of(f[c], flags_of(f[c + 2]), f[c + 1])
            amount = to_int(f[c + 7])
            if not caster or not amount:
                return
            fight = self.active_fight(ts)
            if not fight:
                return
            s = self.stats(fight, caster)
            label = f[c + 5]
            s['heal'] += amount
            s['absorb'] += amount
            s['heal_by'][label] = s['heal_by'].get(label, 0) + amount
            return

        src = self.group_of(s_guid, s_flags, s_name)
        if not src:
            return
        if ev == 'SPELL_INTERRUPT':
            fight = self.active_fight(ts)
            if fight:
                s = self.stats(fight, src)
                s['interrupts'] += 1
                what = f[13] if len(f) > 13 else '?'
                s['kicked'][what] = s['kicked'].get(what, 0) + 1
            return
        if ev in ('SPELL_DISPEL', 'SPELL_STOLEN'):
            fight = self.active_fight(ts)
            if fight:
                self.stats(fight, src)['dispels'] += 1
            return
        if ev == 'SPELL_CAST_SUCCESS':
            if src == s_guid:
                self.infer_class(src, s_guid, spell)
            fight = self.active_fight(ts)
            if fight:
                if spell in SELF_REZ:
                    for dd in fight['deaths']:
                        if dd['guid'] == src:
                            dd['rezzed'] = True
                else:
                    # a "dead" player acting again without a resurrect was feigning
                    shaman = (self.players.get(src) or {}).get('cls') == 'SHAMAN' or self.classes.get(short_name(s_name)) == 'SHAMAN'
                    for dd in fight['deaths']:
                        if dd['guid'] == src and not dd.get('rezzed') and dd['ts'] + 500 < ts < dd['ts'] + 60000:
                            if shaman:
                                dd['rezzed'] = True  # Reincarnation isn't logged as a cast: a shaman back on their feet still died
                            else:
                                dd['fake'] = True
            if spell in CONSUMABLE_NAMES or spell_id in CONSUMABLE_IDS:
                fc = fight or self.cur
                if fc:
                    s = self.stats(fc, src)
                    label = CONSUMABLE_LABEL.get(spell, spell)
                    s['cons'][label] = s['cons'].get(label, 0) + 1

    def tick(self, now_ms):
        """Ends a trash fight that's gone quiet (live mode)."""
        # WoW writes the log in bursts, so the rest of a fight can turn up seconds later: don't end a fight on the
        # clock too eagerly (a fight whose mobs all died ends soon; anything else waits LIVE_IDLE)
        cur = self.cur
        if cur and cur['kind'] == 'trash':
            cl = cur.get('cleared')
            if (cl is not None and now_ms - cl > 3000) or now_ms - cur['end'] > LIVE_IDLE:
                self.close_fight()
        elif self.cur and self.cur.get('by_npc') and now_ms - self.cur['end'] > self.cur.get('gap', NPC_BOSS_GAP) + 2000:
            self.end_npc_boss()

    def finish(self):
        if self.cur and self.cur.get('by_npc'):
            self.end_npc_boss()
        if self.cur:
            if self.cur['kind'] == 'boss':
                self.cur['success'] = False
                self.cur['unfinished'] = True
            self.close_fight(self.cur['end'])

    def snapshot(self):
        return {'source': self.source, 'players': self.players, 'fights': self.fights, 'runs': [r for r in self.runs if r['fights']], 'classes': self.classes}


# ======================================================================
#  Chat log
# ======================================================================
#
# WoWChatLog.txt line format (no year in the stamp on Classic clients, two spaces before the text):
#   10/13 10:01:51.269  |Hchannel:RAID|h[Raid]|h Name: text
#   10/13 10:01:51.269  Name receives loot: |cffa335ee|Hitem:16805::::|h[Felheart Gloves]|h|r.
# Channel tags, player names and items can be |H...|h hyperlinks; colour codes (|cffRRGGBB ... |r) are kept.
# Everything is matched on the text with those codes removed, except items, which are read from the raw line
# so their quality colour and item id survive.

QUALITY_BY_COLOR = {'9d9d9d': 0, 'ffffff': 1, '1eff00': 2, '0070dd': 3, 'a335ee': 4, 'ff8000': 5, 'e6cc80': 6, '00ccff': 7}
ITEM_RE = re.compile(r'(?:\|c[fF]{2}([0-9a-fA-F]{6}))?(?:\|H(item:[^|]*)\|h)?\[([^\]]+)\](?:\|h)?(?:\|r)?')
CODES_RE = re.compile(r'\|c[0-9a-fA-F]{8}|\|r|\|H[^|]*\|h|\|h|\|T[^|]*\|t|\|A[^|]*\|a')

# ---- language: every English phrase the chat parser recognises lives here ----
# To support another client language, copy this dict, translate the patterns, and pass it as ChatParser(lang=...).
# Groups must keep the same names. 'who' never includes the realm (that is cut off afterwards).
EN = {
    # [Channel] Name: text  (also "[2. Trade - City] Name: text")
    'channel_line': r'^\[(?:(?P<num>\d+)\. )?(?P<ch>[^\]]+)\] (?P<who>\[?[^:\[\]]+?\]?): (?P<text>.*)$',
    'channel_names': {
        'Raid Warning': 'raidwarning', 'Raid Leader': 'raid', 'Raid': 'raid',
        'Party Leader': 'party', 'Party': 'party', 'Party Guide': 'party',
        'Guild': 'guild', 'Officer': 'officer',
        'Battleground Leader': 'instance', 'Battleground': 'instance', 'Instance Leader': 'instance', 'Instance': 'instance',
    },
    'whisper_in': r'^(?P<who>.+?) whispers: (?P<text>.*)$',
    'whisper_out': r'^To (?P<who>.+?): (?P<text>.*)$',
    'say': r'^(?P<who>.+?) (?P<verb>says|yells): (?P<text>.*)$',
    'say_verbs': {'says': 'say', 'yells': 'yell'},
    'npc_emote': r'^(?P<who>.+?) (?:whispers|emotes): (?P<text>.*)$',

    'loot': r'^(?P<who>You|.+?) receives? (?:bonus )?loot: (?P<item>.*?)(?:x(?P<count>\d+))?\.?$',
    'item_received': r'^(?P<who>You|.+?) receives? item: (?P<item>.*?)(?:x(?P<count>\d+))?\.?$',
    'created': r'^(?P<who>You|.+?) creates?:? (?P<item>.*?)(?:x(?P<count>\d+))?\.?$',
    'won': r'^(?P<who>You|.+?) won: (?P<item>.*?)(?: \((?P<type>Need|Greed|Disenchant) - (?P<val>\d+)\))?\.?$',
    'roll': r'^(?P<who>.+?) rolls (?P<val>\d+) \((?P<lo>\d+)-(?P<hi>\d+)\)\.?$',
    'group_roll': r'^(?P<type>Need|Greed|Disenchant|Transmog) Roll - (?P<val>\d+) for (?P<item>.*) by (?P<who>.+?)\.?$',
    'roll_choice': r'^(?P<who>You|.+?) (?:have|has) selected (?P<type>Need|Greed|Disenchant|Transmog|Pass) for: (?P<item>.*?)\.?$',
    'passed': r'^(?P<who>You|.+?)(?: automatically)? passed on: (?P<item>.*?)(?: because .*)?\.?$',
    'all_passed': r'^Everyone passed on: (?P<item>.*?)\.?$',
    'money': r'^(?:You loot|Your share of the loot is|You receive) (?P<coins>(?:\d+ (?:Gold|Silver|Copper)(?:, )?)+)\.?$',
    'coin': r'(\d+) (Gold|Silver|Copper)',
    'coin_units': {'Gold': 10000, 'Silver': 100, 'Copper': 1},

    'reset': r'^(?P<instance>.+?) has been reset\.?$',
    'reset_failed': r'^Cannot reset (?P<instance>.+?)\.\s*(?P<why>.*)$',
    'honor': r'^You have been awarded (?P<amount>\d+) honor(?: points)?\.?$',
    'honor_kill': r'^(?P<target>.+?) dies(?:, honorable kill Rank: (?P<rank>[^(]+?) \((?:Estimated Honor Points: )?(?P<amount>\d+)(?: Honor Points)?\)| \(Honorable Kill(?:: (?P<rank2>[^)]+))?\)\. You gain (?P<amount2>\d+) Honor.*)\.?$',
    'rep_up': r'^(?:Your )?[Rr]eputation with (?P<faction>.+?) (?:has )?(?P<dir>increased|decreased)(?: by (?P<amount>\d+))?\.?',
    'rep_up_old': r'^Your reputation with (?P<faction>.+?) has (?:very slightly |slightly |greatly )?(?P<dir>increased|decreased)\.?$',
    'xp_kill': r'^(?P<target>.+?) dies, you gain (?P<amount>\d+) experience\.(?: \((?P<bonus>.*)\))?$',
    'xp': r'^You gain (?P<amount>\d+) experience\.(?: \((?P<bonus>.*)\))?$',
    'quest_done': r'^(?P<quest>.+?) completed\.$',
    'quest_accepted': r'^Quest accepted: (?P<quest>.+)$',
    'level_up': r'^Congratulations, you have reached level (?P<level>\d+)!?$',
    'achievement': r'^(?P<who>.+?) has earned the achievement (?P<what>.+?)!$',
    'others_money': r'^(?P<who>.+?) loots (?P<coins>(?:\d+ (?:Gold|Silver|Copper)(?:, )?)+)\.$',
    'currency': r'^You receive currency: (?P<item>.*?)(?:x(?P<count>\d+))?\.$',
    'skill_up': r'^Your skill in (?P<skill>.+?) has increased to (?P<level>\d+)\.$',
    'discovered': r'^Discovered: (?P<zone>.+)$',
    'disenchanted': r'^(?P<item>.+?) was disenchanted for loot by (?P<who>.+?)\.$',
    # group-loot messages are prefixed with a clickable "[Loot]: " in this client
    'loot_prefix': '[Loot]: ',
    'afk_on': r'^You are now (?P<kind>Away|AFK|Busy|DND)(?:\.|: ?(?P<text>.*?)\.?)$',
    'afk_off': r'^You are no longer (?:marked )?(?P<kind>Away|AFK|Busy|DND)\.?$',
    'online': r'^(?P<who>.+?) has come online\.?$',
    'offline': r'^(?P<who>.+?) has gone offline\.?$',
    'joins': r'^(?P<who>.+?) (?:joins the (?:party|raid)|has joined the (?:raid group|instance group|party|battle))\.?$',
    'leaves': r'^(?P<who>.+?) (?:leaves the (?:party|raid)|has left the (?:raid group|instance group|party|battle))\.?$',
    'you_leave': r'^(?:You leave the group|You have been removed from the group|Your group has been disbanded|You have left the raid group)\.?$',
    'you_join': r'^You have joined a raid group\.?$',
    'loot_master': r'^(?P<who>.+?) is now the loot master\.?$',
    'loot_method': r'^Looting (?:changed|set) to (?P<method>.+?)\.?$',
    'loot_threshold': r'^Loot threshold set to (?P<quality>.+?)\.?$',
    'difficulty': r'^(?P<what>Dungeon|Raid|Legacy Raid) Difficulty set to (?P<level>.+?)\.(?: \((?P<note>.*)\))?$',
    'died': r'^(?P<who>.+?) has died\.?$',
    'you_died': r'^You (?:have )?died\.?$',
}

# first word of the message -> which patterns are worth trying (keeps every line to one or two regex tries)
_SYSTEM_ORDER = ['money', 'group_roll', 'all_passed', 'roll', 'roll_choice', 'passed', 'loot', 'item_received', 'won', 'created',
                 'reset', 'reset_failed', 'honor', 'honor_kill', 'rep_up_old', 'rep_up', 'xp_kill', 'xp', 'quest_accepted', 'quest_done',
                 'level_up', 'achievement', 'afk_on', 'afk_off', 'online', 'offline', 'joins', 'leaves', 'you_leave', 'loot_master',
                 'loot_method', 'loot_threshold', 'difficulty', 'you_died', 'died', 'you_join', 'others_money', 'currency', 'skill_up',
                 'discovered', 'disenchanted']
_KEYWORDS = {  # a message must contain this text for the pattern to be tried at all
    'money': ('Copper', 'Silver', 'Gold'), 'group_roll': (' Roll - ',), 'all_passed': ('passed on',), 'roll': (' rolls ',),
    'roll_choice': ('selected',), 'passed': ('passed on',), 'loot': ('loot:',), 'item_received': ('item:',), 'won': ('won',),
    'created': ('create',), 'reset': ('been reset',), 'reset_failed': ('Cannot reset',), 'honor': ('honor',), 'honor_kill': ('onorable',),
    'rep_up_old': ('eputation',), 'rep_up': ('eputation',), 'xp_kill': ('experience',), 'xp': ('experience',), 'quest_accepted': ('Quest accepted',),
    'quest_done': ('completed.',), 'level_up': ('reached level',), 'achievement': ('achievement',), 'afk_on': ('You are now',),
    'afk_off': ('no longer',), 'online': ('online',), 'offline': ('offline',), 'joins': ('join',), 'leaves': ('left', 'leaves'),
    'you_leave': ('group',), 'loot_master': ('loot master',), 'loot_method': ('Looting',), 'loot_threshold': ('threshold',),
    'difficulty': ('Difficulty set',), 'you_died': ('died',), 'died': ('died',), 'you_join': ('joined a raid',),
    'others_money': (' loots ',), 'currency': ('currency:',), 'skill_up': ('Your skill in',), 'discovered': ('Discovered:',),
    'disenchanted': ('disenchanted for loot',),
}


def _compile(lang):
    out = {k: re.compile(v) for k, v in lang.items() if isinstance(v, str) and k != 'loot_prefix'}
    out['_lang'] = lang
    return out


# one search finds every keyword in a line; only the patterns those keywords point to are tried
_KW_TO_KEYS = {}
for _k in _SYSTEM_ORDER:
    for _kw in _KEYWORDS[_k]:
        _KW_TO_KEYS.setdefault(_kw, set()).add(_k)
# a lookahead so keywords that overlap ("honor" inside "honorable") are all found
_KW_RE = re.compile('(?=(' + '|'.join(re.escape(k) for k in sorted(_KW_TO_KEYS, key=len, reverse=True)) + '))')
# the commonest system lines, checked before the general scan (order matters: the first word that fits wins)
_FAST = (('loot:', ('loot',)), (' Roll - ', ('group_roll',)), (' rolls ', ('roll',)), (' won: ', ('won',)),
         ('Copper', ('money', 'others_money')), ('Silver', ('money', 'others_money')), ('Gold', ('money', 'others_money')),
         ('experience', ('xp_kill', 'xp')), ('eputation', ('rep_up_old', 'rep_up')))
_KW_OVERLAP = {kw: {o for o in _KW_TO_KEYS if o != kw and (o in kw or kw in o)} for kw in _KW_TO_KEYS}


_LANGS = {'en': _compile(EN)}


def strip_codes(s):
    return CODES_RE.sub('', s) if '|' in s else s


class _ChatStamper(Stamper):
    """Chat lines are spread out (rarely two in one second), so cache per hour and add minutes and seconds."""

    def __call__(self, stamp):
        sp = stamp.find(' ')
        if sp < 0:
            return None
        date, clock = stamp[:sp], stamp[sp + 1:]
        try:
            hh, mm, rest = clock.split(':')
            ss, _, frac = rest.partition('.')
            offset = (int(mm) * 60 + int(ss)) * 1000 + (int((frac + '000')[:3]) if frac[:3].isdigit() else 0)
        except ValueError:
            return None
        key = date + ' ' + hh
        base = self.cache.get(key)
        if base is None:
            base = Stamper.__call__(self, f'{date} {hh}:00:00.000')
            if base is None:
                return None
            self.cache[key] = base
        if int(mm) > 59 or int(ss) > 59:
            return None
        return base + offset


def _link_at(s, i):
    """Reads the item link whose '|Hitem:' starts at index i: colour (if any), id and name."""
    color = s[i - 6:i].lower() if i >= 10 and s[i - 10:i - 6].lower() == '|cff' else None
    j = s.find(':', i + 7)
    k = s.find('|h[', i)
    e = s.find(']|h', k + 3) if k >= 0 else -1
    if k < 0 or e < 0:
        return None, -1
    return {'name': s[k + 3:e], 'q': QUALITY_BY_COLOR.get(color), 'id': to_int(s[i + 7:j]) if 0 < j < k else to_int(s[i + 7:k])}, e + 3


def item_of(s):
    """The first item in a message: a real item link if there is one, else the first [bracketed] name."""
    i = s.find('|Hitem:')
    if i >= 0:
        it, _ = _link_at(s, i)
        if it:
            return it
    m = ITEM_RE.search(s)
    if not m:
        return None
    color = m.group(1).lower() if m.group(1) else None
    return {'name': m.group(3), 'q': QUALITY_BY_COLOR.get(color), 'id': to_int(m.group(2).split(':')[1]) if m.group(2) else None}


def items_of(s):
    """Every item linked in a message (a roll call can link several)."""
    out = []
    i = s.find('|Hitem:')
    while i >= 0:
        it, end = _link_at(s, i)
        if not it:
            break
        out.append(it)
        i = s.find('|Hitem:', end)
    return out


def clean_name(n):
    """'[Name-Realm]' / 'Name-Realm' / 'Name' -> 'Name'. Battle.net names (with spaces) are kept whole."""
    n = n.strip()
    if n[:1] == '[' and n[-1:] == ']':
        n = n[1:-1]
    i = n.find('-')
    return (n[:i] if i > 0 and ' ' not in n else n).strip()


def _item_from(raw, text_item):
    it = item_of(raw)
    if it:
        return it
    name = text_item.strip()
    if name[:1] == '[' and name.rfind(']') > 0:
        name = name[1:name.rfind(']')]
    return {'name': name, 'q': None, 'id': None}


class ChatParser:
    def _add_loot(self, entry):
        """Group loot writes 'X won: [item]' and then 'X receives loot: [item]' for the same drop: count it once."""
        name = entry['item'].get('name')
        for prev in reversed(self.loot[-12:]):
            if entry['ts'] - prev['ts'] > 120_000:
                break
            if prev['who'] == entry['who'] and prev['item'].get('name') == name and bool(prev.get('won')) != bool(entry.get('won')) and not prev.get('paired'):
                prev['paired'] = True
                if entry.get('won'):
                    prev['won'] = True
                    if entry.get('roll'):
                        prev['roll'] = entry['roll']
                if prev['item'].get('q') is None:
                    prev['item'] = entry['item']
                return
        self.loot.append(entry)

    def __init__(self, year=None, me=None, lang='en'):
        self.stamp = _ChatStamper(year or datetime.now().year)
        self.R = _LANGS.get(lang) or _LANGS['en']
        L = self.R['_lang']
        self.channel_names = L['channel_names']
        self.say_verbs = L['say_verbs']
        self.coin_units = L['coin_units']
        self.loot_prefix = L['loot_prefix']
        self.messages = []      # every chat line, including system lines (kind tells what a system line was)
        self.loot = []          # items looted / won
        self.roll_sessions = []
        self.money = []
        self.me = me
        # extra things worth knowing, each a list of dicts with 'ts'
        self.resets = []        # {instance, ok}
        self.honor = []         # {amount, target?}
        self.reputation = []    # {faction, amount, up}
        self.xp = []            # {amount, target?}
        self.quests = []        # {quest, done}
        self.levels = []        # {level}
        self.achievements = []  # {who, what}
        self.status = []        # {state: 'away'|'busy'|'back', text}
        self.presence = []      # {who, online}
        self.group = []         # {who, joined}  who='You' for your own leaving
        self.loot_settings = [] # {what: 'master'|'method'|'threshold'|'difficulty', value}
        self.crafted = []       # {who, item, count}
        self.deaths = []        # {who}
        self.roll_choices = []  # {who, type, item}
        self.others_money = []  # {who, copper}  gold other group members looted
        self.currency = []      # {item, count}
        self.skills = []        # {skill, level}
        self.discovered = []    # {zone}
        self.disenchants = []   # {who, item}
        self.last_item_call = None
        self.you_seen = []      # (ts, character name) whenever the log shows who "You" is
        self.session = None
        self._group_sessions = {}
        self.bad = 0

    def _who(self, s):
        # "You" stays "You": the chat log can span several characters, so who "You" is depends on when (see you_at)
        return 'You' if s == 'You' else clean_name(s)

    def _infer_you(self, ts, item):
        """Group rolls name everyone, you included: a roller who never chose Need/Greed under their own name is you."""
        s = self._group_sessions.get('ng:' + item)
        if not s or ts - s['end'] > 180_000:
            return
        mine = others = None
        for c in self.roll_choices[-60:]:
            if c['item'].get('name') == item and ts - c['ts'] < 300_000:
                if c['who'] == 'You':
                    mine = True
                else:
                    others = (others or set()) | {c['who']}
        if not mine:
            return
        cand = {r['who'] for r in s['rolls']} - (others or set())
        if len(cand) == 1:
            name = cand.pop()
            if not self.you_seen or self.you_seen[-1][1] != name:
                self.you_seen.append((ts, name))

    def you_at(self, ts):
        """The character "You" meant at that moment, when the log gave it away (None if it never did)."""
        best = None
        for t, name in self.you_seen:
            if t <= ts + 3600_000:
                best = name
            else:
                break
        if best is None and self.you_seen and self.you_seen[0][0] - ts < 12 * 3600_000:
            best = self.you_seen[0][1]
        return best

    def feed(self, line):
        i = line.find('  ')
        if i < 0:
            return
        raw = line[i + 2:].rstrip('\r\n')
        ts = self.stamp(line[:i])
        if ts is None:
            return
        R = self.R
        # fast path for the commonest line: |Hchannel:GUILD|h[Guild]|h Name: text
        if raw.startswith('|Hchannel:'):
            a = raw.find('|h[', 10)
            b = raw.find(']|h ', a) if a > 0 else -1
            c = raw.find(': ', b + 4) if b > 0 else -1
            if c > 0:
                name, who, body = raw[a + 3:b], raw[b + 4:c], raw[c + 2:]
                dot = name.find('. ')
                if dot > 0 and name[:dot].isdigit():
                    ch, name = 'channel', name[dot + 2:]
                else:
                    ch = self.channel_names.get(name)
                if ch:
                    if '|' in who or who[:1] == '[':
                        who = clean_name(strip_codes(who))
                    else:
                        d = who.find('-')
                        if d > 0 and ' ' not in who:
                            who = who[:d]
                    msg = {'ts': ts, 'ch': ch, 'ch_name': name, 'who': who, 'text': strip_codes(body) if '|' in body else body}
                    self.messages.append(msg)
                    if ch in ('raid', 'raidwarning', 'party', 'instance') and '|Hitem:' in body:
                        its = items_of(body)
                        if its:
                            self.last_item_call = {'ts': ts, 'item': its[0], 'items': its, 'by': msg['who']}
                    return
        text = strip_codes(raw)
        if not text:
            return
        lp = self.loot_prefix
        if text.startswith(lp):
            text = text[len(lp):]
            cut = raw.find(']|h: ')
            raw = raw[cut + 5:] if cut >= 0 else raw[len(lp):]
            if not text:
                return
        elif text.startswith('Loot: '):
            # the Anniversary client writes the prefix as plain text (links are stripped from the log file)
            text = text[6:]
            raw = raw[raw.find('Loot: ') + 6:] if 'Loot: ' in raw else text
            if not text:
                return

        # [Channel] Name: text
        if text[0] == '[':
            m = R['channel_line'].match(text)
            if m:
                name = m.group('ch')
                if m.group('num'):
                    ch, ch_name = 'channel', name
                else:
                    ch, ch_name = self.channel_names.get(name), name
                if ch:
                    msg = {'ts': ts, 'ch': ch, 'ch_name': ch_name, 'who': clean_name(m.group('who')), 'text': m.group('text')}
                    self.messages.append(msg)
                    if ch in ('raid', 'raidwarning', 'party', 'instance'):
                        body = raw[raw.find(': ') + 2:] if ': ' in raw else raw
                        its = items_of(body)
                        if its:
                            self.last_item_call = {'ts': ts, 'item': its[0], 'items': its, 'by': msg['who']}
                    return
            # a Battle.net friend: "[Real Name] whispers: hi"
            m = R['whisper_in'].match(text)
            if m and m.group('who').endswith(']'):
                self.messages.append({'ts': ts, 'ch': 'whisper', 'ch_name': 'From', 'who': clean_name(m.group('who')), 'text': m.group('text'), 'bn': True})
                return

        if text.startswith('To '):
            m = R['whisper_out'].match(text)
            if m:
                who = m.group('who')
                self.messages.append({'ts': ts, 'ch': 'whisper', 'ch_name': 'To', 'who': clean_name(who), 'text': m.group('text'), 'out': True,
                                      'bn': who.startswith('[') or ' ' in who})
                return
        if ' whispers: ' in text:
            m = R['whisper_in'].match(text)
            if m:
                who = m.group('who')
                self.messages.append({'ts': ts, 'ch': 'whisper', 'ch_name': 'From', 'who': clean_name(who), 'text': m.group('text'),
                                      'bn': who.startswith('[')})
                return
        if ' says: ' in text or ' yells: ' in text:
            m = R['say'].match(text)
            if m:
                ch = self.say_verbs[m.group('verb')]
                self.messages.append({'ts': ts, 'ch': ch, 'ch_name': 'Say' if ch == 'say' else 'Yell', 'who': clean_name(m.group('who')), 'text': m.group('text')})
                return

        for kw, keys in _FAST:
            if kw in text:
                for key in keys:
                    m = R[key].match(text)
                    if m and self._system(key, m, ts, raw, text) is not False:
                        return
                break
        found = _KW_RE.findall(text)
        if found:
            keys = set()
            for kw in found:
                keys |= _KW_TO_KEYS[kw]
                for o in _KW_OVERLAP[kw]:  # a longer keyword can hide a shorter one at the same spot
                    if o in text:
                        keys |= _KW_TO_KEYS[o]
            for key in _SYSTEM_ORDER:
                if key in keys:
                    m = R[key].match(text)
                    if m and self._system(key, m, ts, raw, text) is not False:
                        return
        self.messages.append({'ts': ts, 'ch': 'system', 'ch_name': 'System', 'who': '', 'text': text, 'kind': 'other'})

    def _sys(self, ts, text, kind):
        self.messages.append({'ts': ts, 'ch': 'system', 'ch_name': 'System', 'who': '', 'text': text, 'kind': kind})

    def _system(self, key, m, ts, raw, text):
        """Handles one recognised system line. Returns False to let the next pattern try."""
        g = m.groupdict()
        if key == 'money':
            c = sum(int(a) * self.coin_units.get(u, 0) for a, u in self.R['coin'].findall(g['coins']))
            if not c:
                return False
            self.money.append({'ts': ts, 'copper': c, 'share': text.startswith('Your share')})
            return
        if key == 'loot':
            self._add_loot({'ts': ts, 'who': self._who(g['who']), 'item': _item_from(raw, g['item']), 'count': to_int(g['count'] or 1) or 1})
            return
        if key == 'item_received':
            if g['who'] != 'You':  # someone else receiving an item is group loot; your own is quests and vendors
                self._add_loot({'ts': ts, 'who': self._who(g['who']), 'item': _item_from(raw, g['item']), 'count': to_int(g['count'] or 1) or 1})
            return
        if key == 'won':
            it = item_of(raw) or _item_from(raw, g['item'])
            if not it or not it.get('name'):
                return False
            entry = {'ts': ts, 'who': self._who(g['who']), 'item': it, 'count': 1, 'won': True}
            if g['who'] == 'You':
                self._infer_you(ts, it.get('name'))
            if g.get('val'):
                entry['roll'] = {'type': g['type'], 'val': int(g['val'])}
            self._add_loot(entry)
            return
        if key == 'created':
            if not g['item'] or len(g['item']) > 80:
                return False
            self.crafted.append({'ts': ts, 'who': self._who(g['who']), 'item': _item_from(raw, g['item']), 'count': to_int(g['count'] or 1) or 1})
            return
        if key == 'roll':
            self._roll(ts, {'ts': ts, 'who': clean_name(g['who']), 'val': int(g['val']), 'lo': int(g['lo']), 'hi': int(g['hi'])})
            return
        if key == 'group_roll':
            it = _item_from(raw[raw.find(' for ') + 5:], g['item'])
            ikey = 'ng:' + it['name']
            s = self._group_sessions.get(ikey)
            if s is None or ts - s['end'] >= 120000:
                s = {'key': ikey, 'start': ts, 'end': ts, 'hi': 100, 'rolls': [], 'item': it, 'kind': 'group'}
                self.roll_sessions.append(s)
                self._group_sessions[ikey] = s
            s['end'] = ts
            s['rolls'].append({'ts': ts, 'who': clean_name(g['who']), 'val': int(g['val']), 'lo': 1, 'hi': 100, 'type': g['type']})
            self._infer_you(ts, it['name'])
            return
        if key in ('roll_choice', 'passed', 'all_passed'):
            self.roll_choices.append({'ts': ts, 'who': self._who(g.get('who') or 'Everyone'), 'type': g.get('type') or 'Pass',
                                      'item': _item_from(raw, g['item'])})
            return
        if key == 'reset':
            self.resets.append({'ts': ts, 'instance': g['instance'], 'ok': True})
        elif key == 'reset_failed':
            self.resets.append({'ts': ts, 'instance': g['instance'], 'ok': False, 'why': g['why']})
        elif key == 'honor':
            self.honor.append({'ts': ts, 'amount': int(g['amount'])})
        elif key == 'honor_kill':
            self.honor.append({'ts': ts, 'amount': int(g['amount'] or g['amount2']), 'target': g['target'],
                               'rank': (g.get('rank') or g.get('rank2') or '').strip() or None})
        elif key in ('rep_up', 'rep_up_old'):
            self.reputation.append({'ts': ts, 'faction': g['faction'], 'amount': to_int(g.get('amount')) or None, 'up': g['dir'] == 'increased'})
        elif key == 'xp_kill':
            self.xp.append({'ts': ts, 'amount': int(g['amount']), 'target': g['target'], 'bonus': g.get('bonus')})
        elif key == 'xp':
            self.xp.append({'ts': ts, 'amount': int(g['amount']), 'bonus': g.get('bonus')})
        elif key == 'quest_accepted':
            self.quests.append({'ts': ts, 'quest': g['quest'], 'done': False})
        elif key == 'quest_done':
            self.quests.append({'ts': ts, 'quest': g['quest'], 'done': True})
        elif key == 'level_up':
            self.levels.append({'ts': ts, 'level': int(g['level'])})
        elif key == 'achievement':
            self.achievements.append({'ts': ts, 'who': clean_name(g['who']), 'what': g['what'].strip('[]')})
        elif key == 'afk_on':
            self.status.append({'ts': ts, 'state': 'busy' if g['kind'] in ('Busy', 'DND') else 'away', 'text': g['text']})
        elif key == 'afk_off':
            self.status.append({'ts': ts, 'state': 'back', 'text': ''})
        elif key in ('online', 'offline'):
            self.presence.append({'ts': ts, 'who': clean_name(g['who']), 'online': key == 'online'})
        elif key in ('joins', 'leaves'):
            self.group.append({'ts': ts, 'who': clean_name(g['who']), 'joined': key == 'joins'})
        elif key in ('you_leave', 'you_join'):
            self.group.append({'ts': ts, 'who': self.me or 'You', 'joined': key == 'you_join'})
        elif key == 'others_money':
            c = sum(int(a) * self.coin_units.get(u, 0) for a, u in self.R['coin'].findall(g['coins']))
            self.others_money.append({'ts': ts, 'who': clean_name(g['who']), 'copper': c})
        elif key == 'currency':
            self.currency.append({'ts': ts, 'item': _item_from(raw, g['item']), 'count': to_int(g['count'] or 1) or 1})
        elif key == 'skill_up':
            self.skills.append({'ts': ts, 'skill': g['skill'], 'level': int(g['level'])})
        elif key == 'discovered':
            self.discovered.append({'ts': ts, 'zone': g['zone']})
        elif key == 'disenchanted':
            self.disenchants.append({'ts': ts, 'who': clean_name(g['who']), 'item': _item_from(raw, g['item'])})
        elif key == 'loot_master':
            self.loot_settings.append({'ts': ts, 'what': 'master', 'value': clean_name(g['who'])})
        elif key == 'loot_method':
            self.loot_settings.append({'ts': ts, 'what': 'method', 'value': g['method']})
        elif key == 'loot_threshold':
            self.loot_settings.append({'ts': ts, 'what': 'threshold', 'value': g['quality']})
        elif key == 'difficulty':
            self.loot_settings.append({'ts': ts, 'what': 'difficulty', 'value': f"{g['what']}: {g['level']}", 'reset_all': bool(g.get('note'))})
        elif key == 'died':
            self.deaths.append({'ts': ts, 'who': clean_name(g['who'])})
        elif key == 'you_died':
            self.deaths.append({'ts': ts, 'who': self.me or 'You'})
        self._sys(ts, text, key)

    def _roll(self, ts, roll):
        s = self.session
        if s is None or ts - s['end'] > 30000 or s['hi'] != roll['hi']:
            call = self.last_item_call if self.last_item_call and ts - self.last_item_call['ts'] < 60000 else None
            s = self.session = {'start': ts, 'end': ts, 'hi': roll['hi'], 'rolls': [], 'item': call['item'] if call else None, 'kind': 'roll', '_who': set()}
            if call:
                self.last_item_call = None
            self.roll_sessions.append(s)
        s['end'] = ts
        seen = s.setdefault('_who', set())
        if roll['who'] in seen:
            roll['again'] = True  # rolled twice: only the first counts
        seen.add(roll['who'])
        s['rolls'].append(roll)


def roll_winner(s):
    if s.get('kind') == 'group':
        counted = [r for r in s['rolls'] if not r.get('again')]
    else:
        counted = [r for r in s['rolls'] if not r.get('again') and r['lo'] == 1 and r['hi'] == s['hi']]
    if not counted:
        return None
    if s.get('kind') == 'group':
        need = [r for r in counted if r.get('type') == 'Need']
        counted = need or counted
    best = counted[0]
    for r in counted[1:]:
        if r['val'] > best['val']:
            best = r
    return best
