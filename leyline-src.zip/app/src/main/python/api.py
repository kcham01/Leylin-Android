# ======================================================================
#  Android app: the Python side. The screens are HTML; they ask this file for data with call(name, args)
#  and get JSON back. All the reading and number-crunching is the same code the PC window uses.
# ======================================================================

import base64
import json
import os
import threading
import time
import traceback
from datetime import datetime

from parsers import CombatParser, ChatParser, roll_winner  # dev
from watcher import Watcher, is_combat, is_chat  # dev
from activities import (fmt, dur, span, clock, plural, fight_dur, gold, KIND_LABEL, KIND_ORDER, run_header, player_header,  # dev
                        discord_run, discord_player, discord_week, discord_session)  # dev
from items import ITEMS, wowhead_url  # dev
from bosses import HOLIDAY_ENCS  # dev
from parsers import NOTABLE  # dev
from core import Core, Settings, CHANNEL_SHORT, fmt_int, mins, day, day_key, fmt_bytes  # dev

PHONE_ROOT = '/storage/emulated/0'
PHONE_LOG_SPOTS = [PHONE_ROOT + '/Leyline/Logs', PHONE_ROOT + '/Leyline', PHONE_ROOT + '/Documents/Leyline/Logs', PHONE_ROOT + '/Logs',
                   PHONE_ROOT + '/Download/Logs', PHONE_ROOT + '/Download', PHONE_ROOT + '/Documents', PHONE_ROOT + '/Syncthing/Logs',
                   PHONE_ROOT + '/Sync/Logs']


def folder_has_logs(d):
    try:
        return any(is_combat(n) or is_chat(n) for n in os.listdir(d))
    except OSError:
        return False


def default_logs_dir():
    return next((p for p in PHONE_LOG_SPOTS if folder_has_logs(p)), PHONE_LOG_SPOTS[0])


def pct(v, total):
    return round(100 * v / total) if total else 0


class Api(Core):
    """One per app. Every public method returns plain data (dicts, lists, strings, numbers)."""

    def __init__(self, data_dir, items_path=None, logs_dir=None, phone=True):
        self.data_dir = data_dir
        os.makedirs(data_dir, exist_ok=True)
        self.phone = phone
        self.cfg = Settings(os.path.join(data_dir, 'settings.json'))
        self.state = 'starting'
        self.progress = ('Starting', 0.0)
        self.error = None
        self.toasts = []
        self.alerts = []
        self.seen_watch = None
        self.run_scope = self.cfg.get('run_scope', 'boss')
        self.watch = self.cfg.get('watch', ['lfm kara', 'need healer'])
        self.sound = self.cfg.get('sound', True)
        self.auto_save = False   # nothing arrives live on a phone (logs are copied over), so reports are saved when asked
        self.report_dir = self.cfg.get('report_dir', None) or os.path.join(self.documents_dir(), 'Leyline Reports')
        self.names_file = os.path.join(data_dir, 'names.json')
        try:
            with open(self.names_file, encoding='utf-8') as fh:
                data = json.load(fh)
            self.saved_classes = data['names'] if isinstance(data, dict) and data.get('v') == 2 else {}
        except Exception:
            self.saved_classes = {}
        self.saved_classes_n = len(self.saved_classes)
        self.name_class = {}
        self.addon_events = []
        self.live = None
        if items_path and os.path.isfile(items_path):
            ITEMS.load_async(items_path)
        self.lock = threading.RLock()
        # worked out when reading starts: before storage access is allowed, no folder can be seen
        self.logs_dir = logs_dir or self.cfg.get('logs_dir', None)
        self.w = None
        self.last_export = 0

    # ---- plumbing ----
    def show_toast(self, text):
        self.toasts.append(text)

    def log_error(self, text):
        try:
            path = os.path.join(self.data_dir, 'errors.log')
            if os.path.exists(path) and os.path.getsize(path) > 1_000_000:
                os.remove(path)
            with open(path, 'a', encoding='utf-8') as fh:
                fh.write(f"---- {datetime.now():%Y-%m-%d %H:%M:%S}\n{text}\n")
        except Exception:
            pass

    def call(self, name, args_json='{}'):
        """The one entry point the app uses: returns JSON text, {"ok": ...} or {"error": ...}."""
        try:
            args = json.loads(args_json or '{}')
            fn = getattr(self, 'api_' + name, None)
            if fn is None:
                raise ValueError('unknown call ' + name)
            with self.lock:
                out = fn(**args)
            return json.dumps({'ok': out}, ensure_ascii=False, default=str)
        except Exception:
            tb = traceback.format_exc()
            self.log_error(tb)
            return json.dumps({'error': tb[-1500:]})

    def start_watcher(self):
        if self.w is not None:
            self.w.running = False
        if not self.logs_dir:
            self.logs_dir = default_logs_dir()
        self.w = Watcher(self.logs_dir, os.path.join(self.data_dir, 'cache'), CombatParser, ChatParser)
        self.state, self.progress, self.error = 'starting', ('Starting', 0.0), None
        for attr in ('_snap_key', '_watch_key', '_act_key', 'model'):
            if hasattr(self, attr):
                delattr(self, attr)
        self.seen_watch = None
        self.w.start()

    def pump(self):
        """Messages from the reading thread (the PC window's pump(), without the drawing)."""
        if self.w is None:
            return
        while True:
            try:
                msg = self.w.q.get_nowait()
            except Exception:
                break
            kind = msg[0]
            if kind == 'missing':
                self.state = 'missing'
            elif kind == 'found':
                self.state = 'loading'
            elif kind == 'progress':
                if self.state != 'ready':
                    self.state = 'loading'
                self.progress = (msg[1], msg[2])
            elif kind == 'loaded':
                self.state = 'ready'
                with self.w.lock:
                    self.snapshot()
                    self.seen_watch = len(self.watch_matches())
            elif kind == 'chat':
                self.check_watch()
            elif kind == 'error':
                self.state, self.error = 'error', msg[1]
                self.log_error(msg[1])
            elif kind == 'warn':
                self.log_error(msg[1])

    def check_watch(self):
        if self.state != 'ready':
            return
        with self.w.lock:
            self.snapshot()
            matches = self.watch_matches()
        if self.seen_watch is None:
            self.seen_watch = len(matches)
            return
        if len(matches) > self.seen_watch:
            m = matches[-1]
            if time.time() * 1000 - m['ts'] < 120000:
                self.alerts.append({'text': f"{m['who']}: {m['text']}", 'sound': bool(self.sound)})
        self.seen_watch = len(matches)

    def ready(self):
        """Fresh indexes for a page. Call with self.lock held (call() does)."""
        self.pump()
        if self.state != 'ready':
            return False
        with self.w.lock:
            self.snapshot()
        return True

    # ---- small helpers ----
    def cls_of(self, name=None, guid=None):
        if guid:
            p = self.players.get(guid)
            if p and p.get('cls'):
                return p['cls']
        return self.name_class.get(name) if name else None

    def item(self, name, q=None, count=None):
        info = ITEMS.info(name)
        return {'name': name, 'q': ITEMS.quality(name, q), 'count': count if count and count > 1 else None}

    def badge(self, f):
        k, label = self.fight_badge(f)
        return {'kind': k, 'label': label}

    def res(self, kind, success, hp):
        if kind != 'boss':
            return {'kind': 'trash', 'label': 'Trash'}
        if success:
            return {'kind': 'kill', 'label': 'Kill'}
        return {'kind': 'wipe', 'label': f"Wipe {round(hp * 100)}%" if hp is not None else 'Wipe'}

    def extras(self, cons, cds, int_by, kicked, dispels, taken, taken_by, avoid):
        """What goes in a player's drop-down: consumables, cooldowns and utility, interrupts, dispels, damage taken."""
        order = {'defensive': 0, 'cooldown': 1, 'utility': 2}
        out = {'cons': [dict(self.item(k), n=v) for k, v in sorted(cons.items(), key=lambda kv: (-kv[1], kv[0]))],
               'cds': [[k, v, NOTABLE.get(k, 'utility')] for k, v in sorted(cds.items(), key=lambda kv: (order.get(NOTABLE.get(kv[0]), 3), -kv[1], kv[0]))],
               'ints': sum(int_by.values()) if int_by else 0,
               'int_by': [[k, v] for k, v in sorted(int_by.items(), key=lambda kv: -kv[1])],
               'kicked': [[k, v] for k, v in sorted(kicked.items(), key=lambda kv: -kv[1])[:6]],
               'dispels': dispels,
               'taken': fmt(taken) if taken else None,
               'taken_by': [[k, fmt(v), pct(v, taken)] for k, v in sorted(taken_by.items(), key=lambda kv: -kv[1])[:5]],
               'avoid': fmt(avoid) if avoid else None}
        return out

    def death_row(self, d, f):
        return {'fight': f['name'] or 'Trash', 'fight_id': f['id'], 'boss': f['kind'] == 'boss', 'at': dur(d['ts'] - f['start']),
                'clock': clock(d['ts']), 'spell': d.get('spell') or 'unknown', 'killer': d.get('killer'),
                'amount': fmt_int(d['amount']) if d.get('amount') else None,
                'recap': [{'ago': f"-{(d['ts'] - e['ts']) / 1000:.1f}s", 'dmg': e['t'] == 'd', 'amount': fmt_int(e['amount']),
                           'spell': e.get('spell') or '', 'src': e.get('src'), 'crit': bool(e.get('crit')),
                           'overkill': fmt_int(e['overkill']) if e.get('overkill') else None} for e in (d.get('recap') or [])[-10:]]}

    def chan_label(self, m):
        if m['ch'] == 'whisper':
            return 'To' if m.get('out') else 'Whisper'
        name = m.get('ch_name') or ''
        return CHANNEL_SHORT.get(name) or name.split(' - ')[0]

    def msg(self, m, since=None):
        out = {'t': dur(m['ts'] - since) if since else clock(m['ts']), 'ch': m['ch'], 'label': self.chan_label(m),
               'who': m.get('who') or '', 'cls': self.cls_of(m.get('who')), 'day': day(m['ts']), 'dk': str(day_key(m['ts']))}
        text = m['text']
        if '[' in text:  # [Item Name] links, like in game
            parts, i = [], 0
            while i < len(text):
                j = text.find('[', i)
                k = text.find(']', j) if j >= 0 else -1
                if j < 0 or k < 0:
                    parts.append({'t': text[i:]})
                    break
                if j > i:
                    parts.append({'t': text[i:j]})
                name = text[j + 1:k]
                if ITEMS.info(name):
                    parts.append({'i': name, 'q': ITEMS.quality(name)})
                else:
                    parts.append({'t': text[j:k + 1]})
                i = k + 1
            out['parts'] = parts
        else:
            out['text'] = text
        return out

    # ==================================================================
    #  Calls
    # ==================================================================
    def api_status(self, versions=None):
        """Polled every second or two: what state we're in, and whether anything changed since 'versions'."""
        if self.w is None:
            self.start_watcher()
        self.pump()
        w = self.w
        vers = dict(getattr(w, 'versions', {}) or {})
        vers['items'] = int(ITEMS.ready)
        vers['state'] = self.state
        status, dot = self.status_line()
        if self.state == 'ready' and self.auto_save and time.time() - self.last_export > 60:
            self.last_export = time.time()
            try:
                self.ready()
                self.auto_export()
            except Exception:
                self.log_error(traceback.format_exc())
        if self.state == 'ready' and len(self.name_class) > self.saved_classes_n:
            self.save_names()
        toasts, self.toasts = self.toasts, []
        alerts, self.alerts = self.alerts, []
        bf = w.backfill
        return {'state': self.state, 'progress': list(self.progress), 'error': self.error, 'logs_dir': self.logs_dir,
                'versions': vers, 'status': status, 'dot': dot, 'toasts': toasts, 'alerts': alerts,
                'backfill': list(bf) if bf else None, 'theme': self.cfg.get('theme', 'dark')}

    def status_line(self):
        w = self.w
        if self.state != 'ready':
            return {'starting': 'Starting', 'loading': 'Reading logs', 'missing': 'No logs folder', 'error': 'Problem reading logs'}.get(self.state, ''), 'idle'
        if w.backfill:
            return f'Reading older logs {w.backfill[0]}/{w.backfill[1]}', 'live'
        if w.active and getattr(w.active.parser, 'cur', None):
            return 'Fight in progress', 'live'
        last = max(w.last_read or 0, getattr(w, 'last_chat', 0) or 0)
        if not last:
            return 'Waiting for logs', 'idle'
        ago = time.time() - last
        txt = 'just now' if ago < 60 else f'{int(ago // 60)}m ago' if ago < 3600 else f'{int(ago // 3600)}h ago' if ago < 86400 else f'{int(ago // 86400)}d ago'
        return f'Updated {txt}', 'live' if ago < 120 else 'idle'

    # ---- menu ----
    def api_nav(self, filter='all'):
        if not self.ready():
            return {'runs': [], 'chat': None}
        runs = []
        for r in reversed(self.runs):
            kind = r.get('kind') or 'instance'
            if filter == 'raid' and kind != 'raid' or filter == 'dungeon' and kind != 'dungeon' or filter == 'pvp' and kind not in ('battleground', 'arena'):
                continue
            sm, line = self.run_line(r)
            if sm.get('result') or kind in ('battleground', 'arena'):
                mark = 'pvp'
            else:
                mark = 'kill' if sm['kills'] else 'wipe' if sm['wipes'] else 'none'
            runs.append({'id': r['id'], 'name': r['name'], 'line': line, 'mark': mark, 'kind': kind})
        chat = None
        cp = self.cp
        if cp:
            chat = {'loot': len(cp.loot), 'rolls': len(cp.roll_sessions), 'activity': len(self.activity_items()),
                    'watch': len(self.watch_matches()), 'messages': len(cp.messages)}
        return {'runs': runs, 'chat': chat}

    # ---- one run ----
    def api_run(self, id, scope=None):
        if not self.ready():
            return None
        r = self.run_by_id.get(id)
        if r is None:
            return None
        if scope:
            self.run_scope = scope
            self.cfg.set('run_scope', scope)
        sc = self.scope_for(r)
        bosses, known, fights = self.bosses_of(r)
        kills = [b for b in bosses if any(a['success'] for a in b['attempts']) and b['id'] not in HOLIDAY_ENCS]
        deaths = sum(len(f['deaths']) for f in fights)
        end = max([r['end']] + [f['end'] for f in fights])
        sm = self.model.run_summary_cached(r, sc)
        kind = r.get('kind', 'instance')
        pvp = kind in ('battleground', 'arena')
        subs = [KIND_LABEL.get(kind, 'Instance') + (f" · {sm['difficulty']}" if sm.get('difficulty') else ''),
                f"{day(r['start'])}, {clock(r['start'])} – {clock(end)}", f"{span(end - r['start'])} total"]
        badge = None
        if sm.get('result'):
            badge = {'kind': 'kill', 'label': 'Win'} if sm['result'] == 'win' else {'kind': 'wipe', 'label': 'Loss'}
        elif known and len(kills) >= known:
            badge = {'kind': 'kill', 'label': 'Cleared'}
        counted = sm['counted']
        sec = max(1, sum(fight_dur(f) for f in counted) / 1000)
        dmg = sum(p['dmg'] for p in sm['players'])
        heal = sum(p['heal'] for p in sm['players'])
        if pvp:
            stats = [{'v': fmt(dmg), 'l': 'Damage done'}, {'v': fmt(heal), 'l': 'Healing done'},
                     {'v': str(deaths), 'l': 'Deaths', 'c': 'wipe' if deaths else None}, {'v': span(end - r['start']), 'l': 'Match length'}]
        else:
            stats = [{'v': str(len(kills)), 'l': 'Bosses killed', 'suffix': f'/{known}' if known else None},
                     {'v': str(sm['wipes']), 'l': 'Wipes', 'c': 'wipe' if sm['wipes'] else None},
                     {'v': mins(sm['clear_time']) if sm['clear_time'] else mins(end - r['start']), 'l': 'Clear time' if sm['clear_time'] else 'Time inside'},
                     {'v': fmt_int(dmg / sec), 'l': 'Raid DPS' if kind == 'raid' else 'Group DPS'},
                     {'v': fmt_int(heal / sec), 'l': 'Raid HPS' if kind == 'raid' else 'Group HPS'},
                     {'v': str(deaths), 'l': 'Deaths', 'c': 'wipe' if deaths else None}]

        def meter_rows(key, rate):
            rows = sorted([p for p in sm['players'] if p[key] > 0], key=lambda p: -p[key])
            total = sum(p[key] for p in rows)
            if key == 'heal':  # a few points from a leech or a bandage doesn't make someone a healer
                rows = [p for p in rows if p['heal'] >= 0.02 * max(1, total)] or rows
            return {'total': fmt(total), 'rows': [{'guid': p['guid'], 'name': p['name'], 'cls': p.get('cls') or self.cls_of(p['name']),
                                                   'v': fmt(p[key]), 'rate': fmt_int(p[rate]), 'pct': pct(p[key], total), 'raw': p[key]} for p in rows]}
        details = {}
        whole = self.model.run_summary_cached(r, 'all')   # the drop-downs cover the whole run, trash included
        for p in whole['players']:
            details[p['guid']] = self.extras(p['cons_by'], p.get('cds_by') or {}, p.get('int_by') or {}, p.get('kicked') or {}, p['dispels'],
                                             p['taken'], p.get('taken_by') or {}, p['avoid'] if kind == 'raid' else 0)
            details[p['guid']]['deaths'] = []
        for f in fights:   # deaths from the whole run, trash included: that's where people often die
            for d in f['deaths']:
                details.setdefault(d['guid'], self.extras({}, {}, {}, {}, 0, 0, {}, 0)).setdefault('deaths', []).append(self.death_row(d, f))
        out = {'id': r['id'], 'name': r['name'], 'kind': kind, 'pvp': pvp, 'badge': badge, 'subs': subs, 'stats': stats, 'details': details,
               'scope': sc, 'scope_choice': kind in ('raid', 'dungeon'),
               'damage': meter_rows('dmg', 'dps'), 'healing': meter_rows('heal', 'hps')}
        # boss by boss
        out['bosses'] = []
        if not pvp:
            for b in bosses:
                kill = next((a for a in b['attempts'] if a['success']), None)
                wipes = sum(1 for a in b['attempts'] if not a['success'])
                best = kill or (max(b['attempts'], key=fight_dur) if b['attempts'] else None)
                tops = []
                if best:
                    bsec = fight_dur(best) / 1000
                    for label, key in (('Damage', 'dmg'), ('Healing', 'heal')):
                        top = sorted([kv for kv in best['players'].items() if kv[1][key] > 0], key=lambda kv: -kv[1][key])[:3]
                        if top:
                            tops.append({'label': label, 'who': [{'name': self.player(g)['name'], 'cls': self.cls_of(self.player(g)['name'], g),
                                                                  'v': fmt_int(st[key] / bsec)} for g, st in top]})
                out['bosses'].append({'name': b['name'], 'pending': not b['attempts'],
                                      'attempts': [{'id': a['id'], 'success': bool(a['success']), 'hp': a.get('boss_hp')} for a in b['attempts']],
                                      'right': (f"{dur(fight_dur(kill))} kill" + (f" · {plural(wipes, 'wipe')}" if wipes else '')) if kill else (plural(wipes, 'wipe') if wipes else ''),
                                      'tops': tops})
        # deaths, pull by pull
        out['deaths'] = []
        for f in fights:
            if not f['deaths']:
                continue
            res = '' if f['kind'] != 'boss' else ' · kill' if f['success'] else ' · wipe'
            out['deaths'].append({'id': f['id'], 'title': f"{f['name'] or 'Trash'}{res}", 'clock': clock(f['start']),
                                  'list': [{'at': dur(d['ts'] - f['start']), 'name': d['name'], 'cls': self.cls_of(d['name'], d['guid']),
                                            'what': (d.get('spell') or 'unknown') + (f" from {d['killer']}" if d.get('killer') else ''),
                                            'amount': fmt_int(d['amount']) if d.get('amount') else None} for d in f['deaths']]})
        out['death_total'] = deaths
        # utility
        util = [p for p in sm['players'] if p['interrupts'] or p['dispels'] or p['cons'] or p['avoid'] or p['taken']]
        util.sort(key=lambda p: (-(p['interrupts'] + p['dispels']), -p['cons'], p['name'].lower()))
        out['utility'] = [{'guid': p['guid'], 'name': p['name'], 'cls': p.get('cls') or self.cls_of(p['name']),
                           'interrupts': p['interrupts'], 'dispels': p['dispels'],
                           'cons': ', '.join(f"{n}{' ×' + str(c) if c > 1 else ''}" for n, c in sorted(p['cons_by'].items(), key=lambda kv: -kv[1])),
                           'taken': fmt(p['taken']) if p['taken'] else None, 'avoid': fmt(p['avoid']) if p['avoid'] else None} for p in util]
        out['avoid_col'] = kind == 'raid'
        # every pull
        out['pulls'] = []
        for f in fights:
            fsec = fight_dur(f) / 1000
            out['pulls'].append({'id': f['id'], 'clock': clock(f['start']), 'name': f['name'] or 'Trash', 'boss': f['kind'] == 'boss',
                                 'res': self.res(f['kind'], f['success'], f.get('boss_hp')), 'len': dur(fight_dur(f)),
                                 'dps': fmt_int(sum(st['dmg'] for st in f['players'].values()) / fsec), 'deaths': len(f['deaths'])})
        # loot, with the boss it most likely came from
        kills_f = [f for f in fights if f['kind'] == 'boss' and f['success']]

        def source(ts):
            k = [f for f in kills_f if f['end'] <= ts and ts - f['end'] < 600000]
            return k[-1]['name'] if k else ''
        out['loot'] = [dict(self.item(l['name'], l['q'], l['count']), t=clock(l['ts']), who=l['who'], cls=self.cls_of(l['who']), src=source(l['ts']))
                       for l in sm['loot']]
        out['records'] = list(sm['records'])
        out['scope_note'] = f"Per second is over the time each player was in the {'boss fights' if sc == 'boss' else 'fights'}."
        return out

    # ---- one fight ----
    def api_fight(self, id):
        if not self.ready():
            return None
        f = self.by_id.get(id)
        if f is None:
            return None
        run = self.run_of(f)
        subs = [f"{day(f['start'])}, {clock(f['start'])}", dur(fight_dur(f))]
        attempt = self.attempt.get(f['id'], f.get('attempt'))
        if attempt:
            subs.append(f"Attempt {attempt}")
        if f.get('targets', 0) > 1:
            subs.append(f"{f['targets']} enemy types")
        sec = fight_dur(f) / 1000
        P = f['players']
        dmg = sum(s['dmg'] for s in P.values())
        heal = sum(s['heal'] for s in P.values())
        ints = sum(s['interrupts'] for s in P.values())
        nd = len(f['deaths'])
        out = {'id': f['id'], 'name': f['name'] or ('Trash' if f['kind'] == 'trash' else 'Boss'), 'badge': self.badge(f), 'subs': subs,
               'crumb': {'id': run['id'], 'label': f"{run['name']}, {day(run['start'])}"} if run else None,
               'stats': [{'v': fmt_int(dmg / sec), 'l': 'Raid DPS'}, {'v': fmt_int(heal / sec), 'l': 'Raid HPS'},
                         {'v': str(nd), 'l': 'Deaths', 'c': 'wipe' if nd else None}, {'v': str(ints), 'l': 'Interrupts'}]}
        meters = {}
        for tab, key, by in (('damage', 'dmg', 'dmg_by'), ('healing', 'heal', 'heal_by'), ('taken', 'taken', 'taken_by')):
            rows = sorted(((g, st) for g, st in P.items() if st[key] > 0), key=lambda kv: -kv[1][key])
            total = sum(st[key] for _, st in rows)
            lst = []
            for g, st in rows:
                pl = self.player(g)
                items = sorted(st[by].items(), key=lambda kv: -kv[1])[:10]
                extra = []
                if tab == 'healing' and st['heal']:
                    extra.append(['Overheal', f"{round(100 * st['overheal'] / (st['overheal'] + st['heal']))}%"])
                if tab == 'damage':
                    extra.append(['Active time', f"{min(100, round(100 * st['active'] / fight_dur(f)))}%"])
                lst.append({'guid': g, 'name': pl['name'], 'cls': self.cls_of(pl['name'], g), 'v': fmt(st[key]), 'rate': fmt_int(st[key] / sec) + '/s',
                            'more': self.extras(st['cons'], st.get('cds') or {}, st.get('int_by') or {}, st.get('kicked') or {}, st['dispels'],
                                                st['taken'], st.get('taken_by') or {}, st['avoid']),
                            'died': [self.death_row(d, f) for d in f['deaths'] if d['guid'] == g],
                            'pct': f"{100 * st[key] / total:.1f}%", 'raw': st[key],
                            'by': [{'n': n, 'v': fmt(v), 'pct': pct(v, st[key]), 'raw': v} for n, v in items], 'extra': extra})
            meters[tab] = lst
        out['meters'] = meters
        out['deaths'] = [{'at': dur(d['ts'] - f['start']), 'name': d['name'], 'cls': self.cls_of(d['name'], d['guid']),
                          'spell': d.get('spell') or 'unknown', 'killer': d.get('killer'), 'amount': fmt_int(d['amount']) if d.get('amount') else None,
                          'recap': [{'ago': f"-{(d['ts'] - e['ts']) / 1000:.1f}s", 'dmg': e['t'] == 'd', 'amount': fmt_int(e['amount']),
                                     'spell': e.get('spell') or '', 'src': e.get('src'), 'crit': bool(e.get('crit')),
                                     'overkill': fmt_int(e['overkill']) if e.get('overkill') else None} for e in (d.get('recap') or [])[-10:]]}
                         for d in f['deaths']]
        rows = sorted(P.items(), key=lambda kv: (-(kv[1]['interrupts'] + kv[1]['dispels']), -kv[1]['avoid']))
        out['utility'] = [{'guid': g, 'name': self.player(g)['name'], 'cls': self.cls_of(self.player(g)['name'], g), 'interrupts': st['interrupts'],
                           'dispels': st['dispels'], 'cons': ', '.join(f"{n}{' ×' + str(c) if c > 1 else ''}" for n, c in st['cons'].items()),
                           'avoid': f"{fmt(st['avoid'])} ({st['avoid_hits']} hits)" if st['avoid'] else None} for g, st in rows]
        cp = self.cp
        out['loot'], out['chat'] = [], []
        if cp:
            lo, hi = f['start'] - 5000, f['end'] + 5000
            out['chat'] = [self.msg(m, since=f['start']) for m in cp.messages if lo <= m['ts'] <= hi and m['ch'] in ('raid', 'raidwarning', 'party', 'yell', 'say')][-60:]
            if f['kind'] == 'boss' and f['success']:
                out['loot'] = [dict(self.item(l['item']['name'], l['item']['q'], l['count']), t=clock(l['ts']), who=l['who'], cls=self.cls_of(l['who']))
                               for l in cp.loot if f['end'] <= l['ts'] <= f['end'] + 300000 and (l['item']['q'] is None or l['item']['q'] >= 3)]
        return out

    # ---- one player in one run ----
    def api_player(self, run, guid):
        if not self.ready():
            return None
        r = self.run_by_id.get(run)
        if r is None:
            return None
        sc = self.scope_for(r)
        ps = self.model.player_summary(r, guid, sc)
        crumb = {'id': r['id'], 'label': r['name']}
        if not ps:
            return {'empty': True, 'name': self.player(guid)['name'], 'crumb': crumb, 'subs': [r['name']]}
        me = ps['player']
        cls = (ps.get('cls') or '').title()
        subs = [s for s in (cls, f"{r['name']} · {day(r['start'])}", 'Boss fights' if ps['scope'] == 'boss' else 'All fights') if s]
        stats = []
        if me['dmg']:
            stats.append({'v': fmt_int(me['dps']), 'l': 'DPS', 'suffix': f" #{ps['rank_dps']}/{ps['of_dps']}" if ps['rank_dps'] else None})
            stats.append({'v': fmt(me['dmg']), 'l': 'Damage done'})
        if me['heal']:
            stats.append({'v': fmt_int(me['hps']), 'l': 'HPS', 'suffix': f" #{ps['rank_hps']}/{ps['of_hps']}" if ps['rank_hps'] else None})
            stats.append({'v': fmt(me['heal']), 'l': 'Healing done'})
        stats.append({'v': str(me['deaths']), 'l': 'Deaths', 'c': 'wipe' if me['deaths'] else None})
        if me['interrupts'] or me['dispels']:
            stats.append({'v': f"{me['interrupts']} / {me['dispels']}", 'l': 'Interrupts / dispels'})
        fights = []
        for row in ps['fights']:
            fights.append({'id': row['fight']['id'], 'name': row['name'] + (f" #{row['attempt']}" if (row['attempt'] or 1) > 1 else ''),
                           'boss': row['kind'] == 'boss', 'res': self.res(row['kind'], row['success'], row.get('boss_hp')), 'time': dur(row['time']),
                           'dps': fmt_int(row['dps']) if row['dmg'] else None, 'dmg': fmt(row['dmg']) if row['dmg'] else None,
                           'hps': fmt_int(row['hps']) if row['heal'] else None, 'heal': fmt(row['heal']) if row['heal'] else None, 'died': bool(row['deaths'])})

        def bars(items):
            total = sum(v for _, v in items) or 1
            top = items[0][1] if items else 1
            return [{'n': n, 'v': fmt(v), 'pct': pct(v, total), 'w': v / top} for n, v in items[:12]]
        return {'name': ps['name'], 'cls': ps.get('cls'), 'subs': subs, 'crumb': crumb, 'stats': stats, 'fights': fights,
                'dmg_by': bars(ps['dmg_by']), 'heal_by': bars(ps['heal_by']),
                'deaths': [{'fight_id': d['fight_id'], 'fight': d['fight'], 'when': f"{dur(d['at'])} in",
                            'what': f"{d.get('spell') or 'Unknown'}" + (f" from {d['killer']}" if d.get('killer') else '') + (f" ({fmt(d['amount'])})" if d.get('amount') else '')}
                           for d in ps['deaths']],
                'cons': [dict(self.item(k), n=v) for k, v in ps['cons_by']],
                'loot': [dict(self.item(l['name'], l['q']), t=clock(l['ts'])) for l in ps['loot']]}

    # ---- sharing and reports ----
    def resolve(self, kind, ident):
        if kind == 'run':
            return self.run_by_id[ident]
        if kind == 'player':
            rid, _, guid = ident.partition('|')
            return (self.run_by_id[rid], guid)
        if kind == 'week':
            return next(wk for wk in self.model.weeks() if str(wk['start']) == str(ident))
        raise ValueError(kind)

    def api_share_text(self, kind, ident):
        self.ready()
        obj = self.resolve(kind, ident)
        sm = self.summary_for(kind, obj)
        if sm is None:
            return None
        return (discord_run(sm) if kind == 'run' else discord_player(sm) if kind == 'player' else discord_week(sm, sm['top']))

    def api_save_report(self, kind, ident, png=None):
        self.ready()
        obj = self.resolve(kind, ident)
        image = base64.b64decode(png.split(',', 1)[-1]) if png else None
        folder = self.save_report(kind, obj, quiet=True, image=image)
        return folder

    def api_card(self, kind, ident):
        """What goes on the share picture (the PC app's card, as data; the phone draws it)."""
        self.ready()
        obj = self.resolve(kind, ident)
        sm = self.summary_for(kind, obj)
        if sm is None:
            return None
        card = {'kind': kind}
        if kind == 'run':
            title, bits = run_header(sm)
            card.update(title=title, bits=bits)
            card['bosses'] = [{'name': b['name'], 'attempts': [{'success': bool(a['success']), 'hp': a.get('boss_hp')} for a in b['attempts'][:8]],
                               'kill': dur(fight_dur(b['kill'])) if b['kill'] else None} for b in sm['bosses'][:12]]
            players = sorted(sm['players'], key=lambda p: -p['dps'])
            heals = any(p['heal'] for p in players)
            card['group_title'] = 'Group' + (' · boss fights' if sm.get('scope') == 'boss' else ' · all fights')
            card['heals'] = heals
            top = max([p['dps'] for p in players] or [1]) or 1
            card['players'] = [{'name': p['name'], 'cls': p.get('cls') or self.cls_of(p['name']), 'w': p['dps'] / top if p['dmg'] else 0,
                                'dps': fmt_int(p['dps']) if p['dmg'] else '–', 'dmg': fmt(p['dmg']) if p['dmg'] else '–',
                                'hps': fmt_int(p['hps']) if p['heal'] else '–', 'heal': fmt(p['heal']) if p['heal'] else '–',
                                'deaths': str(p['deaths']) if p['deaths'] else '–'} for p in players]
            card['loot'] = [dict(self.item(l['name'], l['q']), who=l['who'], cls=self.cls_of(l['who'])) for l in sm['loot'][:8]]
            card['more_loot'] = max(0, len(sm['loot']) - 8)
        elif kind == 'player':
            title, where = player_header(sm)
            card.update(title=title, bits=[where, 'Boss fights' if sm['scope'] == 'boss' else 'All fights'], cls=sm.get('cls'))
            me = sm['player']
            boxes = []
            if me['dmg']:
                boxes.append([fmt_int(me['dps']), 'DPS' + (f" · #{sm['rank_dps']} of {sm['of_dps']}" if sm['rank_dps'] else '')])
                boxes.append([fmt(me['dmg']), 'Damage'])
            if me['heal']:
                boxes.append([fmt_int(me['hps']), 'HPS' + (f" · #{sm['rank_hps']} of {sm['of_hps']}" if sm['rank_hps'] else '')])
                boxes.append([fmt(me['heal']), 'Healing'])
            boxes.append([str(me['deaths']), 'Deaths'])
            card['boxes'], card['died'] = boxes, bool(me['deaths'])
            card['fights'] = [{'name': r['name'] + (f" #{r['attempt']}" if (r['attempt'] or 1) > 1 else ''), 'ok': bool(r['success']),
                               'val': f"{fmt_int(r['dps'])} dps" if r['dmg'] >= r['heal'] else f"{fmt_int(r['hps'])} hps", 'time': dur(r['time'])}
                              for r in sm['fights'] if r['kind'] == 'boss'][:14]
            card['abilities'] = []
            for head, items in (('Damage by ability', sm['dmg_by']), ('Healing by ability', sm['heal_by'])):
                if items:
                    total = sum(v for _, v in items) or 1
                    card['abilities'].append({'head': head, 'rows': [[k, f'{100 * v / total:.0f}%'] for k, v in items[:5]]})
            card['loot'] = [self.item(l['name'], l['q']) for l in sm['loot'][:6]]
        elif kind == 'week':
            card.update(title=f"Week of {day(sm['start'])}", bits=[plural(sm['kills'], 'boss kill'), plural(sm['wipes'], 'wipe')])
            card['runs'] = [{'day': day(r['start']), 'title': run_header(r)[0], 'bits': ' · '.join(run_header(r)[1][1:])}
                            for r in sorted([r for r in sm['runs'] if r['kind'] in ('raid', 'dungeon')], key=lambda r: r['start'])]
            dps, hps = sm['top']
            card['tops'] = [{'head': head, 'rows': [{'name': h['name'], 'cls': h.get('cls'), 'v': fmt_int(v)} for v, h in lst]}
                            for head, lst in (('Top damage on bosses', dps), ('Top healing on bosses', hps)) if lst]
            card['raiders'] = ', '.join(sorted(sm['attendance'])) if sm['attendance'] else ''
        return card

    # ---- history ----
    def api_history(self, tab='weeks'):
        if not self.ready():
            return None
        self.cfg.set('history_tab', tab)
        m = self.model
        if tab == 'weeks':
            out = []
            for wk in m.weeks():
                runs = sorted([sm for sm in wk['runs'] if sm['kind'] in ('raid', 'dungeon')], key=lambda r: r['start'])
                if not runs:
                    continue
                dps, hps = m.week_top(wk['start'])
                raids = sum(1 for sm in runs if sm['kind'] == 'raid')
                out.append({'start': wk['start'], 'title': f"Week of {day(wk['start'])}",
                            'bits': ' · '.join([plural(raids, 'raid'), plural(len(runs) - raids, 'dungeon'), plural(wk['kills'], 'boss kill'), plural(wk['wipes'], 'wipe')]),
                            'runs': [{'id': sm['run']['id'], 'title': run_header(sm)[0], 'line': ' · '.join([day(sm['start'])] + list(run_header(sm)[1][1:]))} for sm in runs],
                            'tops': [{'label': label, 'who': [{'name': h['name'], 'cls': h.get('cls') or self.cls_of(h['name']), 'v': fmt_int(v)} for v, h in lst]}
                                     for label, lst in (('Top damage on bosses', dps), ('Top healing on bosses', hps)) if lst],
                            'raiders': ', '.join(f"{n}{' ×' + str(c) if c > 1 else ''}" for n, c in sorted(wk['attendance'].items(), key=lambda kv: (-kv[1], kv[0])))})
            return {'tab': tab, 'weeks': out}
        if tab == 'bosses':
            out = []
            for b in m.boss_history():
                kills = [fight_dur(k) for k in b['kills']]
                out.append({'name': b['name'], 'line': f"{plural(len(b['kills']), 'kill')} · {plural(b['wipes'], 'wipe')} · last {day(b['pulls'][-1]['start'])}",
                            'best': mins(b['best']) if b['best'] else None, 'latest': mins(b['latest']) if b['latest'] else None,
                            'trend': [-k for k in kills] if len(kills) >= 2 else [],
                            'pulls': [{'id': f['id'], 'when': f"{day(f['start'])}, {clock(f['start'])}", 'res': self.res('boss', f['success'], f.get('boss_hp')),
                                       'len': mins(fight_dur(f)), 'deaths': plural(len(f['deaths']), 'death') if f['deaths'] else ''} for f in b['pulls'][::-1][:40]]})
            return {'tab': tab, 'bosses': out}
        if tab == 'players':
            ph = m.player_history()
            players = sorted(ph.values(), key=lambda h: (h['healer'], -(h['hps'] if h['healer'] else h['dps'])))
            out = []
            for h in players:
                b = h['best']
                trend = [v for _, v in h['trend']]
                out.append({'name': h['name'], 'cls': h.get('cls') or self.cls_of(h['name']), 'healer': h['healer'],
                            'val': f"{fmt_int(h['hps'] if h['healer'] else h['dps'])} {'hps' if h['healer'] else 'dps'}",
                            'kills': len(h['kills']), 'weeks': len(trend),
                            'best': f"{fmt_int(b['hps'] if h['healer'] else b['dps'])} ({b['boss']})" if b else None, 'trend': trend})
            return {'tab': tab, 'players': out}
        if tab == 'attendance':
            nights = m.raid_nights()
            all_n = len(nights)
            nights = nights[-16:]
            counts = {}
            for n in nights:
                for name in n['roster']:
                    counts[name] = counts.get(name, 0) + 1
            players = sorted(counts.items(), key=lambda kv: (-kv[1], kv[0].lower()))
            return {'tab': tab, 'total': all_n, 'nights': [{'label': datetime.fromtimestamp(n['start'] / 1000).strftime('%m/%d'), 'name': n['name']} for n in nights],
                    'players': [{'name': name, 'cls': self.cls_of(name), 'here': [name in n['roster'] for n in nights], 'count': c} for name, c in players]}
        if tab == 'loot':
            return {'tab': tab, 'people': [{'who': who, 'cls': self.cls_of(who), 'items': [dict(self.item(l['name'], l['q']), where=f"{l['raid']} · {day(l['ts'])}")
                                                                                       for l in sorted(items, key=lambda l: -l['ts'])]} for who, items in m.loot_by_player()]}
        raise ValueError(tab)

    def api_phist(self, name):
        if not self.ready():
            return None
        h = self.model.player_history().get(name)
        if not h:
            return {'name': name, 'empty': True}
        key = 'hps' if h['healer'] else 'dps'
        unit = 'HPS' if h['healer'] else 'DPS'
        b = h['best']
        return {'name': name, 'cls': h.get('cls') or self.cls_of(name),
                'subs': [s for s in ((h.get('cls') or '').title(), plural(len(h['kills']), 'boss kill'), plural(h['runs'], 'run')) if s],
                'stats': [{'v': fmt_int(h[key]), 'l': f'Average {unit} on bosses'}, {'v': fmt_int(b[key]) if b else '–', 'l': f"Best: {b['boss']}" if b else 'Best'},
                          {'v': fmt(h['heal'] if h['healer'] else h['dmg']), 'l': 'Healing on bosses' if h['healer'] else 'Damage on bosses'},
                          {'v': str(sum(k['deaths'] for k in h['kills'])), 'l': 'Deaths on kills'}],
                'trend': [v for _, v in h['trend']],
                'weeks': [{'title': f"Week of {day(wk)}", 'v': f"{fmt_int(v)} {unit.lower()}", 'kills': plural(h['weeks'][wk]['kills'], 'boss kill')} for wk, v in h['trend'][::-1]],
                'bosses': [{'name': boss, 'line': f"best {fmt_int(max(k[key] for k in kills))} · latest {fmt_int(kills[-1][key])} · {plural(len(kills), 'kill')}",
                            'trend': [k[key] for k in kills] if len(kills) >= 2 else [],
                            'kills': [{'id': k['fight_id'], 'where': f"{day(k['ts'])} · {k['run']}", 'v': fmt_int(k[key])} for k in kills[::-1][:6]]}
                           for boss, kills in sorted(h['bosses'].items(), key=lambda kv: -kv[1][-1]['ts'])]}

    # ---- chat ----
    def api_chat_loot(self, q=2, who='all', text=''):
        if not self.ready() or not self.cp:
            return None
        cp = self.cp
        self.cfg.set('loot_q', q)
        self.cfg.set('loot_who', who)
        qual = lambda l: ITEMS.quality(l['item']['name'], l['item']['q'])
        gold_in = sum(m['copper'] for m in cp.money)
        epics = sum(1 for l in cp.loot if (qual(l) or 0) >= 4)
        rares = sum(1 for l in cp.loot if (qual(l) or 0) == 3)
        stats = [{'v': gold(gold_in) if gold_in else '–', 'l': 'Gold looted in this log', 'c': 'warn' if gold_in else None},
                 {'v': str(epics), 'l': 'Epics', 'q': 4 if epics else None}, {'v': str(rares), 'l': 'Rares', 'q': 3 if rares else None},
                 {'v': str(len(cp.loot)), 'l': 'Items in total'}]
        text = (text or '').strip().lower()
        rolls = {}
        for sess in cp.roll_sessions:
            if sess.get('item'):
                for rr in sess['rolls']:
                    rolls[(sess['item']['name'], rr['who'])] = rr
        groups = []
        n = 0
        for l in reversed(cp.loot):
            lq = qual(l)
            if q and lq is not None and lq < q:
                continue
            if who == 'me' and l['who'] != 'You':
                continue
            if who == 'won' and not l.get('won'):
                continue
            name = self.model.name_of(l['who'], l['ts'])
            if text and text not in l['item']['name'].lower() and text not in name.lower():
                continue
            roll = l.get('roll') or (rolls.get((l['item']['name'], name)) if l.get('won') else None)
            note = (f"won · {roll['type']} {roll['val']}" if roll.get('type') else f"won · rolled {roll['val']}") if roll else 'won the roll' if l.get('won') else ''
            row = dict(self.item(l['item']['name'], l['item']['q'], l['count']), t=clock(l['ts']), who=name, cls=self.cls_of(name),
                       side=' · '.join(v for v in (self.where_was(l['ts']), note) if v))
            dk = str(day_key(l['ts']))
            if not groups or groups[-1]['dk'] != dk:
                groups.append({'dk': dk, 'day': day(l['ts']), 'rows': []})
            groups[-1]['rows'].append(row)
            n += 1
            if n >= 500:
                break
        return {'stats': stats, 'groups': groups, 'q': q, 'who': who}

    def api_chat_rolls(self):
        if not self.ready() or not self.cp:
            return None
        cp = self.cp
        won = [l for l in cp.loot if l.get('won')]

        def winner(sess):
            if sess.get('kind') == 'group' and sess.get('item'):
                got = next((l for l in won if l['item']['name'] == sess['item']['name'] and -5000 <= l['ts'] - sess['end'] <= 180_000), None)
                if got:
                    who = self.model.name_of(got['who'], got['ts'])
                    return next((r for r in sess['rolls'] if r['who'] == who), None) or {'who': who, 'val': None}
            return roll_winner(sess)
        out = []
        for sess in cp.roll_sessions[::-1][:200]:
            w = winner(sess)
            tie = w is not None and w.get('val') is not None and any(not r.get('again') and r['val'] == w['val'] and r['who'] != w['who'] for r in sess['rolls'])
            out.append({'item': self.item(sess['item']['name'], sess['item']['q']) if sess.get('item') else None, 'hi': sess.get('hi'),
                        'when': f"{day(sess['start'])}, {clock(sess['start'])}",
                        'winner': {'name': w['who'], 'cls': self.cls_of(w['who'])} if w else None, 'tie': tie,
                        'rolls': [{'who': r['who'], 'cls': self.cls_of(r['who']), 'label': f"{r['who']} {r['val']}" + (f" {r['type']}" if r.get('type') else ''),
                                   'win': r is w, 'again': bool(r.get('again'))} for r in sorted(sess['rolls'], key=lambda r: -r['val'])]})
        return {'rolls': out}

    def api_chat_activity(self):
        if not self.ready() or not self.cp:
            return None
        cp = self.cp
        items = self.activity_items()
        honor = sum(e['amount'] for e in getattr(cp, 'honor', []))
        xp = sum(e['amount'] for e in getattr(cp, 'xp', []))
        quests = sum(1 for e in getattr(cp, 'quests', []) if e.get('done'))
        rep = {}
        for e in getattr(cp, 'reputation', []):
            rep[e['faction']] = rep.get(e['faction'], 0) + (e['amount'] if e.get('up', True) else -e['amount'])
        top = sorted(rep.items(), key=lambda kv: -kv[1])
        stats = [{'v': f'{honor:,}', 'l': 'Honor in this log', 'c': 'warn' if honor else None}, {'v': f'{quests:,}', 'l': 'Quests completed'}]
        if xp:
            stats.append({'v': fmt(xp), 'l': 'Experience'})
        if top:
            stats.append({'v': f'+{top[0][1]:,}', 'l': top[0][0], 'c': 'kill'})
        groups = []
        for ts, kind, text, color in items[::-1][:600]:
            dk = str(day_key(ts))
            if not groups or groups[-1]['dk'] != dk:
                groups.append({'dk': dk, 'day': day(ts), 'rows': []})
            groups[-1]['rows'].append({'t': clock(ts), 'kind': kind, 'text': text, 'c': color})
        return {'stats': stats, 'groups': groups}

    def api_chat_watch(self, words=None, sound=None):
        if words is not None:
            self.watch = [w.strip() for w in words.split(',') if w.strip()]
            self.cfg.set('watch', self.watch)
        if sound is not None:
            self.sound = bool(sound)
            self.cfg.set('sound', self.sound)
        if not self.ready() or not self.cp:
            return {'words': ', '.join(self.watch), 'sound': self.sound, 'rows': []}
        matches = self.watch_matches()
        if words is not None:
            self.seen_watch = len(matches)
        return {'words': ', '.join(self.watch), 'sound': self.sound, 'hl': self.watch_words(), 'rows': [self.msg(m) for m in matches[::-1][:300]]}

    def api_chat_messages(self, q='', ch='all', limit=300):
        if not self.ready() or not self.cp:
            return None
        ql = (q or '').strip().lower()
        match = lambda m: (ch == 'all' or m['ch'] == ch or (ch == 'raid' and m['ch'] == 'raidwarning') or (ch == 'say' and m['ch'] == 'yell')
                           or (ch == 'party' and m['ch'] == 'instance') or (ch == 'social' and m['ch'] not in ('channel', 'system')))
        out = []
        for m in reversed(self.cp.messages):
            if match(m) and (not ql or ql in m['text'].lower() or ql in m['who'].lower()):
                out.append(self.msg(m))
                if len(out) >= limit:
                    break
        return {'rows': out, 'more': len(out) >= limit}

    # ---- items ----
    def api_item(self, name):
        info = ITEMS.info(name)
        out = {'name': name, 'q': info.get('q') if info else None, 'tooltip': (info or {}).get('tooltip') or [], 'url': wowhead_url(info, name), 'known': bool(info)}
        if info and info.get('base') and info['base'] != name:
            out['note'] = f"Random enchant ({name[len(info['base']):].strip()}): those extra stats aren't shown here."
        return out

    # ---- settings ----
    def api_settings(self):
        w = self.w
        combat, chat = (w.list_logs() if w and os.path.isdir(self.logs_dir or '') else ([], []))
        if ITEMS.ready:
            items = f"{ITEMS.count:,} TBC items"
        else:
            items = 'loading' if not ITEMS.error else 'couldn\u2019t be read'
        return {'report_dir': self.report_dir, 'logs_dir': self.logs_dir, 'theme': self.cfg.get('theme', 'dark'),
                'combat_logs': len(combat), 'chat_log': bool(chat), 'reading': bool(w and (w.backfill or not w.loaded)),
                'items': items}

    def api_set(self, key, value):
        if key == 'theme':
            pass
        elif key == 'report_dir':
            self.report_dir = value
        elif key == 'run_scope':
            self.run_scope = value
        else:
            raise ValueError(key)
        self.cfg.set(key, value)
        return True

    # ---- picking the logs folder ----
    def api_browse(self, dir=None):
        d = dir or (self.logs_dir if self.logs_dir and os.path.isdir(self.logs_dir) else PHONE_ROOT if os.path.isdir(PHONE_ROOT) else os.path.expanduser('~'))
        try:
            names = sorted(os.listdir(d), key=str.lower)
            err = None
        except OSError as ex:
            names, err = [], str(ex)
        dirs = [n for n in names if not n.startswith('.') and os.path.isdir(os.path.join(d, n))]
        logs = []
        for n in names:
            if is_combat(n) or is_chat(n):
                p = os.path.join(d, n)
                try:
                    st = os.stat(p)
                    info = f"{fmt_bytes(st.st_size)} · {datetime.fromtimestamp(st.st_mtime).strftime('%b %d, %I:%M %p').replace(' 0', ' ')}"
                except OSError:
                    info = ''
                logs.append({'name': n, 'info': info})
        parent = os.path.dirname(d.rstrip('/')) or d
        spots = [(l, p) for l, p in (('Internal storage', PHONE_ROOT), ('Download', PHONE_ROOT + '/Download'), ('Documents', PHONE_ROOT + '/Documents'),
                                     ('Leyline', PHONE_ROOT + '/Leyline')) if os.path.isdir(p)]
        return {'dir': d, 'parent': parent if parent != d else None, 'dirs': dirs, 'logs': logs, 'error': err,
                'combat_count': sum(1 for l in logs if is_combat(l['name'])), 'current': os.path.normpath(d) == os.path.normpath(self.logs_dir or ''),
                'hidden': len(names) - len(dirs) - len(logs), 'spots': [{'label': l, 'dir': p} for l, p in spots]}

    def api_set_logs_dir(self, dir):
        self.cfg.set('logs_dir', dir)
        self.logs_dir = dir
        self.start_watcher()
        return dir

    def api_make_logs_folder(self):
        """Makes Internal storage/Leyline/Logs, the folder to copy logs into."""
        d = PHONE_LOG_SPOTS[0]
        os.makedirs(d, exist_ok=True)
        if os.path.normpath(d) != os.path.normpath(self.logs_dir or ''):
            self.api_set_logs_dir(d)
        return d
