# ======================================================================
#  Exports: PNG images, screen capture, clipboard, CSV, XLSX, HTML reports.
#  Standard library only.
# ======================================================================

import csv
import html
import os
import re
import struct
import subprocess
import sys
import tempfile
import zipfile
import zlib
from datetime import datetime
from xml.sax.saxutils import escape as xml_escape

IS_WINDOWS = sys.platform.startswith('win')


# ---------------------------------------------------------------- PNG

def encode_png(width, height, rows):
    """rows: list of bytes, each width*3 RGB. Returns PNG file bytes."""
    raw = b''.join(b'\x00' + bytes(r[:width * 3]) for r in rows[:height])

    def chunk(kind, data):
        c = struct.pack('>I', len(data)) + kind + data
        return c + struct.pack('>I', zlib.crc32(kind + data) & 0xffffffff)
    ihdr = struct.pack('>IIBBBBB', width, height, 8, 2, 0, 0, 0)
    return b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', ihdr) + chunk(b'IDAT', zlib.compress(raw, 6)) + chunk(b'IEND', b'')


def write_png(path, width, height, rows):
    with open(path, 'wb') as fh:
        fh.write(encode_png(width, height, rows))
    return path


# ---------------------------------------------------------------- screen capture

def _parse_ppm(data):
    """Minimal P6 parser. Returns (w, h, rows)."""
    if data[:2] != b'P6':
        return None
    tokens, i = [], 2
    while len(tokens) < 3:
        while data[i:i + 1].isspace():
            i += 1
        if data[i:i + 1] == b'#':
            while data[i:i + 1] not in (b'\n', b''):
                i += 1
            continue
        j = i
        while not data[j:j + 1].isspace():
            j += 1
        tokens.append(int(data[i:j]))
        i = j
    i += 1  # single whitespace after maxval
    w, h, maxval = tokens
    stride = w * 3
    if maxval > 255:  # 16-bit samples, big-endian: keep the high byte
        pix = data[i:i + stride * h * 2][0::2]
    elif maxval == 255:
        pix = data[i:i + stride * h]
    else:
        return None
    return w, h, [pix[y * stride:(y + 1) * stride] for y in range(h)]


def _crop(w, h, rows, x, y, cw, ch):
    x, y = max(0, x), max(0, y)
    cw, ch = min(cw, w - x), min(ch, h - y)
    if cw <= 0 or ch <= 0:
        return None
    return cw, ch, [rows[y + r][x * 3:(x + cw) * 3] for r in range(ch)]


def _capture_x11(widget):
    widget.update_idletasks()
    x, y = widget.winfo_rootx(), widget.winfo_rooty()
    w, h = widget.winfo_width(), widget.winfo_height()
    fd, tmp = tempfile.mkstemp(suffix='.ppm')
    os.close(fd)
    try:
        subprocess.run(['import', '-window', 'root', '-crop', f'{w}x{h}+{x}+{y}', '+repage', '-depth', '8', 'ppm:' + tmp],
                       check=True, capture_output=True, timeout=20)
        with open(tmp, 'rb') as fh:
            got = _parse_ppm(fh.read())
        if not got:
            return None
        gw, gh, rows = got
        return _crop(gw, gh, rows, 0, 0, w, h)
    except Exception:
        return None
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass


if IS_WINDOWS:
    import ctypes
    from ctypes import wintypes

    _user32 = ctypes.WinDLL('user32', use_last_error=True)
    _gdi32 = ctypes.WinDLL('gdi32', use_last_error=True)
    _kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)

    class BITMAPINFOHEADER(ctypes.Structure):
        _fields_ = [('biSize', wintypes.DWORD), ('biWidth', wintypes.LONG), ('biHeight', wintypes.LONG),
                    ('biPlanes', wintypes.WORD), ('biBitCount', wintypes.WORD), ('biCompression', wintypes.DWORD),
                    ('biSizeImage', wintypes.DWORD), ('biXPelsPerMeter', wintypes.LONG), ('biYPelsPerMeter', wintypes.LONG),
                    ('biClrUsed', wintypes.DWORD), ('biClrImportant', wintypes.DWORD)]

    class BITMAPINFO(ctypes.Structure):
        _fields_ = [('bmiHeader', BITMAPINFOHEADER), ('bmiColors', wintypes.DWORD * 3)]

    def _sig(fn, res, *args):
        fn.restype = res
        fn.argtypes = list(args)
        return fn

    HGDIOBJ = wintypes.HANDLE
    _GetDC = _sig(_user32.GetDC, wintypes.HDC, wintypes.HWND)
    _ReleaseDC = _sig(_user32.ReleaseDC, ctypes.c_int, wintypes.HWND, wintypes.HDC)
    _GetParent = _sig(_user32.GetParent, wintypes.HWND, wintypes.HWND)
    _GetAncestor = _sig(_user32.GetAncestor, wintypes.HWND, wintypes.HWND, wintypes.UINT)
    _GetWindowRect = _sig(_user32.GetWindowRect, wintypes.BOOL, wintypes.HWND, ctypes.POINTER(wintypes.RECT))
    _GetClientRect = _sig(_user32.GetClientRect, wintypes.BOOL, wintypes.HWND, ctypes.POINTER(wintypes.RECT))
    _ClientToScreen = _sig(_user32.ClientToScreen, wintypes.BOOL, wintypes.HWND, ctypes.POINTER(wintypes.POINT))
    _PrintWindow = _sig(_user32.PrintWindow, wintypes.BOOL, wintypes.HWND, wintypes.HDC, wintypes.UINT)
    _CreateCompatibleDC = _sig(_gdi32.CreateCompatibleDC, wintypes.HDC, wintypes.HDC)
    _CreateCompatibleBitmap = _sig(_gdi32.CreateCompatibleBitmap, wintypes.HBITMAP, wintypes.HDC, ctypes.c_int, ctypes.c_int)
    _SelectObject = _sig(_gdi32.SelectObject, HGDIOBJ, wintypes.HDC, HGDIOBJ)
    _DeleteObject = _sig(_gdi32.DeleteObject, wintypes.BOOL, HGDIOBJ)
    _DeleteDC = _sig(_gdi32.DeleteDC, wintypes.BOOL, wintypes.HDC)
    _BitBlt = _sig(_gdi32.BitBlt, wintypes.BOOL, wintypes.HDC, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                   wintypes.HDC, ctypes.c_int, ctypes.c_int, wintypes.DWORD)
    _GetDIBits = _sig(_gdi32.GetDIBits, ctypes.c_int, wintypes.HDC, wintypes.HBITMAP, wintypes.UINT, wintypes.UINT,
                      ctypes.c_void_p, ctypes.POINTER(BITMAPINFO), wintypes.UINT)
    _OpenClipboard = _sig(_user32.OpenClipboard, wintypes.BOOL, wintypes.HWND)
    _CloseClipboard = _sig(_user32.CloseClipboard, wintypes.BOOL)
    _EmptyClipboard = _sig(_user32.EmptyClipboard, wintypes.BOOL)
    _SetClipboardData = _sig(_user32.SetClipboardData, wintypes.HANDLE, wintypes.UINT, wintypes.HANDLE)
    _RegisterClipboardFormatW = _sig(_user32.RegisterClipboardFormatW, wintypes.UINT, wintypes.LPCWSTR)
    _GlobalAlloc = _sig(_kernel32.GlobalAlloc, wintypes.HGLOBAL, wintypes.UINT, ctypes.c_size_t)
    _GlobalLock = _sig(_kernel32.GlobalLock, wintypes.LPVOID, wintypes.HGLOBAL)
    _GlobalUnlock = _sig(_kernel32.GlobalUnlock, wintypes.BOOL, wintypes.HGLOBAL)
    _GlobalFree = _sig(_kernel32.GlobalFree, wintypes.HGLOBAL, wintypes.HGLOBAL)

    GA_ROOT = 2
    PW_RENDERFULLCONTENT = 2
    SRCCOPY = 0x00CC0020
    DIB_RGB_COLORS = 0
    BI_RGB = 0
    CF_DIB = 8
    GMEM_MOVEABLE = 0x0002

    def _grab_hdc(src_dc, w, h, draw):
        """Creates a bitmap, calls draw(mem_dc), returns top-down RGB rows."""
        mem = _CreateCompatibleDC(src_dc)
        bmp = _CreateCompatibleBitmap(src_dc, w, h)
        old = _SelectObject(mem, bmp)
        try:
            if not draw(mem):
                return None
            bi = BITMAPINFO()
            bi.bmiHeader.biSize = ctypes.sizeof(BITMAPINFOHEADER)
            bi.bmiHeader.biWidth = w
            bi.bmiHeader.biHeight = -h  # top-down
            bi.bmiHeader.biPlanes = 1
            bi.bmiHeader.biBitCount = 32
            bi.bmiHeader.biCompression = BI_RGB
            buf = ctypes.create_string_buffer(w * h * 4)
            _SelectObject(mem, old)
            old = None
            if _GetDIBits(mem, bmp, 0, h, buf, ctypes.byref(bi), DIB_RGB_COLORS) != h:
                return None
            data = buf.raw
            rows = []
            for y in range(h):
                line = data[y * w * 4:(y + 1) * w * 4]
                rgb = bytearray(w * 3)
                rgb[0::3] = line[2::4]
                rgb[1::3] = line[1::4]
                rgb[2::3] = line[0::4]
                rows.append(bytes(rgb))
            return rows
        finally:
            if old is not None:
                _SelectObject(mem, old)
            _DeleteObject(bmp)
            _DeleteDC(mem)

    def _capture_windows(widget):
        widget.update_idletasks()
        hwnd = wintypes.HWND(widget.winfo_id())
        top = _GetAncestor(hwnd, GA_ROOT) or _GetParent(hwnd) or hwnd
        wrect = wintypes.RECT()
        _GetWindowRect(top, ctypes.byref(wrect))
        tw, th = wrect.right - wrect.left, wrect.bottom - wrect.top
        if tw <= 0 or th <= 0:
            return None
        sdc = _GetDC(None)
        try:
            rows = _grab_hdc(sdc, tw, th, lambda mem: bool(_PrintWindow(top, mem, PW_RENDERFULLCONTENT)))
            # widget position inside the whole window (window rect includes the frame)
            wr = wintypes.RECT()
            _GetWindowRect(hwnd, ctypes.byref(wr))
            x, y = wr.left - wrect.left, wr.top - wrect.top
            w, h = wr.right - wr.left, wr.bottom - wr.top
            if rows:
                got = _crop(tw, th, rows, x, y, w, h)
                if got and any(any(r) for r in got[2][::max(1, len(got[2]) // 8)]):
                    return got
            # PrintWindow can come back black (e.g. some GPU setups): copy from the screen instead
            rows = _grab_hdc(sdc, w, h, lambda mem: bool(_BitBlt(mem, 0, 0, w, h, sdc, wr.left, wr.top, SRCCOPY)))
            return (w, h, rows) if rows else None
        finally:
            _ReleaseDC(None, sdc)

    def _set_clip(fmt, data):
        h = _GlobalAlloc(GMEM_MOVEABLE, len(data))
        if not h:
            return False
        p = _GlobalLock(h)
        if not p:
            _GlobalFree(h)
            return False
        ctypes.memmove(p, data, len(data))
        _GlobalUnlock(h)
        if not _SetClipboardData(fmt, h):
            _GlobalFree(h)  # ownership only passes to the system on success
            return False
        return True


def dib_bytes(width, height, rows):
    """CF_DIB payload: BITMAPINFOHEADER + 24-bit bottom-up BGR with 4-byte row padding."""
    header = struct.pack('<IiiHHIIiiII', 40, width, height, 1, 24, 0, 0, 2835, 2835, 0, 0)
    pad = (4 - (width * 3) % 4) % 4
    out = bytearray(header)
    for r in reversed(rows[:height]):
        line = bytearray(width * 3)
        line[0::3] = r[2:width * 3:3]
        line[1::3] = r[1:width * 3:3]
        line[2::3] = r[0:width * 3:3]
        out += line + b'\x00' * pad
    return bytes(out)


def capture_widget(widget):
    """Pixels of a widget as shown on screen: (width, height, rows) or None."""
    try:
        if IS_WINDOWS:
            return _capture_windows(widget)
        return _capture_x11(widget)
    except Exception:
        return None


# ---------------------------------------------------------------- clipboard

def copy_image_to_clipboard(width, height, rows, png_bytes=None):
    if not IS_WINDOWS:
        return False
    try:
        dib = dib_bytes(width, height, rows)
        png = png_bytes or encode_png(width, height, rows)
        for _ in range(10):  # another program may hold the clipboard for a moment
            if _OpenClipboard(None):
                break
            import time
            time.sleep(0.05)
        else:
            return False
        try:
            _EmptyClipboard()
            ok = _set_clip(CF_DIB, dib)
            fmt = _RegisterClipboardFormatW('PNG')
            if fmt:
                _set_clip(fmt, png)
            return bool(ok)
        finally:
            _CloseClipboard()
    except Exception:
        return False


def copy_text_to_clipboard(root, text):
    try:
        root.clipboard_clear()
        root.clipboard_append(text)
        root.update()
        return True
    except Exception:
        return False


# ---------------------------------------------------------------- files

_BAD = re.compile(r'[<>:"/\\|?*\x00-\x1f]')
_RESERVED = {'CON', 'PRN', 'AUX', 'NUL'} | {f'COM{i}' for i in range(1, 10)} | {f'LPT{i}' for i in range(1, 10)}


def safe_filename(s):
    s = _BAD.sub(' ', str(s))
    s = re.sub(r'\s+', ' ', s).strip().rstrip('. ')
    if not s:
        s = 'report'
    if s.split('.')[0].upper() in _RESERVED:
        s = '_' + s
    return s[:120].rstrip('. ')


def write_csv(path, header, rows):
    with open(path, 'w', encoding='utf-8-sig', newline='') as fh:
        w = csv.writer(fh)
        w.writerow([_plain(c) for c in header])
        for r in rows:
            w.writerow([_plain(c) for c in r])
    return path


def _plain(c):
    if isinstance(c, dict):
        return c.get('text', '')
    return '' if c is None else c


def _col_letter(i):
    s = ''
    i += 1
    while i:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s


_XML_BAD = re.compile('[\x00-\x08\x0b\x0c\x0e-\x1f]')


def _x(s):
    return xml_escape(_XML_BAD.sub('', str(s)), {'"': '&quot;'})


def _sheet_names(names):
    out, seen = [], set()
    for n in names:
        n = re.sub(r'\s+', ' ', re.sub(r'[\[\]:*?/\\]', ' ', str(n))).strip().strip("'")[:31].strip() or 'Sheet'
        base, k = n, 2
        while n.lower() in seen:
            suf = f' ({k})'
            n = base[:31 - len(suf)] + suf
            k += 1
        seen.add(n.lower())
        out.append(n)
    return out


def write_xlsx(path, sheets):
    """sheets: list of (name, header, rows). Numbers stay numbers; header is bold; top row frozen."""
    names = _sheet_names([s[0] for s in sheets])
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml',
                   '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                   '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
                   '<Default Extension="xml" ContentType="application/xml"/>'
                   '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
                   '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
                   + ''.join(f'<Override PartName="/xl/worksheets/sheet{i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' for i in range(len(sheets)))
                   + '</Types>')
        z.writestr('_rels/.rels',
                   '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
                   '</Relationships>')
        z.writestr('xl/workbook.xml',
                   '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>'
                   + ''.join(f'<sheet name="{_x(n)}" sheetId="{i + 1}" r:id="rId{i + 1}"/>' for i, n in enumerate(names))
                   + '</sheets></workbook>')
        z.writestr('xl/_rels/workbook.xml.rels',
                   '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   + ''.join(f'<Relationship Id="rId{i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{i + 1}.xml"/>' for i in range(len(sheets)))
                   + f'<Relationship Id="rId{len(sheets) + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
                   '</Relationships>')
        z.writestr('xl/styles.xml',
                   '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
                   '<fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts>'
                   '<fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>'
                   '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
                   '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
                   '<cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
                   '<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/></cellXfs>'
                   '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
                   '</styleSheet>')
        for i, (_, header, rows) in enumerate(sheets):
            all_rows = [list(header)] + [list(r) for r in rows]
            ncols = max((len(r) for r in all_rows), default=1)
            widths = [8] * ncols
            out = []
            for ri, row in enumerate(all_rows):
                cells = []
                for ci, c in enumerate(row):
                    v = _plain(c)
                    ref = f'{_col_letter(ci)}{ri + 1}'
                    style = ' s="1"' if ri == 0 else ''
                    if isinstance(v, bool):
                        v = str(v)
                    if isinstance(v, (int, float)) and v == v and v not in (float('inf'), float('-inf')):
                        cells.append(f'<c r="{ref}"{style}><v>{v!r}</v></c>' if isinstance(v, float) else f'<c r="{ref}"{style}><v>{v}</v></c>')
                        widths[ci] = max(widths[ci], len(f'{v:,}' if isinstance(v, int) else f'{v:.2f}') + 2)
                    else:
                        s = str(v)
                        cells.append(f'<c r="{ref}"{style} t="inlineStr"><is><t xml:space="preserve">{_x(s)}</t></is></c>')
                        widths[ci] = max(widths[ci], min(60, len(s) + 2))
                out.append(f'<row r="{ri + 1}">' + ''.join(cells) + '</row>')
            cols = ''.join(f'<col min="{ci + 1}" max="{ci + 1}" width="{w}" customWidth="1"/>' for ci, w in enumerate(widths))
            z.writestr(f'xl/worksheets/sheet{i + 1}.xml',
                       '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                       '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
                       '<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>'
                       f'<cols>{cols}</cols><sheetData>' + ''.join(out) + '</sheetData></worksheet>')
    return path


# ---------------------------------------------------------------- HTML report

_CSS = '''
:root{--bg:#12111c;--surface:#191827;--surface2:#211f33;--line:#2c2a44;--text:#e9e7f5;--muted:#9895b4;--faint:#6f6c8c;
--arcane:#a593ff;--kill:#4fc790;--wipe:#ec5b72;--kill-soft:rgba(79,199,144,.16);--wipe-soft:rgba(236,91,114,.16);color-scheme:dark}
@media (prefers-color-scheme: light){:root{--bg:#f5f4fa;--surface:#fff;--surface2:#f0eef8;--line:#e1def0;--text:#1d1b2f;--muted:#66637f;
--faint:#9a97b2;--arcane:#6b57e3;--kill:#1c9a60;--wipe:#d23a54;--kill-soft:rgba(28,154,96,.12);--wipe-soft:rgba(210,58,84,.10);color-scheme:light}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font:14px/1.5 "Segoe UI Variable Text","Segoe UI",system-ui,sans-serif;
font-variant-numeric:tabular-nums}main{max-width:1100px;margin:0 auto;padding:32px 24px 60px}
h1{font-size:28px;margin:0 0 4px;letter-spacing:-.01em}.sub{color:var(--muted);margin:0 0 24px}.gen{color:var(--faint);font-size:12px;margin-top:30px}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:1px;background:var(--line);border:1px solid var(--line);
border-radius:12px;overflow:hidden;margin-bottom:24px}.stat{background:var(--surface);padding:14px 16px}.stat .v{font-size:22px;font-weight:650}
.stat .l{color:var(--muted);font-size:12.5px}.kill{color:var(--kill)}.wipe{color:var(--wipe)}
section{background:var(--surface);border:1px solid var(--line);border-radius:12px;padding:16px 18px;margin-bottom:20px;break-inside:avoid}
h2{font-size:16px;margin:0 0 10px}table{width:100%;border-collapse:collapse}th{font-size:12.5px;color:var(--muted);text-align:left;font-weight:600;
padding:7px 10px;border-bottom:1px solid var(--line)}td{padding:7px 10px;border-bottom:1px solid var(--surface2)}tr:last-child td{border-bottom:0}
.r{text-align:right}.note{color:var(--faint);font-size:12.5px;margin:10px 0 0}ul{margin:0;padding-left:20px}li{margin:3px 0}
.boss{display:grid;grid-template-columns:minmax(140px,220px) 1fr auto;gap:14px;align-items:center;padding:8px 0;border-top:1px solid var(--surface2)}
.boss:first-of-type{border-top:0}.pips{display:flex;gap:6px;flex-wrap:wrap}.pip{position:relative;width:46px;height:26px;border-radius:7px;
display:inline-grid;place-items:center;font-size:11px;font-weight:700;overflow:hidden}.pip.k{background:var(--kill);color:#fff}
.pip.w{background:var(--wipe-soft);color:var(--wipe)}.pip.w i{position:absolute;left:0;top:0;bottom:0;background:var(--wipe);opacity:.28}
.pip span{position:relative}.bn{font-weight:600}.bt{color:var(--muted);font-size:13px;text-align:right}.text{white-space:pre-wrap}
@media print{body{background:#fff;color:#000}section,.stat{background:#fff}}
'''


def _cell(c):
    if isinstance(c, dict):
        text = html.escape(str(c.get('text', '')))
        style = ''
        if c.get('color') and re.fullmatch(r'#[0-9a-fA-F]{3,8}', str(c['color'])):
            style += f'color:{c["color"]};'
        if c.get('bold'):
            style += 'font-weight:600;'
        return f'<span style="{style}">{text}</span>' if style else text
    if isinstance(c, float):
        return html.escape(f'{c:,.1f}')
    if isinstance(c, int) and not isinstance(c, bool):
        return html.escape(f'{c:,}')
    return html.escape('' if c is None else str(c))


def render_html(doc):
    e = html.escape
    out = ['<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">',
           f'<title>{e(str(doc.get("title", "Leyline report")))}</title><style>{_CSS}</style></head><body><main>',
           f'<h1>{e(str(doc.get("title", "")))}</h1>']
    if doc.get('subtitle'):
        out.append(f'<p class="sub">{e(str(doc["subtitle"]))}</p>')
    stats = doc.get('stats') or []
    if stats:
        out.append('<div class="stats">')
        for s in stats:
            tone = s.get('tone') if s.get('tone') in ('kill', 'wipe') else ''
            out.append(f'<div class="stat"><div class="v {tone}">{e(str(s.get("value", "")))}</div><div class="l">{e(str(s.get("label", "")))}</div></div>')
        out.append('</div>')
    for sec in doc.get('sections') or []:
        out.append('<section>')
        if sec.get('title'):
            out.append(f'<h2>{e(str(sec["title"]))}</h2>')
        kind = sec.get('kind')
        if kind == 'table':
            cols = sec.get('columns') or []
            out.append('<table><thead><tr>' + ''.join(
                f'<th class="{"r" if c.get("align") == "right" else ""}">{e(str(c.get("label", "")))}</th>' for c in cols) + '</tr></thead><tbody>')
            for row in sec.get('rows') or []:
                out.append('<tr>' + ''.join(
                    f'<td class="{"r" if i < len(cols) and cols[i].get("align") == "right" else ""}">{_cell(c)}</td>' for i, c in enumerate(row)) + '</tr>')
            out.append('</tbody></table>')
            if sec.get('note'):
                out.append(f'<p class="note">{e(str(sec["note"]))}</p>')
        elif kind == 'list':
            out.append('<ul>' + ''.join(f'<li>{_cell(i)}</li>' for i in sec.get('items') or []) + '</ul>')
        elif kind == 'text':
            out.append(f'<div class="text">{e(str(sec.get("text", "")))}</div>')
        elif kind == 'bosses':
            for b in sec.get('bosses') or []:
                pips = []
                for a in b.get('attempts') or []:
                    d = e(str(a.get('duration', '')))
                    if a.get('kill'):
                        pips.append(f'<span class="pip k" title="Kill {d}"><span>&#10003;</span></span>')
                    else:
                        hp = a.get('hp')
                        pct = f'{round(hp * 100)}%' if isinstance(hp, (int, float)) else '&#10005;'
                        width = round(max(0, min(1, hp)) * 100) if isinstance(hp, (int, float)) else 100
                        pips.append(f'<span class="pip w" title="Wipe {d}"><i style="width:{width}%"></i><span>{pct}</span></span>')
                out.append(f'<div class="boss"><span class="bn">{e(str(b.get("name", "")))}</span><span class="pips">{"".join(pips)}</span>'
                           f'<span class="bt">{e(str(b.get("note", "")))}</span></div>')
        out.append('</section>')
    out.append(f'<p class="gen">{e(str(doc.get("generated") or "Made with Leyline, " + datetime.now().strftime("%Y-%m-%d %H:%M")))}</p>')
    out.append('</main></body></html>')
    return ''.join(out)


def write_report(folder, base_name, doc, sheets=None, image=None):
    """Writes <base>.html, optional <base>.xlsx + csv/<sheet>.csv, optional <base>.png. Returns {kind: path}."""
    os.makedirs(folder, exist_ok=True)
    base = safe_filename(base_name)
    paths = {}
    p = os.path.join(folder, base + '.html')
    with open(p, 'w', encoding='utf-8') as fh:
        fh.write(render_html(doc))
    paths['html'] = p
    if sheets:
        paths['xlsx'] = write_xlsx(os.path.join(folder, base + '.xlsx'), sheets)
        cdir = os.path.join(folder, 'csv')
        os.makedirs(cdir, exist_ok=True)
        paths['csv'] = []
        for name, (_, header, rows) in zip(_sheet_names([s[0] for s in sheets]), sheets):
            paths['csv'].append(write_csv(os.path.join(cdir, safe_filename(name) + '.csv'), header, rows))
    if image:
        p = os.path.join(folder, base + '.png')
        if isinstance(image, (bytes, bytearray)):  # a finished PNG (the Android app draws its own)
            with open(p, 'wb') as fh:
                fh.write(image)
            paths['png'] = p
        else:
            w, h, rows = image
            paths['png'] = write_png(p, w, h, rows)
    return paths


def open_folder(path):
    try:
        if IS_WINDOWS:
            os.startfile(path)  # noqa
            return True
        for cmd in ('xdg-open', 'open'):
            from shutil import which
            if which(cmd):
                subprocess.Popen([cmd, path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return True
    except Exception:
        pass
    return False
