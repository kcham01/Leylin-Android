# ======================================================================
#  SavedVariables reader: what the Leyline AutoLog addon recorded in game
#  (instance entries, lockouts, rosters, loot, money, boss and PvP results).
#  WoW writes WTF/Account/<ACCOUNT>/SavedVariables/Leyline_AutoLog.lua on logout or /reload.
# ======================================================================

import glob
import logging
import os
import re

SAVED_NAME = 'Leyline_AutoLog.lua'
SAVED_VAR = 'LeylineAutoLogDB'

# one pass over the file: whitespace and '--' comments are skipped, every other token lands in group 1,
# anything unexpected in group 2
_TOKENS = re.compile(r'''\s+|--[^\n]*|("(?:[^"\\]|\\.|\\\n)*"|'(?:[^'\\]|\\.|\\\n)*'|-?(?:0[xX][0-9a-fA-F]+|(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?|inf\b|nan\b)|[A-Za-z_]\w*|[{}\[\]=,;])|(\S)''', re.S)
_BLOCK_COMMENT = re.compile(r'--\[(=*)\[.*?\]\1\]', re.S)

_ESC = {'n': 10, 't': 9, 'r': 13, 'a': 7, 'b': 8, 'f': 12, 'v': 11, '\\': 92, '"': 34, "'": 39, '\n': 10}


def _unescape(body):
    if '\\' not in body:
        return body
    out = bytearray()
    i, n = 0, len(body)
    while i < n:
        c = body[i]
        if c != '\\':
            j = body.find('\\', i)
            if j < 0:
                j = n
            out += body[i:j].encode('utf-8', 'surrogateescape')
            i = j
            continue
        i += 1
        if i >= n:
            break
        c = body[i]
        if c.isdigit():  # \ddd decimal byte
            j = i
            while j < n and j < i + 3 and body[j].isdigit():
                j += 1
            out.append(int(body[i:j]) & 0xFF)
            i = j
        elif c == 'x' and i + 2 < n + 1:
            try:
                out.append(int(body[i + 1:i + 3], 16))
                i += 3
            except ValueError:
                out += b'x'
                i += 1
        elif c == 'z':  # skip following whitespace
            i += 1
            while i < n and body[i].isspace():
                i += 1
        else:
            out.append(_ESC.get(c, ord(c) if ord(c) < 128 else 63))
            i += 1
    return out.decode('utf-8', 'replace')


def _number(s):
    t = s.lower()
    if t.lstrip('-') in ('inf', 'nan'):
        return float(t)
    if 'x' in t:
        return int(t, 16)
    if '.' in t or 'e' in t:
        v = float(t)
        return int(v) if v.is_integer() and abs(v) < 2 ** 53 and 'e' not in t else v
    return int(t)


class _Parser:
    """Recursive-descent parser over a flat token list (strings kept with their quotes)."""

    def __init__(self, text):
        if '--[' in text:
            text = _BLOCK_COMMENT.sub(' ', text)
        toks = []
        self.damaged = None
        for tok, bad in _TOKENS.findall(text):
            if bad:
                # a cut-off string or stray bytes: everything before this point is still good
                self.damaged = bad
                break
            if tok:
                toks.append(tok)
        self.toks = toks
        self.i = 0
        self.truncated = False

    def value(self):
        toks, i = self.toks, self.i
        if i >= len(toks):
            self.truncated = True
            return None
        t = toks[i]
        self.i = i + 1
        c = t[0]
        if c == '{':
            return self.table()
        if c == '"' or c == "'":
            return _unescape(t[1:-1])
        if c.isdigit() or c == '-' or c == '.':
            return _number(t)
        if t == 'true':
            return True
        if t == 'false':
            return False
        if t == 'nil':
            return None
        if t == 'inf' or t == 'nan':
            return float(t)
        raise ValueError(f'unexpected {t!r}')

    def table(self):
        toks = self.toks
        n_toks = len(toks)
        d = {}
        n = 0
        while True:
            i = self.i
            if i >= n_toks:  # file cut off mid-table: keep what we have
                self.truncated = True
                break
            t = toks[i]
            if t == '}':
                self.i = i + 1
                break
            if t == ',' or t == ';':
                self.i = i + 1
                continue
            if t == '[':
                self.i = i + 1
                key = self.value()
                if not self.expect(']') or not self.expect('='):
                    break
                val = self.value()
            elif i + 1 < n_toks and toks[i + 1] == '=' and (t[0].isalpha() or t[0] == '_'):
                key = t
                self.i = i + 2
                val = self.value()
            else:
                n += 1
                key, val = n, self.value()
            if isinstance(key, float) and key.is_integer():
                key = int(key)
            if val is not None:
                d[key] = val
            if self.truncated:
                break
        if d:
            m = len(d)
            if all(type(k) is int for k in d) and min(d) == 1 and max(d) == m:
                return [d[k] for k in range(1, m + 1)]
        return d

    def expect(self, op):
        i = self.i
        if i >= len(self.toks):
            self.truncated = True
            return False
        if self.toks[i] != op:
            raise ValueError(f'expected {op!r}, got {self.toks[i]!r}')
        self.i = i + 1
        return True

    def chunk(self):
        out = {}
        toks = self.toks
        while self.i < len(toks):
            name = toks[self.i]
            if not (name[0].isalpha() or name[0] == '_'):
                raise ValueError(f'expected a variable name, got {name!r}')
            self.i += 1
            if not self.expect('='):
                break
            out[name] = self.value()
            if self.truncated:
                break
        return out


def parse_lua_table(text):
    """Parses a SavedVariables file: one or more `Name = value` assignments. Returns {name: value}.
    Tables whose keys are exactly 1..n become lists, other tables dicts, an empty table {}.
    A file cut off part-way returns everything up to the cut."""
    p = _Parser(text)
    return p.chunk()


def find_saved_files(logs_dir):
    """Leyline_AutoLog.lua for every WoW account, found from the Logs folder (<wow>/_anniversary_/Logs)."""
    roots = []
    for base in (os.path.abspath(logs_dir), os.path.realpath(logs_dir)):
        root = os.path.dirname(base.rstrip('\\/'))
        if root not in roots:
            roots.append(root)
    found = []
    for root in roots:
        pattern = os.path.join(root, 'WTF', 'Account', '*', 'SavedVariables', SAVED_NAME)
        for path in sorted(glob.glob(pattern)):
            if path not in found and os.path.isfile(path):
                found.append(path)
    return found


def load_events(logs_dir, warnings=None):
    """Every recorded event from every account, oldest first. Each is a dict with 'ts' (epoch ms) and
    'account' added. Never raises: unreadable or half-written files are skipped or read up to the damage,
    with a note in `warnings` (a list, if given) and the log."""
    def warn(msg):
        logging.getLogger('leyline').warning(msg)
        if warnings is not None:
            warnings.append(msg)

    events = []
    for path in find_saved_files(logs_dir):
        account = os.path.basename(os.path.dirname(os.path.dirname(path)))
        try:
            with open(path, encoding='utf-8', errors='replace') as fh:
                text = fh.read()
        except OSError as ex:
            warn(f'Could not read {path}: {ex}')
            continue
        try:
            p = _Parser(text)
            data = p.chunk()
            if p.damaged is not None:
                warn(f'{path} has something unreadable in it ({p.damaged!r}); read everything before that point.')
            elif p.truncated:
                warn(f'{path} looks cut off (WoW may still be writing it); read what was there.')
        except Exception as ex:
            warn(f'Could not understand {path}: {ex}')
            continue
        db = data.get(SAVED_VAR)
        if not isinstance(db, dict):
            continue
        raw = db.get('events') or []
        if isinstance(raw, dict):  # a list with gaps comes back as a dict
            raw = [raw[k] for k in sorted(k for k in raw if isinstance(k, int))]
        if (p.truncated or p.damaged is not None) and raw:
            raw = raw[:-1]  # the event WoW was writing when the file was cut off is incomplete
        for ev in raw:
            if isinstance(ev, dict) and isinstance(ev.get('t'), (int, float)) and ev.get('e'):
                ev = dict(ev)
                ev['ts'] = int(ev['t'] * 1000)
                ev['account'] = account
                if isinstance(ev.get('members'), dict):
                    ev['members'] = list(ev['members'].values())
                events.append(ev)
    events.sort(key=lambda e: e['t'])  # stable: same-second events keep their order
    return events
