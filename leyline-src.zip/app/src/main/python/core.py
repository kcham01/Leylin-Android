# ======================================================================
#  Core: everything the screens need that isn't drawing (shared by the PC window and the Android app)
# ======================================================================

import json
import os
import sys
import time
import traceback
from datetime import datetime

from parsers import INSTANCE_BOSSES  # dev
from activities import (CATALOG, plural, Model, KIND_LABEL, KIND_ORDER, discord_week, report_run, sheets_run, report_session,  # dev
                        sheets_session, report_player, sheets_player, gold)  # dev
from items import ITEMS  # dev
from exports import write_png, write_report, open_folder, safe_filename  # dev

PALETTES = {
    'dark': dict(bg='#12111c', surface='#191827', surface2='#211f33', line='#2c2a44', line_soft='#24223a', text='#e9e7f5', muted='#9895b4',
                 faint='#6f6c8c', arcane='#a593ff', kill='#4fc790', wipe='#ec5b72', warn='#e9b44c', bar=.17, on_accent='#ffffff'),
    'light': dict(bg='#f5f4fa', surface='#ffffff', surface2='#f0eef8', line='#e1def0', line_soft='#ebe9f5', text='#1d1b2f', muted='#66637f',
                  faint='#9a97b2', arcane='#6b57e3', kill='#1c9a60', wipe='#d23a54', warn='#b97d0c', bar=.16, on_accent='#ffffff'),
}


CLASS_COLOR = {'WARRIOR': '#C69B6D', 'PALADIN': '#F48CBA', 'HUNTER': '#AAD372', 'ROGUE': '#FFF468', 'PRIEST': '#F2F2F2', 'SHAMAN': '#0070DD',
               'MAGE': '#3FC7EB', 'WARLOCK': '#8788EE', 'DRUID': '#FF7C0A', 'DEATHKNIGHT': '#C41E3A'}


QUALITY = {'dark': ['#9d9d9d', None, '#1eff00', '#2f8fff', '#b048f8', '#ff8000', '#e6cc80'],
           'light': ['#8a8a8a', None, '#12a000', '#0a6fd6', '#8a2be2', '#d96a00', '#a8894a']}


CHANNEL = {'dark': {'raid': '#ff7f00', 'raidwarning': '#ff4709', 'party': '#a8a8ff', 'guild': '#40ff40', 'officer': '#40c040', 'whisper': '#ff80ff', 'yell': '#ff4040',
                    'instance': '#ff7f00', 'channel': '#ffc0c0', 'say': '#e9e7f5', 'system': '#e9d36a'},
           'light': {'raid': '#c25e00', 'raidwarning': '#d43a00', 'party': '#5050d0', 'guild': '#1f8a1f', 'officer': '#1f7a1f', 'whisper': '#b03fb0', 'yell': '#d02020',
                     'instance': '#c25e00', 'channel': '#b3566a', 'say': '#1d1b2f', 'system': '#8a6d00'}}


CHANNEL_SHORT = {'LookingForGroup': 'LFG', 'LocalDefense': 'Defense', 'WorldDefense': 'Defense', 'GuildRecruitment': 'Recruiting',
                 'Raid Warning': 'Warning', 'Raid Leader': 'Raid lead', 'Party Leader': 'Party lead', 'Instance Leader': 'Instance',
                 'Battleground Leader': 'BG lead', 'Battleground': 'BG', 'System': 'System'}


def fmt_bytes(n):
    for unit in ('bytes', 'KB', 'MB', 'GB'):
        if n < 1024 or unit == 'GB':
            return f'{n:,.0f} {unit}' if unit == 'bytes' else f'{n:.1f} {unit}'
        n /= 1024


def mix(a, b, t):
    """Blend colour a over b with opacity t."""
    a, b = a.lstrip('#'), b.lstrip('#')
    ca = [int(a[i:i + 2], 16) for i in (0, 2, 4)]
    cb = [int(b[i:i + 2], 16) for i in (0, 2, 4)]
    return '#' + ''.join(f'{round(x * t + y * (1 - t)):02x}' for x, y in zip(ca, cb))


def fmt_int(n):
    return f'{round(n):,}'


def mins(ms):
    """19m 34s: a length of time that can't be mistaken for a clock time."""
    s = max(0, round(ms / 1000))
    if s >= 3600:
        return f'{s // 3600}h {s % 3600 // 60:02d}m'
    return f'{s // 60}m {s % 60:02d}s' if s >= 60 else f'{s}s'


def day(ts):
    d = datetime.fromtimestamp(ts / 1000)
    return d.strftime('%a, %b ') + str(d.day)


def day_key(ts):
    return datetime.fromtimestamp(ts / 1000).date()


class Settings:
    def __init__(self, path):
        self.path = path
        self.d = {}
        try:
            with open(path, encoding='utf-8') as fh:
                self.d = json.load(fh)
        except Exception:
            pass

    def get(self, k, default):
        return self.d.get(k, default)

    def set(self, k, v):
        self.d[k] = v
        try:
            os.makedirs(os.path.dirname(self.path), exist_ok=True)
            with open(self.path, 'w', encoding='utf-8') as fh:
                json.dump(self.d, fh)
        except Exception:
            pass


class Core:
    """Data for the screens: the indexes built from the logs, summaries, history and reports. The screen class
    (Tk on a PC, the HTML app on Android) provides show_toast() and log_error()."""

    def snapshot(self):
        """Builds the indexes the views read. Call with the watcher lock held.
        Skipped when nothing was read since last time (clicks and redraws reuse what's there)."""
        w = self.w
        key = (tuple(sorted((getattr(w, 'versions', None) or {}).items())), len(w.sources), w.active.path if w.active else None,
               w.chat is not None, ITEMS.ready, self.state, getattr(w, 'version', 0))
        if key == getattr(self, '_snap_key', None) and hasattr(self, 'model'):
            return
        self._snap_key = key
        self._derived = {}
        fights, runs, players = [], [], {}
        for s in w.sources:
            players.update(s['players'])
            fights.extend(s['fights'])
            runs.extend(s['runs'])
        live = None
        if w.active:
            p = w.active.parser
            players.update(p.players)
            fights.extend(p.fights)
            runs.extend(r for r in p.runs if r['fights'])
            live = p.cur
        fights.sort(key=lambda f: f['start'])
        runs.sort(key=lambda r: r['start'])
        self.by_id = {f['id']: f for f in fights}
        if live:
            self.by_id[live['id']] = live
        runs = self.merge_runs(runs)
        self.fights, self.runs, self.players, self.live = fights, runs, players, live
        self.run_by_id = {r['id']: r for r in runs}
        self.cp = w.chat.parser if w.chat else None
        self.addon_events = list(getattr(w, 'addon_events', []) or [])
        ITEMS.learn(self.addon_events)
        classes = dict(self.saved_classes)
        for src in w.sources:
            classes.update(src.get('classes') or {})
        if w.active:
            classes.update(getattr(w.active.parser, 'classes', None) or {})
        for e in self.addon_events:
            if e.get('e') == 'roster':
                for mb in e.get('members') or []:
                    n = (mb.get('n') or '').split('-')[0]
                    if n and mb.get('cls'):
                        classes[n] = mb['cls']
        for p in players.values():
            if p.get('cls'):
                classes[p['name']] = p['cls']
            elif classes.get(p['name']):
                p['cls'] = classes[p['name']]
        self.name_class = classes
        me = next((p['name'] for p in players.values() if p.get('mine')), None)
        self.me = me
        self.model = Model(fights, self.runs, players, self.by_id, self.cp, self.addon_events, me, items=ITEMS)
        self.runs = self.model.runs

    def merge_runs(self, runs):
        """WoW starts a new log file whenever logging is switched back on (a corpse run, a /reload, a crash).
        Runs of the same instance that follow on closely belong together, unless a boss died twice (a new lockout)."""
        merged, self.run_alias, self.attempt = [], {}, {}
        for r in runs:
            m = merged[-1] if merged else None
            pvp = CATALOG.get(r['instance_id'], ('', ''))[1] in ('battleground', 'arena')
            if m and not pvp and m['instance_id'] == r['instance_id'] and r['start'] - m['end'] < 3 * 3600_000 and not (set(m['killed']) & set(r['killed'])):
                m['fights'] = m['fights'] + r['fights']
                m['killed'] = m['killed'] + r['killed']
                m['wipes'] += r['wipes']
                m['end'] = max(m['end'], r['end'])
                self.run_alias[r['id']] = m['id']
            else:
                merged.append(dict(r))  # a copy: the originals belong to the parser and the cache
                self.run_alias[r['id']] = r['id']
        for m in merged:  # attempt numbers count across the whole merged run
            seen = {}
            for fid in sorted(m['fights'], key=lambda i: self.by_id[i]['start'] if i in self.by_id else 0):
                f = self.by_id.get(fid)
                if f and f['kind'] == 'boss':
                    seen[f.get('encounter_id')] = seen.get(f.get('encounter_id'), 0) + 1
                    self.attempt[fid] = seen[f.get('encounter_id')]
        return merged

    def run_of(self, f):
        rid = f.get('run_id')
        return self.run_by_id.get(self.run_alias.get(rid, rid)) if rid else None

    def player(self, guid):
        return self.players.get(guid) or {'name': '?', 'cls': None}

    def bosses_of(self, run):
        info = INSTANCE_BOSSES.get(run['instance_id'])
        fights = [self.by_id[i] for i in run['fights'] if i in self.by_id]
        order, seen = [], {}
        if info:
            for bid, name in info[1]:
                b = {'id': bid, 'name': name, 'attempts': []}
                order.append(b)
                seen[bid] = b
        for f in fights:
            if f['kind'] != 'boss':
                continue
            b = seen.get(f.get('encounter_id'))
            if b is None:
                b = {'id': f.get('encounter_id'), 'name': f['name'], 'attempts': []}
                order.append(b)
                seen[f.get('encounter_id')] = b
            b['attempts'].append(f)
            if f['name']:
                b['name'] = f['name']
        return order, (len(info[1]) if info else 0), fights

    def save_names(self):
        """Keeps the classes of everyone seen, so names stay coloured after old logs are deleted."""
        if len(self.name_class) <= self.saved_classes_n:
            return
        keep = dict(list(self.name_class.items())[-20000:])
        try:
            os.makedirs(self.data_dir, exist_ok=True)
            tmp = self.names_file + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as fh:
                json.dump({'v': 2, 'names': keep}, fh, ensure_ascii=False)
            os.replace(tmp, self.names_file)
            self.saved_classes = keep
            self.saved_classes_n = len(keep)
        except Exception:
            pass

    def watch_words(self):
        return [w.strip().lower() for w in self.watch if w.strip()]

    def watch_matches(self):
        """Messages mentioning a watched word. Only new messages are checked each time."""
        cp = self.w.chat.parser if self.w.chat else None
        words = self.watch_words()
        if not cp or not words:
            return []
        key = (id(cp), tuple(words))
        if key != getattr(self, '_watch_key', None) or len(cp.messages) < getattr(self, '_watch_pos', 0):
            self._watch_key, self._watch_pos, self._watch_hits = key, 0, []
        msgs = cp.messages
        for m in msgs[self._watch_pos:]:
            if m['ch'] != 'system':
                t = m['text'].lower()
                if any(w in t for w in words):
                    self._watch_hits.append(m)
        self._watch_pos = len(msgs)
        return self._watch_hits

    def fight_badge(self, f):
        if f.get('live'):
            return 'live', 'In combat'
        if f['kind'] == 'trash':
            return 'trash', 'Trash'
        if f['success']:
            return 'kill', 'Kill'
        hp = f.get('boss_hp')
        return 'wipe', 'Wipe' + (f' at {round(hp * 100)}%' if hp is not None else '')

    def list_dir(self, d):
        try:
            return os.listdir(d)
        except OSError:
            return []

    def scope_for(self, r):
        return self.run_scope if r.get('kind') in ('raid', 'dungeon') else 'all'  # PvP has no boss fights

    def activity_items(self):
        """Progress lines from the chat log: honor, reputation, experience, quests, resets, levels, achievements."""
        cp = self.cp if hasattr(self, 'cp') else None
        if not cp:
            return []
        key = (id(cp), (getattr(self.w, 'versions', None) or {}).get('chat'), len(cp.messages))
        if getattr(self, '_act_key', None) == key:
            return self._act_items
        out = []
        for e in getattr(cp, 'honor', []):
            out.append((e['ts'], 'Honor', f"+{e['amount']:,} honor" + (f" ({e['target']})" if e.get('target') else ''), 'warn'))
        for e in getattr(cp, 'reputation', []):
            out.append((e['ts'], 'Reputation', f"{'+' if e.get('up', True) else '−'}{e['amount']:,} {e['faction']}", 'kill' if e.get('up', True) else 'wipe'))
        for e in getattr(cp, 'xp', []):
            out.append((e['ts'], 'Experience', f"+{e['amount']:,} experience" + (f" from {e['target']}" if e.get('target') else ''), None))
        for e in getattr(cp, 'quests', []):
            out.append((e['ts'], 'Quest', ('Completed ' if e.get('done') else 'Accepted ') + e['quest'], 'kill' if e.get('done') else None))
        for e in getattr(cp, 'resets', []):
            out.append((e['ts'], 'Reset', f"{e['instance']} reset" + ('' if e.get('ok', True) else ' failed'), None))
        for e in getattr(cp, 'levels', []):
            out.append((e['ts'], 'Level up', f"Reached level {e['level']}", 'kill'))
        for e in getattr(cp, 'achievements', []):
            out.append((e['ts'], 'Achievement', f"{e.get('who', '')} earned {e.get('what', '')}".strip(), 'kill'))
        for e in getattr(cp, 'skills', []):
            out.append((e['ts'], 'Skill', f"{e['skill']} {e['level']}", None))
        for e in getattr(cp, 'currency', []):
            out.append((e['ts'], 'Currency', f"+{e['count']} {e['item']['name']}", 'warn'))
        for e in getattr(cp, 'discovered', []):
            out.append((e['ts'], 'Discovered', e['zone'], None))
        out.sort(key=lambda x: x[0])
        self._act_key, self._act_items = key, out
        return out

    def where_was(self, ts):
        """The instance someone was in at that moment (from the combat log), if any."""
        for r in reversed(self.runs):
            if r['start'] - 60000 <= ts <= r['end'] + 300000:
                return r['name']
        return ''

    def documents_dir(self):
        if self.phone:  # the shared Documents folder other apps can see, not Python's private home
            for d in ('/storage/emulated/0/Documents', '/sdcard/Documents'):
                if os.path.isdir(d):
                    return d
        try:
            import ctypes
            from ctypes import wintypes
            buf = ctypes.create_unicode_buffer(wintypes.MAX_PATH)
            if ctypes.windll.shell32.SHGetFolderPathW(None, 5, None, 0, buf) == 0 and buf.value:  # 5 = My Documents
                return buf.value
        except Exception:
            pass
        return os.path.join(os.path.expanduser('~'), 'Documents')

    def kind_mark(self, kind):
        return {'raid': 'kill', 'dungeon': 'kill', 'battleground': 'trash', 'arena': 'trash'}.get(kind, 'trash')

    def run_line(self, r):
        sm = self.model.run_summary_cached(r)
        bits = [day(r['start'])]
        if sm['kind'] in ('raid', 'dungeon'):
            if sm.get('holiday') and not sm['kills']:
                bits += [f"{n} ×{c}" if c > 1 else n for n, c in sm['holiday']]
            else:
                bits.append(f"{sm['kills']}/{sm['known_bosses']} bosses" if sm['known_bosses'] else plural(sm['kills'], 'boss').replace('bosss', 'bosses'))
            if sm['wipes']:
                bits.append(plural(sm['wipes'], 'wipe'))
        else:
            bits.append(KIND_LABEL.get(sm['kind'], ''))
            if sm.get('result'):
                bits.append('Win' if sm['result'] == 'win' else 'Loss')
        return sm, ' · '.join(bits)

    def session_line(self, s):
        ss = self.model.session_summary(s)
        parts = []
        for kind in KIND_ORDER:
            runs = ss['by_kind'].get(kind, [])
            if not runs:
                continue
            if kind == 'raid':
                parts += [r['name'] for r in runs]
            else:
                parts.append(f"{len(runs)} {KIND_LABEL[kind].lower()}{'s' if len(runs) > 1 else ''}")
        if ss['money_in'] >= 10000:
            parts.append(gold(ss['money_in']))
        return ss, ', '.join(parts) or 'Out in the world'

    def summary_for(self, kind, obj):
        if kind == 'run':
            return self.model.run_summary(obj, self.scope_for(obj))
        if kind == 'player':
            r, guid = obj
            return self.model.player_summary(r, guid, self.scope_for(r))
        if kind == 'week':
            return dict(obj, top=self.model.week_top(obj['start']))
        return self.model.session_summary(obj)

    def report_folder(self, kind, sm):
        when = datetime.fromtimestamp(sm['start'] / 1000)
        if kind == 'week':
            return os.path.join(self.report_dir, safe_filename(f"{when:%Y-%m-%d} Week")), 'Week recap'
        if kind == 'player':
            run = sm['run_summary']['name']
            return (os.path.join(self.report_dir, safe_filename(f"{when:%Y-%m-%d %H%M} {run}")),
                    safe_filename(f"{run} - {sm['name']}"))
        name = sm['name'] if kind == 'run' else 'Session'
        return os.path.join(self.report_dir, safe_filename(f"{when:%Y-%m-%d %H%M} {name}")), safe_filename(name)

    def save_report(self, kind, obj, open_after=False, quiet=False, image=None):
        try:
            sm = self.summary_for(kind, obj)
            folder, base = self.report_folder(kind, sm)
            if sm is None:
                raise ValueError('nothing to save')
            if kind == 'run':
                doc = report_run(sm, self.class_color_report, self.quality_color_report)
                sheets = sheets_run(sm)
            elif kind == 'player':
                doc = report_player(sm, self.class_color_report, self.quality_color_report)
                sheets = sheets_player(sm)
            elif kind == 'week':
                # a week is the recap text and its picture
                os.makedirs(folder, exist_ok=True)
                with open(os.path.join(folder, base + '.txt'), 'w', encoding='utf-8') as fh:
                    fh.write(discord_week(sm, sm['top']) + '\n')
                if image:
                    if isinstance(image, (bytes, bytearray)):
                        with open(os.path.join(folder, base + '.png'), 'wb') as fh:
                            fh.write(image)
                    else:
                        write_png(os.path.join(folder, base + '.png'), *image)
                if open_after:
                    open_folder(folder)
                if not quiet:
                    self.show_toast(f'Saved to {folder}')
                return folder
            else:
                doc = report_session(sm, self.quality_color_report)
                sheets = sheets_session(sm)
            write_report(folder, base, doc, sheets, image=image)
            if open_after:
                open_folder(folder)
            if not quiet:
                self.show_toast(f'Report saved to {folder}')
            return folder
        except Exception:
            self.log_error(traceback.format_exc())
            if not quiet:
                self.show_toast('Couldn’t save the report. Details are in errors.log.')
            return None

    def class_color_report(self, cls):
        return CLASS_COLOR.get(cls)

    @staticmethod
    def quality_color_report(q):
        return QUALITY['dark'][q] if q is not None and 0 <= q < 7 else None

    def auto_export(self):
        """Saves a report for each finished instance session (run), once, without being asked."""
        if not self.auto_save or self.state != 'ready' or not hasattr(self, 'model'):
            return
        now = time.time() * 1000
        baseline = self.cfg.get('export_baseline', None)
        if baseline is None:  # first start: don't flood the folder with every old log
            self.cfg.set('export_baseline', now)
            return
        done = set(self.cfg.get('exported', []))
        new = []
        live_run = self.live.get('run_id') if self.live else None
        loot_seen = dict(self.cfg.get('exported_loot', {}))
        updated = 0
        for r in self.model.runs:
            key = 'run:' + r['id']
            if r['end'] < baseline or now - r['end'] < 20 * 60_000 or r['id'] == live_run:
                continue
            n = len(self.model.loot_of_run(r))
            if key in done:
                # WoW may only write the chat log when you log out: when a run's loot turns up later, save its report again
                if n > loot_seen.get(key, 0) and now - r['end'] < 3 * 86400_000 and self.save_report('run', r, quiet=True):
                    loot_seen[key] = n
                    updated += 1
                continue
            if self.save_report('run', r, quiet=True):
                new.append(key)
                loot_seen[key] = n
        if new or updated:
            self.cfg.set('exported', (list(done) + new)[-2000:])
            self.cfg.set('exported_loot', dict(list(loot_seen.items())[-500:]))
            what = [f"saved {len(new)} report{'s' if len(new) > 1 else ''}"] if new else []
            if updated:
                what.append(f"added loot to {updated} saved report{'s' if updated > 1 else ''}")
            self.show_toast(f"{' and '.join(what).capitalize()} in {self.report_dir}")

    def script_dir(self):
        p = sys.argv[0] if sys.argv and sys.argv[0] else ''
        return os.path.dirname(os.path.abspath(p)) if p and os.path.isfile(p) else os.getcwd()
