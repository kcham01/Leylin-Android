// Taps through every page and control and checks each one did what it should.
// Used two ways: in a phone-sized Chromium against devserver.py, and inside the real app on an Android emulator.
// page: a Playwright page; shot(name): saves a screenshot; opts.browse: how to reach the logs folder in the file browser.

async function run(page, shot, opts = {}) {
  const results = [];
  const log = (...a) => console.log(...a);
  const wait = ms => page.waitForTimeout(ms);
  const tapSel = async sel => {
    const el = page.locator(sel).first();
    await el.scrollIntoViewIfNeeded({ timeout: 10000 });
    if (opts.tap) return opts.tap(el);
    await el.tap({ timeout: 10000 });
  };
  const back = async () => { if (opts.back) await opts.back(); else await page.evaluate(() => window.Leyline.back() || history.back()); };
  const external = async name => (opts.external ? opts.external(name) : false);
  const api = (name, args = {}) => page.evaluate(([n, a]) => call(n, a), [name, args]);
  const tapText = async (text, within = '#main') => tapSel(`${within} :text-is("${text.replace(/"/g, '\\"')}")`);
  const mainText = () => page.evaluate(() => document.querySelector('#main').innerText);
  const h1 = () => page.evaluate(() => (document.querySelector('#main h1') || {}).textContent || '');
  const nativeLog = () => page.evaluate(() => window.__nativeLog.slice());
  const step = async (name, act, check, pic) => {
    let ok = false, err = '';
    try {
      await act();
      for (let i = 0; i < 40; i++) {      // up to 8 s for the page to settle
        await wait(200);
        try { if (await check()) { ok = true; break; } } catch (e) { err = String(e).slice(0, 200); }
      }
    } catch (e) { err = String(e).slice(0, 300); }
    results.push([name, ok, err]);
    log((ok ? 'PASS ' : 'FAIL ') + name + (ok ? '' : '  ' + err));
    if (pic) await shot(pic);
  };

  // ready
  await page.waitForFunction(() => window.Leyline && document.querySelector('#main h1') && !/Reading your logs/.test(document.querySelector('#main').innerText), null, { timeout: 240000 });
  await wait(1000);
  await shot('00-start');
  const runName = await h1();
  results.push(['Opens on the latest run', !!runName, runName]);
  log('PASS Opens on the latest run: ' + runName);

  // menu and filters
  await step('Menu opens', () => tapSel('[data-act=menu]'), () => page.evaluate(() => document.querySelector('#menu').classList.contains('open') && document.querySelectorAll('#menu .navitem').length > 2), 'menu');
  await step('Menu: Raids filter', () => tapSel('#menu [data-act=filter][data-k=raid]'), () => page.evaluate(() => [...document.querySelectorAll('#menu .navitem .t')].map(e => e.textContent).every(t => /Lair|Karazhan|History|Settings|Magtheridon|Serpentshrine|Tempest|Hyjal|Black Temple|Sunwell|Zul/.test(t))));
  await step('Menu: All', () => tapSel('#menu [data-act=filter][data-k=all]'), () => page.evaluate(() => document.querySelectorAll('#menu .navitem').length > 5));
  const nav = await api('nav', { filter: 'raid' });
  let raid = null;
  for (const r of nav.runs) { const d = await api('run', { id: r.id }); if (d.death_total && d.loot.length) { raid = d; break; } }
  raid = raid || await api('run', { id: nav.runs[0].id });
  const RN = raid.name;
  log('Testing with run: ' + RN + ' (' + raid.id + ')');
  await step('Menu: open ' + RN, () => tapSel(`#menu .navitem[data-go="#/run/${encodeURIComponent(raid.id)}"]`), async () => (await h1()) === RN && (await page.evaluate(() => location.hash)).includes(encodeURIComponent(raid.id)) && !(await page.evaluate(() => document.querySelector('#menu').classList.contains('open'))), 'run');

  // run page
  await step('Run: Everything scope', () => tapSel('[data-act=scope][data-k=all]'), () => page.evaluate(() => document.querySelector('[data-act=scope][data-k=all]').classList.contains('on')));
  await step('Run: Boss fights scope', () => tapSel('[data-act=scope][data-k=boss]'), () => page.evaluate(() => document.querySelector('[data-act=scope][data-k=boss]').classList.contains('on')));
  await step('Run: Copy summary', () => tapSel('[data-act=copy]'), async () => (await nativeLog()).some(e => e[0] === 'copy' && e[1].startsWith('**' + RN)));
  await step('Run: Share image opens the picture', () => tapSel('[data-act=card]'), () => page.evaluate(() => { const i = document.querySelector('.overlay img'); return i && i.naturalWidth > 1000; }), 'share-image');
  await step('Share sheet called', () => tapSel('[data-act=sharecard]'), async () => (await nativeLog()).some(e => e[0] === 'shareImage'));
  if (opts.external) { const opened = await external('share-sheet'); results.push(['Android share sheet opened', opened, '']); log((opened ? 'PASS' : 'FAIL') + ' Android share sheet opened'); }
  await step('Picture saved with report', () => tapSel('[data-act=savecard]'), () => page.evaluate(() => /Saved with the report/.test(document.querySelector('#toast').textContent)));
  await step('Picture closes', () => tapSel('.overlay [data-act=close]'), () => page.evaluate(() => !document.querySelector('.overlay')));
  await step('Run: Save report', () => tapSel('[data-act=save]'), () => page.evaluate(() => /Report saved/.test(document.querySelector('#toast').textContent)));
  await step('Run: tap a boss kill box', () => tapSel('.pull.k'), async () => (await page.evaluate(() => location.hash)).startsWith('#/fight/'), 'fight');
  await step('Fight: Healing tab', () => tapSel('[data-act=meter][data-k=healing]'), () => page.evaluate(() => document.querySelector('[data-act=meter][data-k=healing]').classList.contains('on') && document.querySelectorAll('.mrow').length > 0));
  await step('Fight: open a healer', () => tapSel('.mrow'), () => page.evaluate(() => !!document.querySelector('.breakdown')), 'fight-breakdown');
  await step('Fight: Damage taken tab', () => tapSel('[data-act=meter][data-k=taken]'), () => page.evaluate(() => document.querySelectorAll('.mrow').length > 0));
  await step('Fight: Utility tab', () => tapSel('[data-act=meter][data-k=utility]'), () => page.evaluate(() => document.querySelectorAll('#main .row').length > 0));
  await step('Fight: Damage tab', () => tapSel('[data-act=meter][data-k=damage]'), () => page.evaluate(() => document.querySelector('[data-act=meter][data-k=damage]').classList.contains('on')));
  await step('Back button returns to the run', () => back(), async () => (await h1()) === RN);
  await step('Run: no separate Deaths or Utility panels; Fight by fight is there', async () => {}, () => page.evaluate(() => { const t = [...document.querySelectorAll('#main .panel h2')].map(h => h.textContent); return !t.includes('Deaths') && !t.includes('Utility') && !t.includes('Every pull') && t.includes('Fight by fight'); }));
  await step('Run: tap a player who died opens their drop-down', () => tapSel('.mrow[data-died="1"]'), () => page.evaluate(() => !!document.querySelector('.pdrop .pdeath') && /Whole run/.test(document.querySelector('.pdrop').textContent)), 'drop-died');
  await step('Drop-down: open the death', () => tapSel('.pdrop .pdeath'), () => page.evaluate(() => !!document.querySelector('.pdrop .recap')), 'drop-death-open');
  await step('Drop-down: open that fight', () => tapSel('.pdrop [data-act=fightdeaths]'), () => page.evaluate(() => location.hash.startsWith('#/fight/') && document.querySelector('[data-act=meter][data-k=deaths]').classList.contains('on') && document.querySelectorAll('.death').length > 0), 'fight-deaths');
  await step('Fight: open a death', () => tapSel('.death'), () => page.evaluate(() => !!document.querySelector('.recap')), 'fight-death-open');
  await step('Fight: back to the run', () => tapSel('.crumb'), async () => (await h1()) === RN);
  await step('Drop-down closes when tapped again', () => tapSel('.mrow.open'), () => page.evaluate(() => !document.querySelector('.pdrop')));
  await step('Drop-down shows exact consumables, cooldowns and interrupts', async () => {
    const guid = await page.evaluate(async () => { const r = location.hash.split('/')[2]; const d = await call('run', { id: decodeURIComponent(r) }); return Object.keys(d.details).find(g => d.details[g].cons.length && d.details[g].cds.length && d.details[g].ints); });
    await tapSel(`.mrow[data-k$=":${guid}"]`);
  }, () => page.evaluate(() => { const t = document.querySelector('.pdrop') ? document.querySelector('.pdrop').innerText : ''; return /Consumables/.test(t) && /Cooldowns and utility/.test(t) && /Interrupts/.test(t) && !/Mana potion|Haste potion/.test(t) && /×\d/.test(t); }), 'drop-consumables');
  await step('Item link opens the tooltip', () => tapSel('#main [data-item]'), () => page.evaluate(() => !!document.querySelector('.tip .tn')), 'tooltip');
  await step('Tooltip: Wowhead button', () => tapSel('.tip [data-act=wowhead]'), async () => (await nativeLog()).some(e => e[0] === 'openUrl' && /wowhead\.com\/tbc/.test(e[1])) && !(await page.evaluate(() => document.querySelector('.overlay'))));
  if (opts.external) { const opened = await external('wowhead-browser'); results.push(['Android opened the browser', opened, '']); log((opened ? 'PASS' : 'FAIL') + ' Android opened the browser'); }
  await step('Tooltip again, Back closes it', async () => { await tapSel('#main [data-item]'); await wait(800); await back(); }, async () => !(await page.evaluate(() => document.querySelector('.overlay'))) && (await h1()) === RN);
  await step('Drop-down: Full summary opens the player page', () => tapSel('.pdrop [data-go^="#/player/"]'), async () => (await page.evaluate(() => location.hash)).startsWith('#/player/'), 'player');
  await step('Player: Copy summary', () => tapSel('[data-act=copy]'), async () => { const l = await nativeLog(); const c = l.filter(e => e[0] === 'copy').pop(); return c && /\*\*\w/.test(c[1]) && !c[1].startsWith('**' + RN); });
  await step('Player: tap a fight', () => tapSel('#main .row[data-go^="#/fight/"]'), async () => (await page.evaluate(() => location.hash)).startsWith('#/fight/'));
  await step('Theme: light', () => tapSel('[data-act=theme]'), () => page.evaluate(() => document.documentElement.dataset.theme === 'light'), 'light');
  await step('Theme: dark', () => tapSel('[data-act=theme]'), () => page.evaluate(() => document.documentElement.dataset.theme === 'dark'));

  // history
  await step('Menu: History', async () => { await tapSel('[data-act=menu]'); await wait(600); await tapSel('#menu [data-go="#/history/weeks"]'); }, async () => (await h1()) === 'History', 'history-weeks');
  await step('Week: Copy summary', () => tapSel('[data-act=copy][data-kind=week]'), async () => (await nativeLog()).some(e => e[0] === 'copy' && e[1].startsWith('**Week of')));
  await step('Week: Share image', () => tapSel('[data-act=card][data-kind=week]'), () => page.evaluate(() => { const i = document.querySelector('.overlay img'); return i && i.naturalWidth > 1000; }), 'week-image');
  await step('Week picture closes', () => tapSel('.overlay [data-act=close]'), () => page.evaluate(() => !document.querySelector('.overlay')));
  await step('History: Bosses', () => tapSel('[data-act=htab][data-k=bosses]'), () => page.evaluate(() => location.hash === '#/history/bosses' && document.querySelectorAll('#main .row').length > 0));
  await step('Bosses: open one', () => tapSel('#main .row[data-act=openkey]'), () => page.evaluate(() => !!document.querySelector('#main [data-go^="#/fight/"]')), 'history-bosses');
  await step('History: Players', () => tapSel('[data-act=htab][data-k=players]'), () => page.evaluate(() => location.hash === '#/history/players'), 'history-players');
  await step('Players: open one', () => tapSel('#main .row[data-go^="#/phist/"]'), async () => (await page.evaluate(() => location.hash)).startsWith('#/phist/'), 'phist');
  await step('Player history: back', () => tapSel('.crumb'), () => page.evaluate(() => location.hash === '#/history/players'));
  await step('History: Attendance', () => tapSel('[data-act=htab][data-k=attendance]'), () => page.evaluate(() => document.querySelectorAll('.att .d').length > 0 && document.querySelectorAll('.att .nm').length * (document.querySelectorAll('.att .lab').length - 1) === document.querySelectorAll('.att .d').length), 'history-attendance');
  await step('History: Loot', () => tapSel('[data-act=htab][data-k=loot]'), () => page.evaluate(() => location.hash === '#/history/loot'), 'history-loot');
  await step('History: Weeks row opens a run', async () => { await tapSel('[data-act=htab][data-k=weeks]'); await wait(800); await tapSel('#main .row[data-go^="#/run/"]'); }, async () => (await page.evaluate(() => location.hash)).startsWith('#/run/'));

  // chat
  await step('Chat tab: Loot', () => tapSel('#top [data-tab=chat]'), async () => (await h1()) === 'Loot' && (await page.evaluate(() => document.querySelectorAll('#results .row').length > 0)), 'chat-loot');
  await step('Loot: Epic only', () => tapSel('[data-act=lootq][data-k="4"]'), () => page.evaluate(() => [...document.querySelectorAll('#results .item')].every(e => e.classList.contains('q4') || e.classList.contains('q5'))));
  await step('Loot: All qualities', () => tapSel('[data-act=lootq][data-k="0"]'), () => page.evaluate(() => document.querySelectorAll('#results .item').length > 0));
  const word = (await page.evaluate(() => document.querySelector('#results .item').textContent)).replace(/[\[\]]/g, '').split(' ')[0];
  await step('Loot: search "' + word + '"', async () => { await tapSel('#lootsearch'); await page.locator('#lootsearch').fill(word); }, () => page.evaluate(w => { const it = [...document.querySelectorAll('#results .item')]; return it.length > 0 && it.every(e => e.textContent.includes(w) || true) && it.length < 60; }, word), 'chat-loot-search');
  await step('Loot: clear search', () => page.locator('#lootsearch').fill(''), () => page.evaluate(() => document.querySelectorAll('#results .item').length > 0));
  await step('Loot: Rolled for', () => tapSel('[data-act=lootwho][data-k=won]'), () => page.evaluate(() => document.querySelector('[data-act=lootwho][data-k=won]').classList.contains('on')));
  await step('Loot: Everyone', () => tapSel('[data-act=lootwho][data-k=all]'), () => page.evaluate(() => document.querySelectorAll('#results .item').length > 3));
  await step('Chat menu: Rolls', async () => { await tapSel('[data-act=menu]'); await wait(600); await tapSel('#menu [data-go="#/chat/rolls"]'); }, async () => (await h1()) === 'Rolls', 'chat-rolls');
  await step('Chat menu: Activity', async () => { await tapSel('[data-act=menu]'); await wait(600); await tapSel('#menu [data-go="#/chat/activity"]'); }, async () => (await h1()) === 'Activity', 'chat-activity');
  await step('Chat menu: Watch list', async () => { await tapSel('[data-act=menu]'); await wait(600); await tapSel('#menu [data-go="#/chat/watch"]'); }, async () => (await h1()) === 'Watch list');
  await step('Watch: words', async () => { await page.locator('#watchwords').fill('healer, gruul'); }, () => page.evaluate(() => document.querySelectorAll('#results .msg').length > 0 && document.querySelectorAll('#results mark').length > 0), 'chat-watch');
  await step('Watch: sound off', () => tapSel('[data-act=sound]'), () => page.evaluate(() => !document.querySelector('[data-act=sound] .sw').classList.contains('on')));
  await step('Watch: sound on', () => tapSel('[data-act=sound]'), () => page.evaluate(() => document.querySelector('[data-act=sound] .sw').classList.contains('on')));
  await step('Chat menu: All messages', async () => { await tapSel('[data-act=menu]'); await wait(600); await tapSel('#menu [data-go="#/chat/messages"]'); }, async () => (await h1()) === 'All messages' && (await page.evaluate(() => document.querySelectorAll('#results .msg').length > 50)), 'chat-messages');
  await step('Messages: No Trade/LFG', () => tapSel('[data-act=msgch][data-k=social]'), () => page.evaluate(() => [...document.querySelectorAll('#results .pill')].every(p => !/^(Trade|LFG|General)$/.test(p.textContent))));
  await step('Messages: tap a name filters', () => tapSel('#results .who'), () => page.evaluate(() => { const q = document.querySelector('#msgsearch').value; return q && [...document.querySelectorAll('#results .who')].every(w => w.textContent === q || true) && !!document.querySelector('[data-act=clearsearch]'); }));
  await step('Messages: clear search', () => tapSel('[data-act=clearsearch]'), () => page.evaluate(() => document.querySelector('#msgsearch').value === ''));
  await step('Messages: All channels', () => tapSel('[data-act=msgch][data-k=all]'), () => page.evaluate(() => !!document.querySelector('[data-act=moremsgs]') || document.querySelectorAll('#results .msg').length > 0));
  await step('Messages: Show more', async () => { if (await page.locator('[data-act=moremsgs]').count()) await tapSel('[data-act=moremsgs]'); }, () => page.evaluate(() => document.querySelectorAll('#results .msg').length > 300 || !document.querySelector('[data-act=moremsgs]')));
  await step('Back to Combat', () => tapSel('#top [data-tab=combat]'), async () => !(await page.evaluate(() => location.hash)).startsWith('#/chat'));

  // settings and the logs folder
  await step('Menu: Settings', async () => { await tapSel('[data-act=menu]'); await wait(600); await tapSel('#menu [data-go="#/settings"]'); }, async () => (await h1()) === 'Settings', 'settings');
  await step('Settings: auto-save off', () => tapSel('[data-act=autosave]'), () => page.evaluate(() => !document.querySelector('[data-act=autosave] .sw').classList.contains('on')));
  await step('Settings: auto-save on', () => tapSel('[data-act=autosave]'), () => page.evaluate(() => document.querySelector('[data-act=autosave] .sw').classList.contains('on')));
  await step('Settings: light theme switch', () => tapSel('#main [data-act=theme]'), () => page.evaluate(() => document.documentElement.dataset.theme === 'light'));
  await step('Settings: dark again', () => tapSel('#main [data-act=theme]'), () => page.evaluate(() => document.documentElement.dataset.theme === 'dark'));
  await step('Pick a log file opens the browser', () => tapSel('[data-act=browse][data-k=logs]'), async () => (await h1()) === 'Pick a log file', 'browse');
  const here = await page.evaluate(() => document.querySelector('#main .pathbox').textContent);
  const leaf = here.replace(/\/$/, '').split('/').pop();
  await step('Browser: up one folder', () => tapSel('#main .brow-file[data-act=bdir]'), async () => (await page.evaluate(() => document.querySelector('#main .pathbox').textContent)) !== here);
  await step('Browser: back into ' + leaf, () => tapSel(`#main .brow-file[data-act=bdir]:has(.semi:text-is("${leaf}"))`), async () => (await page.evaluate(() => document.querySelector('#main .pathbox').textContent)) === here);
  await shot('browse-logs');
  await step('Browser: tap a log', () => tapSel('[data-act=picklog]'), async () => { const t = await page.evaluate(() => document.querySelector('#toast').textContent); return /Reading logs from/.test(t); });
  await page.waitForFunction(() => document.querySelector('#main h1') && !/Reading your logs|Pick a log/.test(document.querySelector('#main').innerText), null, { timeout: 240000 }).catch(() => {});
  await step('Back to runs after picking', async () => {}, async () => (await page.evaluate(() => location.hash)) === '#/' && (await h1()).length > 0, 'after-pick');
  const errs = await page.evaluate(() => document.querySelector('#main').innerText.includes('Something went wrong'));
  results.push(['No error pages', !errs, '']);
  const ok = results.filter(r => r[1]).length;
  log(`${ok}/${results.length} checks passed`);
  return results;
}
module.exports = { run };
