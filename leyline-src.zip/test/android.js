// Drives the installed app on an Android emulator: real touches (adb input), the real Back button, device screenshots.
const { _android } = require('playwright');
const fs = require('fs');
const path = require('path');
const { run } = require('./flow');
const SHOTS = path.join(__dirname, 'shots');
fs.mkdirSync(SHOTS, { recursive: true });
const PKG = 'app.leyline';
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  const mode = process.argv[2] || 'flow';
  const [device] = await _android.devices();
  console.log('device', device.model(), device.serial());
  const shot = async name => { await sleep(400); await device.screenshot({ path: path.join(SHOTS, name + '.png') }); };
  let webview;
  try {
    webview = await device.webView({ pkg: PKG }, { timeout: 120000 });
  } catch (e) {   // the app's screen never showed up: keep a picture of what was there instead
    await shot(mode + '-no-webview');
    console.log((await device.shell('dumpsys activity activities | grep -E "mResumedActivity|topResumedActivity"')).toString());
    throw e;
  }
  const page = await webview.page();
  page.on('console', m => console.log('  [page]', m.type(), m.text()));
  page.on('pageerror', e => console.log('  [page error]', String(e)));

  // where a CSS pixel on the page lands on the screen: one calibration touch on a throw-away layer
  const size = (await device.shell('wm size')).toString().match(/(\d+)x(\d+)/);
  const W = +size[1], H = +size[2];
  await page.waitForFunction(() => !!document.body, null, { timeout: 120000 });
  await page.evaluate(() => {
    const d = document.createElement('div');
    d.id = '__cal'; d.style.cssText = 'position:fixed;inset:0;z-index:99999;background:transparent';
    d.addEventListener('pointerdown', e => { window.__calib = [e.clientX, e.clientY]; e.stopPropagation(); e.preventDefault(); }, true);
    document.body.appendChild(d);
  });
  await device.input.tap({ x: Math.round(W / 2), y: Math.round(H / 2) });
  await page.waitForFunction(() => !!window.__calib, null, { timeout: 10000 });
  const [cx, cy] = await page.evaluate(() => window.__calib);
  const dpr = await page.evaluate(() => { document.getElementById('__cal').remove(); return window.devicePixelRatio; });
  const offX = W / 2 - cx * dpr, offY = H / 2 - cy * dpr;
  console.log(`screen ${W}x${H}, pixel ratio ${dpr}, page starts at y=${Math.round(offY)}`);

  const tap = async el => {
    let box = await el.boundingBox();
    const vh = await page.evaluate(() => window.innerHeight);
    if (box && (box.y < 70 || box.y + box.height > vh - 90)) {   // keep clear of the top bar and the toast
      await page.evaluate(dy => window.scrollBy(0, dy), box.y - vh / 2);
      await sleep(250);
      box = await el.boundingBox();
    }
    if (!box) throw new Error('not on screen');
    await device.input.tap({ x: Math.round(offX + (box.x + box.width / 2) * dpr), y: Math.round(offY + (box.y + Math.min(box.height / 2, 18)) * dpr) });
  };
  const back = async () => { await device.shell('input keyevent 4'); await sleep(700); };
  const inFront = async () => /app\.leyline/.test((await device.shell('dumpsys activity activities | grep -E "mResumedActivity|topResumedActivity"')).toString());
  const external = async () => {   // after the share sheet or a browser: come back to the app
    await sleep(2500);
    for (let i = 0; i < 4 && !(await inFront()); i++) await back();
    if (!(await inFront())) { await device.shell(`am start -n ${PKG}/.MainActivity`); await sleep(1500); }
  };

  if (mode === 'permission') {
    await page.waitForSelector('[data-act=askstorage]', { timeout: 120000 });
    await shot('01-permission');
    await tap(page.locator('[data-act=askstorage]'));
    await sleep(3000);
    await shot('02-android-allow-screen');
    console.log('in front after Allow:', await inFront());
    process.exit(0);
  }
  const results = await run(page, shot, { tap, back, external });
  fs.writeFileSync(path.join(__dirname, 'results.json'), JSON.stringify(results, null, 1));
  const ok = results.filter(r => r[1]).length;
  console.log(`RESULT ${ok}/${results.length}`);
  process.exit(ok === results.length ? 0 : 1);
})().catch(e => { console.error(e); process.exit(2); });
