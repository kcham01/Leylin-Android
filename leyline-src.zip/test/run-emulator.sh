#!/bin/bash
# Runs on the GitHub emulator: install, first start, storage permission, then every screen and control.
cd "$(dirname "$0")/.."
mkdir -p test/shots
exec > >(tee test/emulator.log) 2>&1
set -x
PKG=app.leyline
mkdir -p test/shots
# a freshly booted emulator is slow: let it settle, and don't let "isn't responding" pop-ups cover the app
adb wait-for-device
until [ "$(adb shell getprop sys.boot_completed | tr -d '\r')" = "1" ]; do sleep 2; done
adb shell settings put global hide_error_dialogs 1
sleep 20
adb logcat -c
adb install -r out/Leyline.apk || exit 1
adb shell mkdir -p /sdcard/Leyline/Logs
adb push test/logs/. /sdcard/Leyline/Logs/
adb shell ls -la /sdcard/Leyline/Logs
# 1) first start: the app asks for storage access
adb shell am start -W -n $PKG/.MainActivity --ez devtools true
sleep 15
node test/android.js permission 2>&1 | tee test/permission.log
# 2) what you do on Android's screen: switch on "Allow access to manage all files", then go back
adb shell appops set --uid $PKG MANAGE_EXTERNAL_STORAGE allow
adb shell input keyevent 4
sleep 2
# back in the app (if Back went past it, open it again: same app, same screen)
adb shell dumpsys activity activities | grep -E "mResumedActivity|topResumedActivity"
adb shell am start -W -n $PKG/.MainActivity --ez devtools true
sleep 4
adb exec-out screencap -p > test/shots/03-after-allow.png
# 3) every screen and control
node test/android.js flow 2>&1 | tee test/flow.log
echo "flow exit ${PIPESTATUS[0]}" | tee -a test/flow.log
adb logcat -d -v time -s Leyline:* python.stdout:* python.stderr:* AndroidRuntime:* chromium:* > test/logcat.log
adb shell ls -laR "/sdcard/Documents/Leyline Reports" > test/reports.txt 2>&1
exit 0
