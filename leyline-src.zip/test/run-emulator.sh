#!/bin/bash
# Runs on the GitHub emulator: install, first start, storage permission, then every screen and control.
set -x
cd "$(dirname "$0")/.."
PKG=app.leyline
mkdir -p test/shots
adb logcat -c
adb install -r out/Leyline.apk || exit 1
adb shell mkdir -p /sdcard/Leyline/Logs
adb push test/logs/. /sdcard/Leyline/Logs/
adb shell ls -la /sdcard/Leyline/Logs
# 1) first start: the app asks for storage access
adb shell am start -W -n $PKG/.MainActivity --ez devtools true
sleep 15
node test/android.js permission 2>&1 | tee test/permission.log
# 2) what you do on Android's screen: switch on "Allow access to manage all files", then go back
adb shell appops set --uid $PKG MANAGE_EXTERNAL_STORAGE allow
adb shell input keyevent 4
sleep 3
adb exec-out screencap -p > test/shots/03-after-allow.png
# 3) every screen and control
node test/android.js flow 2>&1 | tee test/flow.log
echo "flow exit ${PIPESTATUS[0]}" | tee -a test/flow.log
adb logcat -d -v time -s Leyline:* python.stdout:* python.stderr:* AndroidRuntime:* chromium:* > test/logcat.log
adb shell ls -laR "/sdcard/Documents/Leyline Reports" > test/reports.txt 2>&1
exit 0
