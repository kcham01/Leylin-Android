#!/bin/bash
# Builds the APK (run by .github/workflows/build.yml after leyline-src.zip is unpacked)
set -e
mkdir -p test
exec > >(tee test/build.log) 2>&1   # saved with the results, so a failed build can be read from the repo
python test/engine_test.py
gradle --no-daemon --stacktrace assembleRelease
mkdir -p out
cp app/build/outputs/apk/release/app-release.apk out/Leyline.apk
ls -la out
