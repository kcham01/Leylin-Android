#!/bin/bash
# Builds the APK (run by .github/workflows/build.yml after leyline-src.zip is unpacked)
set -e
python test/engine_test.py
gradle --no-daemon --stacktrace assembleRelease
mkdir -p out
cp app/build/outputs/apk/release/app-release.apk out/Leyline.apk
ls -la out
